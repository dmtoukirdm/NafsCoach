
// ══════════════════════════════════════════════════════════
// ✦ CUSTOM GOALS SYSTEM — Full Implementation
// ══════════════════════════════════════════════════════════

const GOALS_KEY = 'mrd_custom_goals_v2';
const GOALS_META_KEY = 'mrd_goals_meta';

// ── Goal Templates (what the survey creates) ──
const GOAL_TYPES = {
  prayers:      { icon:'🕌', label:'Daily Prayers',      unit:'prayers',  max:5,   default:5,   period:'daily',   color:'var(--gold)' },
  quran:        { icon:'📖', label:'Quran Pages',          unit:'pages',    max:20,  default:2,   period:'daily',   color:'var(--teal)' },
  dhikr:        { icon:'📿', label:'Dhikr Count',          unit:'counts',   max:500, default:99,  period:'daily',   color:'var(--purple)' },
  sunnah:       { icon:'☀️', label:'Sunnah Habits',        unit:'habits',   max:8,   default:4,   period:'daily',   color:'var(--amber)' },
  fasting:      { icon:'🤍', label:'Fasting Days',         unit:'days',     max:30,  default:4,   period:'weekly',  color:'var(--rose)' },
  tahajjud:     { icon:'🌙', label:'Tahajjud Nights',      unit:'nights',   max:7,   default:3,   period:'weekly',  color:'var(--purple)' },
};

// ── Data Layer ──
function loadGoals() {
  try {
    const raw = JSON.parse(localStorage.getItem(GOALS_KEY) || '[]');
    // Migrate: remove goal types that no longer exist
    const valid = raw.filter(g => g && g.type && GOAL_TYPES[g.type]);
    if (valid.length !== raw.length) {
      try { localStorage.setItem(GOALS_KEY, JSON.stringify(valid)); } catch {}
    }
    return valid;
  } catch { return []; }
}
function saveGoals(list) {
  try { localStorage.setItem(GOALS_KEY, JSON.stringify(list)); } catch {}
}
function loadGoalsMeta() {
  try { return JSON.parse(localStorage.getItem(GOALS_META_KEY) || '{}'); } catch { return {}; }
}
function saveGoalsMeta(m) {
  try { localStorage.setItem(GOALS_META_KEY, JSON.stringify(m)); } catch {}
}

let _goals = loadGoals();

// ── Get current value for a goal type ──
function getGoalCurrentValue(type) {
  switch (type) {
    case 'prayers':    return Object.values(typeof prayerDone!=='undefined'?prayerDone:{}).filter(Boolean).length;
    case 'quran':      return typeof quranData!=='undefined' ? quranData.pages : 0;
    case 'dhikr':      return typeof dhikrCounts!=='undefined' ? dhikrCounts.reduce((a,b)=>a+b,0) : 0;
    case 'sunnah':     return typeof sunnahDone!=='undefined' ? sunnahDone.filter(Boolean).length : 0;
    case 'fasting': {
      // Count fasting days this week
      let cnt = 0;
      for (let i=0;i<7;i++) { const d=new Date(now); d.setDate(d.getDate()-i); const k=dateKey(d); if(typeof fastingData!=='undefined'&&fastingData[k]) cnt++; }
      return cnt;
    }
    case 'tahajjud': {
      // Count sunnah[0] (Tahajjud) done days this week
      let cnt = 0;
      for (let i=0;i<7;i++) { const d=new Date(now); d.setDate(d.getDate()-i); const k=dateKey(d); const dd=typeof daily!=='undefined'?daily[k]:null; if(dd&&dd.sunnah&&dd.sunnah[0]) cnt++; }
      return cnt;
    }
    default: return 0;
  }
}

// ── Compute progress percent for a goal ──
function getGoalProgress(goal) {
  const cur = getGoalCurrentValue(goal.type);
  const pct = goal.target > 0 ? Math.min(100, Math.round(cur / goal.target * 100)) : 0;
  return { cur, pct, done: pct >= 100 };
}

// ── Build insight text ──
function buildGoalInsight(goal) {
  const { cur, pct, done } = getGoalProgress(goal);
  const t = GOAL_TYPES[goal.type] || { unit: goal.unit || '' };
  const unit = t.unit || '';
  const remaining = Math.max(0, goal.target - cur);
  if (done) return { text:`✦ Goal complete! Mashallah — ${cur}/${goal.target} ${unit}`, cls:'ins-good' };
  if (pct >= 70) return { text:`Almost there — ${remaining} more ${unit} to reach your goal`, cls:'ins-hi' };
  if (pct >= 30) return { text:`Making progress · ${cur}/${goal.target} ${unit} · Keep going`, cls:'' };
  if (cur === 0) return { text:`Start now — your goal is ${goal.target} ${unit} today`, cls:'ins-warn' };
  return { text:`${remaining} ${unit} remaining · You can do this`, cls:'' };
}

// ── Render Goals Home Nudge ──
function renderGoalsHomeNudge() {
  const el = document.getElementById('goals-home-nudge');
  const rowEl = document.getElementById('ghn-goals-row');
  const titleEl = document.getElementById('ghn-title-text');
  if (!el) return;

  _goals = loadGoals();
  const dailyGoals = _goals.filter(g => g.period === 'daily' || !g.period);

  el.style.display = 'block';

  if (dailyGoals.length === 0) {
    // No goals — show setup prompt
    if (titleEl) titleEl.textContent = 'Build your worship plan';
    if (rowEl) rowEl.innerHTML = `
      <div class="ghn-setup-row">
        <div class="ghn-setup-txt">Set personal goals for prayers, Quran, dhikr & more</div>
        <button class="ghn-setup-btn" onclick="event.stopPropagation();openGoalSurvey()">Set Goals ✦</button>
      </div>`;
    // Show dot on Goals nav + clock chip
    const dot = document.getElementById('goals-nav-dot');
    if (dot) dot.style.display = 'block';
    const chipDot = document.getElementById('clock-goals-chip-dot');
    if (chipDot) chipDot.style.display = 'inline-block';
    return;
  }

  // Has goals — show progress pills
  const dot = document.getElementById('goals-nav-dot');
  if (dot) dot.style.display = 'none';
  const chipDot2 = document.getElementById('clock-goals-chip-dot');
  if (chipDot2) chipDot2.style.display = 'none';

  const doneCount = dailyGoals.filter(g => getGoalProgress(g).done).length;
  if (titleEl) titleEl.textContent = doneCount === dailyGoals.length
    ? `✦ All ${dailyGoals.length} goals complete · Mashallah!`
    : `${doneCount}/${dailyGoals.length} goals complete today`;

  if (rowEl) {
    const pills = dailyGoals.slice(0,4).map(g => {
      const { cur, pct, done } = getGoalProgress(g);
      const t = GOAL_TYPES[g.type] || {};
      return `<div class="ghn-goal-pill ${done?'gp-done':''}">
        <span class="gp-icon">${t.icon||'🎯'}</span>
        <span>${cur}/${g.target}</span>
        <div class="gp-bar"><div class="gp-fill" style="width:${pct}%"></div></div>
      </div>`;
    }).join('');
    rowEl.innerHTML = pills + `<div style="flex:1;min-width:6px"></div>`;
  }
}

// ── Open Goals Page ──
function openGoalsPage() {
  openFeatPage('page-goals');
  renderGoalsPage();
}

// ── Render Goals Page ──
let _goalPeriodFilter = 'daily';
let _goalsViewMode = 'card'; // 'card' | 'list'

function toggleGoalsView() {
  _goalsViewMode = _goalsViewMode === 'card' ? 'list' : 'card';
  const btn = document.getElementById('goals-view-toggle');
  if (btn) btn.textContent = _goalsViewMode === 'card' ? '⊞' : '☰';
  renderGoalsPage();
}

function toggleGoalActive(id, e) {
  e && e.stopPropagation();
  _goals = loadGoals();
  const idx = _goals.findIndex(x => x.id === id);
  if (idx < 0) return;
  _goals[idx].inactive = !_goals[idx].inactive;
  saveGoals(_goals);
  renderGoalsPage();
  renderGoalsHomeNudge();
}

function setGoalPeriod(period, btn) {
  _goalPeriodFilter = period;
  document.querySelectorAll('.gps-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  renderGoalsPage();
}

function renderGoalsPage() {
  const body = document.getElementById('goals-page-body');
  if (!body) return;
  _goals = loadGoals();

  // Save today's snapshot whenever page opens
  saveGoalSnapshot();

  let filtered = _goalPeriodFilter === 'all' ? _goals : _goals.filter(g => (g.period||'daily') === _goalPeriodFilter);

  if (filtered.length === 0) {
    body.innerHTML = `
      <div class="goals-empty">
        <div class="goals-empty-icon">🎯</div>
        <div class="goals-empty-title">No ${_goalPeriodFilter === 'all' ? '' : _goalPeriodFilter + ' '}goals yet</div>
        <div class="goals-empty-sub">Build a personal worship plan.<br>Track prayers, Quran, dhikr, fasting & more.</div>
        <button class="goals-empty-btn" onclick="openGoalSurvey()">✦ Set Up Goals</button>
      </div>`;
    return;
  }

  // Summary row
  const totalDone = filtered.filter(g => getGoalProgress(g).done).length;
  const avgPct = filtered.length > 0 ? Math.round(filtered.reduce((s,g)=>s+getGoalProgress(g).pct,0)/filtered.length) : 0;
  const summaryHtml = `
    <div style="padding:14px 14px 6px">
      <div style="display:flex;gap:8px">
        <div style="flex:1;border-radius:18px;padding:14px 10px;background:rgba(var(--green-rgb),.07);border:1px solid rgba(var(--green-rgb),.15);text-align:center">
          <div style="font-family:var(--font-display),'Playfair Display',serif;font-size:1.875rem;font-weight:300;color:var(--green);line-height:1">${totalDone}</div>
          <div style="font-size:0.4rem;letter-spacing:.14em;text-transform:uppercase;color:var(--t3);margin-top:5px">Complete</div>
        </div>
        <div style="flex:1;border-radius:18px;padding:14px 10px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.07);text-align:center">
          <div style="font-family:var(--font-display),'Playfair Display',serif;font-size:1.875rem;font-weight:300;color:var(--text);line-height:1">${filtered.length - totalDone}</div>
          <div style="font-size:0.4rem;letter-spacing:.14em;text-transform:uppercase;color:var(--t3);margin-top:5px">In Progress</div>
        </div>
        <div style="flex:1;border-radius:18px;padding:14px 10px;background:rgba(var(--accent-rgb),.07);border:1px solid rgba(var(--accent-rgb),.15);text-align:center">
          <div style="font-family:var(--font-display),'Playfair Display',serif;font-size:1.875rem;font-weight:300;color:var(--gold);line-height:1">${avgPct}%</div>
          <div style="font-size:0.4rem;letter-spacing:.14em;text-transform:uppercase;color:var(--t3);margin-top:5px">Avg</div>
        </div>
      </div>
    </div>`;

  // Progress chart section
  const chartHtml = buildGoalsChartSection(_goals);

  // Goal cards or list
  const activeFiltered = filtered.filter(g => !g.inactive);
  const inactiveFiltered = filtered.filter(g => g.inactive);

  let contentHtml;
  if (_goalsViewMode === 'list') {
    const allGoals = _goals;
    contentHtml = `<div class="goal-list-view">` +
      (allGoals.length > 0
        ? allGoals.map(g => renderGoalListRow(g)).join('')
        : `<div style="text-align:center;padding:40px 20px;color:var(--t3);font-size:.75rem">No goals set yet</div>`)
      + `</div>`;
  } else {
    const activeCards = activeFiltered.map(g => renderGoalCard(g)).join('');
    const inactiveCards = inactiveFiltered.length > 0
      ? `<div style="padding:10px 14px 5px;font-size:.4rem;letter-spacing:.14em;text-transform:uppercase;color:var(--t3);display:flex;align-items:center;gap:6px"><span style="flex:1;height:1px;background:rgba(255,255,255,.06)"></span>Paused<span style="flex:1;height:1px;background:rgba(255,255,255,.06)"></span></div>` +
        inactiveFiltered.map(g => renderGoalCard(g)).join('')
      : '';
    contentHtml = `<div style="padding:4px 0 2px">${activeCards}${inactiveCards}</div>`;
  }

  // Add goal button
  const addHtml = `
    <div style="padding:6px 14px 24px">
      <button onclick="openGoalSurvey()" style="width:100%;padding:14px;border-radius:18px;border:1px dashed rgba(var(--accent-rgb),.22);background:rgba(var(--accent-rgb),.04);color:var(--gold);font-family:var(--font-ui),'Manrope',sans-serif;font-size:0.6875rem;font-weight:600;letter-spacing:.08em;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:all .2s;display:flex;align-items:center;justify-content:center;gap:8px">
        <span style="font-size:1rem;line-height:1">+</span> Add New Goal
      </button>
    </div>`;

  body.innerHTML = summaryHtml + chartHtml + contentHtml + addHtml;
}

// ── Goal Snapshot System ──
const GOAL_SNAPSHOT_KEY = 'mrd_goal_snapshots_v1';

function getTodayKey() {
  return new Date().toISOString().slice(0,10);
}

function loadGoalSnapshots() {
  try { return JSON.parse(localStorage.getItem(GOAL_SNAPSHOT_KEY) || '{}'); } catch { return {}; }
}

function saveGoalSnapshot() {
  try {
    const snaps = loadGoalSnapshots();
    const today = getTodayKey();
    const goals = loadGoals();
    if (!goals.length) return;
    // Overall avg pct
    const avgPct = Math.round(goals.reduce((s,g) => s + getGoalProgress(g).pct, 0) / goals.length);
    // Per-goal pct map
    const perGoal = {};
    goals.forEach(g => { perGoal[g.id] = { pct: getGoalProgress(g).pct, label: g.label || g.type }; });
    snaps[today] = { avg: avgPct, goals: perGoal };
    // Keep last 30 days only
    const keys = Object.keys(snaps).sort();
    if (keys.length > 30) keys.slice(0, keys.length - 30).forEach(k => delete snaps[k]);
    localStorage.setItem(GOAL_SNAPSHOT_KEY, JSON.stringify(snaps));
  } catch {}
}

// ── Goals Progress Chart ──
function buildGoalsChartSection(goals) {
  const snaps = loadGoalSnapshots();
  const today = getTodayKey();

  // Build last 7 days list
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    days.push(d.toISOString().slice(0,10));
  }

  const dayLabels = days.map(d => {
    const dt = new Date(d);
    return ['Su','Mo','Tu','We','Th','Fr','Sa'][dt.getDay()];
  });

  // Overall avg line data
  const avgData = days.map(d => snaps[d]?.avg ?? null);

  // Per-goal bars (up to 5 active goals)
  const activeGoals = goals.filter(g => !g.inactive).slice(0, 5);

  // Chart dims
  const W = 320, H = 140, PAD = { t:12, r:10, b:28, l:32 };
  const cW = W - PAD.l - PAD.r;
  const cH = H - PAD.t - PAD.b;
  const barGroupW = cW / 7;
  const barW = activeGoals.length > 0 ? Math.min(14, (barGroupW - 6) / activeGoals.length) : barGroupW - 6;

  const goalColors = ['rgba(209,178,108,.85)','rgba(91,191,181,.8)','rgba(167,131,218,.8)','rgba(240,130,115,.8)','rgba(109,191,137,.8)'];

  // Build bars
  let barsHtml = '';
  days.forEach((d, di) => {
    const x0 = PAD.l + di * barGroupW + barGroupW/2 - (activeGoals.length * (barW + 2)) / 2;
    activeGoals.forEach((g, gi) => {
      const pct = snaps[d]?.goals?.[g.id]?.pct ?? (d === today ? getGoalProgress(g).pct : null);
      if (pct === null) return;
      const barH = Math.max(3, (pct / 100) * cH);
      const x = x0 + gi * (barW + 2);
      const y = PAD.t + cH - barH;
      const col = goalColors[gi % goalColors.length];
      const radius = Math.min(3, barW/2);
      barsHtml += `<rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${barW}" height="${barH.toFixed(1)}" rx="${radius}" fill="${col}" opacity="${pct===0?.25:1}"/>`;
    });
  });

  // Avg line
  let linePoints = '';
  let dotHtml = '';
  const validAvg = avgData.map((v,i) => v !== null ? { x: PAD.l + i * barGroupW + barGroupW/2, y: PAD.t + cH - (v/100)*cH, v } : null);
  const pts = validAvg.filter(Boolean);
  if (pts.length > 1) {
    linePoints = pts.map((p,i) => `${i===0?'M':'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
    barsHtml += `<path d="${linePoints}" fill="none" stroke="rgba(255,255,255,.35)" stroke-width="1.5" stroke-dasharray="3 2" stroke-linecap="round"/>`;
  }
  pts.forEach(p => {
    barsHtml += `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="2.5" fill="rgba(255,255,255,.7)"/>`;
  });

  // Y-axis grid lines
  let gridHtml = '';
  [0,25,50,75,100].forEach(v => {
    const y = PAD.t + cH - (v/100)*cH;
    gridHtml += `<line x1="${PAD.l}" y1="${y.toFixed(1)}" x2="${W-PAD.r}" y2="${y.toFixed(1)}" stroke="rgba(255,255,255,.05)" stroke-width="1"/>`;
    gridHtml += `<text x="${(PAD.l-4).toFixed(1)}" y="${(y+3).toFixed(1)}" text-anchor="end" font-size="6" fill="rgba(255,255,255,.3)" font-family="Manrope,sans-serif">${v}</text>`;
  });

  // X-axis labels
  let xLabels = '';
  dayLabels.forEach((lbl, i) => {
    const x = PAD.l + i * barGroupW + barGroupW/2;
    const isToday = days[i] === today;
    xLabels += `<text x="${x.toFixed(1)}" y="${(H-4).toFixed(1)}" text-anchor="middle" font-size="7.5" fill="${isToday?'rgba(209,178,108,.9)':'rgba(255,255,255,.35)'}" font-family="Manrope,sans-serif" font-weight="${isToday?'700':'400'}">${lbl}</text>`;
  });

  // Legend
  const legendItems = activeGoals.map((g, i) => {
    const t = GOAL_TYPES[g.type] || {};
    const col = goalColors[i % goalColors.length];
    return `<span style="display:inline-flex;align-items:center;gap:4px;margin-right:10px;white-space:nowrap">
      <span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:${col};flex-shrink:0"></span>
      <span style="font-size:.45rem;color:var(--t2);letter-spacing:.04em">${g.label || t.label || g.type}</span>
    </span>`;
  }).join('');

  const hasSomeData = pts.length > 0 || activeGoals.some(g => getGoalProgress(g).pct > 0);

  return `
  <div style="margin:8px 14px 12px;border-radius:20px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.07);padding:16px 14px 12px;overflow:hidden">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
      <div>
        <div style="font-size:.4rem;letter-spacing:.2em;text-transform:uppercase;color:var(--t3);margin-bottom:3px">7-Day Overview</div>
        <div style="font-size:.8125rem;font-weight:600;color:var(--text)">Goal Completion</div>
      </div>
      <div style="text-align:right">
        <div style="font-family:var(--font-display),'Playfair Display',serif;font-size:1.625rem;font-weight:300;color:var(--gold);line-height:1">${Math.round(goals.filter(g=>!g.inactive).reduce((s,g)=>s+getGoalProgress(g).pct,0)/Math.max(1,goals.filter(g=>!g.inactive).length))}%</div>
        <div style="font-size:.4rem;letter-spacing:.1em;text-transform:uppercase;color:var(--t3);margin-top:2px">today avg</div>
      </div>
    </div>
    <svg viewBox="0 0 ${W} ${H}" width="100%" style="overflow:visible;display:block">
      ${gridHtml}
      ${barsHtml}
      ${xLabels}
    </svg>
    ${activeGoals.length > 1 ? `<div style="margin-top:10px;display:flex;flex-wrap:wrap;gap:4px;align-items:center">${legendItems}<span style="display:inline-flex;align-items:center;gap:4px;margin-left:4px"><span style="display:inline-block;width:14px;height:1px;border-top:1.5px dashed rgba(255,255,255,.3)"></span><span style="font-size:.4rem;color:var(--t3);letter-spacing:.06em">avg</span></span></div>` : ''}
  </div>`;
}

function renderGoalListRow(g) {
  const t = GOAL_TYPES[g.type] || { icon:'🎯', label:g.label||g.type, unit:'', color:'var(--gold)' };
  const { cur, pct, done } = getGoalProgress(g);
  const isActive = !g.inactive;

  let deadlineTxt = 'Ongoing';
  if (g.deadline) {
    const dl = new Date(g.deadline); const now = new Date();
    const diffDays = Math.ceil((dl - now) / 86400000);
    deadlineTxt = diffDays < 0 ? 'Expired' : (diffDays === 0 ? 'Last day!' : `${diffDays}d left`);
  }

  const salahTxt = (g.type === 'prayers' && g.salahTypes && g.salahTypes.length < 5)
    ? ` · ${g.salahTypes.join(', ')}` : '';

  return `
  <div class="goal-list-row ${g.inactive ? 'inactive-goal' : ''}" onclick="openGoalEdit('${g.id}')">
    <div class="goal-list-icon">${t.icon}</div>
    <div class="goal-list-body">
      <div class="goal-list-name">${g.label || t.label}${salahTxt}</div>
      <div class="goal-list-meta">${cur}/${g.target} ${t.unit} · ${deadlineTxt}</div>
      <div class="goal-list-bar"><div class="goal-list-bar-fill" style="width:${pct}%"></div></div>
    </div>
    <div class="goal-list-pct" style="color:${done?'var(--green)':t.color}">${done?'✓':pct+'%'}</div>
    <button class="goal-active-toggle ${isActive?'on':''}" onclick="toggleGoalActive('${g.id}',event)" title="${isActive?'Pause goal':'Activate goal'}">
      ${isActive ? '●' : '○'}
    </button>
  </div>`;
}

function renderGoalCard(g) {
  const t = GOAL_TYPES[g.type] || { icon:'🎯', label:g.label||g.type, unit:'', color:'var(--gold)' };
  const { cur, pct, done } = getGoalProgress(g);
  const ins = buildGoalInsight(g);
  const periodLabel = { daily:'Daily', weekly:'Weekly', monthly:'Monthly' }[g.period||'daily'] || 'Daily';
  const badgeCls = done ? 'done' : (pct < 30 && cur > 0 ? 'warn' : '');
  const badgeTxt = done ? '✓ Done' : `${pct}%`;

  // Accent color from goal type
  const accentMap = {
    prayers: 'rgba(209,178,108,1)',
    quran:   'rgba(91,191,181,1)',
    dhikr:   'rgba(167,131,218,1)',
    sunnah:  'rgba(240,180,90,1)',
    fasting: 'rgba(240,130,115,1)',
    tahajjud:'rgba(130,140,220,1)',
  };
  const accentColor = accentMap[g.type] || 'rgba(209,178,108,1)';

  // Deadline display
  let deadlineTxt = '';
  let deadlineColor = 'var(--t3)';
  if (g.deadline) {
    const diffDays = Math.ceil((new Date(g.deadline) - new Date()) / 86400000);
    if (diffDays < 0) { deadlineTxt = 'Expired'; deadlineColor = 'var(--rose)'; }
    else if (diffDays === 0) { deadlineTxt = 'Last day'; deadlineColor = 'var(--amber)'; }
    else if (diffDays <= 3) { deadlineTxt = `${diffDays}d left`; deadlineColor = 'var(--amber)'; }
    else { deadlineTxt = `${diffDays}d left`; }
  } else {
    deadlineTxt = 'Ongoing';
  }

  // Salah types chips
  let salahHtml = '';
  if (g.type === 'prayers' && g.salahTypes && g.salahTypes.length > 0 && g.salahTypes.length < 5) {
    salahHtml = `<div style="margin-top:7px;display:flex;gap:4px;flex-wrap:wrap">` +
      g.salahTypes.map(s => `<span style="font-size:.38rem;padding:2px 7px;border-radius:99px;background:rgba(var(--accent-rgb),.1);border:1px solid rgba(var(--accent-rgb),.2);color:var(--gold);letter-spacing:.05em">${s}</span>`).join('') +
      `</div>`;
  }

  return `
  <div class="goal-card ${g.inactive?'':''}${done?' gc-done':''}" onclick="openGoalEdit('${g.id}')" style="${g.inactive?'opacity:.42':''}; --gc-accent:${accentColor}">
    <div class="goal-card-inner">
      <div class="gc-top">
        <div class="gc-left">
          <div class="gc-label">
            <span>${t.icon}</span>
            <span>${periodLabel} Goal</span>
            <span style="margin-left:4px;color:${deadlineColor}">· ${deadlineTxt}</span>
          </div>
          <div class="gc-name">${g.label || t.label}</div>
          ${salahHtml}
        </div>
        <div style="display:flex;align-items:center;gap:6px;margin-top:2px">
          <button class="goal-active-toggle ${g.inactive?'':'on'}" onclick="toggleGoalActive('${g.id}',event)" title="${g.inactive?'Activate':'Pause'}">
            ${g.inactive?'○':'●'}
          </button>
          <div class="gc-badge ${badgeCls}">${badgeTxt}</div>
        </div>
      </div>
      <div class="gc-progress-row">
        <div class="gc-pct-wrap">
          <div class="gc-pct ${done?'done':''}">${done?'✓':pct+'%'}</div>
          <div class="gc-pct-sub">${done?'complete':'progress'}</div>
        </div>
        <div class="gc-bar-col">
          <div class="gc-bar-wrap">
            <div class="gc-bar-fill ${done?'done':''}" style="width:${pct}%;${!done?'background:linear-gradient(90deg,'+accentColor.replace('1)','0.55)')+','+accentColor+')':''}"></div>
          </div>
          <div class="gc-counts">${cur} / ${g.target} ${t.unit}</div>
        </div>
      </div>
      <div class="gc-insight"><span class="${ins.cls}">${ins.text}</span></div>
    </div>
  </div>`;
}

// ── Goal Edit Sheet ──
let _editingGoalId = null;
window._editingGoalId = null;

function openGoalEdit(id) {
  _goals = loadGoals();
  const g = _goals.find(x => x.id === id);
  if (!g) return;
  _editingGoalId = id;
  window._editingGoalId = id;
  const t = GOAL_TYPES[g.type] || { icon:'🎯', label:g.type, unit:'', max:100 };

  const titleEl = document.getElementById('goal-edit-title');
  if (titleEl) titleEl.textContent = g.label || t.label;

  const body = document.getElementById('goal-edit-body');
  if (body) {
    // Salah types section (only for prayers type)
    let salahSection = '';
    if (g.type === 'prayers') {
      const currentSalah = g.salahTypes || ['Fajr','Dhuhr','Asr','Maghrib','Isha'];
      salahSection = `
      <div style="margin-bottom:14px">
        <div style="font-size:0.5rem;color:var(--t3);letter-spacing:.1em;text-transform:uppercase;margin-bottom:8px">Which Prayers to Track</div>
        <div style="display:flex;gap:5px;flex-wrap:wrap" id="edit-salah-types">
          ${SALAH_NAMES.map(s => `
            <button onclick="toggleEditSalah('${s}',this)" data-salah="${s}" class="gss-opt ${currentSalah.includes(s)?'selected':''}" style="flex:calc(33% - 4px);justify-content:center;padding:7px 4px;font-size:.625rem">
              ${s}
            </button>`).join('')}
        </div>
      </div>`;
    }

    // Deadline section
    const today = new Date().toISOString().slice(0,10);
    const existingDl = g.deadline || '';
    const dur30 = new Date(); dur30.setDate(dur30.getDate()+30);
    const dur7 = new Date(); dur7.setDate(dur7.getDate()+7);
    const dur90 = new Date(); dur90.setDate(dur90.getDate()+90);
    const fmtD = d => d.toISOString().slice(0,10);

    body.innerHTML = `
      <div style="margin-bottom:14px">
        <div style="font-size:0.5rem;color:var(--t3);letter-spacing:.1em;text-transform:uppercase;margin-bottom:8px">Custom Label (optional)</div>
        <input id="goal-edit-label" type="text" value="${g.label||''}" placeholder="${t.label}" maxlength="32"
          style="width:100%;background:rgba(255,255,255,.07);border:1px solid rgba(var(--accent-rgb),.25);border-radius:10px;padding:10px 13px;color:var(--text);font-family:var(--font-ui),'Manrope',sans-serif;font-size:.875rem;outline:none;color-scheme:dark;box-sizing:border-box">
      </div>
      <div style="margin-bottom:14px">
        <div style="font-size:0.5rem;color:var(--t3);letter-spacing:.1em;text-transform:uppercase;margin-bottom:8px">Target</div>
        <div class="gss-stepper">
          <button class="gss-step-btn" onclick="editGoalAdj(-1)">−</button>
          <div class="gss-step-val-wrap">
            <div class="gss-step-val" id="edit-goal-val">${g.target}</div>
            <div class="gss-step-unit">${t.unit}</div>
          </div>
          <button class="gss-step-btn" onclick="editGoalAdj(1)">+</button>
        </div>
      </div>
      ${salahSection}
      <div style="margin-bottom:14px">
        <div style="font-size:0.5rem;color:var(--t3);letter-spacing:.1em;text-transform:uppercase;margin-bottom:8px">Period</div>
        <div style="display:flex;gap:6px">
          ${['daily','weekly','monthly','flexible'].map(p => `
            <button onclick="selectEditPeriod('${p}',this)" class="gss-opt ${(g.period||'daily')===p?'selected':''}" style="flex:1;justify-content:center;padding:8px 4px">
              ${p.charAt(0).toUpperCase()+p.slice(1)}
            </button>`).join('')}
        </div>
      </div>
      <div>
        <div style="font-size:0.5rem;color:var(--t3);letter-spacing:.1em;text-transform:uppercase;margin-bottom:8px">Goal Duration</div>
        <div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:8px" id="edit-deadline-presets">
          ${[{label:'7d',val:fmtD(dur7)},{label:'30d',val:fmtD(dur30)},{label:'90d',val:fmtD(dur90)},{label:'Ongoing',val:''}].map(d => `
            <button onclick="pickEditDeadlinePreset('${d.val}',this)" class="gss-opt ${existingDl===d.val?'selected':''}" style="flex:calc(25% - 4px);justify-content:center;padding:7px 2px;font-size:.625rem">
              ${d.label}
            </button>`).join('')}
        </div>
        <input type="date" id="edit-deadline-input" value="${existingDl}" min="${today}"
          style="width:100%;background:rgba(255,255,255,.07);border:1px solid rgba(var(--accent-rgb),.25);border-radius:10px;padding:10px 13px;color:var(--text);font-family:var(--font-ui),'Manrope',sans-serif;font-size:.8125rem;outline:none;color-scheme:dark;box-sizing:border-box"
          onchange="syncEditDeadline(this.value)">
      </div>`;
  }

  document.getElementById('goal-edit-overlay').classList.add('open');
  document.getElementById('goal-edit-sheet').classList.add('open');
}

let _editTarget = 0;
let _editPeriod = 'daily';
let _editSalahTypes = null; // null = not prayers type
let _editDeadline = undefined; // undefined = no change

function toggleEditSalah(name, btn) {
  if (!_editSalahTypes) _editSalahTypes = [...((_goals.find(x=>x.id===_editingGoalId)||{}).salahTypes || SALAH_NAMES)];
  const idx = _editSalahTypes.indexOf(name);
  if (idx >= 0) {
    if (_editSalahTypes.length <= 1) return; // keep at least 1
    _editSalahTypes.splice(idx,1);
    btn.classList.remove('selected');
  } else {
    _editSalahTypes.push(name);
    btn.classList.add('selected');
  }
}

function pickEditDeadlinePreset(val, btn) {
  _editDeadline = val; // '' = ongoing
  document.querySelectorAll('#edit-deadline-presets .gss-opt').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
  const inp = document.getElementById('edit-deadline-input');
  if (inp) inp.value = val;
}

function syncEditDeadline(val) {
  _editDeadline = val;
  // Deselect presets
  document.querySelectorAll('#edit-deadline-presets .gss-opt').forEach(b => b.classList.remove('selected'));
}

function editGoalAdj(delta) {
  _goals = loadGoals();
  const g = _goals.find(x => x.id === _editingGoalId);
  if (!g) return;
  const t = GOAL_TYPES[g.type] || { max: 1000 };
  _editTarget = _editTarget || g.target;
  _editTarget = Math.max(1, Math.min(t.max||1000, _editTarget + delta));
  const el = document.getElementById('edit-goal-val');
  if (el) el.textContent = _editTarget;
}
function selectEditPeriod(p, btn) {
  _editPeriod = p;
  document.querySelectorAll('#goal-edit-body .gss-opt').forEach(b => {
    if(['daily','weekly','monthly','flexible'].includes(b.textContent.trim().toLowerCase())) b.classList.remove('selected');
  });
  if (btn) btn.classList.add('selected');
}
function saveGoalEdit() {
  _goals = loadGoals();
  const idx = _goals.findIndex(x => x.id === _editingGoalId);
  if (idx < 0) { closeGoalEdit(); return; }
  const g = _goals[idx];
  const labelEl = document.getElementById('goal-edit-label');
  _editTarget = _editTarget || g.target;
  _editPeriod = _editPeriod || g.period;

  // Deadline: if _editDeadline was touched use it, else keep existing
  const deadlineVal = _editDeadline !== undefined ? (_editDeadline || null) : g.deadline;

  // Salah types
  const salahTypes = g.type === 'prayers'
    ? (_editSalahTypes || g.salahTypes || SALAH_NAMES)
    : undefined;

  const updated = { ...g, target: _editTarget, period: _editPeriod, label: labelEl?.value.trim()||g.label, deadline: deadlineVal };
  if (salahTypes !== undefined) updated.salahTypes = salahTypes;

  _goals[idx] = updated;
  saveGoals(_goals);
  closeGoalEdit();
  renderGoalsPage();
  renderGoalsHomeNudge();
  showToast('Goal updated ✓');
}
function deleteGoal(id) {
  if (!confirm('Remove this goal?')) return;
  _goals = loadGoals();
  _goals = _goals.filter(x => x.id !== id);
  saveGoals(_goals);
  closeGoalEdit();
  renderGoalsPage();
  renderGoalsHomeNudge();
  showToast('Goal removed');
}
function closeGoalEdit() {
  document.getElementById('goal-edit-overlay').classList.remove('open');
  document.getElementById('goal-edit-sheet').classList.remove('open');
  _editingGoalId = null;
  window._editingGoalId = null;
  _editTarget = 0;
  _editPeriod = 'daily';
  _editSalahTypes = null;
  _editDeadline = undefined;
}

// ══════════════════════════════════════════════════
// ✦ GOAL SURVEY — Smart Guided Setup
// ══════════════════════════════════════════════════

const SALAH_NAMES = ['Fajr','Dhuhr','Asr','Maghrib','Isha'];

const SURVEY_STEPS = [
  {
    id: 'welcome',
    icon: '🌙',
    eyebrow: 'Step 1',
    question: 'What matters most to you right now in your worship?',
    hint: 'Choose the areas you want to improve. You can always add more later.',
    type: 'multi_select',
    opts: [
      { id:'prayers',   icon:'🕌', label:'Daily Prayers',    sub:'Consistency & quality' },
      { id:'quran',     icon:'📖', label:'Quran Reading',     sub:'Pages per day' },
      { id:'dhikr',     icon:'📿', label:'Dhikr & Remembrance', sub:'Daily count target' },
      { id:'fasting',   icon:'🤍', label:'Fasting',           sub:'Weekly fast days' },
      { id:'sunnah',    icon:'☀️', label:'Sunnah Habits',     sub:'Daily habits' },
      { id:'tahajjud',  icon:'🌙', label:'Tahajjud',          sub:'Weekly night prayers' },
    ],
    key: 'selectedTypes',
    required: true,
  },
  {
    id: 'prayers_salah_types',
    icon: '🕌',
    eyebrow: 'Prayer Selection',
    question: 'Which prayers do you want to track?',
    hint: 'Select the specific salah times you want this goal to cover.',
    type: 'multi_select',
    opts: [
      { id:'Fajr',    icon:'🌄', label:'Fajr',    sub:'Dawn prayer' },
      { id:'Dhuhr',   icon:'☀️', label:'Dhuhr',   sub:'Midday prayer' },
      { id:'Asr',     icon:'🌤', label:'Asr',     sub:'Afternoon prayer' },
      { id:'Maghrib', icon:'🌅', label:'Maghrib',  sub:'Sunset prayer' },
      { id:'Isha',    icon:'🌙', label:'Isha',    sub:'Night prayer' },
    ],
    key: 'prayerSalahTypes',
    required: true,
    showIf: s => (s.selectedTypes||[]).includes('prayers'),
  },
  {
    id: 'prayers_quality',
    icon: '🎯',
    eyebrow: 'Prayer Target',
    question: 'How many of these prayers do you aim to complete each day?',
    hint: 'Set a realistic target. Consistency is more valuable than perfection.',
    type: 'stepper',
    key: 'prayerTarget',
    unit: 'prayers',
    min: 1, max: 5, default: 5,
    showIf: s => (s.selectedTypes||[]).includes('prayers'),
  },
  {
    id: 'quran_target',
    icon: '📖',
    eyebrow: 'Quran Target',
    question: 'How many Quran pages do you aim to read each day?',
    hint: 'Even 1 page daily adds up to a Khatam in a year. Start small and build up.',
    type: 'stepper',
    key: 'quranTarget',
    unit: 'pages',
    min: 1, max: 20, default: 2,
    showIf: s => (s.selectedTypes||[]).includes('quran'),
  },
  {
    id: 'dhikr_target',
    icon: '📿',
    eyebrow: 'Dhikr Target',
    question: 'What is your daily dhikr target?',
    hint: 'SubhanAllah × 33, Alhamdulillah × 33, Allahu Akbar × 34 = 100. Choose a meaningful number.',
    type: 'choice',
    key: 'dhikrTarget',
    choices: [
      { val:33, label:'33', sub:'After each prayer' },
      { val:99, label:'99', sub:'Classic set' },
      { val:100, label:'100', sub:'Round century' },
      { val:300, label:'300', sub:'Devoted seeker' },
    ],
    customKey: 'dhikrCustom',
    showIf: s => (s.selectedTypes||[]).includes('dhikr'),
  },
  {
    id: 'fasting_target',
    icon: '🤍',
    eyebrow: 'Fasting Target',
    question: 'How many voluntary fasts per week is your goal?',
    hint: 'The Prophet ﷺ fasted Mondays & Thursdays. Even 1 per week is a beautiful Sunnah.',
    type: 'choice',
    key: 'fastingTarget',
    choices: [
      { val:1, label:'1 day', sub:'Weekly start' },
      { val:2, label:'2 days', sub:'Mon & Thu Sunnah' },
      { val:3, label:'3 days', sub:'White days' },
      { val:4, label:'4 days', sub:'Dedicated' },
    ],
    showIf: s => (s.selectedTypes||[]).includes('fasting'),
  },
  {
    id: 'sunnah_target',
    icon: '☀️',
    eyebrow: 'Sunnah Target',
    question: 'How many Sunnah habits do you want to complete each day?',
    hint: 'Small consistent actions are beloved to Allah. Even 3 daily habits make a difference.',
    type: 'stepper',
    key: 'sunnahTarget',
    unit: 'habits',
    min: 1, max: 8, default: 4,
    showIf: s => (s.selectedTypes||[]).includes('sunnah'),
  },
  {
    id: 'tahajjud_target',
    icon: '🌙',
    eyebrow: 'Tahajjud Target',
    question: 'How many nights per week do you want to pray Tahajjud?',
    hint: 'The Prophet ﷺ never abandoned Tahajjud. Even 1 night a week is a beautiful beginning.',
    type: 'choice',
    key: 'tahajjudTarget',
    choices: [
      { val:1, label:'1 night', sub:'A gentle start' },
      { val:2, label:'2 nights', sub:'Building the habit' },
      { val:3, label:'3 nights', sub:'Midweek devotion' },
      { val:5, label:'5 nights', sub:'Dedicated seeker' },
    ],
    showIf: s => (s.selectedTypes||[]).includes('tahajjud'),
  },
  {
    id: 'goal_duration',
    icon: '📅',
    eyebrow: 'Goal Duration',
    question: 'How long do you want to commit to these goals?',
    hint: 'A deadline keeps you focused. You can always extend or reset later.',
    type: 'choice',
    key: 'goalDuration',
    choices: [
      { val:7,   label:'7 Days',  sub:'One week challenge' },
      { val:30,  label:'30 Days', sub:'One month habit' },
      { val:90,  label:'90 Days', sub:'Quarterly journey' },
      { val:0,   label:'Ongoing', sub:'No end date' },
    ],
    required: true,
  },
];

let _gssState = {};
let _gssVisibleSteps = [];
let _gssCurrentIdx = 0;

function getVisibleSteps() {
  return SURVEY_STEPS.filter(s => !s.showIf || s.showIf(_gssState));
}

function openGoalSurvey(editGoalId) {
  _gssState = {};
  _gssCurrentIdx = 0;
  _gssVisibleSteps = getVisibleSteps();

  const overlay = document.getElementById('goal-survey-overlay');
  const sheet = document.getElementById('goal-survey-sheet');
  overlay.classList.add('open');
  sheet.classList.add('open');
  renderSurveyStep();
}

function closeGoalSurvey() {
  document.getElementById('goal-survey-overlay').classList.remove('open');
  document.getElementById('goal-survey-sheet').classList.remove('open');
}

function renderSurveyStep() {
  _gssVisibleSteps = getVisibleSteps();
  const step = _gssVisibleSteps[_gssCurrentIdx];
  if (!step) { gssFinish(); return; }

  // Title
  const titleEl = document.getElementById('gss-main-title');
  if (titleEl) titleEl.textContent = step.id === 'welcome' ? 'Your Worship Goals' : 'Set Your Target';

  // Progress dots
  const dotsEl = document.getElementById('gss-progress-dots');
  if (dotsEl) {
    dotsEl.innerHTML = _gssVisibleSteps.map((s,i) =>
      `<div class="gss-prog-dot ${i < _gssCurrentIdx ? 'done' : i === _gssCurrentIdx ? 'active' : ''}"></div>`
    ).join('') + `<span class="gss-prog-lbl">${_gssCurrentIdx+1} / ${_gssVisibleSteps.length}</span>`;
  }

  // Step content
  const container = document.getElementById('gss-steps-container');
  if (!container) return;
  container.innerHTML = `<div class="gss-step active">${buildStepHTML(step)}</div>`;

  // Nav
  const backBtn = document.getElementById('gss-back-btn');
  const nextBtn = document.getElementById('gss-next-btn');
  if (backBtn) backBtn.style.display = _gssCurrentIdx > 0 ? 'block' : 'none';
  if (nextBtn) {
    if (_gssCurrentIdx === _gssVisibleSteps.length - 1) {
      nextBtn.textContent = 'Create My Goals ✦';
    } else {
      nextBtn.textContent = step.type === 'multi_select' ? 'Continue →' : 'Next →';
    }
    nextBtn.disabled = step.required && !isStepValid(step);
  }

  // Re-bind events
  bindStepEvents(step);
}

function buildStepHTML(step) {
  let html = `
    <span class="gss-q-icon">${step.icon}</span>
    <div class="gss-q-label">${step.eyebrow}</div>
    <div class="gss-question">${step.question}</div>
    <div class="gss-hint">${step.hint}</div>`;

  if (step.type === 'multi_select') {
    const sel = _gssState[step.key] || [];
    html += `<div class="gss-opts" id="gss-opts-${step.id}">` +
      step.opts.map(o => `
        <div class="gss-opt ${sel.includes(o.id)?'selected':''}" data-val="${o.id}" onclick="gssToggleOpt(this,'${step.id}','${step.key}')">
          <span class="gss-opt-icon">${o.icon}</span>
          <div style="flex:1;min-width:0">
            <div style="font-size:.7rem;font-weight:600;color:var(--text)">${o.label}</div>
            <div style="font-size:0.4rem;color:var(--t3);letter-spacing:.04em">${o.sub}</div>
          </div>
          <div class="gss-opt-check">${sel.includes(o.id)?'✓':''}</div>
        </div>`).join('') + '</div>';
  }

  if (step.type === 'stepper') {
    const val = _gssState[step.key] || step.default;
    html += `
      <div class="gss-stepper">
        <button class="gss-step-btn" onclick="gssAdj('${step.key}',${step.min},${step.max},-1)">−</button>
        <div class="gss-step-val-wrap">
          <div class="gss-step-val" id="gss-val-${step.key}">${val}</div>
          <div class="gss-step-unit">${step.unit}</div>
        </div>
        <button class="gss-step-btn" onclick="gssAdj('${step.key}',${step.min},${step.max},1)">+</button>
      </div>`;
  }

  if (step.type === 'toggle_stepper') {
    const on = _gssState[step.toggleKey] !== false;
    const val = _gssState[step.key] || step.default;
    html += `
      <div class="gss-toggle-row" onclick="gssToggleBool('${step.toggleKey}')">
        <span class="gss-tr-icon">🌟</span>
        <div class="gss-tr-body">
          <div class="gss-tr-name">Enable Takbir-ul-Ula Goal</div>
          <div class="gss-tr-sub">Track how many prayers you catch with Takbir</div>
        </div>
        <label class="sw-wrap gss-tr-toggle" onclick="event.stopPropagation()">
          <input type="checkbox" id="gss-toggle-${step.toggleKey}" ${on?'checked':''} onchange="gssToggleBool('${step.toggleKey}')">
          <div class="sw-slider"></div>
        </label>
      </div>
      <div id="gss-stepper-wrap" style="${on?'':'opacity:.4;pointer-events:none'}">
        <div class="gss-stepper">
          <button class="gss-step-btn" onclick="gssAdj('${step.key}',${step.min},${step.max},-1)">−</button>
          <div class="gss-step-val-wrap">
            <div class="gss-step-val" id="gss-val-${step.key}">${val}</div>
            <div class="gss-step-unit">${step.unit} with Takbir</div>
          </div>
          <button class="gss-step-btn" onclick="gssAdj('${step.key}',${step.min},${step.max},1)">+</button>
        </div>
      </div>`;
  }

  if (step.type === 'choice') {
    const val = _gssState[step.key];
    html += `<div class="gss-opts" id="gss-opts-${step.id}">` +
      step.choices.map(c => `
        <div class="gss-opt ${val===c.val?'selected':''}" style="flex:calc(50% - 4px)" data-val="${c.val}" onclick="gssPickChoice(this,'${step.id}','${step.key}',${c.val})">
          <div style="flex:1;text-align:center">
            <div style="font-size:.875rem;font-weight:700;color:var(--text)">${c.label}</div>
            <div style="font-size:0.4375rem;color:var(--t3);letter-spacing:.04em;margin-top:1px">${c.sub}</div>
          </div>
          <div class="gss-opt-check">${val===c.val?'✓':''}</div>
        </div>`).join('') + '</div>';
  }

  return html;
}

function bindStepEvents(step) {
  // Initialize defaults into state
  if (step.type === 'stepper' && !_gssState[step.key]) _gssState[step.key] = step.default;
  if (step.type === 'toggle_stepper') {
    if (_gssState[step.toggleKey] === undefined) _gssState[step.toggleKey] = true;
    if (!_gssState[step.key]) _gssState[step.key] = step.default;
  }
  updateNextBtn();
}

function gssToggleOpt(el, stepId, key) {
  const val = el.dataset.val;
  if (!_gssState[key]) _gssState[key] = [];
  const idx = _gssState[key].indexOf(val);
  if (idx >= 0) _gssState[key].splice(idx,1);
  else _gssState[key].push(val);
  el.classList.toggle('selected');
  const chk = el.querySelector('.gss-opt-check');
  if (chk) chk.textContent = el.classList.contains('selected') ? '✓' : '';
  updateNextBtn();
  _gssVisibleSteps = getVisibleSteps();
}

function gssAdj(key, min, max, delta) {
  _gssState[key] = Math.max(min, Math.min(max, (_gssState[key]||0) + delta));
  const el = document.getElementById('gss-val-'+key);
  if (el) el.textContent = _gssState[key];
}

function gssToggleBool(key) {
  _gssState[key] = !_gssState[key];
  const chk = document.getElementById('gss-toggle-'+key);
  if (chk) chk.checked = _gssState[key];
  const wrap = document.getElementById('gss-stepper-wrap');
  if (wrap) { wrap.style.opacity = _gssState[key] ? '1' : '.4'; wrap.style.pointerEvents = _gssState[key] ? '' : 'none'; }
}

function gssPickChoice(el, stepId, key, val) {
  _gssState[key] = val;
  const container = document.getElementById('gss-opts-'+stepId);
  if (container) {
    container.querySelectorAll('.gss-opt').forEach(o => {
      o.classList.remove('selected');
      const chk = o.querySelector('.gss-opt-check'); if(chk) chk.textContent='';
    });
  }
  el.classList.add('selected');
  const chk = el.querySelector('.gss-opt-check'); if(chk) chk.textContent='✓';
  updateNextBtn();
}

function isStepValid(step) {
  if (step.type === 'multi_select') return (_gssState[step.key]||[]).length > 0;
  if (step.type === 'choice') return _gssState[step.key] !== undefined;
  return true;
}

function updateNextBtn() {
  const nextBtn = document.getElementById('gss-next-btn');
  if (!nextBtn) return;
  const step = _gssVisibleSteps[_gssCurrentIdx];
  nextBtn.disabled = step && step.required && !isStepValid(step);
}

function gssNext() {
  const step = _gssVisibleSteps[_gssCurrentIdx];
  // Save stepper default if not set
  if (step && step.type === 'stepper' && !_gssState[step.key]) _gssState[step.key] = step.default;
  if (step && step.type === 'toggle_stepper') {
    if (_gssState[step.toggleKey] === undefined) _gssState[step.toggleKey] = true;
    if (!_gssState[step.key]) _gssState[step.key] = step.default;
  }

  _gssVisibleSteps = getVisibleSteps();
  _gssCurrentIdx++;
  if (_gssCurrentIdx >= _gssVisibleSteps.length) { gssFinish(); return; }
  renderSurveyStep();
}

function gssPrev() {
  if (_gssCurrentIdx > 0) { _gssCurrentIdx--; renderSurveyStep(); }
}

function gssFinish() {
  // Build goals from state
  const types = _gssState.selectedTypes || [];
  const newGoals = [];
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2,6);

  // Duration: days=0 means ongoing, else deadline = today + days
  const dur = _gssState.goalDuration;
  let deadline = null;
  if (dur && dur > 0) {
    const d = new Date(); d.setDate(d.getDate() + dur);
    deadline = d.toISOString().slice(0,10);
  }

  if (types.includes('prayers')) {
    const salahTypes = (_gssState.prayerSalahTypes||[]).length > 0 ? _gssState.prayerSalahTypes : ['Fajr','Dhuhr','Asr','Maghrib','Isha'];
    const maxTarget = salahTypes.length;
    const target = Math.min(_gssState.prayerTarget||5, maxTarget);
    newGoals.push({ id:uid(), type:'prayers', target, period:'daily', label:'Daily Prayers', salahTypes, deadline });
  }
  if (types.includes('quran'))      newGoals.push({ id:uid(), type:'quran',      target:_gssState.quranTarget||2,    period:'daily',   label:'Quran Pages',    deadline });
  if (types.includes('dhikr'))      newGoals.push({ id:uid(), type:'dhikr',      target:_gssState.dhikrTarget||99,   period:'daily',   label:'Dhikr Count',    deadline });
  if (types.includes('fasting'))    newGoals.push({ id:uid(), type:'fasting',    target:_gssState.fastingTarget||2,  period:'weekly',  label:'Fasting Days',   deadline });
  if (types.includes('sunnah'))     newGoals.push({ id:uid(), type:'sunnah',     target:_gssState.sunnahTarget||4,   period:'daily',   label:'Sunnah Habits',  deadline });
  if (types.includes('tahajjud'))   newGoals.push({ id:uid(), type:'tahajjud',   target:_gssState.tahajjudTarget||2, period:'weekly',  label:'Tahajjud Nights',deadline });

  // Add all new goals (allow duplicates with different salahTypes/deadline)
  const existing = loadGoals();
  const toAdd = newGoals;
  saveGoals([...existing, ...toAdd]);
  _goals = loadGoals();

  closeGoalSurvey();
  renderGoalsHomeNudge();

  // Show success toast and open goals page
  showToast(`✦ ${toAdd.length} goal${toAdd.length!==1?'s':''} created!`);
  setTimeout(() => { openGoalsPage(); }, 300);
}

// ── Goal-Driven KPI: override renderKPI to reflect goals ──
const _origRenderKPI = window.renderKPI;
window.renderKPI = function() {
  _origRenderKPI && _origRenderKPI();
  renderGoalsHomeNudge();
};

// ── Initialize on load ──
document.addEventListener('DOMContentLoaded', function() {
  setTimeout(() => {
    _goals = loadGoals();
    renderGoalsHomeNudge();
    // Show dot if no goals
    if (_goals.length === 0) {
      const dot = document.getElementById('goals-nav-dot');
      if (dot) dot.style.display = 'block';
    }
  }, 800);
});
