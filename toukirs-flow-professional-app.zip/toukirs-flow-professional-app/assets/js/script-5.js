
(function(){
  const SVG = {
    star:`<svg viewBox="0 0 24 24"><path d="M12 3.5l2.8 5.67 6.26.91-4.53 4.41 1.07 6.23L12 17.8 6.4 20.72l1.07-6.23L2.94 10.08l6.26-.91L12 3.5z"/></svg>`,
    sparkle:`<svg viewBox="0 0 24 24"><path d="M12 2l1.7 5.3L19 9l-5.3 1.7L12 16l-1.7-5.3L5 9l5.3-1.7L12 2zM19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9L19 15zM5 14l.7 1.6L7.3 16l-1.6.7L5 18.3l-.7-1.6L2.7 16l1.6-.7L5 14z"/></svg>`,
    moon:`<svg viewBox="0 0 24 24"><path d="M20 14.5A8.5 8.5 0 0 1 9.5 4 9 9 0 1 0 20 14.5z"/></svg>`,
    mosque:`<svg viewBox="0 0 24 24"><path d="M4 20h16M6 20v-6a6 6 0 0 1 12 0v6M10 20v-4a2 2 0 1 1 4 0v4M12 4v3M12 7l4 2M12 7 8 9M18 20v-5M6 20v-5"/></svg>`,
    location:`<svg viewBox="0 0 24 24"><path d="M12 21s6-5.1 6-11a6 6 0 1 0-12 0c0 5.9 6 11 6 11z"/><circle cx="12" cy="10" r="2.5"/></svg>`,
    target:`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="M12 2v3M22 12h-3M12 22v-3M2 12h3"/></svg>`,
    book:`<svg viewBox="0 0 24 24"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21V5.5z"/><path d="M8 7h8M8 11h8M8 15h6"/></svg>`,
    check:`<svg viewBox="0 0 24 24"><path d="M5 12.5l4.2 4.2L19 7"/></svg>`,
    heart:`<svg viewBox="0 0 24 24"><path d="M12 20s-7-4.35-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.65-7 10-7 10z"/></svg>`,
    globe:`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/></svg>`,
    camera:`<svg viewBox="0 0 24 24"><path d="M4 8h4l1.5-2h5L16 8h4v11H4z"/><circle cx="12" cy="13.5" r="3.5"/></svg>`,
    pencil:`<svg viewBox="0 0 24 24"><path d="M4 20l4.5-1 9.7-9.7a2.1 2.1 0 0 0-3-3L5.5 16 4 20z"/><path d="M13.5 6.5l4 4"/></svg>`,
    logout:`<svg viewBox="0 0 24 24"><path d="M10 5H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h4"/><path d="M14 16l4-4-4-4M18 12H9"/></svg>`,
    settings:`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .32 1.76l.05.05a2 2 0 0 1-2.83 2.83l-.05-.05A1.6 1.6 0 0 0 15 19.4a1.6 1.6 0 0 0-1 .6 1.6 1.6 0 0 1-2 0 1.6 1.6 0 0 0-1-.6 1.6 1.6 0 0 0-1.76.32l-.05.05a2 2 0 1 1-2.83-2.83l.05-.05A1.6 1.6 0 0 0 4.6 15a1.6 1.6 0 0 0-.6-1 1.6 1.6 0 0 1 0-2 1.6 1.6 0 0 0 .6-1 1.6 1.6 0 0 0-.32-1.76l-.05-.05a2 2 0 1 1 2.83-2.83l.05.05A1.6 1.6 0 0 0 9 4.6c.37 0 .73-.14 1-.4a1.6 1.6 0 0 1 2 0c.27.26.63.4 1 .4a1.6 1.6 0 0 0 1.76-.32l.05-.05a2 2 0 0 1 2.83 2.83l-.05.05A1.6 1.6 0 0 0 19.4 9c0 .37.14.73.4 1a1.6 1.6 0 0 1 0 2c-.26.27-.4.63-.4 1z"/></svg>`,
    bell:`<svg viewBox="0 0 24 24"><path d="M6 9a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>`,
    dumbbell:`<svg viewBox="0 0 24 24"><path d="M3 9v6M6 7v10M9 10h6M15 7v10M18 9v6"/></svg>`,
    music:`<svg viewBox="0 0 24 24"><path d="M9 18V6l10-2v12"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="16" r="2"/></svg>`,
    menu:`<svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg>`,
    prev:`<svg viewBox="0 0 24 24"><path d="M11 7l-5 5 5 5M18 7l-5 5 5 5"/></svg>`,
    next:`<svg viewBox="0 0 24 24"><path d="M13 7l5 5-5 5M6 7l5 5-5 5"/></svg>`,
    expand:`<svg viewBox="0 0 24 24"><path d="M9 3H3v6M15 3h6v6M21 15v6h-6M3 15v6h6"/><path d="M3 9l6-6M15 3l6 6M21 15l-6 6M9 21l-6-6"/></svg>`,
    palette:`<svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 0 0 18h1.2a2.3 2.3 0 0 0 0-4.6H12a1.4 1.4 0 0 1 0-2.8h3a6 6 0 0 0 0-12z"/><circle cx="7.5" cy="10" r="1"/><circle cx="10" cy="7.5" r="1"/><circle cx="14" cy="7.5" r="1"/></svg>`,
    type:`<svg viewBox="0 0 24 24"><path d="M4 7h16M12 7v10M8 17h8"/></svg>`,
    bolt:`<svg viewBox="0 0 24 24"><path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z"/></svg>`,
    sunrise:`<svg viewBox="0 0 24 24"><path d="M5 18h14M8 18a4 4 0 0 1 8 0M12 3v5M4.5 10.5l2 2M19.5 10.5l-2 2M2 14h3M19 14h3"/></svg>`,
    ruler:`<svg viewBox="0 0 24 24"><path d="M4 20L20 4l0 0 0 0"/><path d="M7 17l2 2M10 14l2 2M13 11l2 2M16 8l2 2"/><path d="M4 20l-1-4 13-13 4 1 1 4-13 13z"/></svg>`,
    chart:`<svg viewBox="0 0 24 24"><path d="M4 19h16"/><path d="M7 16V9M12 16V5M17 16v-3"/></svg>`,
    clock:`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>`,
    hash:`<svg viewBox="0 0 24 24"><path d="M9 3L7 21M17 3l-2 18M4 9h16M3 15h16"/></svg>`,
    tag:`<svg viewBox="0 0 24 24"><path d="M20 10l-8.5 8.5a2 2 0 0 1-2.8 0L3 13V4h9l8 8a2 2 0 0 1 0 2.8z"/><circle cx="7.5" cy="7.5" r="1"/></svg>`,
    beads:`<svg viewBox="0 0 24 24"><path d="M8 4a4 4 0 0 0 8 0"/><path d="M12 8v12"/><circle cx="12" cy="11" r="1.8"/><circle cx="12" cy="15" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg>`,
    phonevibrate:`<svg viewBox="0 0 24 24"><rect x="8" y="3" width="8" height="18" rx="2"/><path d="M5 8l-2 2 2 2M19 8l2 2-2 2M5 14l-2 2 2 2M19 14l2 2-2 2"/></svg>`,
    calendar:`<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/></svg>`,
    scroll:`<svg viewBox="0 0 24 24"><path d="M7 4h10a3 3 0 0 1 0 6H8a3 3 0 1 0 0 6h9a3 3 0 0 1 0 6H7"/><path d="M7 4a3 3 0 0 0 0 6"/></svg>`,
    lock:`<svg viewBox="0 0 24 24"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V8a4 4 0 1 1 8 0v3"/></svg>`,
    key:`<svg viewBox="0 0 24 24"><circle cx="8" cy="12" r="3"/><path d="M11 12h10M17 12v-2M20 12v2"/></svg>`,
    shield:`<svg viewBox="0 0 24 24"><path d="M12 3l7 3v6c0 4.5-2.9 7.7-7 9-4.1-1.3-7-4.5-7-9V6l7-3z"/></svg>`,
    save:`<svg viewBox="0 0 24 24"><path d="M5 4h11l3 3v13H5z"/><path d="M8 4v5h8V4M9 18h6"/></svg>`,
    box:`<svg viewBox="0 0 24 24"><path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12L4 7.5M12 12v9"/></svg>`,
    sync:`<svg viewBox="0 0 24 24"><path d="M20 7v5h-5M4 17v-5h5"/><path d="M7 17a7 7 0 0 0 11.5-2M17 7A7 7 0 0 0 5.5 9"/></svg>`,
    clipboard:`<svg viewBox="0 0 24 24"><rect x="6" y="5" width="12" height="16" rx="2"/><path d="M9 5.5h6M9 10h6M9 14h6"/><path d="M10 3h4v4h-4z"/></svg>`,
    note:`<svg viewBox="0 0 24 24"><path d="M6 3h9l3 3v15H6z"/><path d="M15 3v4h4M9 12h6M9 16h4"/></svg>`,
    trash:`<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13"/></svg>`,
    hands:`<svg viewBox="0 0 24 24"><path d="M7 13l3-7 2 5 2-5 3 7"/><path d="M5 18h14"/></svg>`,
    sun:`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M2 12h3M19 12h3M4.9 19.1L7 17M17 7l2.1-2.1"/></svg>`,
    home:`<svg viewBox="0 0 24 24"><path d="M3 10.5L12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/></svg>`,
    drop:`<svg viewBox="0 0 24 24"><path d="M12 3s6 6 6 10a6 6 0 0 1-12 0c0-4 6-10 6-10z"/></svg>`,
    flame:`<svg viewBox="0 0 24 24"><path d="M12 3s4 4 4 8a4 4 0 0 1-8 0c0-3 2-5 4-8z"/><path d="M12 13a4 4 0 0 1 4 4 4 4 0 0 1-8 0c0-2 1.2-3.5 4-4z"/></svg>`,
    medal:`<svg viewBox="0 0 24 24"><circle cx="12" cy="14" r="5"/><path d="M9 3l3 4 3-4M10 14l1.2 1.2L14 12.5"/></svg>`,
    leaf:`<svg viewBox="0 0 24 24"><path d="M5 19C17 18 19 9 19 5 15 5 6 7 5 19z"/><path d="M7 17c3-3 5-5 10-7"/></svg>`,
    bookmark:`<svg viewBox="0 0 24 24"><path d="M7 4h10v16l-5-3-5 3z"/></svg>`,
    brain:`<svg viewBox="0 0 24 24"><path d="M9 5a3 3 0 0 0-3 3v1a2.5 2.5 0 0 0 0 5V15a3 3 0 0 0 5 2.2A3.5 3.5 0 0 0 17.5 15V8a3 3 0 0 0-5-2.2A3 3 0 0 0 9 5z"/><path d="M9 9v6M12 7v10M15 9v6"/></svg>`,
    headphones:`<svg viewBox="0 0 24 24"><path d="M4 13a8 8 0 0 1 16 0"/><rect x="4" y="13" width="4" height="7" rx="2"/><rect x="16" y="13" width="4" height="7" rx="2"/></svg>`,
    search:`<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6"/><path d="M20 20l-4.35-4.35"/></svg>`,
    compass:`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M14.5 9.5l-2 5-5 2 2-5 5-2z"/></svg>`,
    trophy:`<svg viewBox="0 0 24 24"><path d="M8 4h8v3a4 4 0 0 1-8 0V4z"/><path d="M6 5H4a3 3 0 0 0 3 5M18 5h2a3 3 0 0 1-3 5M12 11v4M9 21h6M10 15h4"/></svg>`,
    coins:`<svg viewBox="0 0 24 24"><ellipse cx="12" cy="6" rx="6" ry="3"/><path d="M6 6v8c0 1.7 2.7 3 6 3s6-1.3 6-3V6"/><path d="M6 10c0 1.7 2.7 3 6 3s6-1.3 6-3"/></svg>`,
    newspaper:`<svg viewBox="0 0 24 24"><path d="M5 5h13a2 2 0 0 1 2 2v12H7a2 2 0 0 1-2-2V5z"/><path d="M8 9h8M8 12h8M8 15h5"/></svg>`,
    handshake:`<svg viewBox="0 0 24 24"><path d="M8 12l3 3a2 2 0 0 0 3 0l2-2"/><path d="M3 10l4-4 4 4-4 4-4-4zM13 10l4-4 4 4-4 4-4-4z"/></svg>`,
    phone:`<svg viewBox="0 0 24 24"><path d="M6 4h4l2 5-2.5 2.5a14 14 0 0 0 4 4L16 13l5 2v4a2 2 0 0 1-2 2A17 17 0 0 1 3 5a2 2 0 0 1 2-1h1z"/></svg>`,
    meal:`<svg viewBox="0 0 24 24"><path d="M4 4v7M7 4v7M4 8h3M12 4v17M16 4h4v8a2 2 0 0 1-2 2h-2"/></svg>`,
    hand:`<svg viewBox="0 0 24 24"><path d="M7 21V9a1 1 0 0 1 2 0v5M9 14V7a1 1 0 0 1 2 0v7M11 14V6a1 1 0 0 1 2 0v8M13 14V8a1 1 0 0 1 2 0v7M15 14l2-1a1.5 1.5 0 0 1 2 1.4V17a4 4 0 0 1-4 4H11a4 4 0 0 1-4-4z"/></svg>`,
    walk:`<svg viewBox="0 0 24 24"><circle cx="14" cy="5" r="2"/><path d="M12 22l1-6-3-3 2-3 3 2 2 4 3 1"/></svg>`,
    salad:`<svg viewBox="0 0 24 24"><path d="M5 14a7 7 0 0 1 14 0v2a4 4 0 0 1-4 4H9a4 4 0 0 1-4-4v-2z"/><path d="M8 12c0-2 1.6-4 4-4s4 2 4 4"/></svg>`,
    bed:`<svg viewBox="0 0 24 24"><path d="M3 18V9h18v9M3 13h18M7 13V9M5 18v3M19 18v3"/></svg>`,
    bike:`<svg viewBox="0 0 24 24"><circle cx="6" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="M6 17l4-7h4l2 7M10 10l-2-3M14 10h3"/></svg>`,
    apple:`<svg viewBox="0 0 24 24"><path d="M12 7c2-3 5-2 5-2 0 2-1 3-3 4"/><path d="M12 7c-2-3-5-2-5-2 0 2 1 3 3 4"/><path d="M8 10c-2 0-3 2-3 5 0 4 3 7 7 7s7-3 7-7c0-3-1-5-3-5-2 0-2 1-4 1s-2-1-4-1z"/></svg>`,
    sleep:`<svg viewBox="0 0 24 24"><path d="M5 8h6l-6 7h6M13 5h4l-4 5h4M16 13h3l-3 4h3"/></svg>`,
    ban:`<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M7 7l10 10"/></svg>`,
    folder:`<svg viewBox="0 0 24 24"><path d="M3 7h6l2 2h10v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7z"/></svg>`,
    mail:`<svg viewBox="0 0 24 24"><path d="M4 6h16v12H4z"/><path d="M4 8l8 6 8-6"/></svg>`,
    briefcase:`<svg viewBox="0 0 24 24"><rect x="3" y="7" width="18" height="12" rx="2"/><path d="M9 7V5h6v2M3 12h18"/></svg>`,
    cook:`<svg viewBox="0 0 24 24"><path d="M4 14h12a4 4 0 0 1 0 8H8a4 4 0 0 1-4-4v-4z"/><path d="M16 14l4-2M7 12a3 3 0 0 1 6 0"/></svg>`,
    run:`<svg viewBox="0 0 24 24"><circle cx="14" cy="5" r="2"/><path d="M7 13l4-2 2 2 3-1 2 3-4 1-1 5h-3l1-4-3-2-1-2z"/></svg>`,
    stretch:`<svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="2"/><path d="M12 7v5M6 12l6-2 6 2M8 21l4-4 4 4"/></svg>`,
    flask:`<svg viewBox="0 0 24 24"><path d="M10 3v5l-5 8a3 3 0 0 0 2.6 4.5h8.8A3 3 0 0 0 19 16l-5-8V3"/><path d="M8 14h8"/></svg>`,
    alert:`<svg viewBox="0 0 24 24"><path d="M12 3l10 18H2L12 3z"/><path d="M12 9v5M12 17h.01"/></svg>`,
    idea:`<svg viewBox="0 0 24 24"><path d="M9 18h6M10 22h4M8 14a6 6 0 1 1 8 0c-1 1-1.5 2-2 4h-4c-.5-2-1-3-2-4z"/></svg>`,
    quote:`<svg viewBox="0 0 24 24"><path d="M9 8H5v6h4l-2 4M19 8h-4v6h4l-2 4"/></svg>`,
    party:`<svg viewBox="0 0 24 24"><path d="M4 4l8 8M14 10l6-6M12 12l7 7M5 19l7-7"/><path d="M7 7l2-2M17 7l2 2M17 17l2 2M7 17l2-2"/></svg>`,
    eye:`<svg viewBox="0 0 24 24"><path d="M2 12s4-6 10-6 10 6 10 6-4 6-10 6S2 12 2 12z"/><circle cx="12" cy="12" r="2.5"/></svg>`,
    clip:`<svg viewBox="0 0 24 24"><path d="M9 12l6-6a3 3 0 0 1 4 4l-8 8a5 5 0 0 1-7-7l8-8"/></svg>`,
    flag:`<svg viewBox="0 0 24 24"><path d="M5 3v18"/><path d="M5 4h11l-2 4 2 4H5"/></svg>`,
    mic:`<svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M6 11a6 6 0 0 0 12 0M12 17v4M9 21h6"/></svg>`,
    signal:`<svg viewBox="0 0 24 24"><path d="M3 18h2M7 15h2M11 12h2M15 9h2M19 6h2"/></svg>`,
    scales:`<svg viewBox="0 0 24 24"><path d="M12 4v16M7 7h10M5 7l-3 5h6l-3-5zM19 7l-3 5h6l-3-5zM8 20h8"/></svg>`
  };
  const map = {
    '✓':'check','✅':'check','☑':'check','✗':'check','❌':'check',
    '🕋':'compass','✦':'sparkle','✨':'sparkle','💫':'sparkle','🌟':'star','★':'star','☆':'star','☪':'moon','🌙':'moon','🌕':'moon',
    '☁':'shield','🕌':'mosque','📍':'location','🎯':'target','📖':'book','📚':'book','📙':'book','📗':'book','📘':'book','📕':'book','📓':'book','📒':'book',
    '🤍':'heart','🤎':'heart','💚':'heart','🌐':'globe','🌍':'globe','📷':'camera','✏':'pencil','✎':'pencil','✍':'pencil',
    '🚪':'logout','⚙':'settings','🔔':'bell','📳':'phonevibrate','⏰':'clock','🕐':'clock','🕛':'clock','⏱':'clock','⏳':'clock','⏸':'clock',
    '💪':'dumbbell','🎵':'music','🎧':'headphones','☰':'menu','⎘':'clipboard','⏮':'prev','⏭':'next','⛶':'expand','🎨':'palette','🔤':'type',
    '🌫':'sparkle','⚡':'bolt','🌅':'sunrise','🌄':'sunrise','🌆':'sunrise','🌤':'sunrise','🌃':'moon','📐':'ruler','📊':'chart','📈':'chart','📉':'chart','🔢':'hash','🏷':'tag',
    '📿':'beads','📅':'calendar','🗓':'calendar','📜':'scroll','🔒':'lock','🔑':'key','🫣':'shield','💾':'save','📦':'box','🔄':'sync','🔁':'sync','📋':'clipboard','📝':'note','🗑':'trash',
    '🤲':'hands','☀':'sun','🏠':'home','💧':'drop','🔥':'flame','🏅':'medal','🏆':'trophy','🌿':'leaf','🌱':'leaf','🔖':'bookmark','🧠':'brain','⌕':'search','🔍':'search','🧭':'compass',
    '💰':'coins','💸':'coins','📰':'newspaper','🍽':'meal','🤝':'handshake','☎':'phone','🙏':'hands','✋':'hand','🚶':'walk','🧘':'stretch','🏃':'run','🤸':'stretch','🥗':'salad','🛌':'bed','🚴':'bike','🍎':'apple','😴':'sleep','💤':'sleep','🚫':'ban',
    '🗂':'folder','📵':'ban','🧹':'sparkle','🛒':'box','📧':'mail','💼':'briefcase','🍳':'cook','🧪':'flask','🚨':'alert','⚠':'alert','💡':'idea','❝':'quote','🎉':'party','🙈':'eye','👁':'eye','💭':'quote','👍':'check','📎':'clip','🏁':'flag','🎙':'mic','📡':'signal','⚖':'scales','🏛':'home','♾':'sync',
    '🦉':'sparkle','🦋':'sparkle','🌺':'sparkle','🌸':'sparkle','💎':'sparkle','🌊':'drop','🕊':'hands','🤫':'shield','🧎':'hands'
  };
  const regex = new RegExp(Object.keys(map).sort((a,b)=>b.length-a.length).map(k=>k.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|'),'g');
  const skipTags = new Set(['SCRIPT','STYLE','TEXTAREA','INPUT','OPTION']);
  const norm = s => s ? s.replace(/[\uFE0F\u200D]/g,'') : s;
  const svgHtml = name => SVG[name] || SVG.sparkle;
  const render = emoji => `<span class="svg-emoji-inline icon-replaced" data-emoji="${emoji}" aria-hidden="true">${svgHtml(map[norm(emoji)]||'sparkle')}</span>`;
  function replaceTextNode(node){
    if(!node || !node.nodeValue || !regex.test(norm(node.nodeValue))) return;
    regex.lastIndex = 0;
    const parent = node.parentNode;
    if(!parent || skipTags.has(parent.nodeName) || parent.closest?.('.svg-emoji-inline,[data-no-emoji-replace="1"]')) return;
    const html = node.nodeValue.replace(regex, m => render(m));
    if(html === node.nodeValue) return;
    const wrap = document.createElement('span');
    wrap.innerHTML = html;
    const frag = document.createDocumentFragment();
    while(wrap.firstChild) frag.appendChild(wrap.firstChild);
    parent.replaceChild(frag, node);
  }
  function replaceEmojiOnlyElement(el){
    if(!el || skipTags.has(el.nodeName) || el.closest?.('.svg-emoji-inline')) return;
    const kids = Array.from(el.childNodes||[]);
    if(kids.length !== 1 || kids[0].nodeType !== 3) return;
    const raw = kids[0].nodeValue.trim();
    const n = norm(raw);
    if(!map[n] || raw.length > 4) return;
    el.innerHTML = render(raw);
    el.classList.add('icon-replaced');
  }
  function walk(root){
    if(!root) return;
    if(root.nodeType===3){ replaceTextNode(root); return; }
    if(root.nodeType!==1 || skipTags.has(root.nodeName)) return;
    replaceEmojiOnlyElement(root);
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    const nodes=[]; while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(replaceTextNode);
    root.querySelectorAll && root.querySelectorAll('*').forEach(replaceEmojiOnlyElement);
  }
  window.applySvgEmojiReplacement = function(root){ walk(root || document.body); };
  document.addEventListener('DOMContentLoaded', function(){
    walk(document.body);
    const mo = new MutationObserver(muts => {
      for(const mut of muts){
        if(mut.type==='characterData') replaceTextNode(mut.target);
        mut.addedNodes && mut.addedNodes.forEach(n => walk(n));
      }
    });
    mo.observe(document.body,{childList:true,subtree:true,characterData:true});
    window.__svgEmojiObserver = mo;
  });
})();
