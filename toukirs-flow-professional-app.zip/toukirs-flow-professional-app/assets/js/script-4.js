
// ══════════════════════════════════════════════════
// ✦ XP + LEVEL SYSTEM
// ══════════════════════════════════════════════════

const XP_LEVELS = [
  { level:1,  name:'Beginner',    xpNeeded:0,    desc:'Every journey starts with bismillah.',      icon:'🌱' },
  { level:2,  name:'Devoted',     xpNeeded:200,  desc:'You are building a beautiful habit.',        icon:'📖' },
  { level:3,  name:'Steadfast',   xpNeeded:500,  desc:'Consistency is the mark of the sincere.',   icon:'🕌' },
  { level:4,  name:'Worshipper',  xpNeeded:1000, desc:'Your heart is turning toward Allah.',        icon:'🤲' },
  { level:5,  name:'Seeker',      xpNeeded:2000, desc:'You seek knowledge and closeness to Allah.', icon:'⭐' },
  { level:6,  name:'Ascetic',     xpNeeded:3500, desc:'The dunya grows lighter in your hands.',     icon:'🌙' },
  { level:7,  name:'Righteous',   xpNeeded:5500, desc:'Your deeds shine in the record of angels.',  icon:'✨' },
  { level:8,  name:'Scholar',     xpNeeded:8000, desc:'You carry the light of knowledge and amal.', icon:'🏆' },
];

// XP values for each action
const XP_ACTIONS = {
  prayer:        25,   // per prayer
  allPrayers:    50,   // bonus for all 5
  takbirUla:     15,   // per takbir-ul-ula prayer
  fasting:       40,   // per fast day
  quranPage:      5,   // per page
  dhikrComplete: 20,   // per dhikr set completed
  sunnahDone:    10,   // per sunnah item
  activityDone:  10,   // per activity
  dailyLogin:    15,   // just opening the app
  streak7:       75,   // 7-day prayer streak bonus
  streak30:     200,   // 30-day prayer streak bonus
  perfectDay:   100,   // 100% score day
};

function loadXPData() {
  try { return JSON.parse(localStorage.getItem('mrd_xp_v1') || 'null') || { total: 0, today: {}, lastDay: '' }; } catch { return { total: 0, today: {}, lastDay: '' }; }
}
function saveXPData(d) {
  try { localStorage.setItem('mrd_xp_v1', JSON.stringify(d)); } catch {}
  // ☁️ Push XP data to Supabase settings (debounced)
  clearTimeout(saveXPData._supaTimer);
  saveXPData._supaTimer = setTimeout(() => { supaPushSettings(); }, 3000);
}

function getXP() { return loadXPData().total; }

function awardXP(amount, label, key) {
  if (amount <= 0) return;
  const d = loadXPData();
  // Reset today's keys if new day
  if (d.lastDay !== TODAY_KEY) { d.today = {}; d.lastDay = TODAY_KEY; }
  // Prevent duplicate awards per key per day (unless key has _multi suffix)
  if (key && !key.endsWith('_multi') && d.today[key]) return;
  if (key && !key.endsWith('_multi')) d.today[key] = true;
  const prevTotal = d.total;
  d.total += amount;
  saveXPData(d);
  showXPToast('+' + amount + ' XP' + (label ? ' · ' + label : ''));
  // Check level-up — only show popup when viewing today
  const prevLevel = getLevelForXP(prevTotal);
  const newLevel  = getLevelForXP(d.total);
  if (newLevel.level > prevLevel.level) {
    const _isToday = (typeof viewingDate === 'undefined' || !viewingDate || viewingDate === TODAY_KEY);
    if (_isToday) setTimeout(() => showLevelup(newLevel), 800);
  }
  // Refresh widget
  setTimeout(renderXPWidget, 100);
}

function getLevelForXP(xp) {
  let cur = XP_LEVELS[0];
  for (const lv of XP_LEVELS) { if (xp >= lv.xpNeeded) cur = lv; }
  return cur;
}
function getNextLevelForXP(xp) {
  for (const lv of XP_LEVELS) { if (xp < lv.xpNeeded) return lv; }
  return null; // maxed out
}

let _xpToastTimer = null;
function showXPToast(msg) {
  const el = document.getElementById('xp-toast');
  const txt = document.getElementById('xp-toast-text');
  if (!el || !txt) return;
  txt.textContent = msg;
  el.classList.add('show');
  clearTimeout(_xpToastTimer);
  _xpToastTimer = setTimeout(() => el.classList.remove('show'), 2200);
}

function showLevelup(lv) {
  // Level-up popup disabled
}
function closeLevelup() {
  const overlay = document.getElementById('levelup-overlay');
  if (overlay) overlay.classList.remove('show');
}

// ── Grant daily login XP once per day ──
(function grantDailyLogin() {
  const d = loadXPData();
  if (d.lastDay !== TODAY_KEY) {
    awardXP(XP_ACTIONS.dailyLogin, 'Daily check-in', 'login');
  }
})();

// ── Hook into existing persist functions ──
// We patch persist() to award XP based on current state
const _origPersist = window.persist;
function _calcAndAwardXP() {
  const d = loadXPData();
  if (d.lastDay !== TODAY_KEY) { d.today = {}; d.lastDay = TODAY_KEY; }

  // Prayers
  const PRAYER_NAMES = ['Fajr','Dhuhr','Asr','Maghrib','Isha'];
  let prayerCount = 0;
  PRAYER_NAMES.forEach(p => {
    if (typeof prayerDone !== 'undefined' && prayerDone[p]) {
      prayerCount++;
      if (!d.today['prayer_' + p]) {
        d.today['prayer_' + p] = true;
        d.total += XP_ACTIONS.prayer;
        showXPToast('+' + XP_ACTIONS.prayer + ' XP · ' + p + ' prayer');
      }
      // Takbir-ul-ula bonus
      if (typeof prayerQuality !== 'undefined' && prayerQuality[p] === 'takbir' && !d.today['takbir_' + p]) {
        d.today['takbir_' + p] = true;
        d.total += XP_ACTIONS.takbirUla;
      }
    }
  });
  // All 5 prayers bonus
  if (prayerCount === 5 && !d.today['allPrayers']) {
    d.today['allPrayers'] = true;
    d.total += XP_ACTIONS.allPrayers;
    showXPToast('+' + XP_ACTIONS.allPrayers + ' XP · All 5 prayers! 🌟');
  }

  // Fasting
  if (typeof fastingData !== 'undefined' && fastingData[TODAY_KEY] && !d.today['fasting']) {
    d.today['fasting'] = true;
    d.total += XP_ACTIONS.fasting;
    showXPToast('+' + XP_ACTIONS.fasting + ' XP · Fasting 🤍');
  }

  // Sunnah
  if (typeof sunnahDone !== 'undefined') {
    const sCount = sunnahDone.filter(Boolean).length;
    const prev = d.today['sunnahCount'] || 0;
    if (sCount > prev) {
      const gained = (sCount - prev) * XP_ACTIONS.sunnahDone;
      d.total += gained;
      d.today['sunnahCount'] = sCount;
    }
  }

  // Activities
  if (typeof todayActs === 'function') {
    const doneCount = todayActs().filter(a => a.done).length;
    const prev = d.today['actCount'] || 0;
    if (doneCount > prev) {
      const gained = (doneCount - prev) * XP_ACTIONS.activityDone;
      d.total += gained;
      d.today['actCount'] = doneCount;
    }
  }

  // Perfect day
  if (typeof calcDayScore === 'function') {
    const score = calcDayScore(TODAY_KEY);
    if (score >= 90 && !d.today['perfectDay']) {
      d.today['perfectDay'] = true;
      d.total += XP_ACTIONS.perfectDay;
      showXPToast('+' + XP_ACTIONS.perfectDay + ' XP · Perfect day! 🏆');
    }
  }

  // Streak bonuses
  if (typeof calcAllFivePrayerStreak === 'function') {
    const streak = calcAllFivePrayerStreak();
    if (streak >= 7 && !d.today['streak7']) {
      d.today['streak7'] = true;
      d.total += XP_ACTIONS.streak7;
      showXPToast('+' + XP_ACTIONS.streak7 + ' XP · 7-day streak! 🔥');
    }
    if (streak >= 30 && !d.today['streak30']) {
      d.today['streak30'] = true;
      d.total += XP_ACTIONS.streak30;
      showXPToast('+' + XP_ACTIONS.streak30 + ' XP · 30-day streak! 🌙');
    }
  }

  const prevTotal = getXP() - d.total; // rough check
  saveXPData(d);

  // Check level-up — only show popup when viewing today
  const prevLv = getLevelForXP(Math.max(0, d.total - 300));
  const newLv  = getLevelForXP(d.total);
  if (newLv.level > prevLv.level) {
    const _isToday2 = (typeof viewingDate === 'undefined' || !viewingDate || viewingDate === TODAY_KEY);
    if (_isToday2) setTimeout(() => showLevelup(newLv), 900);
  }

  setTimeout(renderXPWidget, 200);
}

// Award XP for quran pages changes
function awardQuranPageXP(pages) {
  const d = loadXPData();
  if (d.lastDay !== TODAY_KEY) { d.today = {}; d.lastDay = TODAY_KEY; }
  const prev = d.today['quranPages'] || 0;
  if (pages > prev) {
    const gained = (pages - prev) * XP_ACTIONS.quranPage;
    d.total += gained;
    d.today['quranPages'] = pages;
    saveXPData(d);
    showXPToast('+' + gained + ' XP · Quran reading 📖');
    setTimeout(renderXPWidget, 200);
    // Check level-up — only show popup when viewing today
    const prevLv = getLevelForXP(d.total - gained);
    const newLv  = getLevelForXP(d.total);
    if (newLv.level > prevLv.level) {
      const _isToday3 = (typeof viewingDate === 'undefined' || !viewingDate || viewingDate === TODAY_KEY);
      if (_isToday3) setTimeout(() => showLevelup(newLv), 900);
    }
  }
}

// Hook quran page changes
const _origQrPages = window.qrSetPages;
if (typeof qrSetPages === 'function') {
  window.qrSetPages = function(n) {
    _origQrPages && _origQrPages(n);
    awardQuranPageXP(typeof quranData !== 'undefined' ? quranData.pages : 0);
  };
}

// ══════════════════════════════════════════════════
// ✦ RENDER XP WIDGET
// ══════════════════════════════════════════════════
function renderXPWidget() {
  const el = document.getElementById('xp-widget');
  if (!el) return;

  const xp       = getXP();
  const curLv    = getLevelForXP(xp);
  const nextLv   = getNextLevelForXP(xp);
  const streak   = typeof calcAllFivePrayerStreak === 'function' ? calcAllFivePrayerStreak() : 0;
  const barPct   = nextLv ? Math.min(100, ((xp - curLv.xpNeeded) / (nextLv.xpNeeded - curLv.xpNeeded)) * 100) : 100;
  const d        = loadXPData();
  const todayActs_done = (typeof todayActs === 'function' ? todayActs().filter(a => a.done).length : 0);
  const prayersDone  = typeof prayerDone !== 'undefined' ? Object.values(prayerDone).filter(Boolean).length : 0;

  // Recent XP sources
  const chips = [
    { icon: '🕌', label: prayersDone + '/5 Prayers', pts: prayersDone * XP_ACTIONS.prayer, earned: prayersDone > 0 },
    { icon: '📖', label: 'Quran', pts: (d.today?.quranPages||0) * XP_ACTIONS.quranPage, earned: (d.today?.quranPages||0) > 0 },
    { icon: '🌙', label: 'Fasting', pts: XP_ACTIONS.fasting, earned: !!d.today?.fasting },
    { icon: '📿', label: 'Sunnah', pts: (d.today?.sunnahCount||0) * XP_ACTIONS.sunnahDone, earned: (d.today?.sunnahCount||0) > 0 },
    { icon: '✅', label: 'Activities', pts: (d.today?.actCount||0) * XP_ACTIONS.activityDone, earned: (d.today?.actCount||0) > 0 },
  ];

  el.innerHTML = `
    <div class="xp-inner">
      <div class="xp-top-row">
        <div class="xp-flame-wrap">
          <span class="xp-flame">${streak > 0 ? '🔥' : '💧'}</span>
          <div class="xp-flame-ring"></div>
          ${streak > 0 ? `<span class="xp-streak-num">${streak}</span>` : ''}
        </div>
        <div class="xp-info">
          <div class="xp-level-row">
            <span class="xp-level-badge">Lvl ${curLv.level}</span>
            <span class="xp-level-name">${curLv.icon} ${curLv.name}</span>
          </div>
          <div class="xp-subtitle">${nextLv ? `${(nextLv.xpNeeded - xp).toLocaleString()} XP to ${nextLv.name}` : '✦ Max Level Reached'}</div>
        </div>
        <div class="xp-right">
          <div class="xp-pts">${xp.toLocaleString()}</div>
          <div class="xp-pts-lbl">Total XP</div>
        </div>
      </div>
      <div class="xp-bar-wrap">
        <div class="xp-bar-fill" style="width:${barPct}%"></div>
      </div>
      <div class="xp-bar-labels">
        <span>${curLv.xpNeeded.toLocaleString()} XP</span>
        <span>${nextLv ? nextLv.xpNeeded.toLocaleString() + ' XP' : 'MAX'}</span>
      </div>
      <div class="xp-actions">
        ${chips.map(c => `
          <div class="xp-action-chip ${c.earned ? 'earned' : ''}">
            <span>${c.icon}</span>
            <span>${c.label}</span>
            <span class="chip-pts">+${c.pts}</span>
          </div>`).join('')}
      </div>
    </div>`;
}

// ══════════════════════════════════════════════════
// ✦ STATS: STREAK HISTORY CALENDAR (last 5 weeks)
// ══════════════════════════════════════════════════
function renderStreakCalendar() {
  const wrap = document.getElementById('streak-cal-section');
  if (!wrap) return;

  const DAYS = ['Su','Mo','Tu','We','Th','Fr','Sa'];
  // Build 35 days back from today (5 weeks)
  const cells = [];
  const today  = new Date(now);

  // Fill leading empty cells so week starts on Sunday
  const startDay = new Date(today);
  startDay.setDate(today.getDate() - 34);
  const offset = startDay.getDay(); // 0=Sun
  for (let i = 0; i < offset; i++) cells.push(null);

  for (let i = 34; i >= 0; i--) {
    const d = new Date(today); d.setDate(today.getDate() - i);
    cells.push(d);
  }

  // Score each day
  function scoreClass(key) {
    const s = typeof calcDayScore === 'function' ? calcDayScore(key) : 0;
    if (s === 0) return 'sc-none';
    if (s < 40)  return 'sc-low';
    if (s < 70)  return 'sc-mid';
    if (s < 90)  return 'sc-high';
    return 'sc-perfect';
  }

  // Current streak
  let streak = 0;
  for (let i = 0; i < 365; i++) {
    const d2 = new Date(today); d2.setDate(today.getDate() - i);
    const k = dateKey(d2);
    const pDone = k === TODAY_KEY ? prayerDone : (daily[k]?.prayers || {});
    if (Object.values(pDone).filter(Boolean).length > 0) streak++;
    else if (i > 0) break;
  }

  // Best streak
  let bestStreak = 0, cur = 0;
  for (let i = 364; i >= 0; i--) {
    const d2 = new Date(today); d2.setDate(today.getDate() - i);
    const k = dateKey(d2);
    const pDone = k === TODAY_KEY ? prayerDone : (daily[k]?.prayers || {});
    if (Object.values(pDone).filter(Boolean).length > 0) { cur++; bestStreak = Math.max(bestStreak, cur); }
    else cur = 0;
  }

  // Active days (any score > 0)
  let activeDays = 0;
  for (let i = 0; i < 35; i++) {
    const d2 = new Date(today); d2.setDate(today.getDate() - i);
    const k = dateKey(d2);
    if ((typeof calcDayScore === 'function' ? calcDayScore(k) : 0) > 0) activeDays++;
  }

  const todayKey = TODAY_KEY;

  wrap.innerHTML = `
    <div class="streak-cal-wrap">
      <div class="streak-cal-grid">
        ${DAYS.map(d => `<div class="streak-cal-dow">${d}</div>`).join('')}
        ${cells.map(d => {
          if (!d) return '<div class="streak-cal-day sc-empty"></div>';
          const k = dateKey(d);
          const cls = scoreClass(k) + (k === todayKey ? ' sc-today' : '');
          const score = typeof calcDayScore === 'function' ? calcDayScore(k) : 0;
          return `<div class="streak-cal-day ${cls}" title="${d.toLocaleDateString('en-GB',{day:'numeric',month:'short'})} · ${score}%">${d.getDate()}</div>`;
        }).join('')}
      </div>
      <div class="streak-cal-legend">
        <span>None</span>
        <div class="streak-cal-legend-dot" style="background:rgba(var(--accent-rgb),.12)"></div>
        <div class="streak-cal-legend-dot" style="background:rgba(var(--accent-rgb),.25)"></div>
        <div class="streak-cal-legend-dot" style="background:rgba(var(--accent-rgb),.45)"></div>
        <div class="streak-cal-legend-dot" style="background:var(--gold)"></div>
        <span>Perfect</span>
      </div>
      <div class="streak-cal-summary">
        <div class="sc-stat">
          <div class="sc-stat-val">${streak}</div>
          <div class="sc-stat-lbl">Day Streak</div>
        </div>
        <div class="sc-stat">
          <div class="sc-stat-val">${bestStreak}</div>
          <div class="sc-stat-lbl">Best Streak</div>
        </div>
        <div class="sc-stat">
          <div class="sc-stat-val">${activeDays}</div>
          <div class="sc-stat-lbl">Active / 35d</div>
        </div>
      </div>
    </div>`;
}

// ══════════════════════════════════════════════════
// ✦ STATS: BEST / WORST DAY SUMMARY
// ══════════════════════════════════════════════════
function renderBestWorstDay() {
  const wrap = document.getElementById('bw-section');
  if (!wrap) return;

  let best = null, worst = null;
  // Scan last 60 days
  for (let i = 0; i < 60; i++) {
    const d = new Date(now); d.setDate(d.getDate() - i);
    const k = dateKey(d);
    const score = typeof calcDayScore === 'function' ? calcDayScore(k) : 0;
    if (score === 0) continue;
    if (!best  || score > best.score)  best  = { key: k, score, date: d };
    if (!worst || score < worst.score) worst = { key: k, score, date: d };
  }

  function fmt(d) { return d ? d.toLocaleDateString('en-GB',{weekday:'short',day:'numeric',month:'short'}) : '—'; }
  function desc(score) {
    if (score >= 90) return 'Near-perfect ibadah 🌟';
    if (score >= 70) return 'Strong day of worship';
    if (score >= 50) return 'Moderate practice';
    if (score >= 30) return 'Light practice';
    return 'A tough day';
  }

  wrap.innerHTML = `
    <div class="bw-grid">
      <div class="bw-card" style="border-color:rgba(var(--green-rgb),.2)">
        <div class="bw-label" style="color:var(--green)">✦ Best Day</div>
        <div class="bw-score" style="color:var(--green)">${best ? best.score + '%' : '—'}</div>
        <div class="bw-date">${best ? fmt(best.date) : 'No data yet'}</div>
        <div class="bw-desc">${best ? desc(best.score) : 'Start tracking today'}</div>
      </div>
      <div class="bw-card" style="border-color:rgba(var(--rose-rgb),.2)">
        <div class="bw-label" style="color:var(--rose)">↓ Lowest Day</div>
        <div class="bw-score" style="color:var(--rose)">${worst ? worst.score + '%' : '—'}</div>
        <div class="bw-date">${worst ? fmt(worst.date) : 'No data yet'}</div>
        <div class="bw-desc">${worst ? desc(worst.score) : 'Start tracking today'}</div>
      </div>
    </div>`;
}

// ══════════════════════════════════════════════════
// ✦ STATS: MONTHLY QURAN PAGES TREND CHART
// ══════════════════════════════════════════════════
function renderQuranMonthChart() {
  const wrap = document.getElementById('quran-month-chart');
  if (!wrap) return;

  // Build last 8 months of data
  const months = [];
  const today = new Date(now);

  for (let m = 7; m >= 0; m--) {
    const d = new Date(today.getFullYear(), today.getMonth() - m, 1);
    const label = d.toLocaleDateString('en-GB', { month: 'short' });
    const year  = d.getFullYear();
    const month = d.getMonth();

    // Sum pages for this month from daily data
    let pages = 0;
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    for (let day = 1; day <= daysInMonth; day++) {
      const dd = new Date(year, month, day);
      if (dd > today) break;
      const k = dateKey(dd);
      const snap = daily[k];
      if (k === TODAY_KEY) pages += quranData.pages || 0;
      else if (snap?.quranPages) pages += snap.quranPages;
    }
    const isCurrent = (month === today.getMonth() && year === today.getFullYear());
    months.push({ label, pages, isCurrent });
  }

  const maxPages = Math.max(...months.map(m => m.pages), 1);
  const avgPages = Math.round(months.reduce((s, m) => s + m.pages, 0) / months.length);
  const totalPages = months.reduce((s, m) => s + m.pages, 0);
  const bestMonth = months.reduce((best, m) => m.pages > best.pages ? m : best, months[0]);
  const avgPct = (avgPages / maxPages) * 100;

  wrap.innerHTML = `
    <div class="qtr-wrap">
      <div class="qtr-chart">
        <div class="qtr-baseline"></div>
        ${avgPages > 0 ? `<div class="qtr-avg-line" style="bottom:${avgPct}%"><span class="qtr-avg-lbl">avg</span></div>` : ''}
        ${months.map(m => {
          const pct = maxPages > 0 ? (m.pages / maxPages) * 76 : 0;
          return `
            <div class="qtr-bar-col">
              <div class="qtr-bar ${m.isCurrent ? 'current-month' : ''}" style="height:${Math.max(pct, m.pages > 0 ? 8 : 3)}px" title="${m.label}: ${m.pages} pages"></div>
              <div class="qtr-bar-lbl">${m.label}</div>
            </div>`;
        }).join('')}
      </div>
      <div class="qtr-summary">
        <div class="qtr-stat">
          <div class="qtr-stat-val">${totalPages}</div>
          <div class="qtr-stat-lbl">8-Mo Total</div>
        </div>
        <div class="qtr-stat">
          <div class="qtr-stat-val">${avgPages}</div>
          <div class="qtr-stat-lbl">Monthly Avg</div>
        </div>
        <div class="qtr-stat">
          <div class="qtr-stat-val">${bestMonth.label}</div>
          <div class="qtr-stat-lbl">Best Month</div>
        </div>
      </div>
    </div>`;
}

// ══════════════════════════════════════════════════
// ✦ QURAN: READING TIME ESTIMATE
// ══════════════════════════════════════════════════
// Average reading speed: ~150-170 words/min Arabic. Approx 12 words/ayah.
function estimateReadTime(ayatCount) {
  const words = ayatCount * 12;
  const mins  = Math.round(words / 160);
  if (mins < 1) return '< 1 min';
  if (mins < 60) return mins + ' min';
  return Math.round(mins / 60) + 'h ' + (mins % 60) + 'm';
}

// Patch svRenderList to add reading time
const _origSvRenderList = window.svRenderList;
if (typeof svRenderList === 'function') {
  window.svRenderList = function() {
    // Call original then patch in reading times
    _origSvRenderList && _origSvRenderList();
    // Add reading time to each row's meta
    if (typeof SV_SURAHS !== 'undefined') {
      SV_SURAHS.forEach(s => {
        const row = document.getElementById('sv-row-' + s.n);
        if (!row) return;
        const meta = row.querySelector('.sv-row-meta');
        if (!meta || meta.querySelector('.sv-read-time')) return;
        const rt = document.createElement('span');
        rt.className = 'sv-read-time';
        rt.textContent = estimateReadTime(s.ayat);
        meta.appendChild(rt);
      });
    }
  };
}

// ══════════════════════════════════════════════════
// ✦ INJECT XP WIDGET INTO HOME VIEW
// ══════════════════════════════════════════════════
function injectXPWidget() {
  if (document.getElementById('xp-widget')) { renderXPWidget(); return; }
  const streakRow = document.getElementById('streak-row');
  if (!streakRow) return;
  const widget = document.createElement('div');
  widget.id = 'xp-widget';
  widget.onclick = () => {
    // Navigate to stats
    const statsBtn = document.querySelector('.nb[data-view="stats"]');
    if (statsBtn) statsBtn.click();
  };
  streakRow.parentNode.insertBefore(widget, streakRow.nextSibling);
  renderXPWidget();
}

// ══════════════════════════════════════════════════
// ✦ INJECT NEW STATS SECTIONS
// ══════════════════════════════════════════════════
function injectStatsSections() {
  const noteSlider = document.querySelector('#stats-content-wrap .sp-section:last-child');
  if (!noteSlider) return;

  // Only inject once
  if (document.getElementById('bw-section')) return;

  // 1. Best/Worst Day
  const bwSection = document.createElement('div');
  bwSection.className = 'sp-section';
  bwSection.innerHTML = `
    <div class="sp-lbl">✦ Best &amp; Lowest Day</div>
    <div id="bw-section"></div>`;

  // 2. Streak Calendar
  const calSection = document.createElement('div');
  calSection.className = 'sp-section';
  calSection.innerHTML = `
    <div class="sp-lbl">Streak History</div>
    <div id="streak-cal-section"></div>`;

  // 3. Quran Monthly Chart
  const quranSection = document.createElement('div');
  quranSection.className = 'sp-section';
  quranSection.innerHTML = `
    <div class="sp-lbl">📖 Quran — Monthly Pages</div>
    <div id="quran-month-chart"></div>`;

  // Insert before notes slider
  noteSlider.parentNode.insertBefore(bwSection, noteSlider);
  noteSlider.parentNode.insertBefore(calSection, noteSlider);
  noteSlider.parentNode.insertBefore(quranSection, noteSlider);
}

// ══════════════════════════════════════════════════
// ✦ HOOK PERSIST TO AWARD XP
// ══════════════════════════════════════════════════
const _origPersistFn = window.persist;
window.persist = function() {
  if (typeof _origPersistFn === 'function') _origPersistFn();
  try { _calcAndAwardXP(); } catch(e) {}
};

// ══════════════════════════════════════════════════
// ✦ INITIALISE ON DOM READY
// ══════════════════════════════════════════════════
function initNewFeatures() {
  // ── Settings-derived UI (merged from earlier definition) ──
  renderNiyyahBanner();
  applyHomeSections();
  applyFocusMode();
  if (appSettings.ishraqNudge === false) {
    const nudgeEl = document.getElementById('ishraq-nudge');
    if (nudgeEl) nudgeEl.style.display = 'none';
  }

  // ── XP widget + extended stats sections ──
  injectXPWidget();
  injectStatsSections();
  renderBestWorstDay();
  renderStreakCalendar();
  renderQuranMonthChart();

  // Re-render stats sections when stats view is opened
  const statsBtn = document.querySelector('.nb[data-view="stats"]');
  if (statsBtn) {
    statsBtn.addEventListener('click', () => {
      setTimeout(() => {
        renderBestWorstDay();
        renderStreakCalendar();
        renderQuranMonthChart();
      }, 80);
    });
  }

  // Also hook into renderStats
  const _origRenderStats = window.renderStats;
  if (typeof _origRenderStats === 'function') {
    window.renderStats = function() {
      _origRenderStats();
      injectStatsSections();
      setTimeout(() => {
        renderBestWorstDay();
        renderStreakCalendar();
        renderQuranMonthChart();
      }, 60);
    };
  }

  // Patch svRenderList for reading time
  const _origSVRL = window.svRenderList;
  if (typeof _origSVRL === 'function' && _origSVRL !== window.svRenderList) {
    window.svRenderList = function() {
      _origSVRL();
      if (typeof SV_SURAHS !== 'undefined') {
        SV_SURAHS.forEach(s => {
          const row = document.getElementById('sv-row-' + s.n);
          if (!row) return;
          const meta = row.querySelector('.sv-row-meta');
          if (!meta || meta.querySelector('.sv-read-time')) return;
          const rt = document.createElement('span');
          rt.className = 'sv-read-time';
          rt.textContent = estimateReadTime(s.ayat);
          meta.appendChild(rt);
        });
      }
    };
  }
}

// Call once here — this is the correct definition (merged, complete).
// The first script block's call was removed since this definition lives in script block 2.
initNewFeatures();

// ── Prayer strip: swipe left/right to navigate dates ──────────────────────
(function() {
  // We patch switchDate to suppress smoothScrollToList during prayer swipe
  // (bare function calls can't be intercepted via window.xxx override)
  let _swipeNav = false;

  function offsetDate(key, delta) {
    const [y, m, d] = key.split('-').map(Number);
    const dt = new Date(y, m - 1, d);
    dt.setDate(dt.getDate() + delta);
    return dateKey(dt);
  }

  function clampDate(key) {
    if (key >= TODAY_KEY) return TODAY_KEY;
    const limit = offsetDate(TODAY_KEY, -90);
    if (key < limit) return limit;
    return key;
  }

  function updatePrayerDateLabel(key) {
    const el = document.getElementById('prayer-date-nav-label');
    if (!el) return;
    if (key === TODAY_KEY) {
      el.textContent = 'Today';
      el.style.color = 'var(--gold)';
      el.style.borderColor = 'rgba(var(--accent-rgb),.2)';
    } else {
      const [y, m, d] = key.split('-').map(Number);
      const dt = new Date(y, m - 1, d);
      const yesterday = offsetDate(TODAY_KEY, -1);
      el.textContent = key === yesterday
        ? 'Yesterday'
        : dt.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
      el.style.color = 'var(--t2)';
      el.style.borderColor = 'rgba(255,255,255,.12)';
    }
  }

  function navigatePrayerDate(delta) {
    const newKey = clampDate(offsetDate(viewingDate, delta));
    if (newKey === viewingDate) return;

    _swipeNav = true;
    switchDate(newKey);
    updatePrayerDateLabel(newKey);
    _swipeNav = false;

    // Animate prayer row slide
    const row = document.getElementById('prayer-row');
    if (row) {
      row.style.transition = 'opacity .14s, transform .14s';
      row.style.opacity = '0';
      row.style.transform = `translateX(${delta > 0 ? '-14px' : '14px'})`;
      setTimeout(() => {
        row.style.opacity = '1';
        row.style.transform = 'translateX(0)';
        setTimeout(() => { row.style.transition = ''; row.style.transform = ''; }, 160);
      }, 140);
    }
  }

  function injectPrayerDateNav() {
    if (document.getElementById('prayer-date-nav-label')) return;
    const strip = document.getElementById('prayer-strip-fixed');
    if (!strip) return;
    const headerRow = strip.querySelector(':scope > div');
    if (!headerRow) return;

    const label = document.createElement('span');
    label.id = 'prayer-date-nav-label';
    label.textContent = 'Today';
    label.style.cssText = 'font-size:0.5rem;letter-spacing:.1em;color:var(--gold);font-weight:600;font-family:Outfit,sans-serif;cursor:pointer;-webkit-tap-highlight-color:transparent;padding:2px 8px;border-radius:99px;background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.2);transition:color .2s,border-color .2s;white-space:nowrap;flex-shrink:0';
    label.onclick = () => {
      if (viewingDate !== TODAY_KEY) {
        switchDate(TODAY_KEY);
        updatePrayerDateLabel(TODAY_KEY);
      }
    };

    const badge = document.getElementById('prayer-streak-badge');
    if (badge && badge.parentNode === headerRow) {
      badge.insertAdjacentElement('afterend', label);
    } else {
      const spacer = headerRow.querySelector('div[style*="flex:1"]');
      if (spacer) headerRow.insertBefore(label, spacer);
      else headerRow.appendChild(label);
    }
  }

  function initPrayerSwipe() {
    injectPrayerDateNav();
    const strip = document.getElementById('prayer-strip-fixed');
    if (!strip || strip._swipeInit) return;
    strip._swipeInit = true;

    // Patch window.smoothScrollToList — switchDate now calls it via window.xxx
    // so this override correctly suppresses scroll during swipe
    const _origSSL = window.smoothScrollToList;
    window.smoothScrollToList = function() {
      if (_swipeNav) return;
      if (typeof _origSSL === 'function') _origSSL.apply(this, arguments);
    };

    // Expose label updater so switchDate can call it for non-swipe navigation too
    window._updatePrayerDateLabel = updatePrayerDateLabel;

    let startX = 0, startY = 0, didMove = false;

    strip.addEventListener('touchstart', e => {
      startX = e.touches[0].clientX;
      startY = e.touches[0].clientY;
      didMove = false;
    }, { passive: true });

    strip.addEventListener('touchmove', () => { didMove = true; }, { passive: true });

    strip.addEventListener('touchend', e => {
      if (!didMove) return;
      const dx = e.changedTouches[0].clientX - startX;
      const dy = e.changedTouches[0].clientY - startY;
      if (Math.abs(dx) < 45 || Math.abs(dy) > Math.abs(dx) * 0.75) return;
      // Swipe right = previous day, swipe left = next day (toward today)
      navigatePrayerDate(dx > 0 ? -1 : 1);
    }, { passive: true });
  }

  document.addEventListener('DOMContentLoaded', () => setTimeout(initPrayerSwipe, 500));
})();

// ══ PREMIUM AUDIO SETTINGS UI ══
const QRAS_RECITERS = [
  { id: 'Alafasy_128kbps',               name: 'Mishary Alafasy',        style: 'Murattal · Egypt',         emoji: '🎙️' },
  { id: 'AbdurRahmaanAs-Sudais_192kbps', name: 'Abdurrahman As-Sudais',  style: 'Murattal · Saudi Arabia',  emoji: '🕌' },
  { id: 'Husary_128kbps',                name: 'Mahmoud Khalil Husary',  style: 'Murattal · Egypt',         emoji: '📖' },
  { id: 'Minshawy_Murattal_128kbps',     name: 'Mohamed S. Minshawi',    style: 'Murattal · Egypt',         emoji: '✨' },
  { id: 'Muhammad_Ayyoub_128kbps',       name: 'Muhammad Ayyoub',        style: 'Murattal · Saudi Arabia',  emoji: '🌙' },
  { id: 'Hani_Rifai_192kbps',            name: 'Hani Rifai',             style: 'Murattal · Saudi Arabia',  emoji: '🎵' },
  { id: 'Maher_AlMuaiqly_128kbps',       name: 'Maher Al-Muaiqly',       style: 'Murattal · Saudi Arabia',  emoji: '⭐' },
  { id: 'Ghamadi_40kbps',                name: 'Saad Al-Ghamdi',         style: 'Murattal · Saudi Arabia',  emoji: '🌟' },
  { id: 'Ibrahim_Akhdar_32kbps',         name: 'Ibrahim Al-Akhdar',      style: 'Murattal · Saudi Arabia',  emoji: '🌿' },
  { id: 'Abdullah_Basfar_192kbps',       name: 'Abdullah Basfar',        style: 'Murattal · Saudi Arabia',  emoji: '💎' },
  { id: 'Sahl_Yasin_128kbps',            name: 'Sahl Yasin',             style: 'Murattal · Egypt',         emoji: '🔆' },
  { id: 'Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah', name: 'Ahmed Al-Ajamy', style: 'Murattal · Saudi Arabia', emoji: '🌙' },
];

function qrasBuildReciterGrid() {
  const grid = document.getElementById('qras-reciter-grid');
  if (!grid) return;
  const current = _qrState.reciter;
  grid.innerHTML = QRAS_RECITERS.map(r => `
    <div class="qras-reciter-card ${r.id === current ? 'active' : ''}" onclick="qrasSelectReciter('${r.id}',this)">
      <div class="qras-reciter-avatar">${r.emoji}</div>
      <div class="qras-reciter-info">
        <div class="qras-reciter-name">${r.name}</div>
        <div class="qras-reciter-style">${r.style}</div>
      </div>
      <div class="qras-reciter-check">✓</div>
    </div>`).join('');
}

function qrasSelectReciter(id, cardEl) {
  document.querySelectorAll('.qras-reciter-card').forEach(c => c.classList.remove('active'));
  if (cardEl) cardEl.classList.add('active');
  qrAudioSetReciter(id);
  // Keep hidden compat select in sync
  const ms = document.getElementById('qr-menu-reciter');
  if (ms) ms.value = id;
}

function qrasSetSpeed(btn) {
  document.querySelectorAll('.qras-speed-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const v = parseFloat(btn.dataset.speed);
  qrAudioSetSpeed(v);
  // Keep hidden compat select in sync
  const ms = document.getElementById('qr-menu-speed');
  if (ms) ms.value = String(v);
}

function qrasRefreshToggles() {
  // Auto-play card
  const ap = document.getElementById('qras-autoplay-card');
  if (ap) ap.classList.toggle('active', !!_qrState.audioOn);
  // Repeat card
  const rp = document.getElementById('qras-repeat-card');
  if (rp) rp.classList.toggle('active', !!_qrAudioRepeat);
  // Update hidden compat values (qrUpdateMenuState reads these)
  const apVal = document.getElementById('qr-menu-audio-val');
  if (apVal) { apVal.textContent = _qrState.audioOn ? 'On' : 'Off'; apVal.className = 'qr-sheet-row-val' + (_qrState.audioOn ? ' on' : ''); }
  const rpVal = document.getElementById('qr-menu-repeat-val');
  if (rpVal) { rpVal.textContent = _qrAudioRepeat ? 'On' : 'Off'; rpVal.className = 'qr-sheet-row-val' + (_qrAudioRepeat ? ' on' : ''); }
}

function qrasRefreshSpeed() {
  const cur = String(_qrAudioSpeed);
  document.querySelectorAll('.qras-speed-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.speed === cur);
  });
}

// Patch qrOpenMenu to also build new UI
const _origQrOpenMenu = typeof qrOpenMenu === 'function' ? qrOpenMenu : null;
window.qrOpenMenu = function() {
  if (_origQrOpenMenu) _origQrOpenMenu();
  qrasBuildReciterGrid();
  qrasRefreshToggles();
  qrasRefreshSpeed();
};

// Re-export so other code calling it still works
// ══ AYAH DONE PROGRESS — surah completion celebration ══
function _qrCelebrateSurahComplete() {
  const surah = (typeof SURAHS !== 'undefined' ? SURAHS : []).find(s => s.n === _qrState.surahNum)
             || { en: 'Surah', n: _qrState.surahNum };

  // Flash the done bar gold
  const fill = document.getElementById('qr-done-fill');
  if (fill) {
    fill.style.transition = 'width .4s, box-shadow .4s';
    fill.style.boxShadow  = '0 0 12px rgba(var(--accent-rgb),.6)';
    setTimeout(() => { if(fill) fill.style.boxShadow = ''; }, 1800);
  }

  // Toast banner
  const toast = document.createElement('div');
  toast.style.cssText = [
    'position:fixed;left:50%;transform:translateX(-50%) translateY(0)',
    'bottom:120px;z-index:9999',
    'background:linear-gradient(135deg,rgba(18,14,8,.97),rgba(12,10,6,.97))',
    'border:1px solid rgba(var(--accent-rgb),.45)',
    'border-radius:20px;padding:14px 22px',
    'display:flex;flex-direction:column;align-items:center;gap:4px',
    'box-shadow:0 8px 32px rgba(0,0,0,.6),0 0 0 1px rgba(var(--accent-rgb),.1)',
    'backdrop-filter:blur(20px)',
    'animation:qrToastIn .38s cubic-bezier(.34,1.56,.64,1) both',
    'max-width:280px;text-align:center',
  ].join(';');
  toast.innerHTML = `
    <div style="font-size:1.5rem;margin-bottom:2px">✦</div>
    <div style="font-size:0.875rem;font-family:'Playfair Display',serif;color:var(--gold);font-weight:600;letter-spacing:.02em">${surah.en} Complete</div>
    <div style="font-size:0.5625rem;color:var(--t3);letter-spacing:.1em;text-transform:uppercase">All ayahs marked · MashAllah!</div>
  `;
  document.body.appendChild(toast);

  // Inject keyframe if needed
  if (!document.getElementById('qr-toast-kf')) {
    const st = document.createElement('style');
    st.id = 'qr-toast-kf';
    st.textContent = '@keyframes qrToastIn{from{opacity:0;transform:translateX(-50%) translateY(20px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}';
    document.head.appendChild(st);
  }

  setTimeout(() => {
    toast.style.transition = 'opacity .5s, transform .5s';
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-50%) translateY(12px)';
    setTimeout(() => toast.remove(), 520);
  }, 2800);
}

// ══ FULL SURAH READER — open from ayah-by-ayah player ══
function qrOpenFullSurahReader() {
  const surahNum = _qrState.surahNum;
  if (!surahNum) return;

  // Capture current playing ayah before opening
  const playingAyah = _qrState.audioAyah > 0 ? _qrState.audioAyah : null;

  // Open the surah-view feat-page
  openFeatPage('page-surah-view');

  // Open reader panel after page slide animation
  setTimeout(async () => {
    await svOpenReader(surahNum);

    // Sync the playing ayah highlight into the full view
    if (playingAyah) {
      // Set svr state so the row is styled correctly
      svrPlayingAyah = playingAyah;
      svrSurahNum    = surahNum;
      svrIsPlaying   = false; // don't auto-start a second audio — user can tap
      svrRefreshPlayingRow();
      svrUpdateAudioBar();
      // Scroll to playing ayah
      setTimeout(() => {
        const el = document.getElementById('sv-ayah-' + playingAyah);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 380);
    }
  }, 320);
}

// Show the Full View button in the reader header whenever a surah is loaded
function _qrShowFullViewBtn(show) {
  const btn = document.getElementById('qr-fullview-btn');
  if (btn) btn.style.display = show ? 'inline-flex' : 'none';
}

// Watch surah title element for changes to toggle the Full View button
(function() {
  function hookTitleObserver() {
    const titleEl = document.getElementById('qr-surah-title');
    if (!titleEl) return;
    const obs = new MutationObserver(() => {
      _qrShowFullViewBtn(!!_qrState.surahNum);
    });
    obs.observe(titleEl, { childList: true, characterData: true, subtree: true });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', hookTitleObserver);
  } else {
    hookTitleObserver();
  }
})();

// Re-run XP widget render periodically to stay fresh

// Re-run XP widget render periodically to stay fresh
setInterval(() => {
  if (document.getElementById('xp-widget')) renderXPWidget();
}, 30000);

// ── Hide nav when any popup/modal/overlay is open ──────────────────────────
(function() {
  const NAV_SELECTORS = [
    '.ovl',
    '#profile-modal',
    '.asma-detail-ovl',
    '#celebration-modal',
  ];

  function isAnyOpen() {
    return NAV_SELECTORS.some(sel =>
      document.querySelector(sel + '.open')
    );
  }

  function syncNavVisibility() {
    const nav  = document.getElementById('main-nav');
    const qnav = document.getElementById('quick-nav');
    // Don't interfere if a feat-page is already hiding nav
    if (document.querySelector('.feat-page.open')) return;
    if (!nav) return;

    if (isAnyOpen()) {
      // Hide nav
      nav.style.transition    = 'opacity .18s, transform .18s';
      nav.style.opacity       = '0';
      nav.style.transform     = 'translateY(12px)';
      nav.style.pointerEvents = 'none';
      if (qnav) { qnav.style.opacity = '0'; qnav.style.pointerEvents = 'none'; }
    } else {
      // Show nav
      nav.style.transition    = 'opacity .25s, transform .25s cubic-bezier(.22,1,.36,1)';
      nav.style.opacity       = '1';
      nav.style.transform     = 'translateY(0)';
      nav.style.pointerEvents = '';
      if (qnav) { qnav.style.opacity = ''; qnav.style.pointerEvents = ''; }
      setTimeout(() => {
        if (nav && !isAnyOpen()) {
          nav.style.transition = '';
          nav.style.opacity    = '';
          nav.style.transform  = '';
        }
      }, 300);
    }
  }

  // Observe class changes on the whole document body
  const obs = new MutationObserver(mutations => {
    for (const m of mutations) {
      if (m.type === 'attributes' && m.attributeName === 'class') {
        const el = m.target;
        const isOverlay = NAV_SELECTORS.some(sel => el.matches(sel));
        if (isOverlay) { syncNavVisibility(); return; }
      }
    }
  });

  document.addEventListener('DOMContentLoaded', () => {
    obs.observe(document.body, {
      subtree: true,
      attributes: true,
      attributeFilter: ['class'],
    });
  });
})();
// ══════════════════════════════════════════════
// TAFSIR EXPLORER
// ══════════════════════════════════════════════

const TAFSIR_SURAHS = [
  {num:1,name:"Al-Fatihah",arabic:"الفاتحة",ayahs:7,theme:"Opening prayer — the essence of all worship"},
  {num:2,name:"Al-Baqarah",arabic:"البقرة",ayahs:286,theme:"Guidance, law, stories of Bani Israel"},
  {num:3,name:"Al-Imran",arabic:"آل عمران",ayahs:200,theme:"Family of Imran, unity of believers"},
  {num:4,name:"An-Nisa",arabic:"النساء",ayahs:176,theme:"Rights of women, family law, justice"},
  {num:5,name:"Al-Maidah",arabic:"المائدة",ayahs:120,theme:"The table spread, covenants, halal/haram"},
  {num:6,name:"Al-Anam",arabic:"الأنعام",ayahs:165,theme:"Tawheed, prophethood, cattle laws"},
  {num:7,name:"Al-Araf",arabic:"الأعراف",ayahs:206,theme:"The Heights, stories of past nations"},
  {num:8,name:"Al-Anfal",arabic:"الأنفال",ayahs:75,theme:"Battle of Badr, war ethics, spoils"},
  {num:9,name:"At-Tawbah",arabic:"التوبة",ayahs:129,theme:"Repentance, hypocrites, jihaad"},
  {num:10,name:"Yunus",arabic:"يونس",ayahs:109,theme:"Prophet Yunus, divine mercy"},
  {num:11,name:"Hud",arabic:"هود",ayahs:123,theme:"Prophet Hud, steadfastness"},
  {num:12,name:"Yusuf",arabic:"يوسف",ayahs:111,theme:"The most beautiful story — Prophet Yusuf"},
  {num:13,name:"Ar-Ra'd",arabic:"الرعد",ayahs:43,theme:"Thunder, signs of Allah in creation"},
  {num:14,name:"Ibrahim",arabic:"إبراهيم",ayahs:52,theme:"Prophet Ibrahim's gratitude and prayer"},
  {num:15,name:"Al-Hijr",arabic:"الحجر",ayahs:99,theme:"The rocky tract, the Quran's preservation"},
  {num:16,name:"An-Nahl",arabic:"النحل",ayahs:128,theme:"The Bee, blessings of Allah"},
  {num:17,name:"Al-Isra",arabic:"الإسراء",ayahs:111,theme:"Night Journey, moral commandments"},
  {num:18,name:"Al-Kahf",arabic:"الكهف",ayahs:110,theme:"The Cave — trials of faith, wealth, knowledge, power"},
  {num:19,name:"Maryam",arabic:"مريم",ayahs:98,theme:"Mary, Zakariyya, Isa — mercy stories"},
  {num:20,name:"Ta-Ha",arabic:"طه",ayahs:135,theme:"Prophet Musa, divine address"},
  {num:36,name:"Ya-Sin",arabic:"يس",ayahs:83,theme:"Heart of the Quran — resurrection, prophethood"},
  {num:55,name:"Ar-Rahman",arabic:"الرحمان",ayahs:78,theme:"Which blessings of your Lord will you deny?"},
  {num:67,name:"Al-Mulk",arabic:"الملك",ayahs:30,theme:"Sovereignty of Allah, life and death"},
  {num:78,name:"An-Naba",arabic:"النبأ",ayahs:40,theme:"The Great News — Day of Judgment"},
  {num:112,name:"Al-Ikhlas",arabic:"الإخلاص",ayahs:4,theme:"Pure monotheism — worth 1/3 of Quran"},
  {num:113,name:"Al-Falaq",arabic:"الفلق",ayahs:5,theme:"Seeking refuge from evil"},
  {num:114,name:"An-Nas",arabic:"الناس",ayahs:6,theme:"Seeking refuge from whispers"},
];

const TAFSIR_DATA = {
  1: {
    title:"Al-Fatihah — The Opening",
    overview:"Al-Fatihah is the foundational surah of the Quran, recited in every rakat of salah. It encapsulates the entire message of Islam: praising Allah, acknowledging His sovereignty, and seeking guidance on the straight path.",
    themes:["Pure Tawheed (monotheism)","Du'a and worship","Divine guidance","Relationship between servant and Lord"],
    virtues:["Called 'Umm al-Quran' (Mother of the Quran)","Contains 7 verses, revealed twice (Makkah & Madinah)","Ibn Masud: 'No prayer is valid without Al-Fatihah' (Bukhari)","A cure for every disease according to multiple narrations"],
    keyAyahs:[
      {ayah:"1:2", arabic:"الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", meaning:"All praise is for Allah, Lord of all worlds", tafsir:"This opening establishes the fundamental Islamic worldview — everything that exists belongs to Allah and all gratitude flows back to Him alone. 'Rabb' encompasses Creator, Sustainer, and Nurturer."},
      {ayah:"1:5", arabic:"إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", meaning:"You alone we worship, You alone we ask for help", tafsir:"The pivot of the surah. Moving from third person (Allah) to second person (You) signals a direct conversation with Allah — the essence of prayer. This ayah alone contains the entire religion: worship + reliance."},
      {ayah:"1:6-7", arabic:"اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ", meaning:"Guide us to the straight path", tafsir:"The most repeated du'a in Islam — said 17+ times daily. Imam Al-Nawawi noted this is a request for divine guidance in every aspect of life, not just religious matters."}
    ],
    lessons:["Gratitude is the foundation of a believer's worldview","Worship and reliance on Allah must go together","Seeking guidance is a daily, lifelong need","Allah's mercy (Rahman) precedes His judgment (Malik)"]
  },
  12: {
    title:"Surah Yusuf — The Best of Stories",
    overview:"Allah calls this 'the best of stories' (12:3). It narrates the life of Prophet Yusuf (Joseph) — from betrayal by his brothers, slavery in Egypt, false accusation, imprisonment, and ultimate elevation to power. It is a story of patience, purity, and divine planning.",
    themes:["Patience in trials (sabr)","Trusting Allah's plan","Forgiveness over revenge","Dreams and their interpretation","Jealousy as a destructive force"],
    virtues:["The only surah narrating one complete story","Revealed during the Year of Sorrow to console the Prophet ﷺ","Contains the longest mention of any prophet's life in the Quran","Ibn Kathir called it 'a source of comfort for the afflicted'"],
    keyAyahs:[
      {ayah:"12:18", arabic:"فَصَبْرٌ جَمِيلٌ وَاللَّهُ الْمُسْتَعَانُ", meaning:"Patience is most fitting. And Allah is the one sought for help", tafsir:"Ya'qub's response upon seeing Yusuf's shirt with false blood. 'Sabr jameel' — beautiful patience — means patience without complaint to other than Allah. Ibn Qayyim said this is the highest station of sabr."},
      {ayah:"12:87", arabic:"إِنَّهُ لَا يَيْأَسُ مِن رَّوْحِ اللَّهِ إِلَّا الْقَوْمُ الْكَافِرُونَ", meaning:"No one despairs of Allah's mercy except the disbelieving people", tafsir:"Yusuf's father instructing his sons — even after 40+ years of separation, he forbids despair. A profound lesson that hope in Allah's mercy is inseparable from faith."},
      {ayah:"12:101", arabic:"رَبِّ قَدْ آتَيْتَنِي مِنَ الْمُلْكِ", meaning:"My Lord, You have given me sovereignty...", tafsir:"Yusuf's final du'a after reunion with his family — he begins with gratitude, not triumph. He asks to die as a Muslim and join the righteous. Power didn't change his humility before Allah."}
    ],
    lessons:["Trials are not punishments — they are preparations","Never reveal blessings to those who envy","Forgiveness is a sign of strength, not weakness","Allah's plan unfolds across years — trust the process","Purity of character is tested most in private"]
  },
  18: {
    title:"Surah Al-Kahf — The Cave",
    overview:"Surah Al-Kahf presents four major stories — the People of the Cave, the Two Men and their Gardens, Musa and Al-Khidr, and Dhul-Qarnayn. Each story addresses one of the four great trials of life: religion, wealth, knowledge, and power.",
    themes:["Trials of faith (deen)","Trials of wealth and arrogance","Trials of knowledge","Trials of power","Protection from the Dajjal"],
    virtues:["Reciting on Fridays protects from Dajjal (Muslim)","First and last 10 ayahs memorized protect from Dajjal's fitnah","Light between two Fridays for the reciter","One of the most recommended weekly recitations"],
    keyAyahs:[
      {ayah:"18:10", arabic:"رَبَّنَا آتِنَا مِن لَّدُنكَ رَحْمَةً وَهَيِّئْ لَنَا مِنْ أَمْرِنَا رَشَدًا", meaning:"Our Lord, grant us mercy from Yourself and prepare for us right guidance in our matter", tafsir:"The du'a of the youth of the cave. They sought divine mercy first, then guidance — acknowledging that right direction is a gift from Allah, not self-achieved."},
      {ayah:"18:46", arabic:"الْمَالُ وَالْبَنُونَ زِينَةُ الْحَيَاةِ الدُّنْيَا", meaning:"Wealth and children are the adornment of worldly life", tafsir:"The key verse of the second story. Wealth and family are beautiful but temporary. The righteous deeds (al-baqiyat al-salihat) are better in reward with your Lord — this is the corrective to materialism."},
      {ayah:"18:65", arabic:"فَوَجَدَا عَبْدًا مِّنْ عِبَادِنَا آتَيْنَاهُ رَحْمَةً مِّنْ عِندِنَا", meaning:"They found a servant of Ours whom We had given mercy from Us", tafsir:"Al-Khidr is described as a 'servant' before a 'scholar'. True divine knowledge comes through servitude and proximity to Allah, not mere academic study."}
    ],
    lessons:["Read Al-Kahf every Friday as a weekly spiritual reset","The greatest protection from materialism is gratitude","True knowledge humbles, never arrogates","Every trial corresponds to a specific test — know which you face","Power without accountability always corrupts"]
  },
  36: {
    title:"Surah Ya-Sin — Heart of the Quran",
    overview:"Called the 'heart of the Quran' by the Prophet ﷺ. It powerfully addresses resurrection, divine signs in creation, the story of the people of Antioch (Antakya), and the fate of those who reject guidance.",
    themes:["Prophethood and rejection","Signs of resurrection","Divine signs in creation","The believing man from the city — standing firm alone","Death and afterlife"],
    virtues:["'Recite Ya-Sin over your dying' — Abu Dawud","Equals 10 recitations of the Quran — Tirmidhi","Called Qalb al-Quran (Heart of the Quran)","Used for blessing major life events in many traditions"],
    keyAyahs:[
      {ayah:"36:12", arabic:"إِنَّا نَحْنُ نُحْيِي الْمَوْتَىٰ وَنَكْتُبُ مَا قَدَّمُوا وَآثَارَهُمْ", meaning:"Indeed it is We who give life to the dead and record what they have put forth and what they left behind", tafsir:"Every deed and its lingering effect (athar) is recorded. Scholars note 'athar' includes knowledge taught, sadaqah jariyah built, and any good that continues after death — making this an encouragement for legacy-building."},
      {ayah:"36:77", arabic:"أَوَلَمْ يَرَ الْإِنسَانُ أَنَّا خَلَقْنَاهُ مِن نُّطْفَةٍ", meaning:"Does man not consider that We created him from a drop of fluid?", tafsir:"The argument for resurrection from the miracle of creation itself. If Allah can create from nothing, resurrection is logically simpler. This is the Quran's consistent response to those who deny the afterlife."}
    ],
    lessons:["Stand for truth even when alone — like the man from the city","Your deeds ripple beyond your lifetime","Creation itself is a proof of resurrection","The Quran's 'heart' reminds us: spiritual life requires nourishment"]
  },
  55: {
    title:"Surah Ar-Rahman — The Most Merciful",
    overview:"One of the most rhythmically beautiful surahs, with its repeating refrain 'Fa-bi-ayyi ala'i Rabbikuma tukaddhiban' (So which of your Lord's favors will you deny?) appearing 31 times. It catalogues Allah's blessings across creation and the afterlife.",
    themes:["Enumeration of divine blessings","Creation as an act of mercy","Balance and justice (mizan)","Jannah and its rewards","Both humans and jinn addressed together"],
    virtues:["Known as 'Bride of the Quran' (Arus al-Quran)","The jinn wept when they heard it and responded honestly to the refrain","Recommended for anyone experiencing ingratitude or depression","Ibn Arabi: 'contains the secrets of divine mercy'"],
    keyAyahs:[
      {ayah:"55:1-4", arabic:"الرَّحْمَٰنُ عَلَّمَ الْقُرْآنَ خَلَقَ الْإِنسَانَ عَلَّمَهُ الْبَيَانَ", meaning:"The Most Merciful — taught the Quran — created man — taught him speech", tafsir:"Allah's first gift mentioned is the Quran, before even the creation of man. Then He taught humans 'bayan' (eloquent speech/expression) — placing language and meaning at the heart of what makes us human."},
      {ayah:"55:60", arabic:"هَلْ جَزَاءُ الْإِحْسَانِ إِلَّا الْإِحْسَانُ", meaning:"Is the reward for excellence anything but excellence?", tafsir:"A principle that applies both to Allah rewarding humans, and to how believers should treat one another. Ihsan (excellence) is answered with ihsan — the universe has a moral symmetry built into it."}
    ],
    lessons:["Gratitude is the correct response to every blessing — small and large","Balance (mizan) is a divine principle — do not violate it","Both this world and the next are filled with Allah's mercy","Denial of blessings is the root of spiritual disease"]
  },
  67: {
    title:"Surah Al-Mulk — Sovereignty",
    overview:"A Makkan surah focusing on Allah's absolute sovereignty, the purpose of death and life (testing who is best in deeds), and the consequence of denying divine signs. It is one of the most important nightly recitations.",
    themes:["Sovereignty belongs only to Allah","Death and life as a divine test","Signs in creation — birds, water, stars","Warning to those who deny the messengers","The Quran's challenge: find any flaw in creation"],
    virtues:["Intercedes for its reciter on the Day of Judgment — Tirmidhi","'Tabarak' — protects from the punishment of the grave — Nasa'i","Ibn Abbas reported the Prophet ﷺ never slept without reciting it","Known as Al-Mani'ah (the Protector) and Al-Waqiyah (the Shield)"],
    keyAyahs:[
      {ayah:"67:2", arabic:"الَّذِي خَلَقَ الْمَوْتَ وَالْحَيَاةَ لِيَبْلُوَكُمْ أَيُّكُمْ أَحْسَنُ عَمَلًا", meaning:"Who created death and life to test you as to which of you is best in deed", tafsir:"Death is listed before life — scholars note this is intentional. Death gives life urgency and meaning. The goal is not the most deeds but the best in quality (ahsan 'amalan). Al-Fudayl ibn Iyad: best deed = most sincere and most correct."},
      {ayah:"67:19", arabic:"أَوَلَمْ يَرَوْا إِلَى الطَّيْرِ فَوْقَهُمْ صَافَّاتٍ وَيَقْبِضْنَ", meaning:"Do they not see the birds above them spreading and folding their wings?", tafsir:"The flight of birds as a sign of Allah's sustaining power — not aerodynamics alone, but divine permission (rahmaan) keeping them aloft. The universe requires constant divine attention to function."}
    ],
    lessons:["Recite Al-Mulk every night before sleep","Quality over quantity in deeds is the Islamic standard","Death is not an ending — it is a door that gives life meaning","Look at creation with wonder — it is all a sign"]
  },
  112: {
    title:"Surah Al-Ikhlas — Pure Sincerity",
    overview:"Four ayahs that define the oneness of Allah completely. The Prophet ﷺ said it equals one third of the Quran in reward because the Quran covers three major themes: stories (qasas), rulings (ahkam), and the Divine attributes (sifat) — and Al-Ikhlas covers the third category entirely.",
    themes:["Absolute Tawheed","Negation of all false concepts of God","Allah's eternal independence (Samad)","Rejection of anthropomorphism"],
    virtues:["Equals 1/3 of the Quran in reward (Bukhari)","Reciting 3× equals completing the full Quran","'Qul huwa Allahu Ahad' — loved by Allah — Bukhari","Used in morning/evening adhkar, after every salah, before sleep"],
    keyAyahs:[
      {ayah:"112:1-4", arabic:"قُلْ هُوَ اللَّهُ أَحَدٌ اللَّهُ الصَّمَدُ لَمْ يَلِدْ وَلَمْ يُولَدْ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", meaning:"Say: He is Allah, One. Allah, the Eternal Refuge. He neither begets nor is born. Nor is there any equivalent to Him.", tafsir:"Each ayah answers a specific false belief about God: 'Ahad' refutes polytheism; 'Samad' refutes the need for children or parents; 'Lam yalid' refutes those who say God has a son; 'Lam yulad' refutes those who trace God's origin; 'Kufuwan Ahad' refutes any comparison to creation."}
    ],
    lessons:["The shortest surah with the deepest theology","Memorize and recite constantly — it purifies Tawheed","Loving this surah is itself a sign of loving Allah","Start every du'a by understanding Who you are speaking to"]
  }
};

let tafsirSelectedSurah = null;

function renderTafsirPage() {
  const body = document.getElementById('tafsir-body');
  if (!body) return;
  tafsirSelectedSurah = null;
  body.innerHTML = `
    <div style="padding:16px">
      <!-- Search -->
      <div style="position:relative;margin-bottom:14px">
        <input id="tafsir-search" type="text" placeholder="Search surah name..."
          oninput="tafsirFilterSurahs(this.value)"
          style="width:100%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:11px 16px 11px 38px;color:var(--text);font-family:'Manrope',sans-serif;font-size:0.8125rem;outline:none;color-scheme:dark">
        <svg style="position:absolute;left:12px;top:50%;transform:translateY(-50%);opacity:.4" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      </div>
      <!-- Surah list -->
      <div id="tafsir-surah-list"></div>
    </div>`;
  tafsirFilterSurahs('');
}

function tafsirFilterSurahs(q) {
  const list = document.getElementById('tafsir-surah-list');
  if (!list) return;
  const filtered = TAFSIR_SURAHS.filter(s =>
    !q || s.name.toLowerCase().includes(q.toLowerCase()) || String(s.num).includes(q)
  );
  if (!filtered.length) { list.innerHTML = `<div style="text-align:center;color:var(--t3);padding:32px;font-size:0.8125rem">No surahs found</div>`; return; }
  list.innerHTML = filtered.map(s => {
    const hasDetail = !!TAFSIR_DATA[s.num];
    return `<div onclick="tafsirOpenSurah(${s.num})" style="display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:16px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);margin-bottom:8px;cursor:pointer;transition:background .18s;-webkit-tap-highlight-color:transparent" onmouseenter="this.style.background='rgba(var(--teal-rgb),.07)'" onmouseleave="this.style.background='rgba(255,255,255,.03)'">
      <div style="width:36px;height:36px;border-radius:10px;background:rgba(var(--teal-rgb),.1);border:1px solid rgba(var(--teal-rgb),.2);display:flex;align-items:center;justify-content:center;font-size:0.6875rem;font-weight:600;color:var(--teal);flex-shrink:0">${s.num}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:0.8125rem;font-weight:500;color:var(--text)">${s.name}</div>
        <div style="font-size:0.625rem;color:var(--t3);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${s.theme}</div>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0">
        <div style="font-size:0.875rem;font-family:'Playfair Display',serif;color:var(--gold);opacity:.7">${s.arabic}</div>
        <div style="font-size:0.5rem;color:var(--t3)">${s.ayahs} ayahs</div>
      </div>
      ${hasDetail ? '<div style="position:absolute;right:8px;top:8px"></div>' : ''}
    </div>`;
  }).join('');
}

function tafsirOpenSurah(num) {
  tafsirSelectedSurah = num;
  const data = TAFSIR_DATA[num];
  const surah = TAFSIR_SURAHS.find(s => s.num === num);
  const body = document.getElementById('tafsir-body');
  if (!body || !surah) return;

  if (!data) {
    body.innerHTML = `
      <div style="padding:16px">
        <button onclick="renderTafsirPage()" style="background:none;border:none;color:var(--teal);font-family:'Manrope',sans-serif;font-size:0.8125rem;cursor:pointer;margin-bottom:16px">← Back to Surahs</button>
        <div style="text-align:center;padding:48px 24px">
          <div style="font-size:2rem;margin-bottom:12px">📖</div>
          <div style="font-size:1rem;color:var(--text);margin-bottom:8px">${surah.name}</div>
          <div style="font-size:0.75rem;color:var(--t3);line-height:1.6">Detailed tafsir for this surah is coming soon. Core surahs like Al-Fatihah, Yusuf, Al-Kahf, Ya-Sin, Ar-Rahman, Al-Mulk & Al-Ikhlas have full tafsir available.</div>
        </div>
      </div>`;
    return;
  }

  body.innerHTML = `
    <div style="padding:16px 16px 40px">
      <button onclick="renderTafsirPage()" style="background:none;border:none;color:var(--teal);font-family:'Manrope',sans-serif;font-size:0.8125rem;cursor:pointer;margin-bottom:16px;display:flex;align-items:center;gap:6px">← All Surahs</button>

      <!-- Header -->
      <div style="text-align:center;padding:20px;border-radius:20px;background:linear-gradient(135deg,rgba(var(--teal-rgb),.1),rgba(var(--accent-rgb),.07));border:1px solid rgba(var(--teal-rgb),.2);margin-bottom:20px">
        <div style="font-family:'Playfair Display',serif;font-size:2rem;color:var(--gold);margin-bottom:4px">${surah.arabic}</div>
        <div style="font-size:1.0625rem;font-weight:600;color:var(--text);margin-bottom:4px">${surah.name}</div>
        <div style="font-size:0.625rem;color:var(--t3);letter-spacing:.1em;text-transform:uppercase">${surah.ayahs} Ayahs</div>
        <div style="font-size:0.75rem;color:var(--t2);margin-top:10px;line-height:1.5;font-style:italic">${data.overview}</div>
      </div>

      <!-- Themes -->
      <div style="margin-bottom:16px">
        <div style="font-size:0.5625rem;letter-spacing:.2em;text-transform:uppercase;color:var(--gold);margin-bottom:10px">Key Themes</div>
        <div style="display:flex;flex-wrap:wrap;gap:6px">
          ${data.themes.map(t => `<span style="padding:5px 12px;border-radius:99px;background:rgba(var(--teal-rgb),.08);border:1px solid rgba(var(--teal-rgb),.2);font-size:0.625rem;color:var(--teal)">${t}</span>`).join('')}
        </div>
      </div>

      <!-- Virtues -->
      <div style="margin-bottom:16px;border-radius:16px;background:rgba(var(--accent-rgb),.06);border:1px solid rgba(var(--accent-rgb),.15);padding:14px">
        <div style="font-size:0.5625rem;letter-spacing:.2em;text-transform:uppercase;color:var(--gold);margin-bottom:10px">✦ Virtues & Significance</div>
        ${data.virtues.map(v => `<div style="display:flex;gap:8px;margin-bottom:7px;font-size:0.75rem;color:var(--t2);line-height:1.5"><span style="color:var(--gold);flex-shrink:0">◈</span>${v}</div>`).join('')}
      </div>

      <!-- Key Ayahs Tafsir -->
      <div style="margin-bottom:16px">
        <div style="font-size:0.5625rem;letter-spacing:.2em;text-transform:uppercase;color:var(--gold);margin-bottom:10px">Key Ayahs — Explained</div>
        ${data.keyAyahs.map(a => `
          <div style="border-radius:16px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);padding:14px;margin-bottom:10px">
            <div style="font-size:0.5625rem;color:var(--teal);letter-spacing:.1em;margin-bottom:6px">${a.ayah}</div>
            <div style="font-family:'Playfair Display',serif;font-size:1.25rem;color:var(--gold);text-align:right;direction:rtl;line-height:1.8;margin-bottom:8px">${a.arabic}</div>
            <div style="font-size:0.75rem;color:var(--t2);font-style:italic;margin-bottom:10px;line-height:1.5">"${a.meaning}"</div>
            <div style="font-size:0.75rem;color:var(--t3);line-height:1.6;border-top:1px solid rgba(255,255,255,.06);padding-top:10px">${a.tafsir}</div>
          </div>`).join('')}
      </div>

      <!-- Lessons -->
      <div style="border-radius:16px;background:rgba(var(--green-rgb),.06);border:1px solid rgba(var(--green-rgb),.15);padding:14px">
        <div style="font-size:0.5625rem;letter-spacing:.2em;text-transform:uppercase;color:var(--green);margin-bottom:10px">Lessons for Today</div>
        ${data.lessons.map(l => `<div style="display:flex;gap:8px;margin-bottom:7px;font-size:0.75rem;color:var(--t2);line-height:1.5"><span style="color:var(--green);flex-shrink:0">✓</span>${l}</div>`).join('')}
      </div>
    </div>`;
}

// ══════════════════════════════════════════════
// ISLAMIC HISTORY TIMELINE
// ══════════════════════════════════════════════

const HISTORY_ERAS = [
  { id:'prophets', label:'Prophets Era', icon:'🌙', color:'212,168,83', events:[
    { year:'Before 2000 BCE', title:'Prophet Ibrahim (Abraham)', subtitle:'Father of Monotheism', detail:'Ibrahim ﷺ rejected the idol worship of his people in Ur (Iraq/Mesopotamia). After being thrown into fire and saved by Allah, he migrated to Canaan and later built the Kaaba in Makkah with his son Ismail. His submission to Allah\'s command to sacrifice his son became the basis of Eid al-Adha. The three Abrahamic faiths all trace their lineage to him.', tags:['Tawheed','Kaaba','Sacrifice'] },
    { year:'~1700-1600 BCE', title:'Prophet Yusuf (Joseph)', subtitle:'From the pit to the palace', detail:'Yusuf ﷺ was thrown into a well by his jealous brothers, sold into slavery in Egypt, falsely imprisoned, then elevated to minister of Egypt — all within one lifetime. His story, the longest in the Quran, is a masterclass in patience, purity, and trusting Allah\'s plan across decades of hardship.', tags:['Patience','Forgiveness','Divine Plan'] },
    { year:'~1300-1200 BCE', title:'Prophet Musa (Moses)', subtitle:'Liberation of Bani Israel', detail:'Musa ﷺ was born during Pharaoh\'s massacre of Israelite boys, raised in the palace of his people\'s oppressor, then chosen by Allah to confront Pharaoh. The Exodus from Egypt, the splitting of the Red Sea, the revelation at Mount Sinai (Torah), and 40 years in the Sinai Desert — all occurred under his prophethood.', tags:['Liberation','Torah','Miracles'] },
    { year:'~1000 BCE', title:'Prophets Dawud & Sulayman', subtitle:'The Golden Kingdom of Israel', detail:'Dawud ﷺ (David) — warrior, king, and poet — was given the Psalms (Zabur). His son Sulayman ﷺ (Solomon) ruled a kingdom commanding humans, jinn, and animals. The Temple in Jerusalem was built under their reign. Both represent the intersection of prophethood and political power.', tags:['Kingdom','Psalms','Jerusalem'] },
    { year:'~6 BCE – 570 CE', title:'Prophet Isa (Jesus)', subtitle:'Miraculous birth, divine message', detail:'Isa ﷺ was born miraculously to Maryam (Mary) without a father. He performed miracles — healing the blind, raising the dead — and was given the Injil (Gospel). Islam teaches he was not crucified but raised to Allah, and will return before the Day of Judgment. He is among the five greatest prophets (Ulul Azm).', tags:['Miracles','Gospel','Return'] },
    { year:'570 CE', title:'Birth of Prophet Muhammad ﷺ', subtitle:'The Seal of Prophets born in Makkah', detail:'Muhammad ﷺ was born in the Year of the Elephant (when Abraha\'s army attempted to destroy the Kaaba). Orphaned early — father died before birth, mother at age 6 — he was raised by grandfather Abd al-Muttalib then uncle Abu Talib. Known as Al-Amin (the Trustworthy), he received his first revelation at age 40 in the Cave of Hira.', tags:['Makkah','Al-Amin','Prophethood'] },
  ]},
  { id:'propheticera', label:'Prophetic Era', icon:'☪️', color:'78,201,190', events:[
    { year:'610 CE', title:'First Revelation — Iqra', subtitle:'The Quran begins descending', detail:'In the Cave of Hira during Ramadan, angel Jibreel appeared to Muhammad ﷺ and commanded "Iqra!" (Read/Recite). This began 23 years of Quranic revelation. Khadijah RA became the first Muslim, followed by Ali RA, Zayd ibn Haritha, and Abu Bakr RA. The mission began secretly for three years.', tags:['Quran','Hira','First Revelation'] },
    { year:'622 CE', title:'The Hijra — Migration to Madinah', subtitle:'Year 1 of the Islamic Calendar', detail:'After 13 years of persecution in Makkah, the Muslims migrated to Yathrib (renamed Madinah al-Munawwarah). This migration marks Year 1 of the Islamic Hijri calendar. The Prophet ﷺ established the first Islamic state, built Masjid al-Nabawi, and created the Constitution of Madinah — a pluralistic social contract between Muslims, Jews, and others.', tags:['Hijri Calendar','Madinah','Constitution'] },
    { year:'624 CE', title:'Battle of Badr', subtitle:'The first major victory of Islam', detail:'313 poorly-equipped Muslims faced nearly 1,000 Quraysh soldiers. The Muslim victory was decisive — 70 Qurayshi leaders killed, 70 captured. The Prophet ﷺ called it "the Day of Furqan" (Criterion). Surah Al-Anfal was revealed about this battle. It established Muslim confidence and deterred the enemies of Islam.', tags:['Victory','Furqan','300 Warriors'] },
    { year:'628 CE', title:'Treaty of Hudaybiyyah', subtitle:'Apparent defeat, real triumph', detail:'Muslims traveled for Umrah but were stopped at Hudaybiyyah. The resulting treaty seemed unfair — 10-year peace, Muslims return without Umrah this year. Yet the Quran called it "a clear victory" (48:1). It gave Islam 2 years of peace during which more people entered Islam than in the previous 20 years combined.', tags:['Diplomacy','Clear Victory','Surah Fath'] },
    { year:'630 CE', title:'Conquest of Makkah', subtitle:'The bloodless liberation', detail:'With 10,000 Muslims, the Prophet ﷺ entered Makkah almost without bloodshed. He declared a general amnesty — "Go, you are free." The Kaaba was purified of 360 idols. Abu Sufyan, the former enemy leader, accepted Islam on the eve of the conquest. It stands as one of history\'s most merciful military victories.', tags:['Mercy','Amnesty','Kaaba Purified'] },
    { year:'632 CE', title:'Farewell Hajj & Passing of the Prophet ﷺ', subtitle:'The final message delivered', detail:'In his last Hajj, the Prophet ﷺ delivered the Farewell Sermon at Mount Arafat — proclaiming human equality, women\'s rights, prohibition of usury, and the trust of the Quran and Sunnah. Shortly after returning to Madinah, he passed away at age 63 in the arms of Aisha RA. Umar RA refused to believe it; Abu Bakr RA reminded the ummah: "Whoever worshipped Muhammad — Muhammad is dead. Whoever worships Allah — Allah is ever-living."', tags:['Farewell Sermon','Legacy','Completion of Religion'] },
  ]},
  { id:'khulafa', label:'Rightly-Guided Caliphs', icon:'⚔️', color:'167,139,250', events:[
    { year:'632–634 CE', title:'Abu Bakr As-Siddiq RA', subtitle:'The First Caliph — Unifier of the Ummah', detail:'The closest companion of the Prophet ﷺ, Abu Bakr RA confronted the Ridda Wars (apostasy movements), unified Arabia, initiated the compilation of the Quran into a single manuscript, and began the expansion toward Persia and Byzantium. His 2-year caliphate was decisive for Islam\'s survival. He died with less wealth than when he became caliph.', tags:['Quran Compilation','Ridda Wars','Siddiq'] },
    { year:'634–644 CE', title:"Umar ibn al-Khattab RA", subtitle:'The Farooq — Justice and Expansion', detail:'Under Umar RA, the Islamic state expanded to include Persia, Egypt, Syria, and Palestine — including Jerusalem (Al-Quds). He established the Hijri calendar, created the diwan (treasury/welfare system), instituted regular salaries for scholars, and founded new cities like Kufa and Basra. His assassination by Abu Lu\'lu\'ah ended 10 years of extraordinary leadership.', tags:['Jerusalem','Justice','Administrative Reform'] },
    { year:'644–656 CE', title:'Uthman ibn Affan RA', subtitle:'The standardization of the Quran', detail:"Uthman RA compiled the definitive written copy of the Quran (the Uthmani Mushaf) and distributed copies to major cities, destroying variant copies. This preserved the Quran's integrity across the expanding empire. He also expanded Masjid al-Haram and Masjid al-Nabawi. His caliphate ended tragically with his assassination during a period of political strife.", tags:['Mushaf','Quran Preservation','Expansion'] },
    { year:'656–661 CE', title:'Ali ibn Abi Talib RA', subtitle:"The Prophet's cousin and son-in-law", detail:"The first male Muslim, raised in the Prophet's ﷺ household, Ali RA faced the First Fitna (civil war) — battles of Jamal and Siffin between companions. Known for his extraordinary knowledge, courage, and spiritual depth, he compiled his wisdom in Nahj al-Balagha. Assassinated in Kufa while going to Fajr prayer, his caliphate lasted nearly 5 years.", tags:['Knowledge','First Fitna','Nahj al-Balagha'] },
  ]},
  { id:'golden', label:'Golden Age of Islam', icon:'🌟', color:'212,168,83', events:[
    { year:'661–750 CE', title:'Umayyad Caliphate', subtitle:'Expansion from Spain to Central Asia', detail:'Under the Umayyads, the Islamic world expanded from the Iberian Peninsula (Al-Andalus/Spain) to the borders of China and India — the largest contiguous empire to that point. The Dome of the Rock in Jerusalem was built (691 CE). Arabic became the administrative language of a vast multi-ethnic civilization. However, dynastic rule replaced the consultative caliphate model.', tags:['Al-Andalus','Dome of Rock','Expansion'] },
    { year:'750–1258 CE', title:'Abbasid Caliphate & the Golden Age', subtitle:'Baghdad — Center of world civilization', detail:'The Abbasids moved the capital to Baghdad, which became the world\'s largest city. The House of Wisdom (Bayt al-Hikmah) translated and preserved Greek, Persian, and Indian knowledge. Muslim scholars like Al-Khwarizmi (algebra), Ibn Sina (medicine), Al-Farabi (philosophy), Al-Biruni (astronomy), and Al-Razi (chemistry) transformed human civilization. This Golden Age (8th–13th century) preserved and advanced human knowledge during Europe\'s Dark Ages.', tags:['House of Wisdom','Baghdad','Al-Khwarizmi'] },
    { year:'711–1492 CE', title:'Al-Andalus — Islamic Spain', subtitle:'The light of Europe for 700 years', detail:'Muslim-ruled Spain was medieval Europe\'s most advanced civilization — with libraries of 400,000 books when most European monasteries had fewer than 100. Cordoba was Europe\'s largest city. Muslim, Jewish, and Christian scholars worked together (Convivencia). The Great Mosque of Cordoba remains an architectural wonder. This civilization\'s knowledge transfer catalyzed the European Renaissance.', tags:['Cordoba','Convivencia','Libraries'] },
    { year:'1258 CE', title:'Fall of Baghdad — Mongol Invasion', subtitle:'The end of the Abbasid Caliphate', detail:'The Mongol army under Hulagu Khan (grandson of Genghis Khan) sacked Baghdad — burning the House of Wisdom, killing the Caliph, and reportedly turning the Tigris River black with ink from destroyed books. It was one of the most catastrophic events in Islamic history — ending the Abbasid Caliphate and the classical Golden Age. However, the Mongols later converted to Islam.', tags:['Tragedy','Hulagu Khan','Resilience'] },
    { year:'1300–1924 CE', title:'Ottoman Caliphate', subtitle:'The last great Islamic empire', detail:'The Ottoman Empire at its peak controlled Anatolia, the Levant, Egypt, North Africa, the Balkans, and the Caucasus — stretching across 3 continents. Constantinople (Istanbul) was conquered in 1453 CE by Sultan Mehmed II, fulfilling a hadith of the Prophet ﷺ. The Ottomans maintained the Haramayn (the two holy mosques) and served as protectors of Islamic civilization until the caliphate\'s abolition in 1924.', tags:['Constantinople','Haramayn','Mehmed II'] },
  ]},
  { id:'modern', label:'Modern Era', icon:'🕌', color:'94,201,137', events:[
    { year:'1924 CE', title:'Abolition of the Caliphate', subtitle:'End of 1300 years of Islamic governance', detail:'Under Mustafa Kemal Ataturk, the Turkish National Assembly abolished the Ottoman Caliphate — the last institution of pan-Islamic governance. This marked a decisive break in Islamic political history. The Muslim Brotherhood was founded in Egypt in 1928 partly in response. The question of Islamic governance and revival has defined much of Muslim intellectual thought since.', tags:['Caliphate','Ataturk','Revival'] },
    { year:'1947–1948 CE', title:'Pakistan & the Nakba', subtitle:'Partition and displacement', detail:'The 1947 partition of British India created Pakistan as a homeland for Muslims of the subcontinent — at the cost of one of history\'s largest migrations and immense violence. In 1948, the establishment of Israel led to the Nakba (catastrophe) — the displacement of 700,000+ Palestinians from their homeland. Both events continue to shape Muslim identity and politics globally.', tags:['Pakistan','Palestine','Displacement'] },
    { year:'1979 CE', title:'Iranian Revolution', subtitle:'Islamic republic established', detail:'The Iranian Revolution led by Ayatollah Khomeini overthrew the Shah and established the Islamic Republic of Iran — the first modern state explicitly based on Islamic governance (in Shia tradition). It inspired and alarmed Muslim movements globally, reshaping Middle Eastern geopolitics and sparking the Iran-Iraq War (1980–88).', tags:['Iran','Shia','Revolution'] },
    { year:'2011 CE', title:'The Arab Spring', subtitle:'Popular uprisings across Muslim world', detail:'Beginning in Tunisia with Mohamed Bouazizi\'s self-immolation, popular uprisings swept Egypt, Libya, Syria, Yemen, and Bahrain. Decades-old authoritarian regimes fell or were shaken. The aftermath was mixed — Tunisia achieved a transition to democracy, while Syria descended into devastating civil war that displaced millions. The Arab Spring revealed the deep aspirations for dignity and justice in Muslim-majority societies.', tags:['Revolution','Democracy','Dignity'] },
    { year:'Present', title:'The Global Muslim Ummah Today', subtitle:'1.9 billion Muslims worldwide', detail:'Muslims constitute nearly 25% of the world\'s population — approximately 1.9 billion people across 50+ Muslim-majority countries. Indonesia has the largest Muslim population. Islam is the world\'s fastest-growing religion. Muslims face challenges of identity, Islamophobia, internal reform debates, and political representation — while contributing significantly to science, art, medicine, and culture globally.', tags:['Ummah','Global','Future'] },
  ]},
];

let historyActiveEra = 'prophets';

function renderHistoryPage() {
  const body = document.getElementById('history-body');
  if (!body) return;
  body.innerHTML = `
    <div style="padding:16px 16px 40px">
      <!-- Era tabs -->
      <div style="display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;padding-bottom:14px;margin-bottom:4px;-webkit-overflow-scrolling:touch">
        ${HISTORY_ERAS.map(e => `
          <button onclick="historySelectEra('${e.id}')" id="hist-tab-${e.id}"
            style="flex:0 0 auto;padding:7px 14px;border-radius:99px;border:1px solid rgba(255,255,255,.1);background:${e.id===historyActiveEra?`rgba(${e.color},.15)`:'rgba(255,255,255,.04)'};color:${e.id===historyActiveEra?'var(--text)':'var(--t3)'};font-family:'Manrope',sans-serif;font-size:0.625rem;letter-spacing:.06em;cursor:pointer;-webkit-tap-highlight-color:transparent;white-space:nowrap;transition:all .2s">
            ${e.icon} ${e.label}
          </button>`).join('')}
      </div>
      <!-- Events -->
      <div id="history-events"></div>
    </div>`;
  historyRenderEvents();
}

function historySelectEra(id) {
  historyActiveEra = id;
  // Update tab styles
  HISTORY_ERAS.forEach(e => {
    const tab = document.getElementById('hist-tab-' + e.id);
    if (!tab) return;
    const active = e.id === id;
    tab.style.background = active ? `rgba(${e.color},.15)` : 'rgba(255,255,255,.04)';
    tab.style.color = active ? 'var(--text)' : 'var(--t3)';
    tab.style.borderColor = active ? `rgba(${e.color},.3)` : 'rgba(255,255,255,.1)';
  });
  historyRenderEvents();
}

function historyRenderEvents() {
  const container = document.getElementById('history-events');
  if (!container) return;
  const era = HISTORY_ERAS.find(e => e.id === historyActiveEra);
  if (!era) return;
  container.innerHTML = era.events.map((ev, i) => `
    <div style="display:flex;gap:12px;margin-bottom:16px">
      <!-- Timeline line -->
      <div style="display:flex;flex-direction:column;align-items:center;flex-shrink:0">
        <div style="width:10px;height:10px;border-radius:50%;background:rgba(${era.color},.8);border:2px solid rgba(${era.color},.3);box-shadow:0 0 8px rgba(${era.color},.3);margin-top:4px;flex-shrink:0"></div>
        ${i < era.events.length-1 ? `<div style="width:1px;flex:1;background:linear-gradient(rgba(${era.color},.3),transparent);min-height:20px;margin-top:4px"></div>` : ''}
      </div>
      <!-- Card -->
      <div onclick="this.querySelector('.hist-detail').style.display=this.querySelector('.hist-detail').style.display==='none'?'block':'none'"
        style="flex:1;border-radius:16px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);padding:14px;cursor:pointer;-webkit-tap-highlight-color:transparent;margin-bottom:${i<era.events.length-1?'0':'0'}">
        <div style="font-size:0.5625rem;color:rgba(${era.color},.8);letter-spacing:.1em;margin-bottom:4px">${ev.year}</div>
        <div style="font-size:0.875rem;font-weight:600;color:var(--text);margin-bottom:2px">${ev.title}</div>
        <div style="font-size:0.6875rem;color:var(--t2);margin-bottom:10px">${ev.subtitle}</div>
        <div class="hist-detail" style="display:none;font-size:0.75rem;color:var(--t3);line-height:1.65;border-top:1px solid rgba(255,255,255,.06);padding-top:10px;margin-bottom:10px">${ev.detail}</div>
        <div style="display:flex;flex-wrap:wrap;gap:5px">
          ${ev.tags.map(t => `<span style="padding:3px 9px;border-radius:99px;background:rgba(${era.color},.08);border:1px solid rgba(${era.color},.2);font-size:0.5rem;color:rgba(${era.color},.9)">${t}</span>`).join('')}
        </div>
      </div>
    </div>`).join('');
}

// ══════════════════════════════════════════════
// ISLAMIC NEWS FEED (via Claude AI)
// ══════════════════════════════════════════════

let newsCache = null;
let newsCacheTime = 0;
const NEWS_CACHE_MS = 10 * 60 * 1000; // 10 minutes

function renderNewsPage() {
  const body = document.getElementById('news-body');
  if (!body) return;
  body.innerHTML = `
    <div style="padding:16px 16px 40px">
      <!-- Categories -->
      <div style="display:flex;gap:6px;overflow-x:auto;scrollbar-width:none;padding-bottom:12px;-webkit-overflow-scrolling:touch" id="news-cats">
        ${['All','World','Ummah','Palestine','Science','Ramadan','Community'].map((c,i) =>
          `<button onclick="newsSelectCat(this,'${c}')" style="flex:0 0 auto;padding:6px 14px;border-radius:99px;border:1px solid rgba(255,255,255,.1);background:${i===0?'rgba(var(--green-rgb),.15)':'rgba(255,255,255,.04)'};color:${i===0?'var(--green)':'var(--t3)'};font-family:'Manrope',sans-serif;font-size:0.625rem;letter-spacing:.06em;cursor:pointer;-webkit-tap-highlight-color:transparent;white-space:nowrap;transition:all .2s">${c}</button>`
        ).join('')}
      </div>
      <!-- Feed -->
      <div id="news-feed">
        <div style="text-align:center;padding:40px 20px">
          <div style="font-size:1.5rem;margin-bottom:12px;animation:spin 1s linear infinite;display:inline-block">⟳</div>
          <div style="font-size:0.75rem;color:var(--t3)">Fetching Islamic news...</div>
        </div>
      </div>
    </div>
    <style>@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}</style>`;
  newsLoadFeed('All');
}

let newsActiveCat = 'All';
function newsSelectCat(btn, cat) {
  newsActiveCat = cat;
  document.querySelectorAll('#news-cats button').forEach(b => {
    b.style.background = 'rgba(255,255,255,.04)';
    b.style.color = 'var(--t3)';
    b.style.borderColor = 'rgba(255,255,255,.1)';
  });
  btn.style.background = 'rgba(var(--green-rgb),.15)';
  btn.style.color = 'var(--green)';
  btn.style.borderColor = 'rgba(var(--green-rgb),.3)';
  newsLoadFeed(cat);
}

async function newsLoadFeed(category) {
  const feed = document.getElementById('news-feed');
  if (!feed) return;
  const now = Date.now();
  if (newsCache && (now - newsCacheTime) < NEWS_CACHE_MS && newsCache._cat === category) {
    newsRenderArticles(newsCache.articles); return;
  }
  feed.innerHTML = `<div style="text-align:center;padding:40px 20px"><div style="font-size:1.5rem;margin-bottom:12px;animation:spin 1s linear infinite;display:inline-block">⟳</div><div style="font-size:0.75rem;color:var(--t3)">Searching latest news...</div></div>`;
  const apiKey = localStorage.getItem('mrd_claude_api_key') || '';
  const catPrompt = category === 'All' ? 'Islamic world, Muslim community, and global Muslim affairs' : `${category} from an Islamic or Muslim perspective`;
  const doFetch = (messages) => fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
    body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: 2000,
      tools: [{ type: 'web_search_20250305', name: 'web_search' }],
      system: `You are an Islamic news curator. Search for recent news about ${catPrompt}. After searching, return ONLY a JSON array (no markdown, no preamble) of 6 articles: [{"title":"...","summary":"2-3 sentences","source":"...","category":"World|Ummah|Palestine|Science|Community","sentiment":"positive|neutral|concern","timeAgo":"X hours/days ago"}]`,
      messages })
  }).then(r => r.json());
  try {
    let messages = [{ role: 'user', content: `Search for the latest Islamic and Muslim news about: ${catPrompt}. Today is ${new Date().toDateString()}.` }];
    let data = await doFetch(messages);
    if (data.error) throw new Error(data.error.message || 'API error');
    let loopCount = 0;
    while (data.stop_reason === 'tool_use' && loopCount < 5) {
      loopCount++;
      const toolResults = data.content.filter(b => b.type === 'tool_use').map(tu => ({ type: 'tool_result', tool_use_id: tu.id, content: tu.input ? JSON.stringify(tu.input) : '' }));
      messages = [...messages, { role: 'assistant', content: data.content }, { role: 'user', content: toolResults }];
      data = await doFetch(messages);
      if (data.error) throw new Error(data.error.message || 'API error');
    }
    const textBlocks = (data.content || []).filter(b => b.type === 'text');
    if (!textBlocks.length) throw new Error('No text in final response');
    let raw = textBlocks[textBlocks.length - 1].text.trim();
    raw = raw.replace(/```json\s*/g, '').replace(/```/g, '').trim();
    const match = raw.match(/\[[\s\S]*\]/);
    if (!match) throw new Error('No JSON array found');
    const articles = JSON.parse(match[0]);
    newsCache = { articles, _cat: category }; newsCacheTime = now;
    newsRenderArticles(articles);
  } catch(e) {
    feed.innerHTML = `<div style="text-align:center;padding:40px 20px"><div style="font-size:2rem;margin-bottom:12px">📡</div><div style="font-size:0.8125rem;color:var(--text);margin-bottom:8px">Could not load news</div><div style="font-size:0.6875rem;color:var(--t3);margin-bottom:16px">${e.message||'Check connection.'}</div><button onclick="newsLoadFeed('${category}')" style="padding:9px 20px;border-radius:12px;border:1px solid rgba(var(--green-rgb),.3);background:rgba(var(--green-rgb),.1);color:var(--green);font-family:'Manrope',sans-serif;font-size:0.75rem;cursor:pointer">Retry</button></div>`;
  }
}

const NEWS_CAT_COLORS = {
  World:'78,201,190',
  Ummah:'212,168,83',
  Palestine:'94,201,137',
  Science:'167,139,250',
  Community:'232,120,138',
  Ramadan:'212,168,83',
  neutral:'255,255,255',
};
const NEWS_SENTIMENT_ICON = { positive:'🌟', neutral:'📰', concern:'🔔' };

function newsRenderArticles(articles) {
  const feed = document.getElementById('news-feed');
  if (!feed || !articles || !articles.length) return;
  feed.innerHTML = articles.map(a => {
    const col = NEWS_CAT_COLORS[a.category] || NEWS_CAT_COLORS.neutral;
    const icon = NEWS_SENTIMENT_ICON[a.sentiment] || '📰';
    return `
    <div style="border-radius:18px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);padding:16px;margin-bottom:10px;transition:background .18s" onmouseenter="this.style.background='rgba(255,255,255,.05)'" onmouseleave="this.style.background='rgba(255,255,255,.03)'">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <span style="padding:3px 10px;border-radius:99px;background:rgba(${col},.1);border:1px solid rgba(${col},.25);font-size:0.5rem;color:rgba(${col},.9);letter-spacing:.08em">${a.category||'News'}</span>
        <span style="font-size:0.5625rem;color:var(--t3);margin-left:auto">${icon} ${a.timeAgo||'Recently'}</span>
      </div>
      <div style="font-size:0.875rem;font-weight:600;color:var(--text);line-height:1.4;margin-bottom:8px">${a.title}</div>
      <div style="font-size:0.75rem;color:var(--t3);line-height:1.6;margin-bottom:10px">${a.summary}</div>
      <div style="font-size:0.5625rem;color:var(--t3);letter-spacing:.06em">SOURCE: ${a.source||'Islamic News'}</div>
    </div>`;
  }).join('') + `
  <div style="text-align:center;margin-top:16px">
    <button onclick="newsCache=null;newsLoadFeed(newsActiveCat)" style="padding:9px 20px;border-radius:12px;border:1px solid rgba(var(--green-rgb),.25);background:rgba(var(--green-rgb),.07);color:var(--green);font-family:'Manrope',sans-serif;font-size:0.6875rem;letter-spacing:.06em;cursor:pointer;-webkit-tap-highlight-color:transparent">↻ Refresh Feed</button>
  </div>`;
}

// ══════════════════════════════════════════════
// SUPABASE — Session restore on app start
// Deferred: UI renders first, then sync runs in background
// ══════════════════════════════════════════════
async function _supaInit() {
  try {
    // Create client now — SDK is guaranteed loaded (defer script done)
    _supa = supabase.createClient(SUPA_URL, SUPA_KEY);

    // Register auth state listener
    _supa.auth.onAuthStateChange((event, session) => {
      const prevUser = _supaUser;
      _supaUser = session?.user || null;
      // Only do a full sync on actual new login — NOT on token refresh (TOKEN_REFRESHED)
      if (event === 'SIGNED_IN' && !prevUser && !_supaInitSyncDone) {
        supaFullSync();
      }
      if (event === 'SIGNED_OUT') {
        _supaInitSyncDone = false;
        const card = document.getElementById('supa-auth-card');
        if (card) card.innerHTML = _supaAuthFormHTML();
      }
    });

    // Now check session and sync in background (non-blocking)
    await supaGetSession();
    if (_supaUser) {
      console.log('[Supa] Logged in as:', _supaUser.email);
      _supaInitSyncDone = true;

      // ── Restore profile from cloud if no local account ──
      const localAcc = loadAccount();
      if (!localAcc) {
        const restoredAcc = await supaPullProfile();
        if (restoredAcc) {
          updateProfileBtn(restoredAcc);
          updateAppTitle(restoredAcc.name);
          // Hide onboarding if it's visible — user already has an account
          const ob = document.getElementById('onboarding-screen');
          if (ob) ob.style.display = 'none';
          console.log('[Supa] Profile restored for:', _supaUser.email);
        }
      }

      supaFullSync(); // fire-and-forget, UI already painted
    }
  } catch(e) {
    console.warn('[Supa] Init failed:', e.message);
  }
}
// Run after first paint — UI loads instantly, sync happens silently after
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => setTimeout(_supaInit, 0));
} else {
  setTimeout(_supaInit, 0);
}

// ══════════════════════════════════════════════
// 🔔 ADMIN NOTIFICATIONS — Realtime Listener
// ══════════════════════════════════════════════
let _notifChannel = null;
let _notifSeenKey = 'mrd_notif_seen';

function _notifGetSeen() {
  try { return new Set(JSON.parse(localStorage.getItem(_notifSeenKey) || '[]')); }
  catch { return new Set(); }
}
function _notifMarkSeen(id) {
  const seen = _notifGetSeen();
  seen.add(id);
  // Keep only last 100
  const arr = [...seen].slice(-100);
  try { localStorage.setItem(_notifSeenKey, JSON.stringify(arr)); } catch {}
}

function showAdminNotif(title, body, id, createdAt) {
  const popup = document.getElementById('admin-notif-popup');
  const titleEl = document.getElementById('admin-notif-title');
  const bodyEl  = document.getElementById('admin-notif-body');
  if (!popup || !titleEl || !bodyEl) return;

  titleEl.textContent = title;
  bodyEl.textContent  = body;
  addNotifHistoryItem({ id, title, body, type:'admin', createdAt });

  popup.style.display = 'block';
  popup.style.pointerEvents = 'all';
  // Animate in
  requestAnimationFrame(() => {
    popup.style.opacity   = '1';
    popup.style.transform = 'translateX(-50%) translateY(0)';
  });

  // Auto-dismiss after 7 seconds
  clearTimeout(popup._dismissTimer);
  popup._dismissTimer = setTimeout(() => closeAdminNotif(), 7000);

  // Browser / phone notification (if permission granted)
  if (Notification.permission === 'granted') {
    try {
      new Notification(title, {
        body,
        icon: '/icon-192.png',
        badge: '/icon-192.png',
        tag: 'admin-notif-' + (id || Date.now()),
        renotify: true,
      });
    } catch(e) {}
  }
}

function closeAdminNotif() {
  const popup = document.getElementById('admin-notif-popup');
  if (!popup) return;
  popup.style.opacity   = '0';
  popup.style.transform = 'translateX(-50%) translateY(30px)';
  popup.style.pointerEvents = 'none';
  clearTimeout(popup._dismissTimer);
  setTimeout(() => { if (popup) popup.style.display = 'none'; }, 360);
}

const NOTIF_HISTORY_KEY = 'tf_notification_history_v1';
const NOTIF_HISTORY_READ_KEY = 'tf_notification_history_read_at';

function _safeNotifTime(value) {
  const d = value ? new Date(value) : new Date();
  return Number.isNaN(d.getTime()) ? new Date() : d;
}
function getNotifHistory() {
  try {
    const arr = JSON.parse(localStorage.getItem(NOTIF_HISTORY_KEY) || '[]');
    return Array.isArray(arr) ? arr : [];
  } catch(e) { return []; }
}
function saveNotifHistory(items) {
  try { localStorage.setItem(NOTIF_HISTORY_KEY, JSON.stringify((items || []).slice(0, 120))); } catch(e) {}
}
function addNotifHistoryItem(item) {
  if (!item) return;
  const list = getNotifHistory();
  const createdAt = _safeNotifTime(item.createdAt || item.sent_at || item.time).toISOString();
  const entry = {
    id: item.id || ('local_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8)),
    title: item.title || 'Notification',
    body: item.body || '',
    type: item.type || 'general',
    createdAt,
  };
  const filtered = list.filter(x => !(x && x.id === entry.id));
  filtered.unshift(entry);
  filtered.sort((a,b) => _safeNotifTime(b.createdAt) - _safeNotifTime(a.createdAt));
  saveNotifHistory(filtered);
  renderNotifHistoryBadge();
  const panel = document.getElementById('notif-history-sheet');
  if (panel && panel.style.display !== 'none') renderNotifHistory();
}
function getNotifReadAt() {
  return parseInt(localStorage.getItem(NOTIF_HISTORY_READ_KEY) || '0', 10) || 0;
}
function markNotifHistoryRead() {
  try { localStorage.setItem(NOTIF_HISTORY_READ_KEY, String(Date.now())); } catch(e) {}
  renderNotifHistoryBadge();
}
function getNotifUnreadCount() {
  const readAt = getNotifReadAt();
  return getNotifHistory().filter(x => _safeNotifTime(x.createdAt).getTime() > readAt).length;
}
function renderNotifHistoryBadge() {
  const badge = document.getElementById('notif-history-badge');
  if (!badge) return;
  const count = getNotifUnreadCount();
  if (count > 0) {
    badge.style.display = 'flex';
    badge.textContent = count > 99 ? '99+' : String(count);
  } else {
    badge.style.display = 'none';
    badge.textContent = '';
  }
}
function _notifHistoryDateLabel(dateObj) {
  const now = new Date();
  const todayKey = dateKey(now);
  const y = new Date(); y.setDate(y.getDate() - 1);
  const key = dateKey(dateObj);
  if (key === todayKey) return 'Today';
  if (key === dateKey(y)) return 'Yesterday';
  return dateObj.toLocaleDateString('en-US', { weekday:'long', month:'short', day:'numeric', year:'numeric' });
}
function renderNotifHistory() {
  const host = document.getElementById('notif-history-list');
  const sub = document.getElementById('notif-history-sub');
  if (!host) return;
  const list = getNotifHistory().sort((a,b) => _safeNotifTime(b.createdAt) - _safeNotifTime(a.createdAt));
  if (sub) sub.textContent = list.length ? `${list.length} saved notifications · recent first` : 'Recent first · grouped by date';
  if (!list.length) {
    host.innerHTML = `<div style="padding:18px 14px;border-radius:20px;border:1px dashed rgba(var(--accent-rgb),.18);background:rgba(255,255,255,.02);text-align:center;color:var(--t3)"><div style="font-size:.86rem;color:var(--text);margin-bottom:6px">No notifications yet</div><div style="font-size:.72rem;line-height:1.6">New admin messages, prayer alerts, and alarm notifications will appear here.</div></div>`;
    return;
  }
  let html = '';
  let currentGroup = '';
  list.forEach(item => {
    const d = _safeNotifTime(item.createdAt);
    const group = _notifHistoryDateLabel(d);
    if (group !== currentGroup) {
      currentGroup = group;
      html += `<div style="position:sticky;top:-12px;z-index:1;padding:10px 6px 8px;margin:2px 0 6px;background:linear-gradient(180deg,rgba(10,12,16,.98),rgba(10,12,16,.84),rgba(10,12,16,0));font-size:.66rem;letter-spacing:.12em;text-transform:uppercase;color:var(--gold)">${group}</div>`;
    }
    const typeLabel = item.type === 'admin' ? 'Admin' : item.type === 'prayer' ? 'Prayer' : item.type === 'alarm' ? 'Alarm' : 'Notice';
    html += `<div style="padding:13px 13px 12px;margin-bottom:10px;border-radius:18px;border:1px solid rgba(255,255,255,.06);background:linear-gradient(180deg,rgba(255,255,255,.04),rgba(255,255,255,.02));box-shadow:inset 0 1px 0 rgba(255,255,255,.03)">
      <div style="display:flex;align-items:flex-start;gap:10px">
        <div style="width:34px;height:34px;border-radius:12px;display:flex;align-items:center;justify-content:center;background:rgba(var(--accent-rgb),.12);border:1px solid rgba(var(--accent-rgb),.22);color:var(--gold);flex-shrink:0">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M15 17h5l-1.4-1.4A2 2 0 0 1 18 14.2V11a6 6 0 1 0-12 0v3.2a2 2 0 0 1-.6 1.4L4 17h5"></path><path d="M10 21a2 2 0 0 0 4 0"></path></svg>
        </div>
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:3px">
            <div style="font-size:.84rem;font-weight:700;color:var(--text);line-height:1.35">${escHtml(item.title || 'Notification')}</div>
            <div style="font-size:.62rem;color:var(--t3);white-space:nowrap">${d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'})}</div>
          </div>
          <div style="font-size:.73rem;line-height:1.55;color:var(--t2)">${escHtml(item.body || '')}</div>
          <div style="margin-top:8px;font-size:.58rem;letter-spacing:.12em;text-transform:uppercase;color:var(--t3)">${typeLabel}</div>
        </div>
      </div>
    </div>`;
  });
  host.innerHTML = html;
}
function openNotifHistory() {
  const overlay = document.getElementById('notif-history-overlay');
  const sheet = document.getElementById('notif-history-sheet');
  if (!overlay || !sheet) return;
  renderNotifHistory();
  markNotifHistoryRead();
  overlay.style.display = 'block';
  sheet.style.display = 'block';
  requestAnimationFrame(() => {
    overlay.style.opacity = '1';
    sheet.style.opacity = '1';
    sheet.style.transform = 'translateX(-50%) translateY(0)';
  });
}
function closeNotifHistory() {
  const overlay = document.getElementById('notif-history-overlay');
  const sheet = document.getElementById('notif-history-sheet');
  if (!overlay || !sheet) return;
  overlay.style.opacity = '0';
  sheet.style.opacity = '0';
  sheet.style.transform = 'translateX(-50%) translateY(-18px)';
  setTimeout(() => {
    overlay.style.display = 'none';
    sheet.style.display = 'none';
  }, 220);
}

async function _initNotifListener() {
  let attempts = 0;
  while (!_supa && attempts < 20) {
    await new Promise(r => setTimeout(r, 300));
    attempts++;
  }
  renderNotifHistoryBadge();
  if (!_supa) return;

  try {
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    const { data } = await _supa
      .from('notifications')
      .select('*')
      .gte('sent_at', since)
      .order('sent_at', { ascending: false })
      .limit(1);
    if (data && data.length) {
      const n = data[0];
      addNotifHistoryItem({ id:n.id, title:n.title, body:n.body, type:'admin', createdAt:n.sent_at || n.created_at });
      const seen = _notifGetSeen();
      if (!seen.has(n.id)) {
        _notifMarkSeen(n.id);
        setTimeout(() => {
          showAdminNotif(n.title, n.body, n.id, n.sent_at || n.created_at);
        }, 2500);
      }
    }
  } catch(e) {}

  if (_notifChannel) {
    try { _supa.removeChannel(_notifChannel); } catch {}
  }
  _notifChannel = _supa
    .channel('public:notifications')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications' }, payload => {
      const n = payload.new;
      if (!n || !n.id) return;
      addNotifHistoryItem({ id:n.id, title:n.title, body:n.body, type:'admin', createdAt:n.sent_at || n.created_at });
      const seen = _notifGetSeen();
      if (seen.has(n.id)) return;
      _notifMarkSeen(n.id);
      showAdminNotif(n.title, n.body, n.id, n.sent_at || n.created_at);
    })
    .subscribe();
}

setTimeout(_initNotifListener, 3000);

// ── Splash Screen ──
(function() {
  const APP_ICON_URL = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCAIAAgADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD45ooxmnYxX3R1oBxSgUAU8DpVDAKadRTgPT8aAALT1WlC8U/b9AKoBAOwp68e/wBaTHpTlGOgpgFOC7valA6cU8DtVJWHsIBTgMe1KB6U8DJphYaAafj0pwQ4pwX6UANC07bntTgOelPx60DIwKeBxTselOxmgBm2nbT3wPrTwKcB6qPxpgMxjuT9adtPpTto9KUL9BSAbt9qXA7U7H0pdvtTsMZilx7U7BpcU7CG4+lGKfj2pMH0oSuOw3FGKft9qNv0p8oWGY96Me4qTZ9KMY7D8KVgI8e4pMVLj2FN2n0osAzb7UEVqRy6UPDk0ElpKb8zKyTCUABdrZGNvqRxms7FAERFG32qTHNJj86BEe09iKaQPSpsUxlGO4/GiwEJWmkGpitIQRSsBDj0pCPbFTEetMxSAhIwelN2VNimlfWgCAikxUxU0wrQBCy5FNK+1TFQTzTNuOtAiFgQaaRUxX3ppXNAEJGeoppGDUpHrTSOOmaiwiEimkVMw4qMrSEQ0hFSEe3HpTSMGpaDYjIpMZp5AP1phBpbjGEYpKf1GKaRipYrDvpTgM0Ad6eox1qxhjApw59aKeopgCg9qeAKAop4HemAKM9afye1Az3pwHrTXcdhoGaeq0oGe1PA56VYAAAMflTh9KUDmnhCOT0oGNVc1IF9qUCngZ6UAIBg04D1pcY6CnhaAG49KUCnhSfenheKAGBT9acF9ad9cfhTgPQU0AmPwFGKcBTgPUCmNjQKUCnbfwFO207DGYNKBntUgXtShadgI9vtShcVIAB2/WjGKdgI8UpTHoak2k0bfcU7AMC4pduey/hTwBS49iKAIsY6hfwpSvsPwqTHsaMetAEOyjZUu2jb7UAQlT0pCvsPyqUqTRtpWAh2+1IVqcrTSKLAQ4I6CmkVMVI7ZppUntU2AiIppB9Km203bik0BEVFMK1Ng03r0oEQFaaRVgrTCvpSsIhK5phUVMV5pu3tSAgK00jBxVjHtUZFAEOPTpTCvFTFeKaRQIgI54phGKmK57U0j86VhEJHoKaV9KlxTSPSk0BCR6VGRzxU5GelMI9KhgQkYNNYZFSkZpmMHFIWxEQaQjIxUhHfvTDwaW4yQLTqO1OA9KYChfSngcdKAOKeB61QAB604DHJAoA9aeBzz+FOw0AHrTwDmhR37+tPA4qrAAHpTwM9KFFSKuB05pjBVp6jHWgD0pwFAAF9acFzSqvtUir7UAMC1Iq88/kKcFx7U4D0qgGge1OApwWnBc0DGBadt9qkCn1FLtquUYwCnBe1P289acF9qdgGgew/GgLUuygL7UwGAZ9KUDPapQue1PETGgCDYaXZzzmrsNjPMcRRPJn+6Cf5VoxeG9SlwRbbB6uQKhzSFcwtuKdt9APyrqI/Cd23LyxJ+Zq0nhFf+Wl0c/7Kf/Xpe1iFzjdh96PLbuK7hfClqPvTTH8AKkHhSxxgtOf+BD/Cp9tELnCbCO1IYzjpiu9/4RWw/wCmv/fQ/wAKY3hSzPAkmH4g/wBKft4hzHCFSOoNJj2rt28JQ/wXDj/eUGq0nhKUD93cxn/eXFCrRYXOQ2D0o24ro5vC+oJyqROP9l/8aoTaRewj95ayL77eKtTTC5k7fpSEZ7VaaFwelRmNhTuMg2U0rVjYfwphXFMCArx0ppUipitJtoYEBX2ppGR0qcrmmFanlEyIjimY9BUzD2FMZcGpEREUwripSM0m0/WgZBimkZ+tTMufp696RhjrjFKwiBh60wjPTrUzDjmmFTSAhI9qYR61My0wjFArEJRtpO04HGajIweK2ItV8nw3c6UbGyfzpkl+0NEDIu0MMBs5/irLYcUAQkHtTCM1MR3xTDUtAQkd6YwwKmI9qjYcVLQiGkIp7DnpTakVh4GalUYpqj161IBnpVDACnikA9KeAfSmgFA/KnAfnQBnGRzUgHYVYABx/WpAPakUVIo/AUFCqtOA7UBT0p+DQMAM9Kcq0oX8KkAOcmmIQLUgHFA604Lz60xiKOeaftP/ANalC4HAp4XmmlcBqqaeFx70oHsKeBV2GJtHtS4p4QgU5UyeBQAwL608KT06Vat7KWeQJHG0jnoFGa6Gx8KzPhrp1iH9wcn/AAFQ5pbibOYWBmrTtNBvrrBS3Kqf4n+UV2tno1naAGKAFh/G3JrSWDnpWLrdhNnJ2vhJBg3M+f8AZjGP1NbNroNhCQUtFY+r/Mf1rZESjnHNOC1k5yZJWS2VV2gbR6AVIsCVMFPeneXUjsQ+WnpThGOwH5VMIz2p3lE0AQbBjpRsHov5VY8k0vkfQ/hS0EVto9BSbR6CrRhPoPypDDTshorFc9h+VJ5Y71aMRxmmmJvQ0tBFQwr6VG1uMdfyq6yH0ppQ+lMdjJn0u1uMiaCN/qOfzrLuPC9lICYvMib2ORXU7aaV46U1KSDY4C68L3cWWiKTD/Z4P5GsS5spYX2yRsjejDFerGIMPSqs9lHNGUliV1PUMM1oqz6hc8paM57Uwriu7vPC9tLlrcmFvQ8r/jXPX2h3VpkyR5T++vIreNVSKuYZWmlRnvVl4Sp6VEVPerGV2XvTCtWMe1NK+lMCuRTcYqcrUbDjpUNWFYhNNx7ipSKaR60gICuD0ppHtUzCmFeeKW4iErzxTGXj2qbBPQUwj2pAQFcdKYQO9Tkd+1RkYoAgI/8A10w8dKnK8Y7VGw7Ac0CICOc5NNI7jgVKy/l6UwjFSIiIqMqamYUxhxzUgSgU5Rjp+NCj1pQBjpQAoHYVIq8ZoC5/rTwD/wDW7VYwUZPvUgXjikA/OpAuO1MYoGOlPAoANOA7UAKAc09VH40KvFSAelPYAAx9acB2FAFSBeOn4Uxgq8U8D25pQMfSpFX2ppDGhKkAo+gFSKMcVYDAOakVSex/GnpCzdRW7pegXF5iRgY4v75HX6CpcktwMiG0kkkVEQsx4AAyTXTad4WZtsl6dg/55r1/E9q6HT9Kt7JAIYgD3kP3jWmkYXsM+tc0qrexNyja6dBbR7IIURe+Byfxq6sSgc1KB6AYp6oayeoiIKB2/Onhc9qmSInsTWja6NdTYJTy19X4/Sk3YLmWIye1SrAWOAuT7V0sGhwIAZS0h9OgrRhtYoRiKJE/3RUOohHKw6Tdy/dgZR6twKux+H5TzJIi+wBNdII6kEZz0rN1X0AwY9BgGN0kh+gAqwmjWa9YifqxrZELdhTxbN6VPO+4GONMsx0tk/HJp4061H/LtFj/AHa2PsxPUUv2Ueg/Ol7QVzH/ALPtsf8AHtF/3yKadOtT/wAu0X/fNbX2X2FBtTnpmlzhcwW0qyPWAfUEioH0S0b7okU+xz/OuiNsaYbdh2p87GcvJ4fGfknH/AhVSXQ7tMlUVx6qa69oDn7tNMWO1UqrFc4SWzkiOJI2Q/7QxUDQ+xrvWiDDBAI9xmqM+k2kuT5Qjb1Tj9K0VVdR3scY0XtTCmO1dJcaDKuTCyv7Hg/4Vkz2kkLlZIyp9xVqSewrmeUB6gVA8Gf4avNEc1GUOetUM5rUPDdrcktGohk9VHBP0/wrlNQ0a5smPmx5Xs68qa9NZc8EVBNbJIpDKGU9QeauFWURpnkjwlT0qIrXd6n4YRwZLIKh7xt0P0PauTubKSGRo5IyrjqCMEV1RqKRSdzOK5qMpVhoyDyKjx+NWMrlcU0j24qwy+1Rlcen4VLQrkBXFMI7GpyPyqMj3qREDLTCtTkcEdqjZfbntSsBCQajI9KnYCo2UUgIGAqMrk4NWCDUZXtQLcgIHWmHI61MR7ZPpTGA6YoEQkZGCKjYcVNg9DTGBPY1mBKBzx0pw60gHOKeB3qkgLemXMFpq1tc3NqlzFHKrtE5IBAYHsRReTQ3OoTTwWyW8buzLEhJCgknGSTVcDtUirzVDQqgA81KBge9IBT8Y60DADtUij2pFXnpxUgGKYCgdhTwuaAuelPA6cU0MUDJp4HpQAfYfU08LVJXGKq08fSgDPXpUiqT0FUAijPGKtW9o80oRVLOegA61Y0/TZ7y4EUMeWP5D3Nd1pWiwWEeVAeUj5pCP0HoKynUUdBN2M3SPDaR7ZrxQz9RH2H19TXTRwgDpUqIFHv2qRRz61yuTluQNC9Keq57U9YyT0rSsdJnusHaUT+8w6/T1qW0hlCOElgACa2LPQppAHmPlL6YyTWzZ6dBaj92nzd3PWr6Rj0rGVXsIo22n29sB5cY3f3m5NXVjGasJbsx6VpWej3V1jyYSR/fPCj8axc+7Ay1hYnoanS1ZiMjmustfDMaAG5lLH+6n+Na9vYWtuP3MCKfXGT+dYSrJbCbONttCu5sFLd8erfKP1rTg8LSf8tZY09gC2K6oJzTgtZOs2TcwY/DVouPMklf9KtR6Hp6j/j2B/3iTWttHYUY9qlzYiium2SfdtYR6fKDUgs7cf8ALGIfRRVvFGKXMwKptIf+eMZ/4CKa1hanrbQn/gAq4RijGetLmaAzW0iwfrax/gMfyqrJ4esH6JIn0b/GtzaPQfhSbc+1PnaA5iXwxGQTFOfo6/4VnT+G7tPuokgH90/0rtyvFN2D0q1VaBOx5vPp0sJ2yRsh9GGKpvbEdq9QkhWRSrIGHoRmsy60GymzhDET3T/CtI1+47nnjRH0qCW3SRNjoHU9Q3NddeeHLmLLRbZU9uD+VYk1mysVKkEdQRW0Z32GtTlrnQ4nJa3Oxv7rcisO6sZrd8SoR6HsfpXdvCRziq8sCSIUdQynqDW8ancZwLR46CoSuDXU3uhggva8H+4f6GsKa3eN2RlII7Gt1K4yg0YIxWZqGlW97HsmTDD7rjqtbLJ69KjI/Kne2wHm2q6JPYyEsu5D0cdD/gaxHiIPOcV63PbpLEyOgZGGCCM5rjda8PNbbri2UtD1I7r/AIiuinVvoykzkSMdqYyirckJVjxUDLit07lFcr70wjHapyBUZGOtJoCAjuaY3TFSkY6VGenNIViEjHSmMPyqYjPao2GOlIRCRjrTGHOR1qYjjmo2BqQISKiIqcjvURA6Y49KBEZFMIqVh3qMj3qRDwKkUUij9aeB61QDguakVeOmfekUVIBQUKBT1GT0pAKkVfXpQmAqripFBzQBT16VQ2Ko7YJ+lPUGkUY6VKo9qaGAWpAtAXnGKkVcnAqgBFy2B1rX0vSpr6cJGuB1ZiOFFJpelS310scQ92YjgCu/sLCKzt1hhXAHU9yfU1jUqW0QmxunabDZ24jiTA/iY9WPvWkqAChVAwMVKqk4rlbuQIq5wasQwNI4VVLE9ABnNTWllJcyiONcnuT0FdRYabFaINq7n7sRz/8AWFTOdgKNhoiIBJcrlu0YPA+vrW2kYAGB7YqVIie1XbWyeaRURdzHoq81yyqXFcqpATjAxWtp+jXF22Y48L3dugrd07w5HGBJdgOe0Y6D6nvW+kSqoVVAA6ADGK551ktEJsyrLQLW3w0o86Qd26D8K1lRR0HT8KkC5pwXmueUmyRoXjpS7cVJt9aMZ7UgGhfanYHvU1va3F1II7aCSZvSNS1blp4N1q4AMkUdsD/z1bn8hms5VYx3YrpbnPbaNvtXdW3gGHA+1ahIx9IkC/qc1pw+C9CiHzQSTf8AXSQ/0xWTxUETzo8yx7Uhx6j869bj8OaHH93S7b8Uz/Op10nTF4XT7UD2iX/Cs3jF0Qc6PHRj1/M0uM9K9jOm6eRg2NsR7xL/AIVG+iaQ4w+m2h/7ZAUvra7BznkO09xmk2n0NeqSeFdAlHOnRp7oSv8AI1Qn8CaU4/cT3MJ/3gw/WrWKh1DnR5yVHuaMV11z4EvkObW9hmHYSAof6isW70HVrHJuLCQIP44xvH6VtGtCWzK5kzJwPSmlc1OVpm2tEMhZc9qp3VhbXa4niDHs3Qj8a0StMK+1O7QXschfeGpEBe1Pmjuh4b/A1z09o8bFSpBHUHtXpxX1FUL7TLa9Q+amG7OOo/xreNXox8x5rJHjgiqF5YQ3KYkTkdGHUV1up6JPaEsVDR9nX+vpWLLCVJ4rqhPqizh77TZbV8kbk7MBwf8A69Zrxmu/lhV0KsuQeoNc9qWjtFmWAZj6le6//WrojUuBzhUj0qF0BHIq68ZFQEY5rRgcZrvh8BXurOP5erxgdPcf4VyEsO1uBzXrrpkVyev6EDuu7WP3dB/MV0U6ltGNPocMRUbD2q3NFtPSoCPrXQncsrsPWo2WrDLxUZHtQBWYZprA+lSsD0ppqBEDLUZHtU5FREUrCISPao2WpyPao2GaQmQHjNREdu1WG6ZqEigRKP8A9VSKDQAM09R60DsOAp4FIBT1HegY4DBxUigCmqPzPQU8daaVxj156dqeBSKMcAVIKYxQM1IAaRBx+NSKM00AqitLT7GW7uEhiXLN+Q9zVa2gaSQBVJJ6CvQdE0lbG2ywHnOPnPp7VNWfKhMt6XpsVlarDGPdj3J9a0woAwKao2ipVUntXE3ckEXmtLT9PkupgqAAD7zHtSWFg91OEUYH8TegrrrW1jt4lijUBR+tROdhDbSzit4hHEuB396vJGegFOjjJ4xit/R9Fa7YSSgpD692+n+Nck6nViuVtM0ia9kwi4QfecjgV2Fjp0FjFtiX5j1c9TViCCOGJY4kCqvAAGKnC/lXJKbZAgXjpT1XHHf0pVXtingYFQ2AgHc04H2rW0jw7f6swaFBFB3mk6fh613eleF9M0oLIqefOP8AltKMkfQdBXNUxEYadSXJI4jTPC2q6iFfyfs0J/5aTcZ+i9TXW6f4K0q1Ae633kg/56cKP+Aj+ua6aiuOdecupm5NkcMENvEI4IkjQdFRQo/SpKKKyJCiiigAooooAKKKKACiiigAooooAzL7QtL1HJurSNmP8aja35iuW1HwJKgL6ZdCQf8APKbg/gw4/Ou8oq4VJR2Y02jxq6srqxnMN3byQv6OOv0Peq5X2r2a6tLa9tzBdQRyxnqrjNcbq/gkqGn0mQsOvkSHn/gLf0NddPFJ6SNFO+5xBWmFatTQSQztFLG0cinDIwwRUOK6lK5ZWeJXUgrkHgg1zmq+HgVaazXjqYv8P8K6kr2FMZauM2tgPLp7YqTkEGqjpXoWraJHdhpoRtm6n0f6+/vXG3Vo8TsjIVIOCD2NdkKl0UtjkNT0fO6a2XnqyD+YrnZIirdK9BdMcd6wdW0oMGuIE56so/mK6qdTox7HKsOcEZFQSICOlXZI8HPeoGGK2QzhvEGi+UWu7dB5Z+8o/hP+FcpLGVbkV63NCrxlWUEEcg1wWu6SbK4JQEwvkofT2ropVOjKTObZc1G68VNIuGqNq6EOxAw4yBk96jIwelTkGo2AFQMgxTGFSkVGaBEJFRt0qZhzUZB6mpEQnrUbDrj8qmYVGRQIlUU8DApoFSKKBigdqmUZ7cVGoyalHTvQMcOvSnKOc00Z7VKBVDHKPSpFHrTVGTUoGDQAoHNTxR73HHFRouSK3tD0w3l4qMD5a8ufb0ok7LUDa8N6SAq3sy8/8s1/rXVxoAtMgiCRgBQABgCrAGTiuOUuZkvUVQTV6ys5LmdY0HzHv6VDDEWcKoJJOMCuw0zThaW4B5lb7xHb2rOUrIkmsrKO3gWONfcn1NaMceSMfypIo88Vv6LpBu5d7giFTyfX2rklPqxN2JNF0Y3JE0y4iHb+9/8AWrrokVFCqAABgAdqIo1SMIqhQBgADGKmAFcUpOTJADjNPA4pRVvT9PutSvFtbSLe55z2UepPYVm5JasRBFDJNMsUSM8jHCqoySa7jQvBkcQW51cLJIORbjlV/wB49z7dPrWxoXh200eDcuJLlhh5iOfoPQVt1wVcQ5aR2MpTvsNRFRAqgBQMAAYApQM0tFcxAmKWiigApDS0UAAGKKKKACiiigBtLilooAKKKKAAnFIBmlooAKKKKACm06igDN1XQ7HV4Nl1F8wHyyrwy/j/AErzrWfD97o8uZQJLdj8syDg+xHY16vTJoY54WhmRXRhhlYZBFa06soehSlY8VYZqMjNdZ4i8LSafvvNPVpLXq0fVox/UfyrljyK9CE1NXRqncgKgjpWVq2kR30JdAFmA4b19jW0QaYV57fjWqlYZ5jd2jRSMjoVZTgg9qzpE56V6LrOkrfQmWJcTqOMfxD0rhrm3KOQVxjr7V2U53RSZyGsaaFJuIV+X+NR29/pXPyx47V6BIgIIIyD1HrXK6rYG3nyqny26E9vau2nO+hRhMtUNQsY7y0eCQcHv6Hsa1HUg5qFh+VabO4Hleo2T2tzJFIuHU1mMMHkV6J4i0oXVoZ4l/fR88dx6f1rgp4yrHsK66cuZFoqMPaoiOOlWGHqKjYc81oMrsPSoyPapiMGozUgQsuDUZGO1TEZqJgc0iSIjvUbD1qYio2HFICRR+dPFIo4pw5NAEijinjmkFSAVQxyj06VItMUU8c8c4oGPQd6kX0pFGBUka5amBZtoS7gBck8ACvRtG04WVgsZUeYeXPv6fhXOeGdOE119pkX5IsYz3b/ADzXbxrgCuerO+hMmPUADipo0JamovNaWm2ZurpYhnHViOwrFuwjV0PTxxdyL7IP5mujiTpUUESoiqowFGAKv28RkcAAk9ABXHUldiLul6e95dLEowOrN6Cu7treO3t1hiXCqOBVTSNOWxsghAMjcv8A4VpqPSuGpO7MwC1KFx2pAAB04q1Z2c9/eR2lsm+VzgD+p9qylJLVgP0zTbnVb9bW2TLHlnPRB6mvUtI0e10exEFsuSeXkPVz6n/Co9E0e30fTxBFhpGwZZMcuf8AD0FalebWrOo7LYxlK4UUUViSFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUVkeIPE/h7wppDap4l1vT9Jsl63F9cLCmfQFjyfYV4pr/AO2d8CdDlMUGu6jrRXgtpdhI6fg77VP1Bq4U5z+FXGk3sfQVFfM1j+3T8Ery4EUsXiezUnHmzacHUfXy3Y/pXtngn4leBviPpLaj4J8S2OsQpgSLA+JIiegeNgGT8QKc6NSGsotA4tHW0UUVmIQjNcH4o8LCAPqWmx/u/vSwqPu/7S+3tXe0hGRVQm4O6GnY8TI7imEZNdb4r8OixkbUrJMWzH94gH+rPr9D+lcqwPpXpU5qaujZO5AwGK5nxDpIkVryFeesij+ddSQO4qJ0DKQeQa6IyaegzyuaIoxGKzru2S5t3hfgHofQ+tdfrml/ZbktGP3T5K/1Fc3IuM12wldXLRwd3btFO0bjDA4NUWXBxXXa1ZebB9pRfmT7w9RXLyr1rsg7oEUpFBFcF4i00Wt8WjTEUnzL7eor0FhxWTrFgL3T3jH31G5T7+n41pCXKxnmDLhsdqiYVduoikhyOnWqjCu1dyyBh61Ew56VYYHHtULdaVhkJ6mmMKmYVG3PWkSV6awHpx3qQ8U0jtUiY6npTFqVegpjHqKkX6CmrT15pgPFSL96owOKmQYFBQ4cnFXLaIu4UDJPAFVkXLAV03hmx8/UhIy5WIbz9e3+falJ2QHW6TZCz0+OHHIGWPqe9agHOKjiXAFTqvNchJJEpPauv0Wz+z2gdlw8nJz2HYVgaVaC5vUQrlR8zfSuxjXgVhVl0JJ415wK6zw3pwZheSLkKcIPfua5/T7Vrm5jijHzOcZr0O1t0t7ZIYxhVGB7+9cNadlYlssKAPapAB+FIop6iuYkcoJYYGT2HrXpfhbQhpdgZp1/0uYZc/3B/dH9fesDwZoouLn+1bhMxRHEQP8AE/c/h/P6V6BXnYipd8qM5y6ATikzQRmlAxXMZhUN1d21jayXV3PFBBGpaSWVwiIB3JPAH1rgPjD8YfC/wa8BN4h8Qu09xMTFYabCwE15LjO1c9FHVnPCj1JAP59a74t+O/7UXi6WzsdN1HU7GKTK6RpgMen2Q7eY7EKW/wBqQk+gA4rrw+ElW95u0e7LjBvU+4fE37VvwK8L3MlrceN7fUbmM4aLSIZLzH/AkGz/AMerkG/bn+Cok2rB4qcf3xpgA/V814Pov7CfxRv7JJdY8Q+GtHZh/qA8t06+x2qF/Imr91+wN4/SMmy8eeG5m/uy208X6jdXYsPgVo6jZajDufQek/tl/AbVJAk/iO/0tj0+36bMg/NVYCvSvDXxa+GnjAonhrx14f1KV+kMN6nmf98Ehv0r8+vEP7Hnxz0BHltdAsNciTndpN8jMfokmxj+FeM+IvC3iXwtqH2PxV4d1PRrgHhNRtXhP4FgAfwNarLcNVX7qpqP2cXsz9ngfXilJxX5DeE/jN8VvAojXw1481u1gTlbWWc3MH08uXcuPoBXvHhH9u/xzpwjg8ZeFdI1yIcNcWTtZTH3x86E/gK56uUV4ax1JdGS2P0BJxRXzh4W/bZ+C2uBI9YudX8NzkfMNQs2kjB9pIt4/MCvTtM+OXwd1iATWPxN8Ksp7SajHE35OQf0rgnQqw+KLIcWj0Go5J4opY43kRXkJCKWALYGTgd+Oa8z8R/tE/BXwvZPPqXxH0GVlBIhsLkXkrewSLcc1856N8ddT+PH7a/gKz8JaddWHhvQri5u18/AlnUwOkksoBIQbSEVcn73PJwKp4apNOVrJAotn25RTR0GTzXH6v8AFj4Y6Bemz1r4geGLC5U4aC41OFXH1XdkVik3olcmx2VFc/oPjfwd4n/5FvxVournGcWF9HOfyUk1v5GKVmtwAnFfJXx+/bH03wddXXhP4ZLaavrkW6O51WU77SyYcFVA/wBdIO/OxT1JORXP/tdftKXWnXd18JvAV+YboL5et6nA2Gi3D/j1jYdGIPzsOQDtHJOMT9kn9mu08QW1p8VPH2nrLpwYSaLpU6fJcYPFzKp6oCPkXocbjxtz6NHDQp0/b19ui7msYJLmkYXw6/Z1+Kvx/wBTi+IPxb8TapY6VcYkhmvf3l5coenkRN8kEfoSBkYwpHNfWHhT9mT4J+EbWNbXwLp2pTqPmu9ZX7bK59T5mVH4ACvXQoHSlrnrYupU0vZdkQ5tnn+s/A74Qa/p7Wep/Dbwy8TDGYtPjgdfo8YVh+Br4o+N/wALda/Zg+JmjfED4Y63e2ul3czR27yvve2lA3G3lP8Ay1iZQSA3UBgeQDX6L18p/t66nY2/wA0XSZWU3l5rkTwL32xxSF2/Dco/4EK0wNWftVBu6ejRVOTvY91+Enj+0+J/we0PxvaxCA38H7+3Bz5MyEpImfQOpx7Yrt6+dP2Jba6g/ZPsZbhWVJ9SvZYcjqnmbcj23K1fRdc9eChUlFbJkSVnYKKKKyERyxJPC0UqhkYFWUjIIPavLfEGjPo+pFFBa1k5iY/+gn3FerAYrP1nTIdV0t7SUAE8o5H3G7GtKVRwlcqMrM8hZccZFRsM1auLeW2uZLeZdssbFWHoagIr1E76mxm6hZreWbRMBk8qfQ159e27RTujLhgcEV6cy8VyviTT+RdoOvyv9exroozs7DTOIkQEEFcg8EVx+p2htrt4wPl6r9K7eWPBPFYus2vnWZkUZaPn3x3/AMa7qbsyzjWGGqCRcqTVyVTuqsw7HkV1AcB4l0/yL9pEXEcvzD69x/WuaZSDzXpev2X2rSpNoy8fzL/X9K85uE2yGumlK6LRVYVC9WCMioWHFaDIWBx0IpjD5qlIqM8DNITIWFRmpnqIipEKvWpl6VGoqReRTQEgqQDFMXnFSCmND1FSimLyakXrTGTwoWYV6H4ctPI0lXK4aU7/AMO3+feuI062NxdxQqOXYLXptrEqRqqjCqMCsK0uhLZYQYqxGuT0qFRzXTeFfDcuu3g8xzDaI2HkHU+y+/8AKuaTUVdkvQt6HbCKy81hhpDkfStuNCCAR19a73T7HTdNgWKzto0CjG4jcx/E1ogQXA2SRJIDxhlBrglWu7iuYfhexwjXbjn7if1P9K6dR0wOakXT4YbcJbIEVf4B0/D9aIomfpwPU1yTld3IFAq7p9lLqGoQ2cI+eRsZ/ujufwFRLAoHJJNbmgTtplw15HAkhddnz9hnnBrGpdR0E/I9Es7WGxsYrWBcRxqFUVR1TXbXS1CODLMRlYlPP1J7Coxr1vLpUtwg2yoP9Ux5yen1FcZMss9w80zF3c5Zj3rgp0eZ+8Zxjfcvz+KdXlYmHyYV9Am79TTY/GV/ZI8+otA9vGpeSRhs2KBktkdgATWd5X0FecfH6/m0b9mnxhfWz7JXsfsqsOo86RYifyc12woQk1GxpyrY8D0fSdZ/bG/amv8AV9Qubmz8G6WAMocNBZ7j5UMfYSykF2btyf4VFffPhfwn4e8F+GLbw74X0m20zTLZcRW1um1R6knqzHuxySepr5m/ZM0UeF/2fdJ1i0QC51Wea/mP98bzGin2CRj8zX1bb3CXNpHcJ911DCs8e2pKC+FbEVNHYmpMiq739mjbHuoQ3oXFfBn7Wd14q+Fn7RGl+NfBPjLW9NGu2puSkN9I0STxMEcCMkoUZTGShGM7uOa58PQdefItGTGN3Y+/ODVPUdL07VrF7LVLG2vbVxh4LmJZUb6qwIrzz4BfE0/Fv4Iab4suYo4dR3PaahFEMItxGcMVHZWBVwO27HavTXYICxIA7k1lKLhJxe6FseAfEH9lL4D61p91q9zpS+ETGjSzX+l3ItIowOSzo2YgB34FfCGq/DnStc+MEHgb4M6/feOnuXKR3DWH2RBjq28sQY1HJkIUemcivQv2pf2hbz4l+L7vwf4bvmj8F6ZOUzE3GpzIfmlbH3owQQi9DjceSMfV/wCyt8GLb4Z/CW31jVLRV8U65ClzfSOuXt4j80duD2CggsO7E+gr2IVauEoqpOTu9kbJuCuz4a8Q/s5fHDwvK41D4c6xcxp/y30xVvUI9QYiT+YFcZL4I8bLceTN4K8RiTONr6VPn/0Cv2W2rnOOaNvufzqY5zUStKKYvbM/KPwb+zb8ZvGlzHHp/ge/0y2cjdeauhsoUHr8/wAzfRVNfeXwB/Z80P4K+H55zdrqviS/ULfals2KFByIYlPKxg8nPLHk9AB7VgUprlxWYVcQuV6LsiZVHLQ/PD9qr4/+K/EXxN1P4Y+EtRu7DQdMn+w3S2LFZdSuQcOrFfmKBjsCD7xBJzwBzvgz9jL4x+J9Mj1C9stK8MwyrvSPV5is5B9Yo1YqfZiD6ivbPhz8Er/w5/wUM8Q614k0aa40to7zXNE1BoS8DyyyrwXxgSxiWQYODwGHY19iAADiuieN+rxjTw9tld+ZTnypKJ+c+p/sOfGPSFF9ouq+Gb+5Q7lFpey20oP+yzIOf+BCqE3xe/al+AkP9geMX1Bbe6ikhs21+NbwKQMF4JwxLFMg4LMOmRX6Tk8V+Vf7T3xOPxM+P2p3dtceZomjltM04A5UojfvJf8Agbhjn+6qela4OtPF1OWqk0t9Bwbm7M5H4bWXhHxB8ZNKPxO186f4ekuWuNTvJw8huOrFGZQSPMY4Zz0BY5zX6yeFfEHhPXtBhl8H6xpWo6dGipGdMmSSONQMKoCE7QBgY4xivm34OfsnfD3U/wBnTRm+IXhxpvEOox/2hLdxzvBcWokwY4gykcKm3III3FqytY/YUj03U31T4a/E7VtFuAcot5GWZf8AttC0bfmDWWNrUcTO3Na2m2gpyjJn2LketGR6ivjEfCj9tjw2yw6L8WrTVoV4UzahvJHbieAn9TTJvh5+3LrZ+zX/AMRLSwjbgvDqUUOPxhg3flXJ9Wj/AM/ERy+Z9ReP/ih4K+GPhx9Z8aa5badEFJigY7p7hv7sUQ+ZyfYY9SK/PfxRrfjz9r/9oW3sdB0+S1063UxWkT/NFpdoW+aedhxvYgE46kKi5xmvZdB/YY1LWte/tr4sfEu61S4Y5lj07fJLJ7G4nycfRa+qfAXw48G/DPwwug+C9Dt9Ms8hpCmWknfH35JDlnb3J+mK1p1aWFu6b5pd+iGmo7FrwT4S0vwJ8P8ASPCGioVsNMtUtot33m2jlm/2mOWPuTXQUUV57d3dmYUUUUAFFFFAHD+N9IIVNWgXpiObH/jrf0/KuJI5zXtF1bRXdnJbTANHIpRh7GvIb+zksdRms5R88Tlc+o7H8Riu3DVLrlZrB9CkQaq3dutxavA4+Vhg/wCNXGAqNhkYNdidmWeY6hbNDcPGwwykg1lyqCCCMg9R612fiayxcC4UDDjB+o/+t/KuTkTBNd8JXRaOE1G2+z3kkeOAePes5hk4NdRr9uCiXCjnOxv6VzTrhq7Iu6uCKcy8HgGvONcs/s2ozRDoDkfQ9K9NkXK1x/iy0yI7kDsUb+Y/rW9KVmXE4j1+tRsOeO1TyDD1Ew7nrXUUQEfWozUrDIqI9TSERHp9KjNTEc1E4qWIeo4zkU8VCrYPNP3ntir5B2JwMmpQKrLKw6gH6VZjZXGVNFmMlTpn8KkUVGtTxDLUgOn8K23m6n5mOIk3fieB/Wu7iXCVzXhO326fJMRy74/If4muoQfLiuSo7yIZLDG0s6RqPmdgo/GvWPD3lWlqlvCMRwoF+pPU/WvMNNIXUY3OPlyRn6V6FpExWwDZ5Y5rmraoR1qXZPetfSSZbnd12jNcnFNkgZrrtCXbYeYc5du/oOK4amiIZtBuOtPVu2RUCmng+tc4ixEryzJEn3mIUV0q2gRFRV4UYFUPDNobjUXnI3LCvp/Ef/rZrqvs3HIrmq1LOxMnYxvs/sKDbHHStk23tSC2x/DWSmLmMb7P7V5d+0RoV1rH7MfjG1s4zJNFZC7CgckQypKf/HUavavs3qKbJZRS28kE8KSwyKUkjcZV1IwQR6EEg1cK3LJSQKSueB/sr61Z6/8Asx6LbwSK1xpEk2nXCg8qQ5dD9CjqR+Ne1mW6+yJbeYwiTOEHAPPf1r4h1e38b/sffHS51HSdOm1TwBrUmI4nYrHNHklYS+CI7iLJCk/eX1BOPofw/wDtR/AzXNJS5uPFy6HcYy9pq1vJFIh9MqGVvqpNdFek5P2kVdPUqWuqPUjbBh0r4U/bN8RWuofGDSfDNrIsjaLYH7TtOQss7B9v1CLGT/vV678Tf2yPBOi6PPY/DQt4h1iRSsd7JA0dnbH++d4DSkdlAAPc9q+afhZ8KfGvx9+JM9wZrtrSS5NxrPiCcFliLNubBPDzNzhB06nCiunB0vZN1quiRcFbVn2N+w3pt1Yfs0TXlyrKuo6xcXUCnvGAkW4exaNvyrY/a9+J8nw++Ak2maZctBrPiJm062ZDhooiuZ5B6YQ7QexcV6d4d0Ox8HeHbHQ9Btha6fYW6WtvD12xqMAe57k9ySe9fnt+154/l8ZftHXulJLusfDkQ0yJV+75v352+u8hf+2Yrkw9H6ziuZ7XuZxjzTucr+zx4AT4h/tG+G9BuLcSadbzf2jfLj5TBBh9p9mbYn/Aq/WUcV8XfsD+Dgmk+KvH08WGnlj0m1fH8KDzZcfVmjH/AAGvr7X/ABDonhfQrjW/EOq2el6dbrvlu7yURRoPcnuew6ntUZpV9pXcV00FVd5WNSivnPxJ+2v8EdDlji0y/wBV8Rsxw7aXZkJHz3aYoD/wHNet/Dj4l+Evir4LTxP4Pv2uLMyGGWOVDHNbyAAmORD91gCD3BBBBIrhnRqQXNKLSM3Frc7GiuO+IPxT8CfC3SLbUvHPiCHS4bp2jt1ZHkkmYDJCIgLHAIycYGR61N4D+I/g34meG213wTrcOqWSSmGRkVkeJwAdro4DKcEHkcg5FRyy5ea2gWe51dAOa4bx78Xfh18MTaL458U2ekSXYZreF1eWSULwWCIpbaCQM4xW54T8YeG/HHhiDxF4U1i11XS5yRHc2zZUkHBUg4KsD1BAIo5ZJXa0FY8//aX+ID/Dj9nDX9atJvK1O6jGm6ew6ieb5Aw91Xe//Aa/O74C+BF+I/7QHhvwtNEZLAz/AGu9z0+zQ/O4P+9hU/4HXu37enjX7f438OfD+2m/dabbtqd0qn/lrLlIwfcIrH/gdXv2J9I0Xwj4K8Z/GbxXeW+nadDt0yK9uW2pHEmJJjnqcs0SgDklcDJr2sOnh8HKot5G8fdhc+6EUIoAAA7AdqdXyLqv7fHga18SG00nwTr+o6Yr7TfNLFA7juyxNk49AxU/Svpbwj410Dxt4A0/xloF4JdJvoPtEU0g2FQMhg4P3WUghh2INeTUoVKaTnG1zJxa3Piz9r744/EDSvjJP8OvDOu3+g6Xp9tBLM9hKYZbuSVd+WkHzBACAFBAyGJz29X/AGL/AB7448XfCfX38bardapa6ZfLBZalfPukK+XvkjaQ/eCErySSN2CeK19cn/ZR+OvxJtNJ1XVPDviLxLEDBb+RdSwyzKuSY1kQqJgPmIXJ74715x+2dr8Pw2+Dvhf4WeB7ODQ9I1TznuLawTylaCHb+647O8gZu7bec5Nd0eWrCGGjC0n1L3SjY+s9D8Z+E/FElzH4a8S6PrD2rBbhbC8jnMJPQNsJx0PWt2vgP9iDwzeaf+0R4tngnWWx03SRZ3E0QxHJLJKhVffHlyY+me9ffWcd648TQVCo4J3InHldj5O/aK/av174WfFFfA/g/QNLu7i2ginvbrUw7KTINyxoqMv8OCWJ/iwBxX0F8LPG0fxG+EGgeN47I2X9q2izvbbtwifJV1B7jcpwe4xXyJ+15oGieP8A9ovwp4I8C6eLvx/dw+XqMkLfJFBwYfOA6FQXcseiYB6rXuvir4o/Dz9lr4QeG/CV69zqN3bWKW1jplmB59yIxhpm3HEaFsksT1OADg1vUpQdKmqa99lNLlVtz3eivmP4S/tj6H8TPibZeDLnwVqOjT6gzR2lylyt3GXCl9smFUpkKeeR0zjOa+nO1clSlOm+WasyGmtwooAxRUCCuG8dadsmg1ONfvfupD7/AMJ/LIruazdcsv7R0G5tcAuULJ/vDkVdOXLJMadmeRsKYw5xUpHGajbp79q9VM3MjWbX7Rpcqhcso3r+H/1s159cJtkNepSKCDnJHfNedarb+ReyxYxtYj/P4V10X0Kic7qNv51jLH6jI+tcTMuGPFegSdK4nU4vJ1CaMdA2QPrzXfSdtCjOYZHPWsTXbbz9InXGSo3D6j/62a3D3qrPGGUqwGCMGtU7MDye4XDniqp6VqalD5N3LFjlGK/gKzSOCK7U7o0IG64qJhmpm61BM5X5R1/lTSu7ARsQOp59KiLZ7UY9aWtFBAHel60ir25p4GTRcAC59KlQlGBH/wCumqKeBSvcC4vIz61YgGXFVYWG0J3rQtlzIAO/FZNWA9F0GDytFtlI5K7j+JzWyo7VUtECW8cY/hUL+Qq4vauKWruZlm2ykykHmu+tD5dvGmfuqBXEafH5l/DGe7iu3i61jV1A0rdyWr0Kxj8qxhjxjagH6VwWlxedfwRY+9IB+tehxj0rgrPoQyUH3qQdKjWpVBK4HWudsR6B4SsjF4dWYrhp3L/gOB/Ktzyafp9sLXS7e2Ax5car+lWNteTKbbbMWyr5PYAE/Sk8r2q3gf3aNoPbNLmFcqeUaPIz25q3tX0P41wHxQ+MvgL4RaGt94v1QpcTKTa6dbKJLq6x12J/dHdmIUetOPNJ2itRrU6bVNE0rW9Hn0rWtNtdRsbhdk1rdxCWOQehU8GvDdf/AGMvgnrV809npusaGWOTHpeoMsefZJA4H0HFeJeIv22/iT4l1tdK+GvgmxszM22BJoZNSvJPoiYUH2AbHrWtp/xN/bjtIRq938PpL60A3m3n0SNGI/3I5BIPyzXoRw1elrzcr9bFqMkeraH+xh8EtFu1ubrS9X1tl52anqDNGfqkYQH6GvcdI0PS9A0eDSdE0210+wgXbFa2kSxRxj2VQAK8a+B37T+i/FDWm8HeI9Ibw14viDD7DIzGK5KffEZYBldcEmNhnAJBODj35lHeuWvOrzctW9yW5dTm/GGuWfhHwDrPiq/Krb6XZS3r7u+xCwH4kAfjX496jqN1qeq3er6lIZLu7me6uHPUu7F2P5k1+iX7bnjEeH/2eYvDUMu258RXyWxUdTBF+9k/DKxr/wACr4M+H/hSXxx8VvD3hKFSTqeoQ2zkDO2MsDIfwQMfwr2cpXJSnWf9WNqWkXI/Sz9nnQLb4c/sm+G01RorLGntq+oTSnaIzLmZyx7bVIH/AAGvgv4+fGrXPjZ8Rz9lNwvh21mMWjaWoOXydqzMv8Ur8Y/ughR3z9b/ALa3jVvB37PNr4R0p/Il8RXIsMJxttIl3yKPY4jT6Ma+bP2O/AkPjP8AaOttUv4RLY+HYDqbqw4abOyEfgxL/wDAK58GlGM8ZU1fQmHWbL37NHgfwvpn7WOpeCfizpmmTaha2ktrbWOohZYWu90ZKgN8rN5bNt/EjnFdl+zT428JfCL4n/GGy1vXbbS/DNjc5txM+S7R3M0SLGn3ncpgYUEnaPSvYf2kf2e/ht4u0bVfibrGp3vhzVNMsWuLrULII63CRLlRJG3DOMBVYEHoOcDHgX7NXwN8CeKvhdrfxe+KVtdXWl6XPM0Nk02yGVIYw8ry4+Z/mJXG4A7TnNEq1OvTlVm3rZW8/Id4yV2eS/Hb4xal8ZvilLrskctro9ohttKsXIzFDnJZ8ceY5wzY6YUds19j/sMeF5tH/Z8vfEVwrK2u6nJNCD0MUSiFSPqyyfpXwLfTal45+Ik01lZomoa3qGLe0hQKqNLIFjiVRwFXKqAOgFfo98UvEll+zl+xzDpejTRx6jbWEeiaTg4L3LJtMv8AwH95Kfp71rmEeWlTw9NbhU2UUfE37T3jkePf2mvEF9bT+bp2muNIsyGyuyHIcj2MhkP5V9t/sg+Fp/C37KWiy3gaOfWJZtXZWGNqythP/IaIfxr87PAPhO78f/FHQfB1qzGXVb2O2eU8lEJzI5+iB2/Cv0q+PvjfTfhB+zNqLacUt7mS0GjaPbg4IkePYmPZEDOf933qcxjyxp4WAVNlFH5y/GLxk/j347+KvFhcyRXWoSLbf9cIz5cQH/AEB/GvdfhT4B1T46WXh/4bw3c9h8MvByJLq1xbnadV1KXMkgU9yC5VTzsQburrj5Zs7G7vr2303Trea6upnWGGGJS7yMeAoA5JNe3aB8YvHer+AtB+A3wj0qDw9FfH7LNPHchbzU7iTmRnnbasQcg8LzgBd3QHtxdKSpRhT6fh5lyWlkY37SMvw7g+Ok+j/DPStP0/RdHtI9OlexX91PcIWMj5ydxGQhfJyUPJ619JG51P4Of8EtvI1QyWmr6zbSQW8DjDRNfSsQuOxELMxHY5q18Ef2LbDwzq1p4o+KN3Z6xf2zLLb6NagtaQuOQ0rMB5xB6LgLkc7q4T9vHx2NQ8daB8O7ObMOlwHUrxQePOlG2MH3WMMf8AtpXC6kcROnhoO6WrfcjmUmoo8b/Zs8N3Xib9qfwZaWgZUsr4alKw6JFbgyH6ZIVf+BV9iftteDPDus/s+Hxbquo/YNQ8PTebYvjd9oMpVGt8f7WFYHsUz0zXCfsF+A/L0zxH8SbuL5p3GkWLkfwJh5mH1Yxr/wAANbvxJl/4aB/a/wBI+EVkxn8IeDZBqfiF0OUmuBjEJ9eojx6tL/drPF1nLF80doilK8vQ+cbDU/2hP2dvAlpfWBPhvRvE5S6iuDDbXDTN5QZQ24M8bBDnaQMc9819D/si/HT4j/ErxrrfhbxvfJrEFtp4vob826RSxN5ip5bFAAwbcSMjI2nnFeIfth/ElfGvx2bw1ps4bSPC6tYxhD8r3JIM7D6ELGP9w+tfRn7Hvga1+H/7PN14/wBeKWlxrwOoSzTfL5FjEG8vOegI3yH2Yela4txeF9pUiueQ525btanv+meBfCWi+L9W8VaVoFha63qxU32oRxDzrjAAAZuuPlHAwOM1+Xv7SPiLUfEX7Ufja7vpGb7HqD6dboTxHFB8iKB2GQzfVie9foV8BPitqvxh8Ia54putEi07Sk1ie00iRSwe5tkC4dwf4skgkcZ4xxXwh+1j4Ybwz+1h4lZUIg1XytViJHXzUAf/AMiI9YZUmsQ4y3sTS+Kx+gXwL8O+H9B/Z78Hw+HrO3it5tKt7ppEQbpZZIlaSRm6lmYnJP07V6RX58/DX9r3UvBHwI0HwFo3ge48Qa/p6SW6zSSsIRCHJi+WNWdiFIBGABgcmtDTP26/iDpniWOPxt4B0lLANme3tUntbpE7svmkhiB2IAPTIrGpl9dyk7fiS6crs+9qKq6bqFvquk2upWjFre5hSeJiMEq6hgcduCKtV55mFFFFAHkuu2f2LxDd2wGFEhZfoeR/Oso8npXXeOrcR6xb3IGBLFtJ9Sp/wIrlGGM16lGXNBM3i7ogYcVxfiiHbqO8dHQH8eldq/Ga5nxTDutYpQBwxU/ln+lddJ6opbnDyDk1yviCLbeJJ03Lzx3FdbMMMa57X4wbWN8dGI/Ou+D1LOXI5qvKMrVqQfNWbqd/Fp9mZX5Y8LGDyx/oK6Fq7IDg/E8awavOzYCthsn3H+NczJcqDiME+/TNamv3FxfXwuLhgWIwFHQD0FYjL7V6FOC5dTRDWnkJxhfyqJss24nk05hnrQRzitUrAR0h6U7pTT0pgPFPUYpgGfapK57gOVcnrUoHHQU0AVItO4rD0GCCK2NLj8y/gT1kUfrWSg5wAK3tAXdrNsOuHB/LmolsM9Ih+7VhByKrwfcFWUrjMzY0RN2qRH0BP6V2EQ4FcpoC/wDEwJ7hD/SusiFc1XcTOg8OR7tYhOfugt09BXcIOK4/wuoOose6xn9SK7FelcVbclkqjNXtLg+061aQYzvmUfhnmqK8Zrb8KxiTxZZg/wALF/yU1yVX7rJex6nRRQBivKMAoooPSgDy/wCO3xf0v4M/C2fxHcxpd6nO32bS7Bm2/aZyMjOOQij5mPoMdSK/OLw9o/xB/aM+On2aa/fUNc1JjNeX9wD5VpAvVyB92NAQFQdyAOSTXWfta/Eabx7+0TqWnRTltJ8OltLtEz8u9T+/k+pkBXPpGK+r/wBjb4XQeCvgXD4qvbYLrXifbeyOy/NHajPkR+wwTIfd/avapr6jh/a/blsbr93G/U9M+E/wX8FfCDwymneGrBXvnQC81a4UG5u27lm/hX0RcKPc816IVXrgU6ivGlKUnzSd2Yt31Z8O/tt6DD4K8d+DPi54bxY601y0c80Q2mSWALLDIcdWwHQnuMDtX2hoOpprXhjT9YjXYl7axXSj0DoHx+tfDv7dHif/AISj4i+E/hfouLm+tQZp44+SJ7orFDH9duWx6OK+zhcaf4D+F4n1KcLY6HpgM8nQCOCIbiPwQ/nXXWi/Y0776/cXJXirnwD+234zPiL9oqPw5by77Tw7YpblQ3AnmxLJ+IXyh+FX/wBhrwedc+O2oeLJ4ybbQLA7Hxx58+UX8Qiyn8RXzp4r8RXni/xzq/inUCftWq3kt7ID/CXYsF/AED8K/Rn9jbwIfB/7Ntnqt3Dsv/EUx1STcMMIiAkA/wC+FDf8DNevi/8AZsGqfV/0zafuwseJ/t/yzv438EW75+zpYXci+m4yxg/oBW7/AME/oLUaV4+udy/ajcWUZHcR7JCD9Cxb8q9e/ag+B958Y/h7ZP4fkt08R6PI81ms7bEuEcASQlv4ScKVJ4BUZ4JI+NPCPwf/AGoPC3iie38H+FvFmgX9wv2aa6tpltonTPRpt+wrnkEE46iuWjKnWwfseZJruRG0oWue/ftefEi98VappX7PfgL/AE7W9Vuov7TjibOzkNFbsR0ycSv/AHVQZ61sfHzSIPgz/wAE+F8CaLKWDi10eSccGZpJPMnf/ge2T8Gro/2df2a4vhZJP4w8YX0es+N75W8y5DNLHZq/Lqjt8zyN/HIevQcZz2P7Rvwx1D4s/Am+8MaLLCmrRTR39iJ22pJLGT8jN/DuVmXPYkZ4rkVWnGcKa+FPV9yOZJpdD4X/AGR/Dttr/wC1NpF1fBDbaNbXGruZCAA0ahUJPs0gb/gNan7UXxDvfi14rfX9HkL+CNBvToumzgnbd3TIZJpl9RtRQD/d2f3qzvB/7K/x31fxWdLl8P3nha1kBgvNTvLhUiWFuHUCNyZgQPuDg8ZIHNfT/wAXv2ZY7n9lLR/h/wDDa2jkv/D90L6BLh1jfUHKssxZ+gkffuGcD5QvAxj0q+IpRxManNfp6GrlHmueFfsPeHbO7+M+ueL9QeNIdA0ksksjBVieZtpck8ACNJOfeuO/ab+Ll58XfiJ/aGlCU+DNJnk03SpOiXM20NLNz3YbceibOhatP4ffsx/HzWtXutClsNS8G6JfBYdVur2cRxzRBs7fJRsz85wp+XPUgV7J+0R+zBq5+EngnRPhHo39oW/hw3K3Vn5iLc3TTeWWuMsQHctH8wyDgjAwMU5VqMcWqjknf8BXXPe55D+xj4Lj8UftIQ61dQCS08OWj6h8w485v3UQ+oLO3/AK8++L3hy/+E37TWvabpTtZy6bqg1HS5R/BGzCeFh9M7f+Amvs79jP4V+Kfh34J8TXvjLQLjRtS1O9iWOG52+YYIo+D8pOAXd/yrjv27fhhLe6Po/xV0uDc9gBpuqbR/yxZswyH2Vyyk/9NB6VEcYpYxpv3XoHP759P/DDxzY/En4S6J400/aqajbK8sSn/UzD5ZYz7q4YfgK/LH40+JZ/FH7QHjTxBdOz+ZqtwiA9oomMSL+CxivfP2KPi/H4c8ZTfC3XLoJp2syefpjyNgRXmPmj9hIoGP8AaUd2rmPjP+y/8UrH4z61deE/CN74g0LVLyW9tLmxKN5YlYu0UqlgVZSxGTwRg56gLCU44XEzjN200CK5JO59Bav46sf2bf2MfCnhvSdk/jDUdOjj06yRd7vdTfPJOV6lUeTj+821R1rV+Gvgm5/Z4/ZL8TeLdYxN4vnsbjW9VnlO9vtAjZo4i38Wwtz6sznvWH+z9+zNr+i+KLP4lfGO/k1TxHaRJFpenXFybsaeqjCM7kkF1HCqvyp15OMfQ/xE8KR+OfhV4g8HyTi3Gq2E1osx5EbMpCsR3AOD+FebVnGMuVO93dvuZtpOx+TXgTw1c/EL4vaD4XnnZpta1GOC4uGOWw7bpXPvtDn619uftH+LLzX7/Q/2YfhaEXVNW8qHUjB9zT7JQCI2x90bFDMOyKB/GK+Z9M/Zy/aK8P8AxDt00fwbqlpqlnOHt9Ws7iJIEYcCRJy2AMHuM4PI7V9tfAH4DxfCvTb3XvEWoDWvG2r/AD6lqjM0m0E7jFGzfMRnlnPLkDoAAPRzCtT5ozjK9lovMuo1oyfxr4y8E/sv/s96ZaRwmZLOBbDStOVgsl7MFyzMf4RnLu/bJ6kgH4c+O2n/ABa1/RdB+MPxRNvbnxDI1rpumohja0t1TzU+T+FW3MQGJY9WxkCvX/2w76PTf2svhtfeLYJp/CFtBDNJEqF1dVu91yAv8R2iLI7jFct+198cvBnxSHh3w74GvDqVjpkkl5cX/lPHG0joEVEDgE4XcScYyQPWpwFOUJwnFXcrtsIK1mbn7AurXEfxI8X6GAPIuNMhvM45V45dnB9xJ+gr7B+I/wAJ/BXxX8P2+keMtMF1Fb3CXEU0Z2TIVbJUSYyEcZVh3BPQ4I+Rf2Q/DOveFtF1bx1IjWjawiWtl5iDc8CMWaQAj7rMQB6hc9MV9Nf8JZ4iR8rqRI9DGpH8qnHUJyrucGE4tyuj1SCCK2t0t4I0jijUIiIMBQBgAD0xUleeWXj29jIGoWkcy93i+RvyPFdXZ+JNIvbF7qO8jjVBl1lO1k+o/wAK8udGcPiRk4tGxRXE6l49iVzHplr5uP8AlrNlQfoBz+eKwp/F3iCZsi9EQ7CKMDH5g1pDDVJa2GoNnTePYd2kWs+AdkpX81P+ArgGPard3rmr31obe8vHmiyGwyjqPoKoCQk/NXbRpSpxszSMWkI3WsXxDFv0hyOqkNW315rP1OB7jTJooxucrwK3g9UUjzW4HznoKxNZj3aZJ/skGuvuNB1QsStsCP8AfXP8657WrG6ttPnFzbSRDbwzLwfx6V3wepaOElwAT0Arh9Vle/v3m52D5UHoP/r9a7TUSRYTYPJXAP14rl2tgF4Fd1LTUZyGrwYiRsdyKwnXBrsNegxYBsdHH8jXJSr854rtpyuikVj9BUZGKnIqI9+K15hkZAzTSKkPNMYVHMA4dKkFRjpUqiskSSLUqVEOgqVOooKJl9a6Dw6udbgP1/ka59OldF4cH/E6t/8AgX8jSnsSz0GE/KBVpBzVWD7p+tWk5NcVhHQeHxm7kP8Asf1rqIq5jw//AMfUh/2RXURdBXPV3EdX4WGbmY+kY/nXWr938K5Pwr/x8Tf7g/nXWL0rhq7kMkHauk8GqG8Vxk/wxOf0x/WubHUV03gs48VL/wBcX/pXHXfuMmWx6QBiloorzDAKo6vfLpuhXupMMi1gknx67VLf0q9WV4kspNS8I6pp0P8ArLmzmgX6tGyj+dC3QI/HGwhufFnjW0tpHLXOs6giM/ffPKAT+bmv2Y02xttL0i202zjEdtaxJBEg/hRFCqPyAr8e/hps0/4y+DmvPkW21uxEu7ttuEB/UV+xw717OcPWC6WNqz2Rz2r+PfBfh/VzpWveLNE0u+8kXH2a+vo4JDGSQHAcjK5UjPsa8G+MH7Y/w/8ABuk3GneBL628V+IWUpGbVi9lbH+9LKOHx12IST3K9a9S+KvwN8AfGLT7aLxhpspu7QEWuo2b+VcQg8lQ2CCpPO1gRnng1wHhH9i74LeF9bj1O7s9U8RyxMGih1m4WSBSOhMSKqv9GyPavPoewXvVLt9iFy9Tx/8AZX+EfiPx38S3+PfxFE86Gd7vT2uhhr+6bj7Rt7Rp0TsTjHCDPoX7cHxDXw58ErfwTZThb/xLN5cgU8raRENIfozeWnuC1fTcslnpOmPLI0NraW8RZmbCRxRqOSewUAfgBX5Q/Hz4oSfFr43an4mhkY6TF/oelI38NshOGx2Lks5/3gO1duEUsXiOeS92P9IuF5yuY3wo8B3nxO+MWh+C7ZW8u9uA13Kv/LK3T5pn/wC+QQPdhX6wa1r/AIU+HPgZtU1zULTRdC06FY/MlO1IkUBURQOSeAAoBJ7CvnX9iz4PP4S+H1x8RtctTFrHiCNRZpIuGgsQdyn2Mhw/+6ErxD9tz4iajrXxy/4Qdbh10jw7bRubdW4kupU3tIw7kIyKPTLetXiH9dxPs4v3UOXvysfROg/tieF/GHjseHPA/wAOfHXiRRgyXNjZxfImceYUaQFV92K/nX0fGwkQNsK5GcEcivLP2efh7o/w++APh+x061iW7v7KG/1C5C/PcTyoHJY9wu4Ko7BRXqnTtXl1uTnaprRGMrX0K99e2um6fNf31xFb2sEbSzTzOESJFGWZieAAASTXxX46/bG8X+LPiFF4K+Amgx3bzzeRbajc2xnmvW7tFESFSPgnc+eBkhRU37b/AMY5oVt/g/oN2UM0a3etsjclDzFbn2ON7DuNg6E1p/sTfC2y0HwFf/F3XIoo7vUhJb2Es2ALezjP7yQE9N7qcn+7GPU12UsPGlR9vVV77I0UbLmZv/A743/Ey6+O9/8ABn4zadZRa/HbtcQXNtGkbBlRZDG4jJRgY23Ky46EHPb2j4tfFrwr8HvAMviXxNM7l28mzsICPOvJsZEaA/mWPCjk9gfmH4E3h+Kv7cnjn42A+V4c0mKWO3u5PlQhoxDFknp+5jeQ+gYetfP3x4+J+q/HH44SXWmLNcaZDL/Z2g2SfxIXADgf35Wwx9to7VosGq1a1rJJN+Qcl2eoy/tdftAeIJtT8W+GfD+lW/hvSGje9gjsDPDbo7bUWadmDZY8ZXb1zgCvuX4feLIPHfwu0HxhBbG3TVrGK78hjnyiy5K574ORn2r5J+Neh6d8Bv2EtK+FOniObxB4luoo7toxlrmYFZZ3HqAVjiX2K19WfDfQU8DfBXw34cu3SM6VpUFvcO7AKrrGN5JPAG7dWGL9m4KVONtdPNCla10dgMY4FZniLQNL8U+FtQ8Pa3apdadqFu9tcwuOHRhg/Q+h7HBryXx5+1d8GfAnm2z+JBr2ox8fYdDUXTA+jSAiNfxb8K+dtd/bT+KXjrWDoHwn8CrZTyHbGRC2p3p99igIn4hh71lSwlafvJWXd6CUJM+e/ix8NvEHwc+L134avJrgC3kF1pmpJlDcQ7sxyow6OCMNjoyn2r7T+Fn7Y/w/ufhDa3PxM1r+zvE1oBb3UEVrJK16QOJ41RTww6g4w2R0xXk8H7NH7Rnxl1GHXPit4oGmoinyRrE32maIN1CW8WEjzgZGR06V89eP/h74t+E/jttA8W6QsM8b+ZBI6GS1vo1PDxtwHQjqOCMkHBr23Chi4qlUlea7G7UZqzep9p67+3z8MrCbydE8L+JNUfsZRDahvoGct+lY0f7fEUrbk+DmtND/AHxfg/yhx+tbP7Ofxm+BHiLTrTQz4S8L+B/FAAQ2otIoobpsdYJmGTn+453Dtu619P6hqtlpNsPOOWI+WFAMn8OwryqipU5cjpO/mzFpJ2sfOvhH9uD4Ta5fpZeI7LV/C87HBlvI1ngT/eeIll+pUD3r6Kttc0q+8Px65Y31vdadLCJ4rq3kEkciHoVYcEH2ryD4heFPBvxN0+XT/EvhHSXV+FvBEFuoP9tJlwVI6+nHORXg/wCyXrerJp3jTwHFqb3/AIe0y9SWykzlNzSSKdvorhFkwOM5PeqeDjOLnBWt0Y3BPVHuPxH0PRPipZDTfFmkQ3unxP5lvC5KvA2Mb1dSGViOCQcdua8lX4K/AfwJdJrOtW1lCI23J/b2p74gR6I5Ab6EGvdBBjtXwP8AtR6lb6j+0pqkcbK66bbW9kx9HVN7j8DIR+FelhIuX7uLsjWK6H3JYXNjqWlW99pl1b3NlNGHgmt2Dxuh6FSOCMelTiP1rjfghotxo/7PXhCwukKyjTkmdD1XzCZAPycV6ALYntWM2k2iSh5fPOT9aURD06VoC2PHFOFs3Hyk1POguUBF7GlEXsa0Bak9qcLUkfdqXUFczZIisLHHSqpyRW3c2xWylbGMLWMR9KqMropDc4qtIcROfarBx2NV7g7beU9wpP6VaGZck/PWqd1Or2zo4VlIOVbofwqCa4wevFZ15dYtpOf4TW6Gch4l8NWlzbSTaYFhm6mAH5G78f3T+lecTW5QlGUgg4IPFelXd9wfmrktbjSSb7SvDHhvf0NdtNvZgjgfEMQGlMcdHU5rh5hlia9C8RrjRpM/3l/nXn8wG/mu+i9DRFRgM8VG3JqdsVCRzWtxkWKYe9SN0qMnBqWwFHSpAcUxTxTxUkkq1KnWohUqdRVMomWug8PNjWrbnqSP0Nc+Dz0FbOiPs1a1b/poKiWxNj0qH7lWU61VhPyirCdq47iR0Ph8/wCmOPVP611cXauP0NtupKPVSK66I9K56u5LVzq/Czf6bIvrH/UV16/drifDMmNWUZ6ow/r/AErtlPFcNXclkij9K6Lwg+3xbAP7yOv/AI7n+lc6prY8PS+T4osXP/PULn68f1rkrK8WS1oer0UUV5ZgFB5FFFAH5WftM/Dq++Gn7ROqLaQvb6ZqszatpU6ghQGfc6g+schIx6FT3r9GPg78Q9P+KHwe0fxdZTI008KxXsIPMFyoAljI7YbkeoIPem/Fj4S+Fvi94Ffw54lhZGRjLZ30AAms5cYDoT27FTww4PYj4mt/BP7SH7LXjO71Pwvp8uuaDK2Z5bK3e6s7tF+6ZoVPmQuAfvdum5hXqOccXSjBu049+prfnSXU/RagnFfEUH/BQBraxEOrfCxhfqMOItW2Ju+jxbh9Oa4bxP8AtA/tBfHWCTw54G8K6hpmmXAKSw6BbyySyoeCJLpgAq+uNnuawjl9Vv3rJd20L2b6nZ/tfftH2t7YXfwj8B36TrIfK13UbdsrgHm1jYdST/rCOMfJ3bHm37Lv7Pl18UvFEXizxRYuvgzT5ssJAQNTmU/6lfWMH77f8BHJOPQvhD+w/fT3lvrXxeuI7a1QhxoFhKGeX2mmXhV9VTJP94V9s2GnaX4e0KDTtNtbaw06zhEcUEKCOKCNRwABwqgV0VMVTw9P2GHd292U5KKtEuxRJDEscaqqKAqqowAB2A9K/NT9tXwpdaJ+05d61NC32LX7KG6hkA+VmjQQyLn1GxCf98V95N8a/hImurozfEnwqL4ts8n+04id3TGc4zntmqXxj+EPhr41fDw6BrLm2uIm8/T9ShUNJaSkY3D+8hHDL0YehAI5cHWeHqqc1oRB8ruzlf2XPixpHxD+Buk6X9ri/wCEg0K0jsdQtC2HxGoRJgOpR1A57Nkdq9d8TeINP8LeD9T8SarKI7LTrWS7nbOPkRSxA9zjA9zX5jeKfg38b/gR4tXXLSz1SJbVibfxD4fLyRFf9oqNyZHVJBj61N4v/an+KXjn4SX3w+8STaVc292Y1uL+G28m5dUcMUYKdmGKjPyj9a7JZaqs+ehJOLfzRfs7u6PPNQvfEXxb+M8t04aTW/E+qgIo52PM4VF+iKVH0Wv0h+I3wn8Xa38GdD+Enw/1/TPDnh1bdLDVr6VHe5NqiqojhRcKd+GLksOOOhNfnB8NvHR+G3xP0zxrFpNjqlzpxeS3tr2Ro4/MZCgcleTt3EgeuK+jfDv7Sv7Rfxf8e6T4Y8L2djoVrfXUcE99pekvMLaIsN8jSy71XCbjnA5xXXmNGo3HksoxLnF30O8/aIbw7+z3+yPZ/CzwMJLa48QSNaPOzfv5osBrmeRhjLONseegD4GABXi37GngGPxR8ej4q1CNP7L8LwfbWZ+E+0NlYQT0G3EkntsBrK/a58cN4w/aX1LToLhpdP8ADsS6RBuOcuvzTN9TIdpP+xWt4T1HXLP4DaP8C/hrD5/jXx/MdQ1uePI+xWTALHE7D7uYV3uf4Uc93FTGEqeEt9qe78v+GBK0fU9Ht9csPjr+1rqnxS1dmf4a/DeAy2z7Cy3UiEsm1f4mkkHmY6lUiH8VcbqPw2/ah/aN8SXGr65DqWieHrqdpba2165a0tbaIklES2UbnIXAyU5Iznmvr3wpofgT9m39n2O11DUYbPS9Nj+0ahqMq4e6uGxufaOSzNhVQZOAqjpXzD43/by8SXV5d2vw+8JWOn2hBSC+1dmmuD6P5SkID6KS1clCVWpJ+wjdLRN9P+CRG7+E9H+H37C/gDQ1iu/Her3vie6TBNrFmztAfTap3sPqwHtX0n4a8H+F/B2krpnhXQNN0a0UAeTY26wg47nAyx9zmvkj4ZftE/Gjw98Y/D3gv48aSILPxME+w3MtmlpNAZDtibCHaUL4VlYBlLA+x+oPil8QNN+GPwn1jxrqirIthAWhti4Q3Mx+WOIH1ZiBxnAye1cuJVdzUajvfbsTLmvZnZZ9q57xj4G8KfEDw3JoPjDQ7TVrBzu8q4TJRv7yMPmRv9pSDXzB8EP2vfFPxK+Num+CPEHhDSba31MSrDcadLKXgZI2k+cOSGXCEEjBGQa95+N/xTt/g/8AB6+8ZPZx3t0kkdtZ2cjlBPNI2ApYAkAAMxx2U1nPD1aVRQatInladj5o+JH7C1rbu978O/F4hjdvl0zXFLgeyzoM4/3lP1ridL+G37X3gtF0zw9q1zLZpwkcesW9zBj/AGVnPyj2AFe3/A39pW6+NnjG98L6v4Vi0q/t7NryGeznaaF0VlVlYMAVb5xg8g+1eQftN/G/4meB/wBoF9A8J67LpFhpNpb3AhjjQrdvIm9jLuB3r0ULwMA9zmvYoTr83salm13No82zL7fCL9qX4gWp0vx146g0XSZeJ4luI2aRe4MdsoDfRnAr3z4a/CvQfhf4LTw94fWSTc/nXV5PjzbqXGN7Y4AAGAo4A/Env/D1y2t+ENJ1maBYZL6ygumjHRGkjVyv4FsVF4o1/wAOeC/DE/iDxTq9rpOmwjL3Fw2Ax/uqOrseyqCTXLUxc5+7b7iXK7scr488VaX8PPh1qnjDVyPIsYtyRZ5nlPEcQ9SzYH0ye1fn98MvBms/G348x2l+XmS7uX1PWroDhId+6Q/Vidij1Yeldf8AFX4l+L/2lvirp/g/wJo16+kwSn+zdN+68zdGurg9EAGcZOEXPJYmvsr4I/BbTPhB8Pxpkbx3mtXhWbU9QVcCWQDhEzyI0yQo7kljyeOtVfqtJ3+N/gi7qCOrTTo4o1ihhWKNFCoi9FUDAA9gOKlWzx/DW4LUZ6U77L6DivMdW5lzGILL/Z4p4svatv7LzyBSi156UnUDmMYWQz0p4s+22toWo9MU4WvH3aXtGHMczq9v5WiTtjHAH5kVyLDFd34pUQ+HiMAF5FUfz/pXCN2NdNGV4lRd0RGqd+wTTp36YQ1cNZ2tMI9HnPcgD9a6IblHH3M2GODWTqE5FnMc/wAJqzcyEsaxtXl26ZLz1GK7YLYuxztzc5z81ZV1JvjZT3FSzyEk81SkbIJrrQzmfE3y6OR6yKP5159P/rM13vit8adGPWT+Qrgp/v5rso7ForHpUTHipTUTVoMjJqJuhqRhwajboaTEhwqRelRDpT06CkImFSrUSVIvBzVFE461oWMhS4jcH7rA5/Gs8Y7irVucyYqXsI9XgIIz61ZU81m6ZJ52nwSZ+9Gp/StJetcTINbSX2alAc4Bbb+fFdnEffpXA2zlJVYfwkGu7hbcAw781jVA3tDl8rVrd84+cKfx4rv06da8ytZCkqsOoOa9JhcSQo46MA351w1iGWRU8EphnjmU4KMHH4HP9KgXrUi8gjFc8tUI9pjcSxK6nhgGH408jNZHhm5+1+GLSRjllTy2+q8fyxWvXjNWdjnegVl6jr2m6VxdzjzMcRJ8zn8O341leJvEbWWbCwYC5I+eT/nmD6f7X8q4ErI8zO5LOxyWJySfeumjh+fWWiLjC+rOwuPHjM5W007js0z/ANB/jUI8b6jnLWdq3+6WBrmkizjirEcJyMiur2FNdC+VHRxa/od/OH1XRIBJ/wA9WhSX9SM11tnLay2qtaPG0OPl8vG0fgK86jtc9BxWppzXFjcCS3bGeCnZh7iuerRX2SXFdDt554raB5pnSONFLO7ttVQBkknsAK/M39o/9ozW/ir4nu/DnhrULiz8FW0hiiggYodTIOPOlxyVJ+5H0xgkEnj6y/a38ez+Gf2VtSXTZTBea5PHo6kNhkSTLTY/7Zo4/wCBV4D+xL8IbLxN4ovviZ4gsUns9FmW20yKRco13gM0uDwfLUrj0Zs9VFdOChClTliaivbZeZUEormZy/w7/Yw+KPjLQ4tV1mXTfCVnMoaKDUY2kuXU9CYVxsHsxB9q+7fg74M134e/B7SvB3iLX49cutODwx3kcbIDDvJjTDEn5VIXr0ArvcDFeZfHm1+IGo/BXUNE+GcLtr+qSxWCTpKIjawyOBLLv/h2pu+YcjPHOK5q+LqYlqM3oRKbloyTxF8ffg14V1iXSde+Iug2l9EdssC3HmvG391ggO0+xr8+f2o/H+h/EH9oK6vvC9xZ3WiWNpDaWt1aIFS4OPMkkyAN3zOVyf7leqal+w9H4W+HGp+J/FXxRitjptlLe3EdlphaJQiFiA7yAtnGM4HXpXyVaQXF9eQWlvC8lxO6RRxjks7EKF+uSBXr5bh6EZOpTle33G1KMVqmfff7Evw30qP4IXnjDWdGtLq51jUHNtJc2yyFIIR5Y2lgcAuJDx14r6J8b+L/AA/8O/Ad9r2r39jp9taW8kkUc0iwiV1UlY0XjcxIAAAzzXxZpP7Hn7Q2lqtnpvxF0rSrXPIs9ZvUVc9fkRAPWs/4x/szJ8MvgXqfjzxp4+1LxP4iEtva2aZYQxPJKASWkZ3fCh8DKj2NcVWlTrVrupe76Ih2ctz5qt7fW/GfjSO2t4JL7WtavcLECN01xM+cZPHLN1PAr9Nf2ePgHpnwc8JPdXzxah4s1BF/tHUR8wQdRBETz5anGT1YjJ4AA+Kv2RfDya/+1n4fklj3xaXFcamwPYpGVT/x+RT+FffXxy+KFl8I/gvqniqZka+2fZtNgY8z3TgiMY9By5/2VNb5rVm5xw0PIdVu6ij4g/bB+Ltz46+L8vgrS7v/AIp7w3K0ASM/LcXgGJZD67OY19MOe9cpd/A3xTof7Mnh/wCNNvZzzvPfG5ntlQsLayGPImZQM7WdWLHoFdPc15x4Y0a68afEbSPD7TNJdazqMNq8xPJaaUBnPv8AMxr9jLHS7LS9EttJs4Eis7aFLaGED5VjVQqrj0wAK0xVb6lCFKn8ypPkSSPzg+OH7QXhj4reMvht4o03Tb6zk0Ii41OF1XKv58MhSJ84cYjbBOOozis79ov4kfEv4lJoviHxRosvhrwpdTTNoWjzMVkmCgbrlwQC5+dVDkBRkhMjcT6x8PtK8PfFn/gopquveHtD0238KeE1Z1+yWyRQ3EqAxJIQqgMzytI4J7RivNf20fFL+Iv2n7nSkl32+g2UOnoAcjzGHnSH65kUf8BqsNyOtCnGOyvr0uEWrpJHS/sJ+Em1b406x4vmiJg0TTvJjfsJ7hto/JEf/vqtL9u/x+mo+OdB+HVlNuj0qI6jfKp48+UbY1PuIwzf9tBXqP7LFrpXwo/YvvfiJ4iKwRXzXGt3D/xGBB5cSj1LCPgeslfBnjDxZqXjbx9rHi/Wm/0zU7qS7lXORGCeEHsqhVHstFCP1jGSqvaIRXNNs+w/2EPB7R6H4p8eTRfNczR6VbOR/BGPNlx9WeMf8BrH/bF0HTfGH7RXgjwb4cson8V6jarbXM24hTHJLtgVwP7uJmJ6hfwr6A+BcWh/C79kfw5/bM8dqItLOsag/wDc80Gd2b0wrAfgBXhv7Ppv/ib+0j4q/aE1ywY26zvaaPDKcCMlQgx/1zh2r/vSN6VyxnOVedddL2/Im75nInj8F/t1aFZJoGl+J9MurG3QQw3S3Vox2KMLhpIg/QDqCahsf2Qfix8Qddi1n41fEzzNv/LKCZ76dR3VC4WOL/gIP0r62/4SabIP2OL/AL7NTxeJ48gTWbAeqNn+dYvEV1rGKT8kieaSMD4d/CLwN8K9BbTPBujR2hlx9ovJT5lzdEd5JDyfYDCjsBXaiAeg/Gm2uqafeYWKYB/7j8H9av7R/dH5VwynJu8tyG31KYhFL5K9wD+FWtv0o2/Sp5hXKwhFPEI7Cp9nrS496OYLkHkjHSl8upsUYFK4jh/Hc2I7K1BGSWkP8h/M1xJ4NdD4wu/tHiiVAQVgAiH16n+dc8a9PDq0EbRWhGxrC8SS7NMCdCz/AKCt09O9cr4pmzJFCMcKWIHqa6qe5aOTnbLGsLXHK6dtz95wK2peprm/ED/6qLPPLH+Vd1Jaos52Y81Wc/KankOarynC10oDj/FsvywR5/vN/IVxUvLmuo8VS7tS2A52RgH8ea5ZjzXVS0iWiFh3qFqmbrULdK1GRmo26VJTG+7UkoRakHSolqQU0BMvBxUqnmoQeakXrRsUTryKsQnEnXiqyHiplOGpdQPRvDk/maNGufuMV/r/AFreU5Fcd4UueZoCewcfy/wrr42+SuSorMktRHJ5rtdLl83TYXzk7dp/DiuIjODXT6BPuheE9VO4fjWNRaEnTQnDA13+hT+do8WTkplD+HT9MV55Gehrt/DYaK3eOQ4Z/n2+n/164qq0JOjHTOMk0u5s9h9BTAc08ZrnskBpafe31spjtbyaIA7tqOQPriugsfFGqW/yXG26XHG8Yb8x1rlrVxHdoxxtJwa6FbT2rnqQg90RJIzJI5J7h55SWkdizMe5NPS3z1Fai2fP3asJZ4HTFLnS0E5GVHakH7oq3Fa8jp+FaUdn0+WrcdrjHy1nKoTzFGG0PHFXorXH8NWo7bAHFXIrcdxWEpiufIX7diXEfws8IbciE6zKH9M/Zzt/9mr1z9kTTrfT/wBkLwrLAih737ReSkfxO1xIM/kqj8K5z9s/TtCvv2ZryPUNY0+x1KzuodQ0+C5nWN7l0O1441JyxKO/Qdq8L+Ef7YejfCn9n/RvBE3hK/1jVrB50V/tMdvB5bSs6fMdzE/NggL2rtUJ18KowWzLs5Q0P0Jor4Sk/bE+O3iAFvCHwkthE33GXT72+P8A30u1f0rPl/aI/bA3GQ/Dy4iT28KXJA/M1zrAVetvvRPs2exftweNR4e/Z7j8L20u278SXi2xA6/Z4sSy/gSI1/4FXyf+yl4MPjP9qLQRNCZLLR92sXORkfuseWD9ZWj/ACNcv8Xfir47+KPim1n8erBBe6VE9mtpBbNbCElsvuQkkOSADn+6BW58Cfj0/wADtR1e5tPCWn63camsUcks940EkcabjsXCtwS2TkdhXs08LUoYRwj8TNlFxhZbn6rjpXzV+3Ha3E/7LJmgVjHbazaSzEDopLpk/wDAnWuU0b9vzwbM6r4i8A69p/q9lcQ3QH4Eoa7G7/aW/Zr+Kfg2+8KeJvEZtLDUoTb3FprFpNbZU46SAFVYHBBDcEAivFhh61Copyg9DFRlF3sfJf7KPxL8I/C741X+u+NLySzsLjSJbRLlIXm2SeZG4BVAT8wQjp1xXo3jKDxh+1ndeKPHdnaXuneBvCem3X9h2sgw97dqm7kDguduWxnaNiDksa67wd+x58D9d14ajpXxTvPE+khvMWxsbu2LMP7ryx/Nj1wFPuK+u9B8P6N4Z8O2mg6Dp9vp2m2kYit7S3TYkajsB+pJ5JJJrrxWMpqr7WknzefQqU1e63PyG+GniSy8H/GTwp4sv1d7HTNUt7uZYxuby1YbiB3IUkgd8V9m/Hb9rTw7qPgw+DPgzqM+u69rSi0+22UEgFssny7Y9wDNOwO0AD5ckk5AFavjz9hnwN4m8WXOteGfEt/4XS6kM0thHbJc26uTk+WCVZASSduSBnjA4rvPhB+y98PfhHqC63a/adc8QhSq6rqQUtAD18mNRtjyOC3LY4zinicXhqrVV3cl06BKcXqWP2afg6Pg/wDB2LT9Qjj/AOEg1Nheao6HIR9uEhB7rGvHuxc96/Oj44XN3cftH+P5bkH7R/bt4uCOm2RlT9Atfr9gYxXzf8Xf2QfAnxK8c3PjVNf1Lw7f3WHv/ssccsVwygDzNr/dcgAEg4OM4zknHA4xUq0p1Ooqc0pXZ5Drfi2x+OWneAv2fPhndTxeEtPsbSfxJqvlNGFjhRAYwCAThs/70hXGQpNfK/xH0y30j4teLNHsbQW1raardW8FuvSONZWCKM/7OK/R74e/DDwf8MPDb6N4UtpiJnElzfXTB7i7YDAZ2AAAAJwoAC5Pcknzr4l/su+EviH44n8Vx61qGh390Q14ttCk0dwwAG/a2NrkAAkHBxnGc57sJXp05NfZNItI8+8c/Em4+NjaH8EvhE8ktjdQwPq2qPE0cccMar8hBAPlpgFj/EwVBnkn6c8J+FNI8E+CNN8LaFEUsrCIRqW+9I3VpG/2mYlj7msD4cfCzwp8LdBk07w1ZyebOQ11fXDB57lh03tgYUdlAAH15rrtR1PTtH0a61bVr6CxsLSMzXFzO21IkHUk/wCc9BzWVWab5YbCbvojzL4o/FSXwD8Tvh3oSGJrbX9Rktr+NlyywnZGkinsRLID7gEV6sQQSD1HBr4OvfE958ev21fDtzp0MyaVBfwpZRuuGis7d/OeRh2ZtrMfTco7V944JJbnk5p1qfs1FPcJKwdBmtfTtfuLMrFckzw9OfvL9D3rJwBS4z2FcsoKSsyGrnodvcQ3Vus0DhkboRUtcNpWoyafdDOTC331H8x7128ciyxrIhBVhkEdxXBUpuDsZtWHUUUVAgqK4nS2tZLiQ4SNS7H2AzUtcz411AWugfZUOJLltn/ARyf6D8acY8zSGlc8+uZ3uLmS4kPzSMXP1JzVY/hUhbmo2Oewr14q2huRMcDrXC6/cedqszA5AO0H6V2d3MILSSZuiKT+PavObqQvKWJ5PWumkhopyHg+9chrkwk1BxnhQFrq53CRs56KMk1wt1IZZ3c/xMWrupIsqt3NVZ87MDvVhjntWdqFwILSWYnGxS3444/Wt0ugHn+uzedqtw+erkfgOKxmq3dOXkOTz71SbvXYlZWNCJ+hqJuKlaoXqgGVG3Snk80xjzjtUkjV6VIOPSm7B2p2MVTg4haxIvapl6ZqBelSr0xS3HuToealHTPeoFODUwoBm/4fuvI1SEk4VjsP48fzxXoUB45ryq1kZZBg8jkV6Vpl0LmxinB+8Ofr3/WuasuojWXrWto9x5Oopk8P8p/z9ax0qzCxDAjg1i1cTPRLAg3Klui84rp7C98q7RyeAefpXHaXc+bbJOOrDn6962IZjkc1xTjqSz0eM5AqVelZGi3f2rTlycvGdrf0/StZTXJJWZLJF+72rtdDkW/0lH48yP8AduPp0P5VxQ4NbnhrUVsNYVJm/cT4Ryex7N/n1rnqp8pEkdctqOOKmW16cVpCEdMD8ad5QxXA5mVyilsCegqdLcD0/GrIjA6c04L3AqXILkSxYGcV8w/Hv9qC88L+KP8AhV/wmsjrXjSWQW808UX2hbORukSRj/Wz85x91P4snIHqv7Q3xFn+F/wB1rxLYSKmqOq2OnlhkLcSnar/APARuf8A4DXmH7IHwXsvDXgCH4oa/A1z4o8Qxm4huLn55LW1c5GCf45Pvu3UhgPXO9FRjB1aiuui7spbXZxfgn9jfxF441QeM/j74t1K51K5+d9Nt7jzJ8f3Zbg5C/7kQwP71ZV34IH7Jn7RSeMpNBGsfDDVSLeS7ktxcy6TuORuYgkMjdG/5aISM7gK+66r3tjaajZS2V/aw3NtKhSWCdBIkinqrKeCPY0/rtRtqWz6BzvqQ6Rqmna3o1tq2kXkN5YXUSzW9zA++OVGGQykdRiuX+LPj21+GXwc17xncsrPY2xNtEx/1tw3yxJ+LlfwzW94a8L6B4P8PponhnSbXS9Njd5I7S1TZGhdizbV6DJJOBxXwf8Atq/GBPFHjuD4Y6HdCTTdBl83UWjbKzXpGBH7iNSR/vMf7tThKDr1lBbfoEI8zsfNnh7RfEHxE+Jdjodk73mua5fbDM/O6WRizyt7DLOfYGv1h0v4R/D6w8BaX4UuvCeialY6faR2kf22xilZgigbiWUnJOSfcmvmj9iH4NNZWM/xg1612zXcbWmio45WHOJbgf75GxT/AHQx6NX2gRXXmeJ56ihB6RKqzu7I8O8R/sjfAjxErMPBo0eZv+W2j3MlsR/wEEp/47Xj3iX9gLTD5k3g34g3lux+5b6xarMP+/kZU/8Ajpr7S60tclPGVqfwyZCnJdT8xvE37IXxz8JzveaZoltrixnIudCvR5v1CPsfP0zXM2/xb/aG+Fl+thdeKvF+jPEcCz1yN5E+gW4UjH0Nfq8QD1AP1rifHXiTwzaaTqmjasNNnvo9Kn1KCw1GNXS5WNWztV+HwwG4DkZHrXXHM5T0qwUi1Uvuj4k8Oft0/FPTVSPxDoXhzXI+8ixvZyN+KFl/8dr1TQv2+vBVxtXxL4F17TT0L2M0V2o98Eo36VuaL8FPgD8U/BnhyfUfDGn6d4l1PR4tSuv+EflNm0WVXe7RodiKXbAyvPOOhrzLxX+xPozX0zeCvHt7FECdserWizA/8DjKnH/ATW0Vgqzs4uLKtB9D220/bJ+CGpQr5HiSWxmP8OqWU0AX6kKR+ta6fHH4c6/B5cXxK8LOjf8ALMX8cefwYg18W6r+yH8X9NZm0+LRNYQdDa3wicj/AHZQv864vUvgR8Y9MYi8+G+vOo/iggFwv5xlq6IYDDfZmUqcT9B5PH3gONQx8beG8Hv/AGpB/wDF1lX/AMZvhLpkRN98R/DcZH8Md6szH6CPca/O2T4ZfEFZfLb4eeJQ/p/ZE2f/AECtbS/gj8X9VkCWHw38RAH+Ka1Nuo+pk2itfqNJbz/IrkXc+rvF/wC178NtIt5E8L2mqeJLsD5SkP2S3z7vJ8xH0Svlv4hfGL4hfF7VoLDUZWFm8wFpoemI3lGQ8L8oy0snoWz7AV6V4T/Y3+IOrPHN4r1XSvD1seWSN/tlxj2VMID9Wr6c+GnwK8A/C1RdaFp73erlNj6tfkSXGO4TAAjB9FAz3Joc8PQ+DVheMdjjP2bvghP8NtAm8S+JoFXxPqUQjMGQ32CDOfKyOsjHBfHAwF7GveAKlCc9KXyznpXBUqucuaRm3d3IttKFHv8AjUwjJHQ0oj9qzchEG2pYri5hx5U8qY6bWIqQR+opRFntUuz3AvWuvXsJCz4nX34b866O0voL2DzIWyO4PBX6iuP8o+lWLeSW1uFmhIDD16EehrnnST1RLidjXlnifUv7R1+Qo2Yof3UfvjqfxOa7HxBriWvhzzoGxNcZjjHdT3P4f4V5qxwMfzp4aGvMwguoxjxio2OKeahduOa70tTQw/EdyI7JYFIy5yfcD/6/8q4iVvmJrY1u8+06hIwb5R8q+mBWFI3U11wjZFoydZuPKsGUdX+Uf1rkZTknBH4Vs65cmS78sEYjGPxrDfr0FdlNWQyJzjPIrmvEtx5elmPPMjY/Ac/4V0MxwhrhPE935l+Yg2RENv4962pq8ijm5my5NVmORUrnJqF67SiNzxUTn5qkaojSYDDzmo35zT24qNvSkSS0v8NJSiutFCrwcVIvXFR1IOa55x5XYSJl/wDrVKp4qAVKh57VDGWI22sDXa+FbzMb2jt0+df61xCmtbSbs2t7FMD908+471E43RJ6dE2VzVmNuM1Qt5FZFZTlSMg1cU4rkJOm0C7wzWzN1+ZR/OumjkIGc1wFnO0M6SIeVOa7S1nSWBJUPysM1hUj1A6vQr8W1+oYgJINp9vQ12qHIry+F9pFd5od/wDbNPUMw8yP5Wz39DXHVj1IZsr0x3qQdKiVumNv41IDXOxHpfhTVxqWkiGZ83MACvnqw7N/St8LXkemajNpepx3cJzt4ZezL3Br1WxvIL+wju7dt0bjI/wPvXmV6fI/IxlGzLG0elLRRWJJ8p/t9QXkn7N+lSwBjDHrsXnBf9qCZV/8eIH419DfD26sb34UeGrvTGRrKTSrVoCnTZ5K4qr8T/AOl/E74Wav4K1ZzHDfw4SdRlreVSGjlX3VgDjuMjvXyH8P/jX4z/Zfvx8KPjL4YvrjQ7eRv7M1OyG4rEST+6LYWaLJJCgh0yQR2HXCPtqKhHdPbuWtY2R92YFFeBn9sf4Cf2YLpfFF80hGfsw0q4836Y2Y/WvEvif+3NqOqRPoPwk8O3NnPOfLTVdSRXn5/wCeNuu4bvQsT/u1MMHWm7KP3goM9g/ad/aHsvhV4Sl8OeHLqKXxpqERECAhv7Pjbj7RIPX+4p6nnoDXx7+zt8CdW+NnxBbUNYF0nhWxn83VL9mO+7cncYEfvI+cu38IJPUiu7+FX7J/xA+J/iL/AITH4sz6lo2m3Uv2mf7Y5OpaiT14bJiB/vN83ovQj758M+GNC8H+F7Tw74b0y307TLRPLgtoFwqjufUknkk8k8muyVeGEpulRd5Pd/5FOSirIvafYWml6Zb6fYW8VvaW8awwwRKFSNFGFVQOgAAAqzRRXlGQUUUUAFeOftKQ/D5Pghfaj49skm+zhk0uVEJmjvHUiPyyuCMkfNzjaDmvY68i/aTl8Cx/s/6oPH0Ly2jMq2McWfNN5g+TsI6EHJJPG3dnitaP8SPr0Kjujj/2dP8AhE4v2fbC78M2kceq3f7nWrnB8x54+xJ/hwylQOME9ya9N8s+g/KvNv2dx4ak+AWk/wDCORlGUldRViS/2zA8wnPY/KV7bcV6p5PtXdUSjOXqavcqiOlEXPAq15Z7LThET2qOcm5V2N/eYfiaPKyckCrggPpTxB7Uc7DmRTEXHSnLF7VcEP8As0oh9qlyFzFPyx6U4Q1cEIx0NPEP+zz7UuYOYpCLPQH8ad5RParghPpThAewpcwcxT8k+lKIeOlXhCfQ0ogpcwrlIQ+uaGjVVLMQABkk1fEI9K5nxNqYjB02Ajcf9cfT/Z/xpxbk7IauzD1S9N7fFwSIl4QH09fxqgeuaCQeKaTkYrsirKxoNNZGt3otdOYK2JJAVXH6mtR2CgsSAB3NcJreoG7vXZSdi/Ko9vX8a2pq7GZVw+WPNZd7cLb27yk8KP17VbkbAJrmtcu8uLZG4Xlj7+ldsI6lJWMS4lLyFmOSTmqjHmpZD1qvI2BXSUmUb64SC3kmY/Kg3GvNb+dpp2djkk5Ndb4nvQsC2qtyx3N9B0FcRK2XzmumjGyuUlYhJyahbrUjHnI/OojW4xjdKhPSpHPNMbgGkxMjb1qNqe1RmkInoPFFFdRQ6nr0zUY6Yp6GraT3AkVh0qVT0qAdalRsqDXPOHKOxYU96swvtcVUU8VMp9KyJO/8N3/nWXkM3zRdM/3f88V0iNla800i/a0vY5gflBww9RXodtMkkaupyrDIIrlqRs7ks0EbBrodCvME2rtgE5T+ormlParMEzJIHQ4YHINYyV0I9CjatjSdQazvFlB+XowHcVzOn3gurZZAQG6MPQ1pRPg1zSj0JPUYZUlhWRGBVhkGplPGD+Fcn4d1XawtJSNrfcJ7H0/GupDfnXFONmSTK1dD4Z146VdmC4ObSU/N/sH+8P61zdPU+tYVIKSsxNXPa0dZEDowZSMgg5BFOrz/AML+JfsRXT7+QfZicRyE/wCrPofb+Vd+rBhkdPWvNnBwdmYtWFrL13w7oXiXSn0zxDo9hqtk/wB62vrdZoz77WBGfetSio80I8hm/Zd+Ac90bh/hlpCuTkiNpY1/75VwP0rsfC3wx+H/AIJAbwn4O0TSJAMedaWiJIR/v43frXW0mfardSbVnJjuxaKKKgQUUUE4oAKKKpXV0UzHFjf3PpTSuBYkniiGZHVfqa8d/aQ8OaH4y+AuopqOpPp50x11C3uPLLqZVyioVHJD7yvHQkHtXpLRs7b3yWPUmvHPj/8AE/QPB3gG78MytbXmtatAYo7KQBxFETzM6noOPlz1bnoDXTh6cvaR5Ny4LUh/Zq8NWWi/A+G6t737VcalcvPdYGBDIuE8rnqVAGT3zXsAhryP9m7xtpXiL4aReGozBDqOk5VokAUzRk5EuO55wx9QD3r2sQn0rXEOUaklLe5U9ykITngYpwh7mrwg9acIeKw5yCkITnkUvk+1XRDTvKHbNLmApCD2pwhHpV0RjP3cU4IO2PypcwFIQ47U8Qn0q35dL5ftilzAVBD7U4Q+uPwq0E9sUoj9KXMBWEIPalEQ9D+FWdlZetazb6PZ73w87jEcWeWPqfb3oTvohFPX9Xj0iz2x4a6kH7teu0f3j/nk155JIzuXdizMcknkk1Ld3c95dPdXLl5HOSf6fSqpPNd9GnyrzNYxsKeBUbHA5pSao6hfJZWjSuQT0Vf7xroSuUZniDUvJgNqhw7D5vZfT8a4yeTJNWb26eeZpHYs7ck1myNxXXCFkWirfXKW1s8r44HA9T6VxdzM0krOxyxOTWlrF9585jRvkQ9u59axnbJ611wjZDGMcVSu5kijZ3YBVGSasSNhSc1ynibUNkP2RGwXGX+nYVqo3dikjmtVvGubuSYn7x4HoO1ZLGppHLOarsea7IqyKGMcCoWqQmonb9KYEZPJqNqcTUZNIkaaiY041Gx4x2pMRaBp1N6U4c11lgOD7d6eOtMNAGRz171SYE3bNKpw1NXkUtEldWGWFPNTqTVZDkVKp4rjJuW4nKvXaeGtSDx/Y5G5UbkPt3FcMp561W1i7uoNGeG0SVpZv3WYwcqCOentxUTjzKwj2uNsqMVOp/CuY8I6ldX/AIXtZr+No7pB5UofqSvAb8Rg/nXRowwDXK1Z2FY2NMv2tbkMT8h4YetdjDKroGU5BGQa89jbB61v6NqXlMLeVhsP3W9D6VjOF9RHYRSlWBFdroeqi7gEMzfvkHU/xCuAjk6AkVetbqSGZZI2KspyCK5ZwuiWj01T0p2f/wBVZOlarHfwYJAmUfMo/mPatIMa5JKxJMpwQK6vw54oaxKWWoMWtuiSdTH/AIj+VcmMeo/Ong4rGpBTVmJq57SjrJGHRgysMhlOQRTq8w0PxHdaQwhcGa1J+aI9V91Pb6dK9EsNRtNStBcWkodOhHdT6EdjXn1Kbg9TFqxbowKKKzEFFFFABQRmiigCOQlUJHXtVMQ7jk1Yup4ba1e4uJY4oYkLySSMFVFAySSeAAO5r5o8Z/tkfDbSdeu9D0nTNa162RTG+pabKkMbMeD5TMwY4/vjA9PWtqFKpVdqauVFN7Gz8dP2itE+GFtP4f0BoNT8VsuPKPzRWGejS46t6R9ehOB1+AvEPibV/EPiG71zWNQnvb+6kMk1xM2Wdv6AdABwBwK9tvPHn7L9/NJcXHwb8VSTSMXd21lizMepJM2ST61RPiz9lqT5f+FLeKvqNYP/AMdr6DBxWHjrTbfc3grdDzbwP8Q9X8FeJ7bWNMvJLe4hYMHU/oR3B7jvX6I/B740eHvipoSLHNFa63En7+xLY3Y6tH6r7dRXx2mufsuyMMfBfxb/AODk/wDx2tzRvGf7POg38V/ovwn8a2VzEQ0csGtsrKfUHzazxsPbq6ptMclzLY++9n0pQn+RXhPgL9p7wd4l1m30W/0rWtE3qEjvdTaN42boA7oSVJ/vEY9SK94QiRA6sCpGQQcgivCqQnTdpqxzyTW4mwelLs9qk2e9LtFZ3JItopcCpMD0pcUXAixSgZ7VJRSAZtOOlG33FPrktf8AF0VoGtdMKy3HQy9VT6ep/SqjFydkNK5o654gttGg28S3TDKQg/q3oP515te3txfXb3V1IZJG6k9vYDsPao55pJpnmmdpJGOWZjkk1ESc130aKh6msY2AkdSOaYfSnE1XmmSOMyOwVRySa6UUNuJ44IWkkYBVGSa4bV9Te9uS5JCjhR6Cp9Z1dryUxoxEY6D196wZJM1004WKSGyPnrWHq+oeVGYY2/eN1I7CreoXyWsJLMC54VfU1yNzO0kjO5yxOSa6oRuPcilfk1WZgOtPZqq3EpWNiOuOK3GtCrqF5Ha2zzOeFHT1PpXnOoXb3FzJK7ZZjk113jyJ7CeyhE8bRzW4mKKwJVs4OQOmcZH1rhJGy1dFKNtS9iNzxxULHjins3PSoW61uMaxqJmzxTmPvUdDAaTUTHAqQ/eqJjzx2qSSNj6VGx4pxIpjHmkBdHIxQp7U0Gl6HNdaKH0Dg/WgHIzRTAkB5p1RA5FPB55qwWhKp5xUqmq9PEhHSuedN30CxbU5qHULp7SzFyNojRwZCTyF9vfOKaJiOuKwPEOomeNLaOMiMNuMhPUjsKiUGtxNHpGhav8AZZklDBonA3Adx2Ir0CCdJEV0YMrDII715P4a0mefwks9ncJdG3UmSJRh1XrkDuBXUeH9aELrbTv+7Y/Kx/hP+FctSKeqJsdyrY/oKsRvznNUI5Qw61YDYrENzrNJ1Peot52+YcKx7+1bySdK8/jkIwQcV0ul6p5oEMzfvOgY/wAX/wBesJw6ok6q0u5beZZY3KuvQiu10rVYr+HbwswGSvr7ivO45PcVet7l4ZA6OVI6EHpXNOCkTY9LVqkVh071z+la7HdKIbhgk3QHoG/wNbQb3rmcGhFgNVqy1C6sLkXFpM0bj06H2I7iqIOOtP3d+lZOKejA9G0XxhaXoWC+C2054DH7jfQ9vxrplYMMjGK8UDduRWtpniLU9LwkUokgHWKX5l/D0rknhusTNw7Hq1Fc7pni/TL0Kk7G1lPaQ/Kfo3+NdAjq6BlIIPIIOQa5XFrRkNWHVl+IPEOj+FvDt1ruv6hb6fptohknuZ22qi/1J6ADkngZNN8SeI9G8JeFr7xH4h1CGw0yxiM1zczHCxqP5noABySQBya/MX49/tD638ZvFnkWpm0/wnZSk2Gmk4aQjjz5sdZCOg6IDgc5J7MDgZ4udo7dWVCDkzr/AI9/tK6v8Ubufw94ea40vwgjYELHbNqGDw02Oi+kfTu2TwPCBLk8mspbjOOakFxg9c19phsJToQ5YI6kklZGujrnqK0bYxkjIFc6lweuavQXPI5rdwGdhYtDxlFrqtNa3JGUH4155Z3uCOa6TT7/AAw+bisZRGj1bQzZrMjmJD+HWvpn4X+MRb6bDprztLaAYWNzkxf7p9Pb8q+QtJ1LDL8+K9K8MeImtJo5I5MYIyPavNxmFjVjqiZQTVj7ahljniEsTBlYZBHepK8y8CeMo7y0SN5NwPBGa9KikSWMOhBUjIIr5WtQlSlZnJKDiPooqjfavp2mrm8uY4z/AHM5Y/QDmsUr7E2L1UdR1ex0uDzbyZU44Qcs30Fcfqnja4lDRaXF5C9PNk5b8B0H61ys08s8zSzyvLI3VnOSfxrop4dy1kWodzd1nxTe6kGggzbWx42qfmf6n+grns56UhJxzTSa7Y04xVkaJWFJPemZ9qGPc1TvL2G0gMkzhfQd2+laqLYyaeeOGIySMFQdSa47WdZa7by4yVhHQev1/wAKg1TWJr2Q5O2MH5VHQf8A16x5JM55rphTsUohJITk1nXt5HbwmSRuOwHei7vI7eEySNgDt3NcnfXsl1OXZsAfdUdq6YxuUNvLx7mcyOfoPQVQd+9Ods8ZquzY6nFbpWGgdwAea5zXtXW2i+zo37x/vFTyo9vc1b1bU0srYtkGQ/cX1/8ArV5rfa5HcaqYhIXk3fPJngH0rSMb6sZ0ni+XT31SCSzinjmeBTc+Z90tjClPbaB+Ncwzcelem23gTU/HOgwXehXUEt5bw7RZSfK0oznCt0z6A/nXmdzFNbXD29xE8U0bFHjcYZWBwQR2IIrelJNWQ0QM3vURPPNKzEmoycZrUYjGo2PNKSKjPB4pEjWNRMacx5qMnFJgMJqNjSsfSo2JqRMvjrmng5HNNPTNAz611ljxx16U6m8HtSincBehzSikoBPfmqQEoPalAzTBT80xogu5NsO0Hlv5d6zJEWWMo65BrWnVGt2LKCQMg1EIYi9sPLxuB3e9Q3cGVdB1268NauhEpVAcq3t7+1dk1xDPL9rtSphnzIoXoPUfnXE6lbQtpFxL5Y8yOTCtnkDI4/Wuks4ILW2WKCNY1xnA7n1rmlFc1yLWO80DWtyraXL89Ecn9D/SupjcMB615RDMUYDPFdjoeuiQLbXTjd0Rz39j71z1KdtUB1qPirUchGKz45AQMmp1Yg1iI6nTdX3YiuGAPRX9frW9HMCOTXn6SgfWtjT9WaDEcpLR/qtYygI7OOYr3roNL8QPCFhuSXToG7j/ABrkLe4SWMOjBlPcGriSdMVhKKe4j0yC4iniEkLhlPcVPuPrXndlqU9pKHhkI9QehrqbDX7e4ASfEL+uflP+Fc0qbRNjeDZ+tAOfUVCrg4IINSKffismIlzjir9jquoaew+xXciDP+rzlT+B4rNB9a4v4t+LH8EfBPxF4hgkC3UNqYrUg/8ALeQiOM/gW3f8BoVJTko23C1z5p/an+Peq/EnxW3gnTrpU8NaNOVcQEhb66U4aVvVUOVQdOrdxj52ViDnoRTee7Fj3JOST60vOa+rw2HhQgoQVjZJRWhYR/eniQ1Ap4p46Y7+ldQ7llJOOtWY58d6zg2O+akWUD+IUmM2oboqw5rbsr45X5q5COYD+I1ftrvaRzWcogelabqeNvzc12uk6vgr+8rxuy1Haw+aun07V9pHz1zziK59G+D/ABbJp99E6ynbnkZr6R0LxireHPtcUX2gYHybsbT/AIV8K6VrmCp3+nevb/hz43EUi2dxKfLkG0gnrXk4zCxmtSZxTPb77xZrF6CqzC2Q/wAMAwfz61hO5dy7NuJ6knJNN3o4DIwZT0IpCcda8qNJQ0RhZdALH2ppNJnJpjEVdih5YetMLelVLzUbazTM8gB7KOSfwrmNR1+e4BSE+Uh9Dyfqf8K0jTbA2tS12C0DJERJKPyX61yN5qE1zKXlkLN/L6VVklJPU/nVZ5Rjg10xgkXYkeTuazr2+itYt0jAk9F9aq3+rpACkZDSfoK5q5uXmlLyPlj3raMe4yS9vpLmUvI30HYVQd8nrQzZNQs+B1rdKwwZgOW6Vl6lqUVjbNLIQT/CvdjS6jqMNnbmSRv91e7GuC1HUZry4aWRsnsOyj0FawjcozvFPiForaWaWbE8qlYQB39vTGa4TT7uOGUGSQD1JNdnd21texeVdQpKucgMOn0rkksbN9GtJjAN73YiZsnJXcRj8q35dLAz2L4afESw0LUIRJqMCDIHzSAVa+Mb6ZqnjOPxRostvJbalCpmMDqwE68NkDoSNp9+a8audOsFu9XC2ygQwq0YBPykg9PyrQ0iGKLR4GjjVWkQM5H8R9TURppS5kJF0nmomPNOZveoie3et2MRjUZOKUmoy1IQxjzUbU5iKiNSAhNRscinE4FRnrUkmkr8UbqiBpwNdRdiYN7UA4pgPrTw3GMU7jJAMjPegjFMDYp+8ehp3EhQafUW70BzTt2OpquZDFlP+jyf7ppin57Tj+E/ypl1GZIwVbG3kjPWs4sfWpbBss3wzot6AOkhP6iuhQnYuR2FcfPlrd1B5YYz71s6LYXWnxSpczBy7AhVJIWspi3NpWxU8UpQ9aphqlDe/FZtXEdpo3iDaFt7x/lHCyHt7H/GusjmDKCCCD0IryWOUqRzxXQaRr72eIpSXh9M8j6f4VhOn1Qmegq2KlSUgjmsu1vYriISQyBlPcVcVwcYrFoLmxZ38ts4aJz7qehro7LVYbkBSQj/AN09/pXEK+KsRz4PWsnBMnl1PQUl561YSYr3rjLPWpocLJ+8Uep5Fb9rqEFyv7qQE/3T1rKUGhHUWOs3VoQscpKf3G5FVvGvxTs/CWjabdSxAzXd/FAVJyPKBzKw9wvA92FZiyD1rxv4+6tcW9roVudKgmtjO0n22QnKuODCADwGXBJ9h0pQoxnJJhY+uIriKZA8Uiuh5DDkEV4D+17qb2/wa0nTkbAvdXTePURxO+PzK/lXXaHq+of2FZzzQGwuHgRpLZH3CFto+TPcCvKf2n7q81X4baJPKVZLTUzuYDGN8TAZ/FaWHpWrRuNRPlil7UlFfRo0ZIMg5/Knj2IFRKc81JnPPamCVg2jGS5ApQI/7/6UlMYU7jJlMXbrUqSBfumqgpwOKQGtDcsCPmH4Vr2d+ykDdXLJLtPWrsNxgdee9ZyiQz0DT9VKsvzV2+h+IzazI6yYIrxq3vSpHzVt2urMmPn5rmqU76CPt/4b+Iv+Eg8MTMzlmt5ghJ91B/xrrmdRnJCj1NeC/AvWri18B6jctHvFxebY2Y8YRAD9eW/Su21bXtSl0+doVM8ixs0duG2iRsHCk+54rw6lH94ybGj4W+IGn+IbHUp2dVNveyRRooyWi/gb8QDzUt94kmkylsPKX1zk14f8KNYubm41eD+y44YTJ5jyo3+rckgRf7oG7HpivSmkyMk1UqSiwaLEt08jlmYsT1JNVnk96ryzqilmYBR1JrGu9cjTctv8zY+8elaKI7GvcXUcMZeSRVFc7f6zJLlIMonc9z/hWZcXcszlpZCxqqz571tGFhkkkue9Vy5PNIze9QvLjPIrUBXkA71k6nq0NlESzBpD91B3/wDrVT1XXY7YNFAweXuey/4muOurx5pWd3LMeSTWkIX1ZoS6hqEt3OZJXyT+n0rOY7j1prPnknmo2bPeulKxIEk/QVy0Jz4dsSP+f4f+hmtTW7C41C2iS2nEZVslSSA35VxEivHM8Zb7jFeDxkd6AOsuR/puuf8AXuh/8dNWdNP/ABJLT08oVxG5s/ePPXnrXUaHaz29oZZZQUlVSiAk496QkapNRE5zmlY+h4qMkVQwJP41Ex45pxNRM1IBrH/61Rk0pJpjHjiobJEY1GacaYT3pAXqcDTcilHIxW5oPBNPBqIcfSlB/KqTAlzjrS55pm71pwPrQA/NO5HemUA4ouA6Uj7O5/2T/KsfdnrWpOf9FkIP8JrIOO5IpXER3MmyEdiWA/WuuzkkiuPniabaVcAg55HFdYr8VLbYiYN3zxUgNVweakDUD3LCnJHNLa3MdxCJoX3IcjP0OP6VWc5hfIYgqQQn3vw96o+GQBomFSVB5jYEn17f565pBsddp+qT2cweF9p7qeh+ors9N1y3vQFLCKX+4T1+hrzgNzxwaninZCDkjHespU0xHqyyg9+alD5rhtO8RTRAR3X71OzfxD/GuotL+C6jDwShh3HQj6iueUbbiNVHI7mrMc5UgqcH1HWs9JAe4pxkCDc33Ryamwiv4n+K9l4KgSO7Bv72Rd0dojbWx2Zm/hX9T2FfPfjLxtrPjfxH/a2qsiBF8uC2iJ8uFfRQe56k9T+QrJ1rU7jWfEN5ql05eWeUuc9h0AHsBgfhVIAiuylRjHXqUon0X8EviQtxp8fhfV7w+ZENts0xzhf7ufT0z0r0/wAc+HU8X/D/AFHQGISWdN0Dt0SZTuQ/TIx9Ca+KYJpra4Se3laORDlXU4INfQHwn+K+ravcv4f1uNbl4oDLFcA4YgEAg/nXNWoOMueBNjwO5trizvZbS7iaG4hcxyRMMFGBwQfxqKvqDxZ8NvB3jXXf7Yurq90y8dQszWwTExHRmDAjcBxnuMelZS/s++D3GU8R6uw9R5P/AMTXXDFRtqirnzoODUg44r6J/wCGePCp66/rP5Rf/E1IP2d/CuP+Q/rP5Rf/ABNV9agPmPnQHFOr6K/4Z58Kg/8AIe1n/wAhf/E04fs9eFP+g9rP/kL/AOJo+tQFzHzdjB6UtfSB/Z68KH/mO61+Plf/ABNNP7PHhXP/ACHdZ/KL/wCJo+twDmPnGno5U4FfRX/DPHhbH/Id1n8ov/iaP+GevCv/AEHtZ/KL/wCJo+twDmPn1JiDk9K09OS81LUrfT7GJprm4kEUUa9WYnAH+e1e3H9n3wmoJOvaz9T5X/xNbnhH4f8AhXwNq0uo2l3cXt26eWkt1tJhU9doUDk9z1xx61lPExtoI63RLbT/AAP8Prezu7uKC20+Dfc3Mh2ru6u+fdif0rxXxz8crrW0uNF8LRPaWMmY3v5MiaVe+wfwA9Ofmx6U/wDaA8S3EtvpXh+2kdbWUPdzc48wq21AfYcn649K8RjmZDxj8ayoYdSXPLcEj1XwD4lu9D1lLi2n2hhskQjKuvoRXv414XWlJeWygow+Yg52n0xXx3a6xcQONpArv/C3xCvLOVYpZd0LDDKx4Ip1qF9QPbbm+mnYmSQn27flVNpD61Ckyy26Sp911DD6EZphcCudIRIze9RPIAOTzUMk4Ck5xisHUPEMEIKWxErf3h90f41SV9hpXNe5vIoIjJNIEX1NcrquvyTBorclIu57t/hWRfajNdSl5ZC5PbsPp6VQeQt1NbxppblJExeSeURxjLHoBVRzg46Ee3SrNlOYdTgkUgYcZJGah1CUy6lcSM8blpGJaIYQ5Ocj2rSL1sMrs3FRsfWkY+9Rk+9WSO3fMOe9ed3Bzdyn/bb+Zr0AnvXnsn+uf3Yn9aTAbXZae3/Emtf+uYrjeh5rrdMbOj2/qEA/WpQFtjURoJyaaT2qgGswxURNKTk0wnPSoJEY1GTSsc9aYTikAE+lMY8f55pScfWo2PPXipAvAmn7sjiolOPWnBvSui5RICadn1pm7NAODgdKLj2JQfenZz1qIEinZHrT5guTKecUuSelRA0u4+9AwuSRaS8/wmsgnNad23+gyc9qyNx9aAHluK6ZD8oPfArlCTjnJrpozmJfoKIsSLAbjk08GoAccipA3vUJiKOr6stkn2eNRJM6+uAoPetjwlpNtc+GXNlfNJdLmRreQAZGOdp9eM+9ctqdjNLqVxMZUIEYk5GMLnGPrVnT11DRtRE1tcKGSRY8AnB3DP5VL8gZ0obIp6tyKrh2PzMACeoHSpEbkVQznNAuJz4uvFaZyoD4VmJH3xXbW17LDIHjkZHHdTiuB0eeC28VXj3EyRKfMG5zjnfXWQ3MNxF5kEqSpnAZTkVDQHZ2XiZ1CrdLuH99ev4ityPUre5tXMEof5Dx3HHpXm6yFelTLdOikqxU4PI47VDpLoJo8oFKOa3LDSbafwZe6hIP9JRi0bbuAF6gj3yfyFdD4J8L+HdQ0v7br0kztKxEUaOUVQDjJI5JJz7Ct3OyA4PFdn8MSR4tvSDg/wBmXH8hSXfg62tvidY6JDcmfT7thLG+4FvL53KSO42kZ9xW1pOk2+hfFjU7Kz3C3OmTSxq3VAyj5eeuDSc00B5ok83lr++l6D+M07zpv+e0v4OaiX/Vr9BS1egD/Pm/57zf99t/jQbi4H/LxN/38b/GmUcU0kFiTz7j/n4m/wC/jf40G4uT0uJv+/jf41HRRZAP+0XPe4m/7+H/ABpftFz/AM/E3/fxv8aj/KilZAS/abn/AJ+Jf+/jf40n2i47XEv/AH2f8ajop2QD/tFx/wA/E3/fZ/xpySztMn7+X7w/jPr9aip0ZxMn+8P50nYD0v40sW8Q6RntaP8A+h15p+FevePNOi1r4oeG9NuCRDLC3mYPJUMWI/EDH41y1z4Otp/i/J4ct5Ggsz/pBI5aOPYGKjPfnAz7VlTnyqwjihkCporp4TuA6CvR/Gngbw5p/h+S80WWSC6t13NE0xkEqjr16EdfT2rk59IsR8OI9Sjjb7Z5heSTdwULbdoHtwc1ftFJDPd9KulPhuwkZgB9miJJ7fIKpXviG1hysJ85x6cAfj/hXFwalcTaNZpLMzKkEagduFHaoHnJOBXMqWuoJGpf6zdXZxJLhOyLwK4LXZ5T41sQssiqfLyqsQD857Vvz3MNtCZrmZIowcbmOOa5XU7m3uvFtlLbzJKgMYJU5Gdx4rSw2dczUzdn3prHmoZi5gdYn2OVIV8ZwexxVjM59ahk1uOxiYKqv802e47AfWu51nwfc2PhWDxLa30d7ZSsFmwu14WPTI7qfWvKE0m6a82LNGH84xbueSBuzXZ+HfF2p23hy78P37fabe+ti0Y6bCG4PT1FZu6d0QV2Y++O1RsaHYVGTx1rUYFuCa4JsljXcyN8hPsa4bNSxXEwa6jTGJ0eAHsCP1Nczmui0xv+JTEM9M/zNINy4WGeDUTH1pScUwnnrQIQnHFMJ9KCwAzUZbJ4qNwAmmFvanojyH5RgdyelTi3jH3vnPvWkablsUo3KJPvzTGPvWqFVRwoH0FLgdhWn1d9x8hVyT04pd2aiDDsaXdipuIn3ADuacDleKhDDGacG9KYE2SO9KDnvUW6lzkZHSgCYHNPDDFQg04OR2H5UBciu54vs8kYkXdxx+NZWQBgGrd3bRxxPMrHr93tyao596AHbuMYrobe5hlRESVGYKMqDyOK5vJxWzY2cMQjudzFymcHoMigEzUDdOtPBqDPPpTgcVIFC/uoBdXCGdM/ZtmM87t2cfWkmvrVp2IuIsG5iYYPUAcms/Woo49QVo1wZF3tz1OcVVs40l1CCKXJVnAIBxQB3EcqSIHRgynkEd6kB5HPFVIESCBIo12oowBUwbkZoGcLef8AISuD281v5mtzwrdlZprJjw37xB7jgj+X5Vh3Zzfz/wDXRv506xuTZ6jDcj+BgTj07/pQI9DU+9OZvkP0rE/4SPTAf9bJ/wB+zQ3iPSyhHmS9P+eZpMZW0tj/AMIHd84yJf5Ctfw7Ky+GrUKTjDf+hGuVtNXgt/Dc2nMjmSTfhhjAzVvS/EVrY6TDayQzMyAglcYPJPr7012EbF5cuvj3SZUYqyIxBBxj71WhqlwPiNcXTMJHbTWjy4zxjFcxc67bza/aX6xTKkCkMpxk5z0/Oj+3YP8AhIZNQ8qby2tzCF4yD607DMRfugegr0PSfA3hu/0a0urjXL6CaaFZHXyl2qSMkA46V550AFekaTMw0KzGeBCn8qU2+gF6P4XeG5ceX4kuj/wGOrC/CLRW+7rl8fpHHWVqGuW2nRhrmQ5b7qKMs3/1ves4eObVT8tvdj8R/jUWk+pLZ1A+D+jj/mN3/wD36Sj/AIVBo/8A0G7/AP79pXNr8QUX7qXw/wCBj/GpB8RiOB/aGP8AeH+NFpgdB/wp/Rv+g3fn6RpSH4QaP/0Gr8/9s0/wrB/4WOx/i1D8GH+NMPxD3DBGoH/gY/xpJT7gdB/wqLRe+tah/wB+0qOT4VaBH9/X7tQP7wjFc+3juFvvQ3h+rA/1rRsNatdSiL20hLL95GGGX8KdpLqCKmu+B/D+laDeXltrl1cTwx70iKLhjkdSBXArxIv1H869C12Uv4cvRnI8o154PlYEg8GtI3a1Gem65rktz8S9DuliWNoYJAO/XdWa19NN8U57iSQlzbAZHHG1eKwrnX7efXbS+EEwSBGVlOMnPp+dMTW4F8TyaoYZfLaPywmRu6AZ9O1Ty2A6/V7hjol3k8mF/wCVc/K5/wCFY7Sf4Bn/AL+VHe+J7W6sJrdba4UyIVBbbgZH1rOOrwnwoNK8uTzNu3fxj72aLDOvsmxpttz/AMsk/wDQRUxaubg8TWkVnFEbeclECkjHOBj1qQeKbM9ba4/T/GmFyr4qvN00Nmp4UeY31PQflmsbTzjVrY5/5ar/ADpL24a8v5bls/O2QPQdh+VFiP8AiZ2+enmr/MU7Ad4WOetROyqhZmAAHJPFDN1qKVUliaORQyMMEHuKQzIjvrNbwP8AaY8C9aTOeNuzGfpmmWNzB9rswJkJFuyEZ5yWzisjUIo7fVJoYVIjU4UE57Cp9Gijl1H94Cdi7157gipIudMTTC3vSFuPQd6jY8+tUMhuLmCJWSSZEYg4DHrXJBTiuivrCGdnuGd1cJkgdDgVgdqhskbtOMZrZ064iSySJpUD5PGeetZFaFlZxTQrOzNkN90dKV7AabN6daYzAChjj60+OHI3SD6CnGLm7IaVyHbI5+UE++OKcltIWG4gD2NWgOKBXSqKW5aihMBVAAAApM0pzTD9Ca12KHg59aM4pmeKOaLgUKAxqPOepIp2Qe9cV7GJLn34pwPvUORSgkdKdyifJPenKxBABqAN61JvweaLgTg59KXODwQagD+ufypd5ouK4y9b/Qm+orM3fX8qvXzf6H/wIVQyaLjDdXQ2rf6FCP8AYFc5ures2zYw/wC6BRcVy2GxT1bioQxpwYetIRj64c30Y9I/6mqtkcalbn0kX+dWNXOdQU5z8g/rVW14voT6SL/OhMo7HOKcrEHsah3c+9OB5qgOQuv+P6f/AK6N/M1DgVPcj/TZj/tt/OrMWkX0tt5yRDBGQpPzH8KVxGfgUYFSEFTgggjsaSquDG4o49OamggkubhYYly7dK6CDw9arGDPLJI3+ydo/wAaLiRzNFb174f8uIy2bmTHJjfrj2NYn/AR+VMdiPFehaa2NGtOR/qV/lXAkZHQCu604/8AEote37pf5VMho5LXJJJtfuS5ztbYo9AKojPpVzVRnXLsjp5hqTS9Ll1CUkkxwr95/X2HvQBnBSSFAyT09TVpNL1GVcx2U5Hrtx/OuxtbG0skxbwKp7v1Y/jVrcadwOEk0zUYlzJZTqB1O3I/Sq2DkjuOor0TdjpVW8sLO9QieFS3Z14YfjU3A4XB9K0NFleHXrYocbm2MM9Qe1GpaZLp0/J3xMflk6fgfem6WP8Aic2v/XVarcDrNYOdBu/+uZrhsGu31cg6FdYP/LM1xODQgG4NJin8jtV3TtLm1CQ4ISNT8znn8B70xGfg+g/GjBrqR4dsAmC8xb+9u/pisnUdJksv3iMZIScbscg+/wDjUhaxmfhS4FOwaDn0FNjGmpbL/kJW/wD10X+dTWun3V4heGNQo/iY4BpsMUkGrRRSoUdZFyD9aTYmdcSKaTxTS2KaWFAzldTOdYuT/tmpdGJGonn/AJZn+lQX/wA2p3ByP9Yam0nK6kPdSKkSN4k5ppamsfem5oEMuW/0WX/cP8q5oEY6CuguW/0SXn+A/wAqxI7eaQZSJiPXFS1d6BYi4rV084s+OzHFU/sF3jPkn8xV21iligIkjYfNRyvsOxaiTc+484qwTxTIR+6B7nmnEdq7KUbRLirIUDigikBpC2OlXcdxeO5NISPWmluc0hYEVLYXFPWmHINBb2NISMUguZYbinAj1FQhz6CnZzXDzGROGI+lOzgZqDPpTs+vWncCXd33DPtTg1RdTjgUoJouBMDzTlbB96hU08Hii4Ed8f8ARR2O4VQ57mrl4f3C8/xVSzTGHcVuWbH7DEOPu1hAZrYs2P2OP6UAy7mnBu+QB71EGzzQwDIUYZBGDTQjL1J1kvdyOrAKBlTmoITtnjPowP61JdRJFclEGFAHXmo0UFwDyCRU3Hc6dZFfDIykeoORUitzVSGOKCPy4xhc55OamD9KsZgFQ+qlW6GbB/76rqQ9cuvGrr/12/rXRhsnv+dJEmBqyqurSYH3gGP1xVLPtWhqvOpscfwKKpiqA1dARd00mPmGFz7Vu7qxNE4Wf6j+ta2aLjJg3/665LUo1j1e4RBhd2cfUZ/rXUZrm9U/5C83HcfyFFxlIDFdpYN/xK7Yf9Ml/lXGiuvsmxpsAOM+Wv8AKhiRzGpgtrdyByfMNdbaQLa2UdumQEH5nufzrlLznXpf+u39a60t8xpjJN3vQGHv+VRbj6mjcPU0ASbh6mjdn1/lUe+jcfU0ANvYFu7KSBx94cH0PY1yumgjV7b/AK6D+ddaG5Ga5O041qE/9Nf60AdJqh/4ktyMnHlmuPya6vU2/wCJRcDvsNctSQDa6vSlWPR4AP4l3H3JrlhxXUaef+JVbj/YFDAubqhvFWWwmjbkFD/KnZqK4P8Ao0mf7jfypCZyXOOlHNOAOBRyR0NOwzp7NRFp8KDHCDtVDU1H9qWUnG4tg/gR/jV6JsW0eP7o/lVa6i824gcsQEbPHfpSjFvYaVy2W5pjSKilnYKo7mgkGkbaRgjIrX2LDkOZusNfTMCDlycj61JYOiXql3CjB5NbRAyeO9IIomYBokYe4FHsH3DkHE8ZyD9KaAXPFSeWgTaowB0AoyFAAyfpSjRb3BQGmNRGcjJxUVTO3yHoKg5reMUtEWl2HZ4p6E7TyOtRE4pyscEDpVNXGPJ7DpSds0ZxUZbPSlewhSeM0hYYxRnIxTe1IkMilzxTc5PNJuwaRIuaU9OKYWo3e9BRkA9hTgc1F1p4J7155lYkB7UvWmdetOGe/wClAyQHHXpTgajHuKeBQA7JxkUrOFUseAKQfWlwGGCARVAVriZZVULng55qAKSaszxIm0ouOveose1AXGBavQXUUcCxtuBHt71Tx6CrdvDE0SsyAn3Jp6gXwcjNOBqPr0FKDTAoXfzXjHPp/KoUAEi49aluAftL8U1VORx0pIDdznmlBIqIMfQ/hTg3sTVgZQP/ABMwTg/vc/rW5msItsvd5HAfJx9avDUof7sh/CpQFfUcm+J77RVXBNT3Myz3BkUEDAGDUXPpTuOxpaQSFmz6j+tam73rG0+4hgEglbbnGOM1d+32naY/98mhCLu6uf1AZ1OU4HUfyFaYv7Uf8tD/AN8msu7kEt48kZ3Keh/CjcZXwfSuntH/AOJfCP8ApmP5Vze0+ldDan/QIev3B0+lFxmHdnOsSnt5v9RXTluTyDXNXXOrSN/01roCfYmhCJd3+c03cfU/nTc0hOf4T+VMRJuOPejdUe7Hajd7UASBskYrmrbI1eLB/wCWv9a6LPPQVz8AP9pxn0k/rSY0bWoHOlzj/YNc3iuhvWJ06Ucj5awMEjpRcENAOa6Kzz/ZsHUfIK5/B9D+IrVtr63S0jjdyCoxjaaTYzRLD1FMmbNvIB/cP8qrHULT/noR/wABNMfULVonVXOSpHKmmIxAvA5qeG2aXk8KPzpIYTJKF7dzitJQqqFAwBWsIX1ZSVy2gCwoBjgdzTJT8y/WkEqhRwcims4Zl46Gt0WSFmPYCik5pCCasCIn5j9aAfnBppJzxQM7hQBLk0mRSc0Z9qVwGNIpUjNR5PrTnVQpOOajyewoAUk0qnbnofrTOc4xSgA55zU3Ex5bJpM0EDHQ00nFSITOO5P1oz6mm5PpmkyKVwH9+/50vAFM3igt71SQhxb6VGWNJnNNJApN2Q1sf//Z';
  const splash = document.getElementById('app-splash');
  if (!splash) return;

  function hideSplash() {
    splash.classList.add('hidden');
    setTimeout(() => { if (splash.parentNode) splash.parentNode.removeChild(splash); }, 650);
  }

  // Show for at least 1.4s, hide once DOM ready + image loaded (or failed)
  const minWait = new Promise(r => setTimeout(r, 1400));
  const imgLoad = new Promise(r => {
    const img = document.getElementById('app-splash-icon');
    if (!img) return r();
    if (img.complete) return r();
    img.addEventListener('load', r);
    img.addEventListener('error', r);
    setTimeout(r, 3000); // fallback
  });

  Promise.all([minWait, imgLoad, new Promise(r => {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', r);
    else r();
  })]).then(hideSplash);
})();

// ── Update PWA manifest & apple-touch-icon with custom image ──
(function() {
  const APP_ICON_URL = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCAIAAgADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD45ooxmnYxX3R1oBxSgUAU8DpVDAKadRTgPT8aAALT1WlC8U/b9AKoBAOwp68e/wBaTHpTlGOgpgFOC7valA6cU8DtVJWHsIBTgMe1KB6U8DJphYaAafj0pwQ4pwX6UANC07bntTgOelPx60DIwKeBxTselOxmgBm2nbT3wPrTwKcB6qPxpgMxjuT9adtPpTto9KUL9BSAbt9qXA7U7H0pdvtTsMZilx7U7BpcU7CG4+lGKfj2pMH0oSuOw3FGKft9qNv0p8oWGY96Me4qTZ9KMY7D8KVgI8e4pMVLj2FN2n0osAzb7UEVqRy6UPDk0ElpKb8zKyTCUABdrZGNvqRxms7FAERFG32qTHNJj86BEe09iKaQPSpsUxlGO4/GiwEJWmkGpitIQRSsBDj0pCPbFTEetMxSAhIwelN2VNimlfWgCAikxUxU0wrQBCy5FNK+1TFQTzTNuOtAiFgQaaRUxX3ppXNAEJGeoppGDUpHrTSOOmaiwiEimkVMw4qMrSEQ0hFSEe3HpTSMGpaDYjIpMZp5AP1phBpbjGEYpKf1GKaRipYrDvpTgM0Ad6eox1qxhjApw59aKeopgCg9qeAKAop4HemAKM9afye1Az3pwHrTXcdhoGaeq0oGe1PA56VYAAAMflTh9KUDmnhCOT0oGNVc1IF9qUCngZ6UAIBg04D1pcY6CnhaAG49KUCnhSfenheKAGBT9acF9ad9cfhTgPQU0AmPwFGKcBTgPUCmNjQKUCnbfwFO207DGYNKBntUgXtShadgI9vtShcVIAB2/WjGKdgI8UpTHoak2k0bfcU7AMC4pduey/hTwBS49iKAIsY6hfwpSvsPwqTHsaMetAEOyjZUu2jb7UAQlT0pCvsPyqUqTRtpWAh2+1IVqcrTSKLAQ4I6CmkVMVI7ZppUntU2AiIppB9Km203bik0BEVFMK1Ng03r0oEQFaaRVgrTCvpSsIhK5phUVMV5pu3tSAgK00jBxVjHtUZFAEOPTpTCvFTFeKaRQIgI54phGKmK57U0j86VhEJHoKaV9KlxTSPSk0BCR6VGRzxU5GelMI9KhgQkYNNYZFSkZpmMHFIWxEQaQjIxUhHfvTDwaW4yQLTqO1OA9KYChfSngcdKAOKeB61QAB604DHJAoA9aeBzz+FOw0AHrTwDmhR37+tPA4qrAAHpTwM9KFFSKuB05pjBVp6jHWgD0pwFAAF9acFzSqvtUir7UAMC1Iq88/kKcFx7U4D0qgGge1OApwWnBc0DGBadt9qkCn1FLtquUYwCnBe1P289acF9qdgGgew/GgLUuygL7UwGAZ9KUDPapQue1PETGgCDYaXZzzmrsNjPMcRRPJn+6Cf5VoxeG9SlwRbbB6uQKhzSFcwtuKdt9APyrqI/Cd23LyxJ+Zq0nhFf+Wl0c/7Kf/Xpe1iFzjdh96PLbuK7hfClqPvTTH8AKkHhSxxgtOf+BD/Cp9tELnCbCO1IYzjpiu9/4RWw/wCmv/fQ/wAKY3hSzPAkmH4g/wBKft4hzHCFSOoNJj2rt28JQ/wXDj/eUGq0nhKUD93cxn/eXFCrRYXOQ2D0o24ro5vC+oJyqROP9l/8aoTaRewj95ayL77eKtTTC5k7fpSEZ7VaaFwelRmNhTuMg2U0rVjYfwphXFMCArx0ppUipitJtoYEBX2ppGR0qcrmmFanlEyIjimY9BUzD2FMZcGpEREUwripSM0m0/WgZBimkZ+tTMufp696RhjrjFKwiBh60wjPTrUzDjmmFTSAhI9qYR61My0wjFArEJRtpO04HGajIweK2ItV8nw3c6UbGyfzpkl+0NEDIu0MMBs5/irLYcUAQkHtTCM1MR3xTDUtAQkd6YwwKmI9qjYcVLQiGkIp7DnpTakVh4GalUYpqj161IBnpVDACnikA9KeAfSmgFA/KnAfnQBnGRzUgHYVYABx/WpAPakUVIo/AUFCqtOA7UBT0p+DQMAM9Kcq0oX8KkAOcmmIQLUgHFA604Lz60xiKOeaftP/ANalC4HAp4XmmlcBqqaeFx70oHsKeBV2GJtHtS4p4QgU5UyeBQAwL608KT06Vat7KWeQJHG0jnoFGa6Gx8KzPhrp1iH9wcn/AAFQ5pbibOYWBmrTtNBvrrBS3Kqf4n+UV2tno1naAGKAFh/G3JrSWDnpWLrdhNnJ2vhJBg3M+f8AZjGP1NbNroNhCQUtFY+r/Mf1rZESjnHNOC1k5yZJWS2VV2gbR6AVIsCVMFPeneXUjsQ+WnpThGOwH5VMIz2p3lE0AQbBjpRsHov5VY8k0vkfQ/hS0EVto9BSbR6CrRhPoPypDDTshorFc9h+VJ5Y71aMRxmmmJvQ0tBFQwr6VG1uMdfyq6yH0ppQ+lMdjJn0u1uMiaCN/qOfzrLuPC9lICYvMib2ORXU7aaV46U1KSDY4C68L3cWWiKTD/Z4P5GsS5spYX2yRsjejDFerGIMPSqs9lHNGUliV1PUMM1oqz6hc8paM57Uwriu7vPC9tLlrcmFvQ8r/jXPX2h3VpkyR5T++vIreNVSKuYZWmlRnvVl4Sp6VEVPerGV2XvTCtWMe1NK+lMCuRTcYqcrUbDjpUNWFYhNNx7ipSKaR60gICuD0ppHtUzCmFeeKW4iErzxTGXj2qbBPQUwj2pAQFcdKYQO9Tkd+1RkYoAgI/8A10w8dKnK8Y7VGw7Ac0CICOc5NNI7jgVKy/l6UwjFSIiIqMqamYUxhxzUgSgU5Rjp+NCj1pQBjpQAoHYVIq8ZoC5/rTwD/wDW7VYwUZPvUgXjikA/OpAuO1MYoGOlPAoANOA7UAKAc09VH40KvFSAelPYAAx9acB2FAFSBeOn4Uxgq8U8D25pQMfSpFX2ppDGhKkAo+gFSKMcVYDAOakVSex/GnpCzdRW7pegXF5iRgY4v75HX6CpcktwMiG0kkkVEQsx4AAyTXTad4WZtsl6dg/55r1/E9q6HT9Kt7JAIYgD3kP3jWmkYXsM+tc0qrexNyja6dBbR7IIURe+Byfxq6sSgc1KB6AYp6oayeoiIKB2/Onhc9qmSInsTWja6NdTYJTy19X4/Sk3YLmWIye1SrAWOAuT7V0sGhwIAZS0h9OgrRhtYoRiKJE/3RUOohHKw6Tdy/dgZR6twKux+H5TzJIi+wBNdII6kEZz0rN1X0AwY9BgGN0kh+gAqwmjWa9YifqxrZELdhTxbN6VPO+4GONMsx0tk/HJp4061H/LtFj/AHa2PsxPUUv2Ueg/Ol7QVzH/ALPtsf8AHtF/3yKadOtT/wAu0X/fNbX2X2FBtTnpmlzhcwW0qyPWAfUEioH0S0b7okU+xz/OuiNsaYbdh2p87GcvJ4fGfknH/AhVSXQ7tMlUVx6qa69oDn7tNMWO1UqrFc4SWzkiOJI2Q/7QxUDQ+xrvWiDDBAI9xmqM+k2kuT5Qjb1Tj9K0VVdR3scY0XtTCmO1dJcaDKuTCyv7Hg/4Vkz2kkLlZIyp9xVqSewrmeUB6gVA8Gf4avNEc1GUOetUM5rUPDdrcktGohk9VHBP0/wrlNQ0a5smPmx5Xs68qa9NZc8EVBNbJIpDKGU9QeauFWURpnkjwlT0qIrXd6n4YRwZLIKh7xt0P0PauTubKSGRo5IyrjqCMEV1RqKRSdzOK5qMpVhoyDyKjx+NWMrlcU0j24qwy+1Rlcen4VLQrkBXFMI7GpyPyqMj3qREDLTCtTkcEdqjZfbntSsBCQajI9KnYCo2UUgIGAqMrk4NWCDUZXtQLcgIHWmHI61MR7ZPpTGA6YoEQkZGCKjYcVNg9DTGBPY1mBKBzx0pw60gHOKeB3qkgLemXMFpq1tc3NqlzFHKrtE5IBAYHsRReTQ3OoTTwWyW8buzLEhJCgknGSTVcDtUirzVDQqgA81KBge9IBT8Y60DADtUij2pFXnpxUgGKYCgdhTwuaAuelPA6cU0MUDJp4HpQAfYfU08LVJXGKq08fSgDPXpUiqT0FUAijPGKtW9o80oRVLOegA61Y0/TZ7y4EUMeWP5D3Nd1pWiwWEeVAeUj5pCP0HoKynUUdBN2M3SPDaR7ZrxQz9RH2H19TXTRwgDpUqIFHv2qRRz61yuTluQNC9Keq57U9YyT0rSsdJnusHaUT+8w6/T1qW0hlCOElgACa2LPQppAHmPlL6YyTWzZ6dBaj92nzd3PWr6Rj0rGVXsIo22n29sB5cY3f3m5NXVjGasJbsx6VpWej3V1jyYSR/fPCj8axc+7Ay1hYnoanS1ZiMjmustfDMaAG5lLH+6n+Na9vYWtuP3MCKfXGT+dYSrJbCbONttCu5sFLd8erfKP1rTg8LSf8tZY09gC2K6oJzTgtZOs2TcwY/DVouPMklf9KtR6Hp6j/j2B/3iTWttHYUY9qlzYiium2SfdtYR6fKDUgs7cf8ALGIfRRVvFGKXMwKptIf+eMZ/4CKa1hanrbQn/gAq4RijGetLmaAzW0iwfrax/gMfyqrJ4esH6JIn0b/GtzaPQfhSbc+1PnaA5iXwxGQTFOfo6/4VnT+G7tPuokgH90/0rtyvFN2D0q1VaBOx5vPp0sJ2yRsh9GGKpvbEdq9QkhWRSrIGHoRmsy60GymzhDET3T/CtI1+47nnjRH0qCW3SRNjoHU9Q3NddeeHLmLLRbZU9uD+VYk1mysVKkEdQRW0Z32GtTlrnQ4nJa3Oxv7rcisO6sZrd8SoR6HsfpXdvCRziq8sCSIUdQynqDW8ancZwLR46CoSuDXU3uhggva8H+4f6GsKa3eN2RlII7Gt1K4yg0YIxWZqGlW97HsmTDD7rjqtbLJ69KjI/Kne2wHm2q6JPYyEsu5D0cdD/gaxHiIPOcV63PbpLEyOgZGGCCM5rjda8PNbbri2UtD1I7r/AIiuinVvoykzkSMdqYyirckJVjxUDLit07lFcr70wjHapyBUZGOtJoCAjuaY3TFSkY6VGenNIViEjHSmMPyqYjPao2GOlIRCRjrTGHOR1qYjjmo2BqQISKiIqcjvURA6Y49KBEZFMIqVh3qMj3qRDwKkUUij9aeB61QDguakVeOmfekUVIBQUKBT1GT0pAKkVfXpQmAqripFBzQBT16VQ2Ko7YJ+lPUGkUY6VKo9qaGAWpAtAXnGKkVcnAqgBFy2B1rX0vSpr6cJGuB1ZiOFFJpelS310scQ92YjgCu/sLCKzt1hhXAHU9yfU1jUqW0QmxunabDZ24jiTA/iY9WPvWkqAChVAwMVKqk4rlbuQIq5wasQwNI4VVLE9ABnNTWllJcyiONcnuT0FdRYabFaINq7n7sRz/8AWFTOdgKNhoiIBJcrlu0YPA+vrW2kYAGB7YqVIie1XbWyeaRURdzHoq81yyqXFcqpATjAxWtp+jXF22Y48L3dugrd07w5HGBJdgOe0Y6D6nvW+kSqoVVAA6ADGK551ktEJsyrLQLW3w0o86Qd26D8K1lRR0HT8KkC5pwXmueUmyRoXjpS7cVJt9aMZ7UgGhfanYHvU1va3F1II7aCSZvSNS1blp4N1q4AMkUdsD/z1bn8hms5VYx3YrpbnPbaNvtXdW3gGHA+1ahIx9IkC/qc1pw+C9CiHzQSTf8AXSQ/0xWTxUETzo8yx7Uhx6j869bj8OaHH93S7b8Uz/Op10nTF4XT7UD2iX/Cs3jF0Qc6PHRj1/M0uM9K9jOm6eRg2NsR7xL/AIVG+iaQ4w+m2h/7ZAUvra7BznkO09xmk2n0NeqSeFdAlHOnRp7oSv8AI1Qn8CaU4/cT3MJ/3gw/WrWKh1DnR5yVHuaMV11z4EvkObW9hmHYSAof6isW70HVrHJuLCQIP44xvH6VtGtCWzK5kzJwPSmlc1OVpm2tEMhZc9qp3VhbXa4niDHs3Qj8a0StMK+1O7QXschfeGpEBe1Pmjuh4b/A1z09o8bFSpBHUHtXpxX1FUL7TLa9Q+amG7OOo/xreNXox8x5rJHjgiqF5YQ3KYkTkdGHUV1up6JPaEsVDR9nX+vpWLLCVJ4rqhPqizh77TZbV8kbk7MBwf8A69Zrxmu/lhV0KsuQeoNc9qWjtFmWAZj6le6//WrojUuBzhUj0qF0BHIq68ZFQEY5rRgcZrvh8BXurOP5erxgdPcf4VyEsO1uBzXrrpkVyev6EDuu7WP3dB/MV0U6ltGNPocMRUbD2q3NFtPSoCPrXQncsrsPWo2WrDLxUZHtQBWYZprA+lSsD0ppqBEDLUZHtU5FREUrCISPao2WpyPao2GaQmQHjNREdu1WG6ZqEigRKP8A9VSKDQAM09R60DsOAp4FIBT1HegY4DBxUigCmqPzPQU8daaVxj156dqeBSKMcAVIKYxQM1IAaRBx+NSKM00AqitLT7GW7uEhiXLN+Q9zVa2gaSQBVJJ6CvQdE0lbG2ywHnOPnPp7VNWfKhMt6XpsVlarDGPdj3J9a0woAwKao2ipVUntXE3ckEXmtLT9PkupgqAAD7zHtSWFg91OEUYH8TegrrrW1jt4lijUBR+tROdhDbSzit4hHEuB396vJGegFOjjJ4xit/R9Fa7YSSgpD692+n+Nck6nViuVtM0ia9kwi4QfecjgV2Fjp0FjFtiX5j1c9TViCCOGJY4kCqvAAGKnC/lXJKbZAgXjpT1XHHf0pVXtingYFQ2AgHc04H2rW0jw7f6swaFBFB3mk6fh613eleF9M0oLIqefOP8AltKMkfQdBXNUxEYadSXJI4jTPC2q6iFfyfs0J/5aTcZ+i9TXW6f4K0q1Ae633kg/56cKP+Aj+ua6aiuOdecupm5NkcMENvEI4IkjQdFRQo/SpKKKyJCiiigAooooAKKKKACiiigAooooAzL7QtL1HJurSNmP8aja35iuW1HwJKgL6ZdCQf8APKbg/gw4/Ou8oq4VJR2Y02jxq6srqxnMN3byQv6OOv0Peq5X2r2a6tLa9tzBdQRyxnqrjNcbq/gkqGn0mQsOvkSHn/gLf0NddPFJ6SNFO+5xBWmFatTQSQztFLG0cinDIwwRUOK6lK5ZWeJXUgrkHgg1zmq+HgVaazXjqYv8P8K6kr2FMZauM2tgPLp7YqTkEGqjpXoWraJHdhpoRtm6n0f6+/vXG3Vo8TsjIVIOCD2NdkKl0UtjkNT0fO6a2XnqyD+YrnZIirdK9BdMcd6wdW0oMGuIE56so/mK6qdTox7HKsOcEZFQSICOlXZI8HPeoGGK2QzhvEGi+UWu7dB5Z+8o/hP+FcpLGVbkV63NCrxlWUEEcg1wWu6SbK4JQEwvkofT2ropVOjKTObZc1G68VNIuGqNq6EOxAw4yBk96jIwelTkGo2AFQMgxTGFSkVGaBEJFRt0qZhzUZB6mpEQnrUbDrj8qmYVGRQIlUU8DApoFSKKBigdqmUZ7cVGoyalHTvQMcOvSnKOc00Z7VKBVDHKPSpFHrTVGTUoGDQAoHNTxR73HHFRouSK3tD0w3l4qMD5a8ufb0ok7LUDa8N6SAq3sy8/8s1/rXVxoAtMgiCRgBQABgCrAGTiuOUuZkvUVQTV6ys5LmdY0HzHv6VDDEWcKoJJOMCuw0zThaW4B5lb7xHb2rOUrIkmsrKO3gWONfcn1NaMceSMfypIo88Vv6LpBu5d7giFTyfX2rklPqxN2JNF0Y3JE0y4iHb+9/8AWrrokVFCqAABgAdqIo1SMIqhQBgADGKmAFcUpOTJADjNPA4pRVvT9PutSvFtbSLe55z2UepPYVm5JasRBFDJNMsUSM8jHCqoySa7jQvBkcQW51cLJIORbjlV/wB49z7dPrWxoXh200eDcuJLlhh5iOfoPQVt1wVcQ5aR2MpTvsNRFRAqgBQMAAYApQM0tFcxAmKWiigApDS0UAAGKKKKACiiigBtLilooAKKKKAAnFIBmlooAKKKKACm06igDN1XQ7HV4Nl1F8wHyyrwy/j/AErzrWfD97o8uZQJLdj8syDg+xHY16vTJoY54WhmRXRhhlYZBFa06soehSlY8VYZqMjNdZ4i8LSafvvNPVpLXq0fVox/UfyrljyK9CE1NXRqncgKgjpWVq2kR30JdAFmA4b19jW0QaYV57fjWqlYZ5jd2jRSMjoVZTgg9qzpE56V6LrOkrfQmWJcTqOMfxD0rhrm3KOQVxjr7V2U53RSZyGsaaFJuIV+X+NR29/pXPyx47V6BIgIIIyD1HrXK6rYG3nyqny26E9vau2nO+hRhMtUNQsY7y0eCQcHv6Hsa1HUg5qFh+VabO4Hleo2T2tzJFIuHU1mMMHkV6J4i0oXVoZ4l/fR88dx6f1rgp4yrHsK66cuZFoqMPaoiOOlWGHqKjYc81oMrsPSoyPapiMGozUgQsuDUZGO1TEZqJgc0iSIjvUbD1qYio2HFICRR+dPFIo4pw5NAEijinjmkFSAVQxyj06VItMUU8c8c4oGPQd6kX0pFGBUka5amBZtoS7gBck8ACvRtG04WVgsZUeYeXPv6fhXOeGdOE119pkX5IsYz3b/ADzXbxrgCuerO+hMmPUADipo0JamovNaWm2ZurpYhnHViOwrFuwjV0PTxxdyL7IP5mujiTpUUESoiqowFGAKv28RkcAAk9ABXHUldiLul6e95dLEowOrN6Cu7treO3t1hiXCqOBVTSNOWxsghAMjcv8A4VpqPSuGpO7MwC1KFx2pAAB04q1Z2c9/eR2lsm+VzgD+p9qylJLVgP0zTbnVb9bW2TLHlnPRB6mvUtI0e10exEFsuSeXkPVz6n/Co9E0e30fTxBFhpGwZZMcuf8AD0FalebWrOo7LYxlK4UUUViSFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUVkeIPE/h7wppDap4l1vT9Jsl63F9cLCmfQFjyfYV4pr/AO2d8CdDlMUGu6jrRXgtpdhI6fg77VP1Bq4U5z+FXGk3sfQVFfM1j+3T8Ery4EUsXiezUnHmzacHUfXy3Y/pXtngn4leBviPpLaj4J8S2OsQpgSLA+JIiegeNgGT8QKc6NSGsotA4tHW0UUVmIQjNcH4o8LCAPqWmx/u/vSwqPu/7S+3tXe0hGRVQm4O6GnY8TI7imEZNdb4r8OixkbUrJMWzH94gH+rPr9D+lcqwPpXpU5qaujZO5AwGK5nxDpIkVryFeesij+ddSQO4qJ0DKQeQa6IyaegzyuaIoxGKzru2S5t3hfgHofQ+tdfrml/ZbktGP3T5K/1Fc3IuM12wldXLRwd3btFO0bjDA4NUWXBxXXa1ZebB9pRfmT7w9RXLyr1rsg7oEUpFBFcF4i00Wt8WjTEUnzL7eor0FhxWTrFgL3T3jH31G5T7+n41pCXKxnmDLhsdqiYVduoikhyOnWqjCu1dyyBh61Ew56VYYHHtULdaVhkJ6mmMKmYVG3PWkSV6awHpx3qQ8U0jtUiY6npTFqVegpjHqKkX6CmrT15pgPFSL96owOKmQYFBQ4cnFXLaIu4UDJPAFVkXLAV03hmx8/UhIy5WIbz9e3+falJ2QHW6TZCz0+OHHIGWPqe9agHOKjiXAFTqvNchJJEpPauv0Wz+z2gdlw8nJz2HYVgaVaC5vUQrlR8zfSuxjXgVhVl0JJ415wK6zw3pwZheSLkKcIPfua5/T7Vrm5jijHzOcZr0O1t0t7ZIYxhVGB7+9cNadlYlssKAPapAB+FIop6iuYkcoJYYGT2HrXpfhbQhpdgZp1/0uYZc/3B/dH9fesDwZoouLn+1bhMxRHEQP8AE/c/h/P6V6BXnYipd8qM5y6ATikzQRmlAxXMZhUN1d21jayXV3PFBBGpaSWVwiIB3JPAH1rgPjD8YfC/wa8BN4h8Qu09xMTFYabCwE15LjO1c9FHVnPCj1JAP59a74t+O/7UXi6WzsdN1HU7GKTK6RpgMen2Q7eY7EKW/wBqQk+gA4rrw+ElW95u0e7LjBvU+4fE37VvwK8L3MlrceN7fUbmM4aLSIZLzH/AkGz/AMerkG/bn+Cok2rB4qcf3xpgA/V814Pov7CfxRv7JJdY8Q+GtHZh/qA8t06+x2qF/Imr91+wN4/SMmy8eeG5m/uy208X6jdXYsPgVo6jZajDufQek/tl/AbVJAk/iO/0tj0+36bMg/NVYCvSvDXxa+GnjAonhrx14f1KV+kMN6nmf98Ehv0r8+vEP7Hnxz0BHltdAsNciTndpN8jMfokmxj+FeM+IvC3iXwtqH2PxV4d1PRrgHhNRtXhP4FgAfwNarLcNVX7qpqP2cXsz9ngfXilJxX5DeE/jN8VvAojXw1481u1gTlbWWc3MH08uXcuPoBXvHhH9u/xzpwjg8ZeFdI1yIcNcWTtZTH3x86E/gK56uUV4ax1JdGS2P0BJxRXzh4W/bZ+C2uBI9YudX8NzkfMNQs2kjB9pIt4/MCvTtM+OXwd1iATWPxN8Ksp7SajHE35OQf0rgnQqw+KLIcWj0Go5J4opY43kRXkJCKWALYGTgd+Oa8z8R/tE/BXwvZPPqXxH0GVlBIhsLkXkrewSLcc1856N8ddT+PH7a/gKz8JaddWHhvQri5u18/AlnUwOkksoBIQbSEVcn73PJwKp4apNOVrJAotn25RTR0GTzXH6v8AFj4Y6Bemz1r4geGLC5U4aC41OFXH1XdkVik3olcmx2VFc/oPjfwd4n/5FvxVournGcWF9HOfyUk1v5GKVmtwAnFfJXx+/bH03wddXXhP4ZLaavrkW6O51WU77SyYcFVA/wBdIO/OxT1JORXP/tdftKXWnXd18JvAV+YboL5et6nA2Gi3D/j1jYdGIPzsOQDtHJOMT9kn9mu08QW1p8VPH2nrLpwYSaLpU6fJcYPFzKp6oCPkXocbjxtz6NHDQp0/b19ui7msYJLmkYXw6/Z1+Kvx/wBTi+IPxb8TapY6VcYkhmvf3l5coenkRN8kEfoSBkYwpHNfWHhT9mT4J+EbWNbXwLp2pTqPmu9ZX7bK59T5mVH4ACvXQoHSlrnrYupU0vZdkQ5tnn+s/A74Qa/p7Wep/Dbwy8TDGYtPjgdfo8YVh+Br4o+N/wALda/Zg+JmjfED4Y63e2ul3czR27yvve2lA3G3lP8Ay1iZQSA3UBgeQDX6L18p/t66nY2/wA0XSZWU3l5rkTwL32xxSF2/Dco/4EK0wNWftVBu6ejRVOTvY91+Enj+0+J/we0PxvaxCA38H7+3Bz5MyEpImfQOpx7Yrt6+dP2Jba6g/ZPsZbhWVJ9SvZYcjqnmbcj23K1fRdc9eChUlFbJkSVnYKKKKyERyxJPC0UqhkYFWUjIIPavLfEGjPo+pFFBa1k5iY/+gn3FerAYrP1nTIdV0t7SUAE8o5H3G7GtKVRwlcqMrM8hZccZFRsM1auLeW2uZLeZdssbFWHoagIr1E76mxm6hZreWbRMBk8qfQ159e27RTujLhgcEV6cy8VyviTT+RdoOvyv9exroozs7DTOIkQEEFcg8EVx+p2htrt4wPl6r9K7eWPBPFYus2vnWZkUZaPn3x3/AMa7qbsyzjWGGqCRcqTVyVTuqsw7HkV1AcB4l0/yL9pEXEcvzD69x/WuaZSDzXpev2X2rSpNoy8fzL/X9K85uE2yGumlK6LRVYVC9WCMioWHFaDIWBx0IpjD5qlIqM8DNITIWFRmpnqIipEKvWpl6VGoqReRTQEgqQDFMXnFSCmND1FSimLyakXrTGTwoWYV6H4ctPI0lXK4aU7/AMO3+feuI062NxdxQqOXYLXptrEqRqqjCqMCsK0uhLZYQYqxGuT0qFRzXTeFfDcuu3g8xzDaI2HkHU+y+/8AKuaTUVdkvQt6HbCKy81hhpDkfStuNCCAR19a73T7HTdNgWKzto0CjG4jcx/E1ogQXA2SRJIDxhlBrglWu7iuYfhexwjXbjn7if1P9K6dR0wOakXT4YbcJbIEVf4B0/D9aIomfpwPU1yTld3IFAq7p9lLqGoQ2cI+eRsZ/ujufwFRLAoHJJNbmgTtplw15HAkhddnz9hnnBrGpdR0E/I9Es7WGxsYrWBcRxqFUVR1TXbXS1CODLMRlYlPP1J7Coxr1vLpUtwg2yoP9Ux5yen1FcZMss9w80zF3c5Zj3rgp0eZ+8Zxjfcvz+KdXlYmHyYV9Am79TTY/GV/ZI8+otA9vGpeSRhs2KBktkdgATWd5X0FecfH6/m0b9mnxhfWz7JXsfsqsOo86RYifyc12woQk1GxpyrY8D0fSdZ/bG/amv8AV9Qubmz8G6WAMocNBZ7j5UMfYSykF2btyf4VFffPhfwn4e8F+GLbw74X0m20zTLZcRW1um1R6knqzHuxySepr5m/ZM0UeF/2fdJ1i0QC51Wea/mP98bzGin2CRj8zX1bb3CXNpHcJ911DCs8e2pKC+FbEVNHYmpMiq739mjbHuoQ3oXFfBn7Wd14q+Fn7RGl+NfBPjLW9NGu2puSkN9I0STxMEcCMkoUZTGShGM7uOa58PQdefItGTGN3Y+/ODVPUdL07VrF7LVLG2vbVxh4LmJZUb6qwIrzz4BfE0/Fv4Iab4suYo4dR3PaahFEMItxGcMVHZWBVwO27HavTXYICxIA7k1lKLhJxe6FseAfEH9lL4D61p91q9zpS+ETGjSzX+l3ItIowOSzo2YgB34FfCGq/DnStc+MEHgb4M6/feOnuXKR3DWH2RBjq28sQY1HJkIUemcivQv2pf2hbz4l+L7vwf4bvmj8F6ZOUzE3GpzIfmlbH3owQQi9DjceSMfV/wCyt8GLb4Z/CW31jVLRV8U65ClzfSOuXt4j80duD2CggsO7E+gr2IVauEoqpOTu9kbJuCuz4a8Q/s5fHDwvK41D4c6xcxp/y30xVvUI9QYiT+YFcZL4I8bLceTN4K8RiTONr6VPn/0Cv2W2rnOOaNvufzqY5zUStKKYvbM/KPwb+zb8ZvGlzHHp/ge/0y2cjdeauhsoUHr8/wAzfRVNfeXwB/Z80P4K+H55zdrqviS/ULfals2KFByIYlPKxg8nPLHk9AB7VgUprlxWYVcQuV6LsiZVHLQ/PD9qr4/+K/EXxN1P4Y+EtRu7DQdMn+w3S2LFZdSuQcOrFfmKBjsCD7xBJzwBzvgz9jL4x+J9Mj1C9stK8MwyrvSPV5is5B9Yo1YqfZiD6ivbPhz8Er/w5/wUM8Q614k0aa40to7zXNE1BoS8DyyyrwXxgSxiWQYODwGHY19iAADiuieN+rxjTw9tld+ZTnypKJ+c+p/sOfGPSFF9ouq+Gb+5Q7lFpey20oP+yzIOf+BCqE3xe/al+AkP9geMX1Bbe6ikhs21+NbwKQMF4JwxLFMg4LMOmRX6Tk8V+Vf7T3xOPxM+P2p3dtceZomjltM04A5UojfvJf8Agbhjn+6qela4OtPF1OWqk0t9Bwbm7M5H4bWXhHxB8ZNKPxO186f4ekuWuNTvJw8huOrFGZQSPMY4Zz0BY5zX6yeFfEHhPXtBhl8H6xpWo6dGipGdMmSSONQMKoCE7QBgY4xivm34OfsnfD3U/wBnTRm+IXhxpvEOox/2hLdxzvBcWokwY4gykcKm3III3FqytY/YUj03U31T4a/E7VtFuAcot5GWZf8AttC0bfmDWWNrUcTO3Na2m2gpyjJn2LketGR6ivjEfCj9tjw2yw6L8WrTVoV4UzahvJHbieAn9TTJvh5+3LrZ+zX/AMRLSwjbgvDqUUOPxhg3flXJ9Wj/AM/ERy+Z9ReP/ih4K+GPhx9Z8aa5badEFJigY7p7hv7sUQ+ZyfYY9SK/PfxRrfjz9r/9oW3sdB0+S1063UxWkT/NFpdoW+aedhxvYgE46kKi5xmvZdB/YY1LWte/tr4sfEu61S4Y5lj07fJLJ7G4nycfRa+qfAXw48G/DPwwug+C9Dt9Ms8hpCmWknfH35JDlnb3J+mK1p1aWFu6b5pd+iGmo7FrwT4S0vwJ8P8ASPCGioVsNMtUtot33m2jlm/2mOWPuTXQUUV57d3dmYUUUUAFFFFAHD+N9IIVNWgXpiObH/jrf0/KuJI5zXtF1bRXdnJbTANHIpRh7GvIb+zksdRms5R88Tlc+o7H8Riu3DVLrlZrB9CkQaq3dutxavA4+Vhg/wCNXGAqNhkYNdidmWeY6hbNDcPGwwykg1lyqCCCMg9R612fiayxcC4UDDjB+o/+t/KuTkTBNd8JXRaOE1G2+z3kkeOAePes5hk4NdRr9uCiXCjnOxv6VzTrhq7Iu6uCKcy8HgGvONcs/s2ozRDoDkfQ9K9NkXK1x/iy0yI7kDsUb+Y/rW9KVmXE4j1+tRsOeO1TyDD1Ew7nrXUUQEfWozUrDIqI9TSERHp9KjNTEc1E4qWIeo4zkU8VCrYPNP3ntir5B2JwMmpQKrLKw6gH6VZjZXGVNFmMlTpn8KkUVGtTxDLUgOn8K23m6n5mOIk3fieB/Wu7iXCVzXhO326fJMRy74/If4muoQfLiuSo7yIZLDG0s6RqPmdgo/GvWPD3lWlqlvCMRwoF+pPU/WvMNNIXUY3OPlyRn6V6FpExWwDZ5Y5rmraoR1qXZPetfSSZbnd12jNcnFNkgZrrtCXbYeYc5du/oOK4amiIZtBuOtPVu2RUCmng+tc4ixEryzJEn3mIUV0q2gRFRV4UYFUPDNobjUXnI3LCvp/Ef/rZrqvs3HIrmq1LOxMnYxvs/sKDbHHStk23tSC2x/DWSmLmMb7P7V5d+0RoV1rH7MfjG1s4zJNFZC7CgckQypKf/HUavavs3qKbJZRS28kE8KSwyKUkjcZV1IwQR6EEg1cK3LJSQKSueB/sr61Z6/8Asx6LbwSK1xpEk2nXCg8qQ5dD9CjqR+Ne1mW6+yJbeYwiTOEHAPPf1r4h1e38b/sffHS51HSdOm1TwBrUmI4nYrHNHklYS+CI7iLJCk/eX1BOPofw/wDtR/AzXNJS5uPFy6HcYy9pq1vJFIh9MqGVvqpNdFek5P2kVdPUqWuqPUjbBh0r4U/bN8RWuofGDSfDNrIsjaLYH7TtOQss7B9v1CLGT/vV678Tf2yPBOi6PPY/DQt4h1iRSsd7JA0dnbH++d4DSkdlAAPc9q+afhZ8KfGvx9+JM9wZrtrSS5NxrPiCcFliLNubBPDzNzhB06nCiunB0vZN1quiRcFbVn2N+w3pt1Yfs0TXlyrKuo6xcXUCnvGAkW4exaNvyrY/a9+J8nw++Ak2maZctBrPiJm062ZDhooiuZ5B6YQ7QexcV6d4d0Ox8HeHbHQ9Btha6fYW6WtvD12xqMAe57k9ySe9fnt+154/l8ZftHXulJLusfDkQ0yJV+75v352+u8hf+2Yrkw9H6ziuZ7XuZxjzTucr+zx4AT4h/tG+G9BuLcSadbzf2jfLj5TBBh9p9mbYn/Aq/WUcV8XfsD+Dgmk+KvH08WGnlj0m1fH8KDzZcfVmjH/AAGvr7X/ABDonhfQrjW/EOq2el6dbrvlu7yURRoPcnuew6ntUZpV9pXcV00FVd5WNSivnPxJ+2v8EdDlji0y/wBV8Rsxw7aXZkJHz3aYoD/wHNet/Dj4l+Evir4LTxP4Pv2uLMyGGWOVDHNbyAAmORD91gCD3BBBBIrhnRqQXNKLSM3Frc7GiuO+IPxT8CfC3SLbUvHPiCHS4bp2jt1ZHkkmYDJCIgLHAIycYGR61N4D+I/g34meG213wTrcOqWSSmGRkVkeJwAdro4DKcEHkcg5FRyy5ea2gWe51dAOa4bx78Xfh18MTaL458U2ekSXYZreF1eWSULwWCIpbaCQM4xW54T8YeG/HHhiDxF4U1i11XS5yRHc2zZUkHBUg4KsD1BAIo5ZJXa0FY8//aX+ID/Dj9nDX9atJvK1O6jGm6ew6ieb5Aw91Xe//Aa/O74C+BF+I/7QHhvwtNEZLAz/AGu9z0+zQ/O4P+9hU/4HXu37enjX7f438OfD+2m/dabbtqd0qn/lrLlIwfcIrH/gdXv2J9I0Xwj4K8Z/GbxXeW+nadDt0yK9uW2pHEmJJjnqcs0SgDklcDJr2sOnh8HKot5G8fdhc+6EUIoAAA7AdqdXyLqv7fHga18SG00nwTr+o6Yr7TfNLFA7juyxNk49AxU/Svpbwj410Dxt4A0/xloF4JdJvoPtEU0g2FQMhg4P3WUghh2INeTUoVKaTnG1zJxa3Piz9r744/EDSvjJP8OvDOu3+g6Xp9tBLM9hKYZbuSVd+WkHzBACAFBAyGJz29X/AGL/AB7448XfCfX38bardapa6ZfLBZalfPukK+XvkjaQ/eCErySSN2CeK19cn/ZR+OvxJtNJ1XVPDviLxLEDBb+RdSwyzKuSY1kQqJgPmIXJ74715x+2dr8Pw2+Dvhf4WeB7ODQ9I1TznuLawTylaCHb+647O8gZu7bec5Nd0eWrCGGjC0n1L3SjY+s9D8Z+E/FElzH4a8S6PrD2rBbhbC8jnMJPQNsJx0PWt2vgP9iDwzeaf+0R4tngnWWx03SRZ3E0QxHJLJKhVffHlyY+me9ffWcd648TQVCo4J3InHldj5O/aK/av174WfFFfA/g/QNLu7i2ginvbrUw7KTINyxoqMv8OCWJ/iwBxX0F8LPG0fxG+EGgeN47I2X9q2izvbbtwifJV1B7jcpwe4xXyJ+15oGieP8A9ovwp4I8C6eLvx/dw+XqMkLfJFBwYfOA6FQXcseiYB6rXuvir4o/Dz9lr4QeG/CV69zqN3bWKW1jplmB59yIxhpm3HEaFsksT1OADg1vUpQdKmqa99lNLlVtz3eivmP4S/tj6H8TPibZeDLnwVqOjT6gzR2lylyt3GXCl9smFUpkKeeR0zjOa+nO1clSlOm+WasyGmtwooAxRUCCuG8dadsmg1ONfvfupD7/AMJ/LIruazdcsv7R0G5tcAuULJ/vDkVdOXLJMadmeRsKYw5xUpHGajbp79q9VM3MjWbX7Rpcqhcso3r+H/1s159cJtkNepSKCDnJHfNedarb+ReyxYxtYj/P4V10X0Kic7qNv51jLH6jI+tcTMuGPFegSdK4nU4vJ1CaMdA2QPrzXfSdtCjOYZHPWsTXbbz9InXGSo3D6j/62a3D3qrPGGUqwGCMGtU7MDye4XDniqp6VqalD5N3LFjlGK/gKzSOCK7U7o0IG64qJhmpm61BM5X5R1/lTSu7ARsQOp59KiLZ7UY9aWtFBAHel60ir25p4GTRcAC59KlQlGBH/wCumqKeBSvcC4vIz61YgGXFVYWG0J3rQtlzIAO/FZNWA9F0GDytFtlI5K7j+JzWyo7VUtECW8cY/hUL+Qq4vauKWruZlm2ykykHmu+tD5dvGmfuqBXEafH5l/DGe7iu3i61jV1A0rdyWr0Kxj8qxhjxjagH6VwWlxedfwRY+9IB+tehxj0rgrPoQyUH3qQdKjWpVBK4HWudsR6B4SsjF4dWYrhp3L/gOB/Ktzyafp9sLXS7e2Ax5car+lWNteTKbbbMWyr5PYAE/Sk8r2q3gf3aNoPbNLmFcqeUaPIz25q3tX0P41wHxQ+MvgL4RaGt94v1QpcTKTa6dbKJLq6x12J/dHdmIUetOPNJ2itRrU6bVNE0rW9Hn0rWtNtdRsbhdk1rdxCWOQehU8GvDdf/AGMvgnrV809npusaGWOTHpeoMsefZJA4H0HFeJeIv22/iT4l1tdK+GvgmxszM22BJoZNSvJPoiYUH2AbHrWtp/xN/bjtIRq938PpL60A3m3n0SNGI/3I5BIPyzXoRw1elrzcr9bFqMkeraH+xh8EtFu1ubrS9X1tl52anqDNGfqkYQH6GvcdI0PS9A0eDSdE0210+wgXbFa2kSxRxj2VQAK8a+B37T+i/FDWm8HeI9Ibw14viDD7DIzGK5KffEZYBldcEmNhnAJBODj35lHeuWvOrzctW9yW5dTm/GGuWfhHwDrPiq/Krb6XZS3r7u+xCwH4kAfjX496jqN1qeq3er6lIZLu7me6uHPUu7F2P5k1+iX7bnjEeH/2eYvDUMu258RXyWxUdTBF+9k/DKxr/wACr4M+H/hSXxx8VvD3hKFSTqeoQ2zkDO2MsDIfwQMfwr2cpXJSnWf9WNqWkXI/Sz9nnQLb4c/sm+G01RorLGntq+oTSnaIzLmZyx7bVIH/AAGvgv4+fGrXPjZ8Rz9lNwvh21mMWjaWoOXydqzMv8Ur8Y/ughR3z9b/ALa3jVvB37PNr4R0p/Il8RXIsMJxttIl3yKPY4jT6Ma+bP2O/AkPjP8AaOttUv4RLY+HYDqbqw4abOyEfgxL/wDAK58GlGM8ZU1fQmHWbL37NHgfwvpn7WOpeCfizpmmTaha2ktrbWOohZYWu90ZKgN8rN5bNt/EjnFdl+zT428JfCL4n/GGy1vXbbS/DNjc5txM+S7R3M0SLGn3ncpgYUEnaPSvYf2kf2e/ht4u0bVfibrGp3vhzVNMsWuLrULII63CRLlRJG3DOMBVYEHoOcDHgX7NXwN8CeKvhdrfxe+KVtdXWl6XPM0Nk02yGVIYw8ry4+Z/mJXG4A7TnNEq1OvTlVm3rZW8/Id4yV2eS/Hb4xal8ZvilLrskctro9ohttKsXIzFDnJZ8ceY5wzY6YUds19j/sMeF5tH/Z8vfEVwrK2u6nJNCD0MUSiFSPqyyfpXwLfTal45+Ik01lZomoa3qGLe0hQKqNLIFjiVRwFXKqAOgFfo98UvEll+zl+xzDpejTRx6jbWEeiaTg4L3LJtMv8AwH95Kfp71rmEeWlTw9NbhU2UUfE37T3jkePf2mvEF9bT+bp2muNIsyGyuyHIcj2MhkP5V9t/sg+Fp/C37KWiy3gaOfWJZtXZWGNqythP/IaIfxr87PAPhO78f/FHQfB1qzGXVb2O2eU8lEJzI5+iB2/Cv0q+PvjfTfhB+zNqLacUt7mS0GjaPbg4IkePYmPZEDOf933qcxjyxp4WAVNlFH5y/GLxk/j347+KvFhcyRXWoSLbf9cIz5cQH/AEB/GvdfhT4B1T46WXh/4bw3c9h8MvByJLq1xbnadV1KXMkgU9yC5VTzsQburrj5Zs7G7vr2303Trea6upnWGGGJS7yMeAoA5JNe3aB8YvHer+AtB+A3wj0qDw9FfH7LNPHchbzU7iTmRnnbasQcg8LzgBd3QHtxdKSpRhT6fh5lyWlkY37SMvw7g+Ok+j/DPStP0/RdHtI9OlexX91PcIWMj5ydxGQhfJyUPJ619JG51P4Of8EtvI1QyWmr6zbSQW8DjDRNfSsQuOxELMxHY5q18Ef2LbDwzq1p4o+KN3Z6xf2zLLb6NagtaQuOQ0rMB5xB6LgLkc7q4T9vHx2NQ8daB8O7ObMOlwHUrxQePOlG2MH3WMMf8AtpXC6kcROnhoO6WrfcjmUmoo8b/Zs8N3Xib9qfwZaWgZUsr4alKw6JFbgyH6ZIVf+BV9iftteDPDus/s+Hxbquo/YNQ8PTebYvjd9oMpVGt8f7WFYHsUz0zXCfsF+A/L0zxH8SbuL5p3GkWLkfwJh5mH1Yxr/wAANbvxJl/4aB/a/wBI+EVkxn8IeDZBqfiF0OUmuBjEJ9eojx6tL/drPF1nLF80doilK8vQ+cbDU/2hP2dvAlpfWBPhvRvE5S6iuDDbXDTN5QZQ24M8bBDnaQMc9819D/si/HT4j/ErxrrfhbxvfJrEFtp4vob826RSxN5ip5bFAAwbcSMjI2nnFeIfth/ElfGvx2bw1ps4bSPC6tYxhD8r3JIM7D6ELGP9w+tfRn7Hvga1+H/7PN14/wBeKWlxrwOoSzTfL5FjEG8vOegI3yH2Yela4txeF9pUiueQ525btanv+meBfCWi+L9W8VaVoFha63qxU32oRxDzrjAAAZuuPlHAwOM1+Xv7SPiLUfEX7Ufja7vpGb7HqD6dboTxHFB8iKB2GQzfVie9foV8BPitqvxh8Ia54putEi07Sk1ie00iRSwe5tkC4dwf4skgkcZ4xxXwh+1j4Ybwz+1h4lZUIg1XytViJHXzUAf/AMiI9YZUmsQ4y3sTS+Kx+gXwL8O+H9B/Z78Hw+HrO3it5tKt7ppEQbpZZIlaSRm6lmYnJP07V6RX58/DX9r3UvBHwI0HwFo3ge48Qa/p6SW6zSSsIRCHJi+WNWdiFIBGABgcmtDTP26/iDpniWOPxt4B0lLANme3tUntbpE7svmkhiB2IAPTIrGpl9dyk7fiS6crs+9qKq6bqFvquk2upWjFre5hSeJiMEq6hgcduCKtV55mFFFFAHkuu2f2LxDd2wGFEhZfoeR/Oso8npXXeOrcR6xb3IGBLFtJ9Sp/wIrlGGM16lGXNBM3i7ogYcVxfiiHbqO8dHQH8eldq/Ga5nxTDutYpQBwxU/ln+lddJ6opbnDyDk1yviCLbeJJ03Lzx3FdbMMMa57X4wbWN8dGI/Ou+D1LOXI5qvKMrVqQfNWbqd/Fp9mZX5Y8LGDyx/oK6Fq7IDg/E8awavOzYCthsn3H+NczJcqDiME+/TNamv3FxfXwuLhgWIwFHQD0FYjL7V6FOC5dTRDWnkJxhfyqJss24nk05hnrQRzitUrAR0h6U7pTT0pgPFPUYpgGfapK57gOVcnrUoHHQU0AVItO4rD0GCCK2NLj8y/gT1kUfrWSg5wAK3tAXdrNsOuHB/LmolsM9Ih+7VhByKrwfcFWUrjMzY0RN2qRH0BP6V2EQ4FcpoC/wDEwJ7hD/SusiFc1XcTOg8OR7tYhOfugt09BXcIOK4/wuoOose6xn9SK7FelcVbclkqjNXtLg+061aQYzvmUfhnmqK8Zrb8KxiTxZZg/wALF/yU1yVX7rJex6nRRQBivKMAoooPSgDy/wCO3xf0v4M/C2fxHcxpd6nO32bS7Bm2/aZyMjOOQij5mPoMdSK/OLw9o/xB/aM+On2aa/fUNc1JjNeX9wD5VpAvVyB92NAQFQdyAOSTXWfta/Eabx7+0TqWnRTltJ8OltLtEz8u9T+/k+pkBXPpGK+r/wBjb4XQeCvgXD4qvbYLrXifbeyOy/NHajPkR+wwTIfd/avapr6jh/a/blsbr93G/U9M+E/wX8FfCDwymneGrBXvnQC81a4UG5u27lm/hX0RcKPc816IVXrgU6ivGlKUnzSd2Yt31Z8O/tt6DD4K8d+DPi54bxY601y0c80Q2mSWALLDIcdWwHQnuMDtX2hoOpprXhjT9YjXYl7axXSj0DoHx+tfDv7dHif/AISj4i+E/hfouLm+tQZp44+SJ7orFDH9duWx6OK+zhcaf4D+F4n1KcLY6HpgM8nQCOCIbiPwQ/nXXWi/Y0776/cXJXirnwD+234zPiL9oqPw5by77Tw7YpblQ3AnmxLJ+IXyh+FX/wBhrwedc+O2oeLJ4ybbQLA7Hxx58+UX8Qiyn8RXzp4r8RXni/xzq/inUCftWq3kt7ID/CXYsF/AED8K/Rn9jbwIfB/7Ntnqt3Dsv/EUx1STcMMIiAkA/wC+FDf8DNevi/8AZsGqfV/0zafuwseJ/t/yzv438EW75+zpYXci+m4yxg/oBW7/AME/oLUaV4+udy/ajcWUZHcR7JCD9Cxb8q9e/ag+B958Y/h7ZP4fkt08R6PI81ms7bEuEcASQlv4ScKVJ4BUZ4JI+NPCPwf/AGoPC3iie38H+FvFmgX9wv2aa6tpltonTPRpt+wrnkEE46iuWjKnWwfseZJruRG0oWue/ftefEi98VappX7PfgL/AE7W9Vuov7TjibOzkNFbsR0ycSv/AHVQZ61sfHzSIPgz/wAE+F8CaLKWDi10eSccGZpJPMnf/ge2T8Gro/2df2a4vhZJP4w8YX0es+N75W8y5DNLHZq/Lqjt8zyN/HIevQcZz2P7Rvwx1D4s/Am+8MaLLCmrRTR39iJ22pJLGT8jN/DuVmXPYkZ4rkVWnGcKa+FPV9yOZJpdD4X/AGR/Dttr/wC1NpF1fBDbaNbXGruZCAA0ahUJPs0gb/gNan7UXxDvfi14rfX9HkL+CNBvToumzgnbd3TIZJpl9RtRQD/d2f3qzvB/7K/x31fxWdLl8P3nha1kBgvNTvLhUiWFuHUCNyZgQPuDg8ZIHNfT/wAXv2ZY7n9lLR/h/wDDa2jkv/D90L6BLh1jfUHKssxZ+gkffuGcD5QvAxj0q+IpRxManNfp6GrlHmueFfsPeHbO7+M+ueL9QeNIdA0ksksjBVieZtpck8ACNJOfeuO/ab+Ll58XfiJ/aGlCU+DNJnk03SpOiXM20NLNz3YbceibOhatP4ffsx/HzWtXutClsNS8G6JfBYdVur2cRxzRBs7fJRsz85wp+XPUgV7J+0R+zBq5+EngnRPhHo39oW/hw3K3Vn5iLc3TTeWWuMsQHctH8wyDgjAwMU5VqMcWqjknf8BXXPe55D+xj4Lj8UftIQ61dQCS08OWj6h8w485v3UQ+oLO3/AK8++L3hy/+E37TWvabpTtZy6bqg1HS5R/BGzCeFh9M7f+Amvs79jP4V+Kfh34J8TXvjLQLjRtS1O9iWOG52+YYIo+D8pOAXd/yrjv27fhhLe6Po/xV0uDc9gBpuqbR/yxZswyH2Vyyk/9NB6VEcYpYxpv3XoHP759P/DDxzY/En4S6J400/aqajbK8sSn/UzD5ZYz7q4YfgK/LH40+JZ/FH7QHjTxBdOz+ZqtwiA9oomMSL+CxivfP2KPi/H4c8ZTfC3XLoJp2syefpjyNgRXmPmj9hIoGP8AaUd2rmPjP+y/8UrH4z61deE/CN74g0LVLyW9tLmxKN5YlYu0UqlgVZSxGTwRg56gLCU44XEzjN200CK5JO59Bav46sf2bf2MfCnhvSdk/jDUdOjj06yRd7vdTfPJOV6lUeTj+821R1rV+Gvgm5/Z4/ZL8TeLdYxN4vnsbjW9VnlO9vtAjZo4i38Wwtz6sznvWH+z9+zNr+i+KLP4lfGO/k1TxHaRJFpenXFybsaeqjCM7kkF1HCqvyp15OMfQ/xE8KR+OfhV4g8HyTi3Gq2E1osx5EbMpCsR3AOD+FebVnGMuVO93dvuZtpOx+TXgTw1c/EL4vaD4XnnZpta1GOC4uGOWw7bpXPvtDn619uftH+LLzX7/Q/2YfhaEXVNW8qHUjB9zT7JQCI2x90bFDMOyKB/GK+Z9M/Zy/aK8P8AxDt00fwbqlpqlnOHt9Ws7iJIEYcCRJy2AMHuM4PI7V9tfAH4DxfCvTb3XvEWoDWvG2r/AD6lqjM0m0E7jFGzfMRnlnPLkDoAAPRzCtT5ozjK9lovMuo1oyfxr4y8E/sv/s96ZaRwmZLOBbDStOVgsl7MFyzMf4RnLu/bJ6kgH4c+O2n/ABa1/RdB+MPxRNvbnxDI1rpumohja0t1TzU+T+FW3MQGJY9WxkCvX/2w76PTf2svhtfeLYJp/CFtBDNJEqF1dVu91yAv8R2iLI7jFct+198cvBnxSHh3w74GvDqVjpkkl5cX/lPHG0joEVEDgE4XcScYyQPWpwFOUJwnFXcrtsIK1mbn7AurXEfxI8X6GAPIuNMhvM45V45dnB9xJ+gr7B+I/wAJ/BXxX8P2+keMtMF1Fb3CXEU0Z2TIVbJUSYyEcZVh3BPQ4I+Rf2Q/DOveFtF1bx1IjWjawiWtl5iDc8CMWaQAj7rMQB6hc9MV9Nf8JZ4iR8rqRI9DGpH8qnHUJyrucGE4tyuj1SCCK2t0t4I0jijUIiIMBQBgAD0xUleeWXj29jIGoWkcy93i+RvyPFdXZ+JNIvbF7qO8jjVBl1lO1k+o/wAK8udGcPiRk4tGxRXE6l49iVzHplr5uP8AlrNlQfoBz+eKwp/F3iCZsi9EQ7CKMDH5g1pDDVJa2GoNnTePYd2kWs+AdkpX81P+ArgGPard3rmr31obe8vHmiyGwyjqPoKoCQk/NXbRpSpxszSMWkI3WsXxDFv0hyOqkNW315rP1OB7jTJooxucrwK3g9UUjzW4HznoKxNZj3aZJ/skGuvuNB1QsStsCP8AfXP8657WrG6ttPnFzbSRDbwzLwfx6V3wepaOElwAT0Arh9Vle/v3m52D5UHoP/r9a7TUSRYTYPJXAP14rl2tgF4Fd1LTUZyGrwYiRsdyKwnXBrsNegxYBsdHH8jXJSr854rtpyuikVj9BUZGKnIqI9+K15hkZAzTSKkPNMYVHMA4dKkFRjpUqiskSSLUqVEOgqVOooKJl9a6Dw6udbgP1/ka59OldF4cH/E6t/8AgX8jSnsSz0GE/KBVpBzVWD7p+tWk5NcVhHQeHxm7kP8Asf1rqIq5jw//AMfUh/2RXURdBXPV3EdX4WGbmY+kY/nXWr938K5Pwr/x8Tf7g/nXWL0rhq7kMkHauk8GqG8Vxk/wxOf0x/WubHUV03gs48VL/wBcX/pXHXfuMmWx6QBiloorzDAKo6vfLpuhXupMMi1gknx67VLf0q9WV4kspNS8I6pp0P8ArLmzmgX6tGyj+dC3QI/HGwhufFnjW0tpHLXOs6giM/ffPKAT+bmv2Y02xttL0i202zjEdtaxJBEg/hRFCqPyAr8e/hps0/4y+DmvPkW21uxEu7ttuEB/UV+xw717OcPWC6WNqz2Rz2r+PfBfh/VzpWveLNE0u+8kXH2a+vo4JDGSQHAcjK5UjPsa8G+MH7Y/w/8ABuk3GneBL628V+IWUpGbVi9lbH+9LKOHx12IST3K9a9S+KvwN8AfGLT7aLxhpspu7QEWuo2b+VcQg8lQ2CCpPO1gRnng1wHhH9i74LeF9bj1O7s9U8RyxMGih1m4WSBSOhMSKqv9GyPavPoewXvVLt9iFy9Tx/8AZX+EfiPx38S3+PfxFE86Gd7vT2uhhr+6bj7Rt7Rp0TsTjHCDPoX7cHxDXw58ErfwTZThb/xLN5cgU8raRENIfozeWnuC1fTcslnpOmPLI0NraW8RZmbCRxRqOSewUAfgBX5Q/Hz4oSfFr43an4mhkY6TF/oelI38NshOGx2Lks5/3gO1duEUsXiOeS92P9IuF5yuY3wo8B3nxO+MWh+C7ZW8u9uA13Kv/LK3T5pn/wC+QQPdhX6wa1r/AIU+HPgZtU1zULTRdC06FY/MlO1IkUBURQOSeAAoBJ7CvnX9iz4PP4S+H1x8RtctTFrHiCNRZpIuGgsQdyn2Mhw/+6ErxD9tz4iajrXxy/4Qdbh10jw7bRubdW4kupU3tIw7kIyKPTLetXiH9dxPs4v3UOXvysfROg/tieF/GHjseHPA/wAOfHXiRRgyXNjZxfImceYUaQFV92K/nX0fGwkQNsK5GcEcivLP2efh7o/w++APh+x061iW7v7KG/1C5C/PcTyoHJY9wu4Ko7BRXqnTtXl1uTnaprRGMrX0K99e2um6fNf31xFb2sEbSzTzOESJFGWZieAAASTXxX46/bG8X+LPiFF4K+Amgx3bzzeRbajc2xnmvW7tFESFSPgnc+eBkhRU37b/AMY5oVt/g/oN2UM0a3etsjclDzFbn2ON7DuNg6E1p/sTfC2y0HwFf/F3XIoo7vUhJb2Es2ALezjP7yQE9N7qcn+7GPU12UsPGlR9vVV77I0UbLmZv/A743/Ey6+O9/8ABn4zadZRa/HbtcQXNtGkbBlRZDG4jJRgY23Ky46EHPb2j4tfFrwr8HvAMviXxNM7l28mzsICPOvJsZEaA/mWPCjk9gfmH4E3h+Kv7cnjn42A+V4c0mKWO3u5PlQhoxDFknp+5jeQ+gYetfP3x4+J+q/HH44SXWmLNcaZDL/Z2g2SfxIXADgf35Wwx9to7VosGq1a1rJJN+Qcl2eoy/tdftAeIJtT8W+GfD+lW/hvSGje9gjsDPDbo7bUWadmDZY8ZXb1zgCvuX4feLIPHfwu0HxhBbG3TVrGK78hjnyiy5K574ORn2r5J+Neh6d8Bv2EtK+FOniObxB4luoo7toxlrmYFZZ3HqAVjiX2K19WfDfQU8DfBXw34cu3SM6VpUFvcO7AKrrGN5JPAG7dWGL9m4KVONtdPNCla10dgMY4FZniLQNL8U+FtQ8Pa3apdadqFu9tcwuOHRhg/Q+h7HBryXx5+1d8GfAnm2z+JBr2ox8fYdDUXTA+jSAiNfxb8K+dtd/bT+KXjrWDoHwn8CrZTyHbGRC2p3p99igIn4hh71lSwlafvJWXd6CUJM+e/ix8NvEHwc+L134avJrgC3kF1pmpJlDcQ7sxyow6OCMNjoyn2r7T+Fn7Y/w/ufhDa3PxM1r+zvE1oBb3UEVrJK16QOJ41RTww6g4w2R0xXk8H7NH7Rnxl1GHXPit4oGmoinyRrE32maIN1CW8WEjzgZGR06V89eP/h74t+E/jttA8W6QsM8b+ZBI6GS1vo1PDxtwHQjqOCMkHBr23Chi4qlUlea7G7UZqzep9p67+3z8MrCbydE8L+JNUfsZRDahvoGct+lY0f7fEUrbk+DmtND/AHxfg/yhx+tbP7Ofxm+BHiLTrTQz4S8L+B/FAAQ2otIoobpsdYJmGTn+453Dtu619P6hqtlpNsPOOWI+WFAMn8OwryqipU5cjpO/mzFpJ2sfOvhH9uD4Ta5fpZeI7LV/C87HBlvI1ngT/eeIll+pUD3r6Kttc0q+8Px65Y31vdadLCJ4rq3kEkciHoVYcEH2ryD4heFPBvxN0+XT/EvhHSXV+FvBEFuoP9tJlwVI6+nHORXg/wCyXrerJp3jTwHFqb3/AIe0y9SWykzlNzSSKdvorhFkwOM5PeqeDjOLnBWt0Y3BPVHuPxH0PRPipZDTfFmkQ3unxP5lvC5KvA2Mb1dSGViOCQcdua8lX4K/AfwJdJrOtW1lCI23J/b2p74gR6I5Ab6EGvdBBjtXwP8AtR6lb6j+0pqkcbK66bbW9kx9HVN7j8DIR+FelhIuX7uLsjWK6H3JYXNjqWlW99pl1b3NlNGHgmt2Dxuh6FSOCMelTiP1rjfghotxo/7PXhCwukKyjTkmdD1XzCZAPycV6ALYntWM2k2iSh5fPOT9aURD06VoC2PHFOFs3Hyk1POguUBF7GlEXsa0Bak9qcLUkfdqXUFczZIisLHHSqpyRW3c2xWylbGMLWMR9KqMropDc4qtIcROfarBx2NV7g7beU9wpP6VaGZck/PWqd1Or2zo4VlIOVbofwqCa4wevFZ15dYtpOf4TW6Gch4l8NWlzbSTaYFhm6mAH5G78f3T+lecTW5QlGUgg4IPFelXd9wfmrktbjSSb7SvDHhvf0NdtNvZgjgfEMQGlMcdHU5rh5hlia9C8RrjRpM/3l/nXn8wG/mu+i9DRFRgM8VG3JqdsVCRzWtxkWKYe9SN0qMnBqWwFHSpAcUxTxTxUkkq1KnWohUqdRVMomWug8PNjWrbnqSP0Nc+Dz0FbOiPs1a1b/poKiWxNj0qH7lWU61VhPyirCdq47iR0Ph8/wCmOPVP611cXauP0NtupKPVSK66I9K56u5LVzq/Czf6bIvrH/UV16/drifDMmNWUZ6ow/r/AErtlPFcNXclkij9K6Lwg+3xbAP7yOv/AI7n+lc6prY8PS+T4osXP/PULn68f1rkrK8WS1oer0UUV5ZgFB5FFFAH5WftM/Dq++Gn7ROqLaQvb6ZqszatpU6ghQGfc6g+schIx6FT3r9GPg78Q9P+KHwe0fxdZTI008KxXsIPMFyoAljI7YbkeoIPem/Fj4S+Fvi94Ffw54lhZGRjLZ30AAms5cYDoT27FTww4PYj4mt/BP7SH7LXjO71Pwvp8uuaDK2Z5bK3e6s7tF+6ZoVPmQuAfvdum5hXqOccXSjBu049+prfnSXU/RagnFfEUH/BQBraxEOrfCxhfqMOItW2Ju+jxbh9Oa4bxP8AtA/tBfHWCTw54G8K6hpmmXAKSw6BbyySyoeCJLpgAq+uNnuawjl9Vv3rJd20L2b6nZ/tfftH2t7YXfwj8B36TrIfK13UbdsrgHm1jYdST/rCOMfJ3bHm37Lv7Pl18UvFEXizxRYuvgzT5ssJAQNTmU/6lfWMH77f8BHJOPQvhD+w/fT3lvrXxeuI7a1QhxoFhKGeX2mmXhV9VTJP94V9s2GnaX4e0KDTtNtbaw06zhEcUEKCOKCNRwABwqgV0VMVTw9P2GHd292U5KKtEuxRJDEscaqqKAqqowAB2A9K/NT9tXwpdaJ+05d61NC32LX7KG6hkA+VmjQQyLn1GxCf98V95N8a/hImurozfEnwqL4ts8n+04id3TGc4zntmqXxj+EPhr41fDw6BrLm2uIm8/T9ShUNJaSkY3D+8hHDL0YehAI5cHWeHqqc1oRB8ruzlf2XPixpHxD+Buk6X9ri/wCEg0K0jsdQtC2HxGoRJgOpR1A57Nkdq9d8TeINP8LeD9T8SarKI7LTrWS7nbOPkRSxA9zjA9zX5jeKfg38b/gR4tXXLSz1SJbVibfxD4fLyRFf9oqNyZHVJBj61N4v/an+KXjn4SX3w+8STaVc292Y1uL+G28m5dUcMUYKdmGKjPyj9a7JZaqs+ehJOLfzRfs7u6PPNQvfEXxb+M8t04aTW/E+qgIo52PM4VF+iKVH0Wv0h+I3wn8Xa38GdD+Enw/1/TPDnh1bdLDVr6VHe5NqiqojhRcKd+GLksOOOhNfnB8NvHR+G3xP0zxrFpNjqlzpxeS3tr2Ro4/MZCgcleTt3EgeuK+jfDv7Sv7Rfxf8e6T4Y8L2djoVrfXUcE99pekvMLaIsN8jSy71XCbjnA5xXXmNGo3HksoxLnF30O8/aIbw7+z3+yPZ/CzwMJLa48QSNaPOzfv5osBrmeRhjLONseegD4GABXi37GngGPxR8ej4q1CNP7L8LwfbWZ+E+0NlYQT0G3EkntsBrK/a58cN4w/aX1LToLhpdP8ADsS6RBuOcuvzTN9TIdpP+xWt4T1HXLP4DaP8C/hrD5/jXx/MdQ1uePI+xWTALHE7D7uYV3uf4Uc93FTGEqeEt9qe78v+GBK0fU9Ht9csPjr+1rqnxS1dmf4a/DeAy2z7Cy3UiEsm1f4mkkHmY6lUiH8VcbqPw2/ah/aN8SXGr65DqWieHrqdpba2165a0tbaIklES2UbnIXAyU5Iznmvr3wpofgT9m39n2O11DUYbPS9Nj+0ahqMq4e6uGxufaOSzNhVQZOAqjpXzD43/by8SXV5d2vw+8JWOn2hBSC+1dmmuD6P5SkID6KS1clCVWpJ+wjdLRN9P+CRG7+E9H+H37C/gDQ1iu/Her3vie6TBNrFmztAfTap3sPqwHtX0n4a8H+F/B2krpnhXQNN0a0UAeTY26wg47nAyx9zmvkj4ZftE/Gjw98Y/D3gv48aSILPxME+w3MtmlpNAZDtibCHaUL4VlYBlLA+x+oPil8QNN+GPwn1jxrqirIthAWhti4Q3Mx+WOIH1ZiBxnAye1cuJVdzUajvfbsTLmvZnZZ9q57xj4G8KfEDw3JoPjDQ7TVrBzu8q4TJRv7yMPmRv9pSDXzB8EP2vfFPxK+Num+CPEHhDSba31MSrDcadLKXgZI2k+cOSGXCEEjBGQa95+N/xTt/g/8AB6+8ZPZx3t0kkdtZ2cjlBPNI2ApYAkAAMxx2U1nPD1aVRQatInladj5o+JH7C1rbu978O/F4hjdvl0zXFLgeyzoM4/3lP1ridL+G37X3gtF0zw9q1zLZpwkcesW9zBj/AGVnPyj2AFe3/A39pW6+NnjG98L6v4Vi0q/t7NryGeznaaF0VlVlYMAVb5xg8g+1eQftN/G/4meB/wBoF9A8J67LpFhpNpb3AhjjQrdvIm9jLuB3r0ULwMA9zmvYoTr83salm13No82zL7fCL9qX4gWp0vx146g0XSZeJ4luI2aRe4MdsoDfRnAr3z4a/CvQfhf4LTw94fWSTc/nXV5PjzbqXGN7Y4AAGAo4A/Env/D1y2t+ENJ1maBYZL6ygumjHRGkjVyv4FsVF4o1/wAOeC/DE/iDxTq9rpOmwjL3Fw2Ax/uqOrseyqCTXLUxc5+7b7iXK7scr488VaX8PPh1qnjDVyPIsYtyRZ5nlPEcQ9SzYH0ye1fn98MvBms/G348x2l+XmS7uX1PWroDhId+6Q/Vidij1Yeldf8AFX4l+L/2lvirp/g/wJo16+kwSn+zdN+68zdGurg9EAGcZOEXPJYmvsr4I/BbTPhB8Pxpkbx3mtXhWbU9QVcCWQDhEzyI0yQo7kljyeOtVfqtJ3+N/gi7qCOrTTo4o1ihhWKNFCoi9FUDAA9gOKlWzx/DW4LUZ6U77L6DivMdW5lzGILL/Z4p4svatv7LzyBSi156UnUDmMYWQz0p4s+22toWo9MU4WvH3aXtGHMczq9v5WiTtjHAH5kVyLDFd34pUQ+HiMAF5FUfz/pXCN2NdNGV4lRd0RGqd+wTTp36YQ1cNZ2tMI9HnPcgD9a6IblHH3M2GODWTqE5FnMc/wAJqzcyEsaxtXl26ZLz1GK7YLYuxztzc5z81ZV1JvjZT3FSzyEk81SkbIJrrQzmfE3y6OR6yKP5159P/rM13vit8adGPWT+Qrgp/v5rso7ForHpUTHipTUTVoMjJqJuhqRhwajboaTEhwqRelRDpT06CkImFSrUSVIvBzVFE461oWMhS4jcH7rA5/Gs8Y7irVucyYqXsI9XgIIz61ZU81m6ZJ52nwSZ+9Gp/StJetcTINbSX2alAc4Bbb+fFdnEffpXA2zlJVYfwkGu7hbcAw781jVA3tDl8rVrd84+cKfx4rv06da8ytZCkqsOoOa9JhcSQo46MA351w1iGWRU8EphnjmU4KMHH4HP9KgXrUi8gjFc8tUI9pjcSxK6nhgGH408jNZHhm5+1+GLSRjllTy2+q8fyxWvXjNWdjnegVl6jr2m6VxdzjzMcRJ8zn8O341leJvEbWWbCwYC5I+eT/nmD6f7X8q4ErI8zO5LOxyWJySfeumjh+fWWiLjC+rOwuPHjM5W007js0z/ANB/jUI8b6jnLWdq3+6WBrmkizjirEcJyMiur2FNdC+VHRxa/od/OH1XRIBJ/wA9WhSX9SM11tnLay2qtaPG0OPl8vG0fgK86jtc9BxWppzXFjcCS3bGeCnZh7iuerRX2SXFdDt554raB5pnSONFLO7ttVQBkknsAK/M39o/9ozW/ir4nu/DnhrULiz8FW0hiiggYodTIOPOlxyVJ+5H0xgkEnj6y/a38ez+Gf2VtSXTZTBea5PHo6kNhkSTLTY/7Zo4/wCBV4D+xL8IbLxN4ovviZ4gsUns9FmW20yKRco13gM0uDwfLUrj0Zs9VFdOChClTliaivbZeZUEormZy/w7/Yw+KPjLQ4tV1mXTfCVnMoaKDUY2kuXU9CYVxsHsxB9q+7fg74M134e/B7SvB3iLX49cutODwx3kcbIDDvJjTDEn5VIXr0ArvcDFeZfHm1+IGo/BXUNE+GcLtr+qSxWCTpKIjawyOBLLv/h2pu+YcjPHOK5q+LqYlqM3oRKbloyTxF8ffg14V1iXSde+Iug2l9EdssC3HmvG391ggO0+xr8+f2o/H+h/EH9oK6vvC9xZ3WiWNpDaWt1aIFS4OPMkkyAN3zOVyf7leqal+w9H4W+HGp+J/FXxRitjptlLe3EdlphaJQiFiA7yAtnGM4HXpXyVaQXF9eQWlvC8lxO6RRxjks7EKF+uSBXr5bh6EZOpTle33G1KMVqmfff7Evw30qP4IXnjDWdGtLq51jUHNtJc2yyFIIR5Y2lgcAuJDx14r6J8b+L/AA/8O/Ad9r2r39jp9taW8kkUc0iwiV1UlY0XjcxIAAAzzXxZpP7Hn7Q2lqtnpvxF0rSrXPIs9ZvUVc9fkRAPWs/4x/szJ8MvgXqfjzxp4+1LxP4iEtva2aZYQxPJKASWkZ3fCh8DKj2NcVWlTrVrupe76Ih2ctz5qt7fW/GfjSO2t4JL7WtavcLECN01xM+cZPHLN1PAr9Nf2ePgHpnwc8JPdXzxah4s1BF/tHUR8wQdRBETz5anGT1YjJ4AA+Kv2RfDya/+1n4fklj3xaXFcamwPYpGVT/x+RT+FffXxy+KFl8I/gvqniqZka+2fZtNgY8z3TgiMY9By5/2VNb5rVm5xw0PIdVu6ij4g/bB+Ltz46+L8vgrS7v/AIp7w3K0ASM/LcXgGJZD67OY19MOe9cpd/A3xTof7Mnh/wCNNvZzzvPfG5ntlQsLayGPImZQM7WdWLHoFdPc15x4Y0a68afEbSPD7TNJdazqMNq8xPJaaUBnPv8AMxr9jLHS7LS9EttJs4Eis7aFLaGED5VjVQqrj0wAK0xVb6lCFKn8ypPkSSPzg+OH7QXhj4reMvht4o03Tb6zk0Ii41OF1XKv58MhSJ84cYjbBOOozis79ov4kfEv4lJoviHxRosvhrwpdTTNoWjzMVkmCgbrlwQC5+dVDkBRkhMjcT6x8PtK8PfFn/gopquveHtD0238KeE1Z1+yWyRQ3EqAxJIQqgMzytI4J7RivNf20fFL+Iv2n7nSkl32+g2UOnoAcjzGHnSH65kUf8BqsNyOtCnGOyvr0uEWrpJHS/sJ+Em1b406x4vmiJg0TTvJjfsJ7hto/JEf/vqtL9u/x+mo+OdB+HVlNuj0qI6jfKp48+UbY1PuIwzf9tBXqP7LFrpXwo/YvvfiJ4iKwRXzXGt3D/xGBB5cSj1LCPgeslfBnjDxZqXjbx9rHi/Wm/0zU7qS7lXORGCeEHsqhVHstFCP1jGSqvaIRXNNs+w/2EPB7R6H4p8eTRfNczR6VbOR/BGPNlx9WeMf8BrH/bF0HTfGH7RXgjwb4cson8V6jarbXM24hTHJLtgVwP7uJmJ6hfwr6A+BcWh/C79kfw5/bM8dqItLOsag/wDc80Gd2b0wrAfgBXhv7Ppv/ib+0j4q/aE1ywY26zvaaPDKcCMlQgx/1zh2r/vSN6VyxnOVedddL2/Im75nInj8F/t1aFZJoGl+J9MurG3QQw3S3Vox2KMLhpIg/QDqCahsf2Qfix8Qddi1n41fEzzNv/LKCZ76dR3VC4WOL/gIP0r62/4SabIP2OL/AL7NTxeJ48gTWbAeqNn+dYvEV1rGKT8kieaSMD4d/CLwN8K9BbTPBujR2hlx9ovJT5lzdEd5JDyfYDCjsBXaiAeg/Gm2uqafeYWKYB/7j8H9av7R/dH5VwynJu8tyG31KYhFL5K9wD+FWtv0o2/Sp5hXKwhFPEI7Cp9nrS496OYLkHkjHSl8upsUYFK4jh/Hc2I7K1BGSWkP8h/M1xJ4NdD4wu/tHiiVAQVgAiH16n+dc8a9PDq0EbRWhGxrC8SS7NMCdCz/AKCt09O9cr4pmzJFCMcKWIHqa6qe5aOTnbLGsLXHK6dtz95wK2peprm/ED/6qLPPLH+Vd1Jaos52Y81Wc/KankOarynC10oDj/FsvywR5/vN/IVxUvLmuo8VS7tS2A52RgH8ea5ZjzXVS0iWiFh3qFqmbrULdK1GRmo26VJTG+7UkoRakHSolqQU0BMvBxUqnmoQeakXrRsUTryKsQnEnXiqyHiplOGpdQPRvDk/maNGufuMV/r/AFreU5Fcd4UueZoCewcfy/wrr42+SuSorMktRHJ5rtdLl83TYXzk7dp/DiuIjODXT6BPuheE9VO4fjWNRaEnTQnDA13+hT+do8WTkplD+HT9MV55Gehrt/DYaK3eOQ4Z/n2+n/164qq0JOjHTOMk0u5s9h9BTAc08ZrnskBpafe31spjtbyaIA7tqOQPriugsfFGqW/yXG26XHG8Yb8x1rlrVxHdoxxtJwa6FbT2rnqQg90RJIzJI5J7h55SWkdizMe5NPS3z1Fai2fP3asJZ4HTFLnS0E5GVHakH7oq3Fa8jp+FaUdn0+WrcdrjHy1nKoTzFGG0PHFXorXH8NWo7bAHFXIrcdxWEpiufIX7diXEfws8IbciE6zKH9M/Zzt/9mr1z9kTTrfT/wBkLwrLAih737ReSkfxO1xIM/kqj8K5z9s/TtCvv2ZryPUNY0+x1KzuodQ0+C5nWN7l0O1441JyxKO/Qdq8L+Ef7YejfCn9n/RvBE3hK/1jVrB50V/tMdvB5bSs6fMdzE/NggL2rtUJ18KowWzLs5Q0P0Jor4Sk/bE+O3iAFvCHwkthE33GXT72+P8A30u1f0rPl/aI/bA3GQ/Dy4iT28KXJA/M1zrAVetvvRPs2exftweNR4e/Z7j8L20u278SXi2xA6/Z4sSy/gSI1/4FXyf+yl4MPjP9qLQRNCZLLR92sXORkfuseWD9ZWj/ACNcv8Xfir47+KPim1n8erBBe6VE9mtpBbNbCElsvuQkkOSADn+6BW58Cfj0/wADtR1e5tPCWn63camsUcks940EkcabjsXCtwS2TkdhXs08LUoYRwj8TNlFxhZbn6rjpXzV+3Ha3E/7LJmgVjHbazaSzEDopLpk/wDAnWuU0b9vzwbM6r4i8A69p/q9lcQ3QH4Eoa7G7/aW/Zr+Kfg2+8KeJvEZtLDUoTb3FprFpNbZU46SAFVYHBBDcEAivFhh61Copyg9DFRlF3sfJf7KPxL8I/C741X+u+NLySzsLjSJbRLlIXm2SeZG4BVAT8wQjp1xXo3jKDxh+1ndeKPHdnaXuneBvCem3X9h2sgw97dqm7kDguduWxnaNiDksa67wd+x58D9d14ajpXxTvPE+khvMWxsbu2LMP7ryx/Nj1wFPuK+u9B8P6N4Z8O2mg6Dp9vp2m2kYit7S3TYkajsB+pJ5JJJrrxWMpqr7WknzefQqU1e63PyG+GniSy8H/GTwp4sv1d7HTNUt7uZYxuby1YbiB3IUkgd8V9m/Hb9rTw7qPgw+DPgzqM+u69rSi0+22UEgFssny7Y9wDNOwO0AD5ckk5AFavjz9hnwN4m8WXOteGfEt/4XS6kM0thHbJc26uTk+WCVZASSduSBnjA4rvPhB+y98PfhHqC63a/adc8QhSq6rqQUtAD18mNRtjyOC3LY4zinicXhqrVV3cl06BKcXqWP2afg6Pg/wDB2LT9Qjj/AOEg1Nheao6HIR9uEhB7rGvHuxc96/Oj44XN3cftH+P5bkH7R/bt4uCOm2RlT9Atfr9gYxXzf8Xf2QfAnxK8c3PjVNf1Lw7f3WHv/ssccsVwygDzNr/dcgAEg4OM4zknHA4xUq0p1Ooqc0pXZ5Drfi2x+OWneAv2fPhndTxeEtPsbSfxJqvlNGFjhRAYwCAThs/70hXGQpNfK/xH0y30j4teLNHsbQW1raardW8FuvSONZWCKM/7OK/R74e/DDwf8MPDb6N4UtpiJnElzfXTB7i7YDAZ2AAAAJwoAC5Pcknzr4l/su+EviH44n8Vx61qGh390Q14ttCk0dwwAG/a2NrkAAkHBxnGc57sJXp05NfZNItI8+8c/Em4+NjaH8EvhE8ktjdQwPq2qPE0cccMar8hBAPlpgFj/EwVBnkn6c8J+FNI8E+CNN8LaFEUsrCIRqW+9I3VpG/2mYlj7msD4cfCzwp8LdBk07w1ZyebOQ11fXDB57lh03tgYUdlAAH15rrtR1PTtH0a61bVr6CxsLSMzXFzO21IkHUk/wCc9BzWVWab5YbCbvojzL4o/FSXwD8Tvh3oSGJrbX9Rktr+NlyywnZGkinsRLID7gEV6sQQSD1HBr4OvfE958ev21fDtzp0MyaVBfwpZRuuGis7d/OeRh2ZtrMfTco7V944JJbnk5p1qfs1FPcJKwdBmtfTtfuLMrFckzw9OfvL9D3rJwBS4z2FcsoKSsyGrnodvcQ3Vus0DhkboRUtcNpWoyafdDOTC331H8x7128ciyxrIhBVhkEdxXBUpuDsZtWHUUUVAgqK4nS2tZLiQ4SNS7H2AzUtcz411AWugfZUOJLltn/ARyf6D8acY8zSGlc8+uZ3uLmS4kPzSMXP1JzVY/hUhbmo2Oewr14q2huRMcDrXC6/cedqszA5AO0H6V2d3MILSSZuiKT+PavObqQvKWJ5PWumkhopyHg+9chrkwk1BxnhQFrq53CRs56KMk1wt1IZZ3c/xMWrupIsqt3NVZ87MDvVhjntWdqFwILSWYnGxS3444/Wt0ugHn+uzedqtw+erkfgOKxmq3dOXkOTz71SbvXYlZWNCJ+hqJuKlaoXqgGVG3Snk80xjzjtUkjV6VIOPSm7B2p2MVTg4haxIvapl6ZqBelSr0xS3HuToealHTPeoFODUwoBm/4fuvI1SEk4VjsP48fzxXoUB45ryq1kZZBg8jkV6Vpl0LmxinB+8Ofr3/WuasuojWXrWto9x5Oopk8P8p/z9ax0qzCxDAjg1i1cTPRLAg3Klui84rp7C98q7RyeAefpXHaXc+bbJOOrDn6962IZjkc1xTjqSz0eM5AqVelZGi3f2rTlycvGdrf0/StZTXJJWZLJF+72rtdDkW/0lH48yP8AduPp0P5VxQ4NbnhrUVsNYVJm/cT4Ryex7N/n1rnqp8pEkdctqOOKmW16cVpCEdMD8ad5QxXA5mVyilsCegqdLcD0/GrIjA6c04L3AqXILkSxYGcV8w/Hv9qC88L+KP8AhV/wmsjrXjSWQW808UX2hbORukSRj/Wz85x91P4snIHqv7Q3xFn+F/wB1rxLYSKmqOq2OnlhkLcSnar/APARuf8A4DXmH7IHwXsvDXgCH4oa/A1z4o8Qxm4huLn55LW1c5GCf45Pvu3UhgPXO9FRjB1aiuui7spbXZxfgn9jfxF441QeM/j74t1K51K5+d9Nt7jzJ8f3Zbg5C/7kQwP71ZV34IH7Jn7RSeMpNBGsfDDVSLeS7ktxcy6TuORuYgkMjdG/5aISM7gK+66r3tjaajZS2V/aw3NtKhSWCdBIkinqrKeCPY0/rtRtqWz6BzvqQ6Rqmna3o1tq2kXkN5YXUSzW9zA++OVGGQykdRiuX+LPj21+GXwc17xncsrPY2xNtEx/1tw3yxJ+LlfwzW94a8L6B4P8PponhnSbXS9Njd5I7S1TZGhdizbV6DJJOBxXwf8Atq/GBPFHjuD4Y6HdCTTdBl83UWjbKzXpGBH7iNSR/vMf7tThKDr1lBbfoEI8zsfNnh7RfEHxE+Jdjodk73mua5fbDM/O6WRizyt7DLOfYGv1h0v4R/D6w8BaX4UuvCeialY6faR2kf22xilZgigbiWUnJOSfcmvmj9iH4NNZWM/xg1612zXcbWmio45WHOJbgf75GxT/AHQx6NX2gRXXmeJ56ihB6RKqzu7I8O8R/sjfAjxErMPBo0eZv+W2j3MlsR/wEEp/47Xj3iX9gLTD5k3g34g3lux+5b6xarMP+/kZU/8Ajpr7S60tclPGVqfwyZCnJdT8xvE37IXxz8JzveaZoltrixnIudCvR5v1CPsfP0zXM2/xb/aG+Fl+thdeKvF+jPEcCz1yN5E+gW4UjH0Nfq8QD1AP1rifHXiTwzaaTqmjasNNnvo9Kn1KCw1GNXS5WNWztV+HwwG4DkZHrXXHM5T0qwUi1Uvuj4k8Oft0/FPTVSPxDoXhzXI+8ixvZyN+KFl/8dr1TQv2+vBVxtXxL4F17TT0L2M0V2o98Eo36VuaL8FPgD8U/BnhyfUfDGn6d4l1PR4tSuv+EflNm0WVXe7RodiKXbAyvPOOhrzLxX+xPozX0zeCvHt7FECdserWizA/8DjKnH/ATW0Vgqzs4uLKtB9D220/bJ+CGpQr5HiSWxmP8OqWU0AX6kKR+ta6fHH4c6/B5cXxK8LOjf8ALMX8cefwYg18W6r+yH8X9NZm0+LRNYQdDa3wicj/AHZQv864vUvgR8Y9MYi8+G+vOo/iggFwv5xlq6IYDDfZmUqcT9B5PH3gONQx8beG8Hv/AGpB/wDF1lX/AMZvhLpkRN98R/DcZH8Md6szH6CPca/O2T4ZfEFZfLb4eeJQ/p/ZE2f/AECtbS/gj8X9VkCWHw38RAH+Ka1Nuo+pk2itfqNJbz/IrkXc+rvF/wC178NtIt5E8L2mqeJLsD5SkP2S3z7vJ8xH0Svlv4hfGL4hfF7VoLDUZWFm8wFpoemI3lGQ8L8oy0snoWz7AV6V4T/Y3+IOrPHN4r1XSvD1seWSN/tlxj2VMID9Wr6c+GnwK8A/C1RdaFp73erlNj6tfkSXGO4TAAjB9FAz3Joc8PQ+DVheMdjjP2bvghP8NtAm8S+JoFXxPqUQjMGQ32CDOfKyOsjHBfHAwF7GveAKlCc9KXyznpXBUqucuaRm3d3IttKFHv8AjUwjJHQ0oj9qzchEG2pYri5hx5U8qY6bWIqQR+opRFntUuz3AvWuvXsJCz4nX34b866O0voL2DzIWyO4PBX6iuP8o+lWLeSW1uFmhIDD16EehrnnST1RLidjXlnifUv7R1+Qo2Yof3UfvjqfxOa7HxBriWvhzzoGxNcZjjHdT3P4f4V5qxwMfzp4aGvMwguoxjxio2OKeahduOa70tTQw/EdyI7JYFIy5yfcD/6/8q4iVvmJrY1u8+06hIwb5R8q+mBWFI3U11wjZFoydZuPKsGUdX+Uf1rkZTknBH4Vs65cmS78sEYjGPxrDfr0FdlNWQyJzjPIrmvEtx5elmPPMjY/Ac/4V0MxwhrhPE935l+Yg2RENv4962pq8ijm5my5NVmORUrnJqF67SiNzxUTn5qkaojSYDDzmo35zT24qNvSkSS0v8NJSiutFCrwcVIvXFR1IOa55x5XYSJl/wDrVKp4qAVKh57VDGWI22sDXa+FbzMb2jt0+df61xCmtbSbs2t7FMD908+471E43RJ6dE2VzVmNuM1Qt5FZFZTlSMg1cU4rkJOm0C7wzWzN1+ZR/OumjkIGc1wFnO0M6SIeVOa7S1nSWBJUPysM1hUj1A6vQr8W1+oYgJINp9vQ12qHIry+F9pFd5od/wDbNPUMw8yP5Wz39DXHVj1IZsr0x3qQdKiVumNv41IDXOxHpfhTVxqWkiGZ83MACvnqw7N/St8LXkemajNpepx3cJzt4ZezL3Br1WxvIL+wju7dt0bjI/wPvXmV6fI/IxlGzLG0elLRRWJJ8p/t9QXkn7N+lSwBjDHrsXnBf9qCZV/8eIH419DfD26sb34UeGrvTGRrKTSrVoCnTZ5K4qr8T/AOl/E74Wav4K1ZzHDfw4SdRlreVSGjlX3VgDjuMjvXyH8P/jX4z/Zfvx8KPjL4YvrjQ7eRv7M1OyG4rEST+6LYWaLJJCgh0yQR2HXCPtqKhHdPbuWtY2R92YFFeBn9sf4Cf2YLpfFF80hGfsw0q4836Y2Y/WvEvif+3NqOqRPoPwk8O3NnPOfLTVdSRXn5/wCeNuu4bvQsT/u1MMHWm7KP3goM9g/ad/aHsvhV4Sl8OeHLqKXxpqERECAhv7Pjbj7RIPX+4p6nnoDXx7+zt8CdW+NnxBbUNYF0nhWxn83VL9mO+7cncYEfvI+cu38IJPUiu7+FX7J/xA+J/iL/AITH4sz6lo2m3Uv2mf7Y5OpaiT14bJiB/vN83ovQj758M+GNC8H+F7Tw74b0y307TLRPLgtoFwqjufUknkk8k8muyVeGEpulRd5Pd/5FOSirIvafYWml6Zb6fYW8VvaW8awwwRKFSNFGFVQOgAAAqzRRXlGQUUUUAFeOftKQ/D5Pghfaj49skm+zhk0uVEJmjvHUiPyyuCMkfNzjaDmvY68i/aTl8Cx/s/6oPH0Ly2jMq2McWfNN5g+TsI6EHJJPG3dnitaP8SPr0Kjujj/2dP8AhE4v2fbC78M2kceq3f7nWrnB8x54+xJ/hwylQOME9ya9N8s+g/KvNv2dx4ak+AWk/wDCORlGUldRViS/2zA8wnPY/KV7bcV6p5PtXdUSjOXqavcqiOlEXPAq15Z7LThET2qOcm5V2N/eYfiaPKyckCrggPpTxB7Uc7DmRTEXHSnLF7VcEP8As0oh9qlyFzFPyx6U4Q1cEIx0NPEP+zz7UuYOYpCLPQH8ad5RParghPpThAewpcwcxT8k+lKIeOlXhCfQ0ogpcwrlIQ+uaGjVVLMQABkk1fEI9K5nxNqYjB02Ajcf9cfT/Z/xpxbk7IauzD1S9N7fFwSIl4QH09fxqgeuaCQeKaTkYrsirKxoNNZGt3otdOYK2JJAVXH6mtR2CgsSAB3NcJreoG7vXZSdi/Ko9vX8a2pq7GZVw+WPNZd7cLb27yk8KP17VbkbAJrmtcu8uLZG4Xlj7+ldsI6lJWMS4lLyFmOSTmqjHmpZD1qvI2BXSUmUb64SC3kmY/Kg3GvNb+dpp2djkk5Ndb4nvQsC2qtyx3N9B0FcRK2XzmumjGyuUlYhJyahbrUjHnI/OojW4xjdKhPSpHPNMbgGkxMjb1qNqe1RmkInoPFFFdRQ6nr0zUY6Yp6GraT3AkVh0qVT0qAdalRsqDXPOHKOxYU96swvtcVUU8VMp9KyJO/8N3/nWXkM3zRdM/3f88V0iNla800i/a0vY5gflBww9RXodtMkkaupyrDIIrlqRs7ks0EbBrodCvME2rtgE5T+ormlParMEzJIHQ4YHINYyV0I9CjatjSdQazvFlB+XowHcVzOn3gurZZAQG6MPQ1pRPg1zSj0JPUYZUlhWRGBVhkGplPGD+Fcn4d1XawtJSNrfcJ7H0/GupDfnXFONmSTK1dD4Z146VdmC4ObSU/N/sH+8P61zdPU+tYVIKSsxNXPa0dZEDowZSMgg5BFOrz/AML+JfsRXT7+QfZicRyE/wCrPofb+Vd+rBhkdPWvNnBwdmYtWFrL13w7oXiXSn0zxDo9hqtk/wB62vrdZoz77WBGfetSio80I8hm/Zd+Ac90bh/hlpCuTkiNpY1/75VwP0rsfC3wx+H/AIJAbwn4O0TSJAMedaWiJIR/v43frXW0mfardSbVnJjuxaKKKgQUUUE4oAKKKpXV0UzHFjf3PpTSuBYkniiGZHVfqa8d/aQ8OaH4y+AuopqOpPp50x11C3uPLLqZVyioVHJD7yvHQkHtXpLRs7b3yWPUmvHPj/8AE/QPB3gG78MytbXmtatAYo7KQBxFETzM6noOPlz1bnoDXTh6cvaR5Ny4LUh/Zq8NWWi/A+G6t737VcalcvPdYGBDIuE8rnqVAGT3zXsAhryP9m7xtpXiL4aReGozBDqOk5VokAUzRk5EuO55wx9QD3r2sQn0rXEOUaklLe5U9ykITngYpwh7mrwg9acIeKw5yCkITnkUvk+1XRDTvKHbNLmApCD2pwhHpV0RjP3cU4IO2PypcwFIQ47U8Qn0q35dL5ftilzAVBD7U4Q+uPwq0E9sUoj9KXMBWEIPalEQ9D+FWdlZetazb6PZ73w87jEcWeWPqfb3oTvohFPX9Xj0iz2x4a6kH7teu0f3j/nk155JIzuXdizMcknkk1Ld3c95dPdXLl5HOSf6fSqpPNd9GnyrzNYxsKeBUbHA5pSao6hfJZWjSuQT0Vf7xroSuUZniDUvJgNqhw7D5vZfT8a4yeTJNWb26eeZpHYs7ck1myNxXXCFkWirfXKW1s8r44HA9T6VxdzM0krOxyxOTWlrF9585jRvkQ9u59axnbJ611wjZDGMcVSu5kijZ3YBVGSasSNhSc1ynibUNkP2RGwXGX+nYVqo3dikjmtVvGubuSYn7x4HoO1ZLGppHLOarsea7IqyKGMcCoWqQmonb9KYEZPJqNqcTUZNIkaaiY041Gx4x2pMRaBp1N6U4c11lgOD7d6eOtMNAGRz171SYE3bNKpw1NXkUtEldWGWFPNTqTVZDkVKp4rjJuW4nKvXaeGtSDx/Y5G5UbkPt3FcMp561W1i7uoNGeG0SVpZv3WYwcqCOentxUTjzKwj2uNsqMVOp/CuY8I6ldX/AIXtZr+No7pB5UofqSvAb8Rg/nXRowwDXK1Z2FY2NMv2tbkMT8h4YetdjDKroGU5BGQa89jbB61v6NqXlMLeVhsP3W9D6VjOF9RHYRSlWBFdroeqi7gEMzfvkHU/xCuAjk6AkVetbqSGZZI2KspyCK5ZwuiWj01T0p2f/wBVZOlarHfwYJAmUfMo/mPatIMa5JKxJMpwQK6vw54oaxKWWoMWtuiSdTH/AIj+VcmMeo/Ong4rGpBTVmJq57SjrJGHRgysMhlOQRTq8w0PxHdaQwhcGa1J+aI9V91Pb6dK9EsNRtNStBcWkodOhHdT6EdjXn1Kbg9TFqxbowKKKzEFFFFABQRmiigCOQlUJHXtVMQ7jk1Yup4ba1e4uJY4oYkLySSMFVFAySSeAAO5r5o8Z/tkfDbSdeu9D0nTNa162RTG+pabKkMbMeD5TMwY4/vjA9PWtqFKpVdqauVFN7Gz8dP2itE+GFtP4f0BoNT8VsuPKPzRWGejS46t6R9ehOB1+AvEPibV/EPiG71zWNQnvb+6kMk1xM2Wdv6AdABwBwK9tvPHn7L9/NJcXHwb8VSTSMXd21lizMepJM2ST61RPiz9lqT5f+FLeKvqNYP/AMdr6DBxWHjrTbfc3grdDzbwP8Q9X8FeJ7bWNMvJLe4hYMHU/oR3B7jvX6I/B740eHvipoSLHNFa63En7+xLY3Y6tH6r7dRXx2mufsuyMMfBfxb/AODk/wDx2tzRvGf7POg38V/ovwn8a2VzEQ0csGtsrKfUHzazxsPbq6ptMclzLY++9n0pQn+RXhPgL9p7wd4l1m30W/0rWtE3qEjvdTaN42boA7oSVJ/vEY9SK94QiRA6sCpGQQcgivCqQnTdpqxzyTW4mwelLs9qk2e9LtFZ3JItopcCpMD0pcUXAixSgZ7VJRSAZtOOlG33FPrktf8AF0VoGtdMKy3HQy9VT6ep/SqjFydkNK5o654gttGg28S3TDKQg/q3oP515te3txfXb3V1IZJG6k9vYDsPao55pJpnmmdpJGOWZjkk1ESc130aKh6msY2AkdSOaYfSnE1XmmSOMyOwVRySa6UUNuJ44IWkkYBVGSa4bV9Te9uS5JCjhR6Cp9Z1dryUxoxEY6D196wZJM1004WKSGyPnrWHq+oeVGYY2/eN1I7CreoXyWsJLMC54VfU1yNzO0kjO5yxOSa6oRuPcilfk1WZgOtPZqq3EpWNiOuOK3GtCrqF5Ha2zzOeFHT1PpXnOoXb3FzJK7ZZjk113jyJ7CeyhE8bRzW4mKKwJVs4OQOmcZH1rhJGy1dFKNtS9iNzxxULHjins3PSoW61uMaxqJmzxTmPvUdDAaTUTHAqQ/eqJjzx2qSSNj6VGx4pxIpjHmkBdHIxQp7U0Gl6HNdaKH0Dg/WgHIzRTAkB5p1RA5FPB55qwWhKp5xUqmq9PEhHSuedN30CxbU5qHULp7SzFyNojRwZCTyF9vfOKaJiOuKwPEOomeNLaOMiMNuMhPUjsKiUGtxNHpGhav8AZZklDBonA3Adx2Ir0CCdJEV0YMrDII715P4a0mefwks9ncJdG3UmSJRh1XrkDuBXUeH9aELrbTv+7Y/Kx/hP+FctSKeqJsdyrY/oKsRvznNUI5Qw61YDYrENzrNJ1Peot52+YcKx7+1bySdK8/jkIwQcV0ul6p5oEMzfvOgY/wAX/wBesJw6ok6q0u5beZZY3KuvQiu10rVYr+HbwswGSvr7ivO45PcVet7l4ZA6OVI6EHpXNOCkTY9LVqkVh071z+la7HdKIbhgk3QHoG/wNbQb3rmcGhFgNVqy1C6sLkXFpM0bj06H2I7iqIOOtP3d+lZOKejA9G0XxhaXoWC+C2054DH7jfQ9vxrplYMMjGK8UDduRWtpniLU9LwkUokgHWKX5l/D0rknhusTNw7Hq1Fc7pni/TL0Kk7G1lPaQ/Kfo3+NdAjq6BlIIPIIOQa5XFrRkNWHVl+IPEOj+FvDt1ruv6hb6fptohknuZ22qi/1J6ADkngZNN8SeI9G8JeFr7xH4h1CGw0yxiM1zczHCxqP5noABySQBya/MX49/tD638ZvFnkWpm0/wnZSk2Gmk4aQjjz5sdZCOg6IDgc5J7MDgZ4udo7dWVCDkzr/AI9/tK6v8Ubufw94ea40vwgjYELHbNqGDw02Oi+kfTu2TwPCBLk8mspbjOOakFxg9c19phsJToQ5YI6kklZGujrnqK0bYxkjIFc6lweuavQXPI5rdwGdhYtDxlFrqtNa3JGUH4155Z3uCOa6TT7/AAw+bisZRGj1bQzZrMjmJD+HWvpn4X+MRb6bDprztLaAYWNzkxf7p9Pb8q+QtJ1LDL8+K9K8MeImtJo5I5MYIyPavNxmFjVjqiZQTVj7ahljniEsTBlYZBHepK8y8CeMo7y0SN5NwPBGa9KikSWMOhBUjIIr5WtQlSlZnJKDiPooqjfavp2mrm8uY4z/AHM5Y/QDmsUr7E2L1UdR1ex0uDzbyZU44Qcs30Fcfqnja4lDRaXF5C9PNk5b8B0H61ys08s8zSzyvLI3VnOSfxrop4dy1kWodzd1nxTe6kGggzbWx42qfmf6n+grns56UhJxzTSa7Y04xVkaJWFJPemZ9qGPc1TvL2G0gMkzhfQd2+laqLYyaeeOGIySMFQdSa47WdZa7by4yVhHQev1/wAKg1TWJr2Q5O2MH5VHQf8A16x5JM55rphTsUohJITk1nXt5HbwmSRuOwHei7vI7eEySNgDt3NcnfXsl1OXZsAfdUdq6YxuUNvLx7mcyOfoPQVQd+9Ods8ZquzY6nFbpWGgdwAea5zXtXW2i+zo37x/vFTyo9vc1b1bU0srYtkGQ/cX1/8ArV5rfa5HcaqYhIXk3fPJngH0rSMb6sZ0ni+XT31SCSzinjmeBTc+Z90tjClPbaB+Ncwzcelem23gTU/HOgwXehXUEt5bw7RZSfK0oznCt0z6A/nXmdzFNbXD29xE8U0bFHjcYZWBwQR2IIrelJNWQ0QM3vURPPNKzEmoycZrUYjGo2PNKSKjPB4pEjWNRMacx5qMnFJgMJqNjSsfSo2JqRMvjrmng5HNNPTNAz611ljxx16U6m8HtSincBehzSikoBPfmqQEoPalAzTBT80xogu5NsO0Hlv5d6zJEWWMo65BrWnVGt2LKCQMg1EIYi9sPLxuB3e9Q3cGVdB1268NauhEpVAcq3t7+1dk1xDPL9rtSphnzIoXoPUfnXE6lbQtpFxL5Y8yOTCtnkDI4/Wuks4ILW2WKCNY1xnA7n1rmlFc1yLWO80DWtyraXL89Ecn9D/SupjcMB615RDMUYDPFdjoeuiQLbXTjd0Rz39j71z1KdtUB1qPirUchGKz45AQMmp1Yg1iI6nTdX3YiuGAPRX9frW9HMCOTXn6SgfWtjT9WaDEcpLR/qtYygI7OOYr3roNL8QPCFhuSXToG7j/ABrkLe4SWMOjBlPcGriSdMVhKKe4j0yC4iniEkLhlPcVPuPrXndlqU9pKHhkI9QehrqbDX7e4ASfEL+uflP+Fc0qbRNjeDZ+tAOfUVCrg4IINSKffismIlzjir9jquoaew+xXciDP+rzlT+B4rNB9a4v4t+LH8EfBPxF4hgkC3UNqYrUg/8ALeQiOM/gW3f8BoVJTko23C1z5p/an+Peq/EnxW3gnTrpU8NaNOVcQEhb66U4aVvVUOVQdOrdxj52ViDnoRTee7Fj3JOST60vOa+rw2HhQgoQVjZJRWhYR/eniQ1Ap4p46Y7+ldQ7llJOOtWY58d6zg2O+akWUD+IUmM2oboqw5rbsr45X5q5COYD+I1ftrvaRzWcogelabqeNvzc12uk6vgr+8rxuy1Haw+aun07V9pHz1zziK59G+D/ABbJp99E6ynbnkZr6R0LxireHPtcUX2gYHybsbT/AIV8K6VrmCp3+nevb/hz43EUi2dxKfLkG0gnrXk4zCxmtSZxTPb77xZrF6CqzC2Q/wAMAwfz61hO5dy7NuJ6knJNN3o4DIwZT0IpCcda8qNJQ0RhZdALH2ppNJnJpjEVdih5YetMLelVLzUbazTM8gB7KOSfwrmNR1+e4BSE+Uh9Dyfqf8K0jTbA2tS12C0DJERJKPyX61yN5qE1zKXlkLN/L6VVklJPU/nVZ5Rjg10xgkXYkeTuazr2+itYt0jAk9F9aq3+rpACkZDSfoK5q5uXmlLyPlj3raMe4yS9vpLmUvI30HYVQd8nrQzZNQs+B1rdKwwZgOW6Vl6lqUVjbNLIQT/CvdjS6jqMNnbmSRv91e7GuC1HUZry4aWRsnsOyj0FawjcozvFPiForaWaWbE8qlYQB39vTGa4TT7uOGUGSQD1JNdnd21texeVdQpKucgMOn0rkksbN9GtJjAN73YiZsnJXcRj8q35dLAz2L4afESw0LUIRJqMCDIHzSAVa+Mb6ZqnjOPxRostvJbalCpmMDqwE68NkDoSNp9+a8audOsFu9XC2ygQwq0YBPykg9PyrQ0iGKLR4GjjVWkQM5H8R9TURppS5kJF0nmomPNOZveoie3et2MRjUZOKUmoy1IQxjzUbU5iKiNSAhNRscinE4FRnrUkmkr8UbqiBpwNdRdiYN7UA4pgPrTw3GMU7jJAMjPegjFMDYp+8ehp3EhQafUW70BzTt2OpquZDFlP+jyf7ppin57Tj+E/ypl1GZIwVbG3kjPWs4sfWpbBss3wzot6AOkhP6iuhQnYuR2FcfPlrd1B5YYz71s6LYXWnxSpczBy7AhVJIWspi3NpWxU8UpQ9aphqlDe/FZtXEdpo3iDaFt7x/lHCyHt7H/GusjmDKCCCD0IryWOUqRzxXQaRr72eIpSXh9M8j6f4VhOn1Qmegq2KlSUgjmsu1vYriISQyBlPcVcVwcYrFoLmxZ38ts4aJz7qehro7LVYbkBSQj/AN09/pXEK+KsRz4PWsnBMnl1PQUl561YSYr3rjLPWpocLJ+8Uep5Fb9rqEFyv7qQE/3T1rKUGhHUWOs3VoQscpKf3G5FVvGvxTs/CWjabdSxAzXd/FAVJyPKBzKw9wvA92FZiyD1rxv4+6tcW9roVudKgmtjO0n22QnKuODCADwGXBJ9h0pQoxnJJhY+uIriKZA8Uiuh5DDkEV4D+17qb2/wa0nTkbAvdXTePURxO+PzK/lXXaHq+of2FZzzQGwuHgRpLZH3CFto+TPcCvKf2n7q81X4baJPKVZLTUzuYDGN8TAZ/FaWHpWrRuNRPlil7UlFfRo0ZIMg5/Knj2IFRKc81JnPPamCVg2jGS5ApQI/7/6UlMYU7jJlMXbrUqSBfumqgpwOKQGtDcsCPmH4Vr2d+ykDdXLJLtPWrsNxgdee9ZyiQz0DT9VKsvzV2+h+IzazI6yYIrxq3vSpHzVt2urMmPn5rmqU76CPt/4b+Iv+Eg8MTMzlmt5ghJ91B/xrrmdRnJCj1NeC/AvWri18B6jctHvFxebY2Y8YRAD9eW/Su21bXtSl0+doVM8ixs0duG2iRsHCk+54rw6lH94ybGj4W+IGn+IbHUp2dVNveyRRooyWi/gb8QDzUt94kmkylsPKX1zk14f8KNYubm41eD+y44YTJ5jyo3+rckgRf7oG7HpivSmkyMk1UqSiwaLEt08jlmYsT1JNVnk96ryzqilmYBR1JrGu9cjTctv8zY+8elaKI7GvcXUcMZeSRVFc7f6zJLlIMonc9z/hWZcXcszlpZCxqqz571tGFhkkkue9Vy5PNIze9QvLjPIrUBXkA71k6nq0NlESzBpD91B3/wDrVT1XXY7YNFAweXuey/4muOurx5pWd3LMeSTWkIX1ZoS6hqEt3OZJXyT+n0rOY7j1prPnknmo2bPeulKxIEk/QVy0Jz4dsSP+f4f+hmtTW7C41C2iS2nEZVslSSA35VxEivHM8Zb7jFeDxkd6AOsuR/puuf8AXuh/8dNWdNP/ABJLT08oVxG5s/ePPXnrXUaHaz29oZZZQUlVSiAk496QkapNRE5zmlY+h4qMkVQwJP41Ex45pxNRM1IBrH/61Rk0pJpjHjiobJEY1GacaYT3pAXqcDTcilHIxW5oPBNPBqIcfSlB/KqTAlzjrS55pm71pwPrQA/NO5HemUA4ouA6Uj7O5/2T/KsfdnrWpOf9FkIP8JrIOO5IpXER3MmyEdiWA/WuuzkkiuPniabaVcAg55HFdYr8VLbYiYN3zxUgNVweakDUD3LCnJHNLa3MdxCJoX3IcjP0OP6VWc5hfIYgqQQn3vw96o+GQBomFSVB5jYEn17f565pBsddp+qT2cweF9p7qeh+ors9N1y3vQFLCKX+4T1+hrzgNzxwaninZCDkjHespU0xHqyyg9+alD5rhtO8RTRAR3X71OzfxD/GuotL+C6jDwShh3HQj6iueUbbiNVHI7mrMc5UgqcH1HWs9JAe4pxkCDc33Ryamwiv4n+K9l4KgSO7Bv72Rd0dojbWx2Zm/hX9T2FfPfjLxtrPjfxH/a2qsiBF8uC2iJ8uFfRQe56k9T+QrJ1rU7jWfEN5ql05eWeUuc9h0AHsBgfhVIAiuylRjHXqUon0X8EviQtxp8fhfV7w+ZENts0xzhf7ufT0z0r0/wAc+HU8X/D/AFHQGISWdN0Dt0SZTuQ/TIx9Ca+KYJpra4Se3laORDlXU4INfQHwn+K+ravcv4f1uNbl4oDLFcA4YgEAg/nXNWoOMueBNjwO5trizvZbS7iaG4hcxyRMMFGBwQfxqKvqDxZ8NvB3jXXf7Yurq90y8dQszWwTExHRmDAjcBxnuMelZS/s++D3GU8R6uw9R5P/AMTXXDFRtqirnzoODUg44r6J/wCGePCp66/rP5Rf/E1IP2d/CuP+Q/rP5Rf/ABNV9agPmPnQHFOr6K/4Z58Kg/8AIe1n/wAhf/E04fs9eFP+g9rP/kL/AOJo+tQFzHzdjB6UtfSB/Z68KH/mO61+Plf/ABNNP7PHhXP/ACHdZ/KL/wCJo+twDmPnGno5U4FfRX/DPHhbH/Id1n8ov/iaP+GevCv/AEHtZ/KL/wCJo+twDmPn1JiDk9K09OS81LUrfT7GJprm4kEUUa9WYnAH+e1e3H9n3wmoJOvaz9T5X/xNbnhH4f8AhXwNq0uo2l3cXt26eWkt1tJhU9doUDk9z1xx61lPExtoI63RLbT/AAP8Prezu7uKC20+Dfc3Mh2ru6u+fdif0rxXxz8crrW0uNF8LRPaWMmY3v5MiaVe+wfwA9Ofmx6U/wDaA8S3EtvpXh+2kdbWUPdzc48wq21AfYcn649K8RjmZDxj8ayoYdSXPLcEj1XwD4lu9D1lLi2n2hhskQjKuvoRXv414XWlJeWygow+Yg52n0xXx3a6xcQONpArv/C3xCvLOVYpZd0LDDKx4Ip1qF9QPbbm+mnYmSQn27flVNpD61Ckyy26Sp911DD6EZphcCudIRIze9RPIAOTzUMk4Ck5xisHUPEMEIKWxErf3h90f41SV9hpXNe5vIoIjJNIEX1NcrquvyTBorclIu57t/hWRfajNdSl5ZC5PbsPp6VQeQt1NbxppblJExeSeURxjLHoBVRzg46Ee3SrNlOYdTgkUgYcZJGah1CUy6lcSM8blpGJaIYQ5Ocj2rSL1sMrs3FRsfWkY+9Rk+9WSO3fMOe9ed3Bzdyn/bb+Zr0AnvXnsn+uf3Yn9aTAbXZae3/Emtf+uYrjeh5rrdMbOj2/qEA/WpQFtjURoJyaaT2qgGswxURNKTk0wnPSoJEY1GTSsc9aYTikAE+lMY8f55pScfWo2PPXipAvAmn7sjiolOPWnBvSui5RICadn1pm7NAODgdKLj2JQfenZz1qIEinZHrT5guTKecUuSelRA0u4+9AwuSRaS8/wmsgnNad23+gyc9qyNx9aAHluK6ZD8oPfArlCTjnJrpozmJfoKIsSLAbjk08GoAccipA3vUJiKOr6stkn2eNRJM6+uAoPetjwlpNtc+GXNlfNJdLmRreQAZGOdp9eM+9ctqdjNLqVxMZUIEYk5GMLnGPrVnT11DRtRE1tcKGSRY8AnB3DP5VL8gZ0obIp6tyKrh2PzMACeoHSpEbkVQznNAuJz4uvFaZyoD4VmJH3xXbW17LDIHjkZHHdTiuB0eeC28VXj3EyRKfMG5zjnfXWQ3MNxF5kEqSpnAZTkVDQHZ2XiZ1CrdLuH99ev4ityPUre5tXMEof5Dx3HHpXm6yFelTLdOikqxU4PI47VDpLoJo8oFKOa3LDSbafwZe6hIP9JRi0bbuAF6gj3yfyFdD4J8L+HdQ0v7br0kztKxEUaOUVQDjJI5JJz7Ct3OyA4PFdn8MSR4tvSDg/wBmXH8hSXfg62tvidY6JDcmfT7thLG+4FvL53KSO42kZ9xW1pOk2+hfFjU7Kz3C3OmTSxq3VAyj5eeuDSc00B5ok83lr++l6D+M07zpv+e0v4OaiX/Vr9BS1egD/Pm/57zf99t/jQbi4H/LxN/38b/GmUcU0kFiTz7j/n4m/wC/jf40G4uT0uJv+/jf41HRRZAP+0XPe4m/7+H/ABpftFz/AM/E3/fxv8aj/KilZAS/abn/AJ+Jf+/jf40n2i47XEv/AH2f8ajop2QD/tFx/wA/E3/fZ/xpySztMn7+X7w/jPr9aip0ZxMn+8P50nYD0v40sW8Q6RntaP8A+h15p+FevePNOi1r4oeG9NuCRDLC3mYPJUMWI/EDH41y1z4Otp/i/J4ct5Ggsz/pBI5aOPYGKjPfnAz7VlTnyqwjihkCporp4TuA6CvR/Gngbw5p/h+S80WWSC6t13NE0xkEqjr16EdfT2rk59IsR8OI9Sjjb7Z5heSTdwULbdoHtwc1ftFJDPd9KulPhuwkZgB9miJJ7fIKpXviG1hysJ85x6cAfj/hXFwalcTaNZpLMzKkEagduFHaoHnJOBXMqWuoJGpf6zdXZxJLhOyLwK4LXZ5T41sQssiqfLyqsQD857Vvz3MNtCZrmZIowcbmOOa5XU7m3uvFtlLbzJKgMYJU5Gdx4rSw2dczUzdn3prHmoZi5gdYn2OVIV8ZwexxVjM59ahk1uOxiYKqv802e47AfWu51nwfc2PhWDxLa30d7ZSsFmwu14WPTI7qfWvKE0m6a82LNGH84xbueSBuzXZ+HfF2p23hy78P37fabe+ti0Y6bCG4PT1FZu6d0QV2Y++O1RsaHYVGTx1rUYFuCa4JsljXcyN8hPsa4bNSxXEwa6jTGJ0eAHsCP1Nczmui0xv+JTEM9M/zNINy4WGeDUTH1pScUwnnrQIQnHFMJ9KCwAzUZbJ4qNwAmmFvanojyH5RgdyelTi3jH3vnPvWkablsUo3KJPvzTGPvWqFVRwoH0FLgdhWn1d9x8hVyT04pd2aiDDsaXdipuIn3ADuacDleKhDDGacG9KYE2SO9KDnvUW6lzkZHSgCYHNPDDFQg04OR2H5UBciu54vs8kYkXdxx+NZWQBgGrd3bRxxPMrHr93tyao596AHbuMYrobe5hlRESVGYKMqDyOK5vJxWzY2cMQjudzFymcHoMigEzUDdOtPBqDPPpTgcVIFC/uoBdXCGdM/ZtmM87t2cfWkmvrVp2IuIsG5iYYPUAcms/Woo49QVo1wZF3tz1OcVVs40l1CCKXJVnAIBxQB3EcqSIHRgynkEd6kB5HPFVIESCBIo12oowBUwbkZoGcLef8AISuD281v5mtzwrdlZprJjw37xB7jgj+X5Vh3Zzfz/wDXRv506xuTZ6jDcj+BgTj07/pQI9DU+9OZvkP0rE/4SPTAf9bJ/wB+zQ3iPSyhHmS9P+eZpMZW0tj/AMIHd84yJf5Ctfw7Ky+GrUKTjDf+hGuVtNXgt/Dc2nMjmSTfhhjAzVvS/EVrY6TDayQzMyAglcYPJPr7012EbF5cuvj3SZUYqyIxBBxj71WhqlwPiNcXTMJHbTWjy4zxjFcxc67bza/aX6xTKkCkMpxk5z0/Oj+3YP8AhIZNQ8qby2tzCF4yD607DMRfugegr0PSfA3hu/0a0urjXL6CaaFZHXyl2qSMkA46V550AFekaTMw0KzGeBCn8qU2+gF6P4XeG5ceX4kuj/wGOrC/CLRW+7rl8fpHHWVqGuW2nRhrmQ5b7qKMs3/1ves4eObVT8tvdj8R/jUWk+pLZ1A+D+jj/mN3/wD36Sj/AIVBo/8A0G7/AP79pXNr8QUX7qXw/wCBj/GpB8RiOB/aGP8AeH+NFpgdB/wp/Rv+g3fn6RpSH4QaP/0Gr8/9s0/wrB/4WOx/i1D8GH+NMPxD3DBGoH/gY/xpJT7gdB/wqLRe+tah/wB+0qOT4VaBH9/X7tQP7wjFc+3juFvvQ3h+rA/1rRsNatdSiL20hLL95GGGX8KdpLqCKmu+B/D+laDeXltrl1cTwx70iKLhjkdSBXArxIv1H869C12Uv4cvRnI8o154PlYEg8GtI3a1Gem65rktz8S9DuliWNoYJAO/XdWa19NN8U57iSQlzbAZHHG1eKwrnX7efXbS+EEwSBGVlOMnPp+dMTW4F8TyaoYZfLaPywmRu6AZ9O1Ty2A6/V7hjol3k8mF/wCVc/K5/wCFY7Sf4Bn/AL+VHe+J7W6sJrdba4UyIVBbbgZH1rOOrwnwoNK8uTzNu3fxj72aLDOvsmxpttz/AMsk/wDQRUxaubg8TWkVnFEbeclECkjHOBj1qQeKbM9ba4/T/GmFyr4qvN00Nmp4UeY31PQflmsbTzjVrY5/5ar/ADpL24a8v5bls/O2QPQdh+VFiP8AiZ2+enmr/MU7Ad4WOetROyqhZmAAHJPFDN1qKVUliaORQyMMEHuKQzIjvrNbwP8AaY8C9aTOeNuzGfpmmWNzB9rswJkJFuyEZ5yWzisjUIo7fVJoYVIjU4UE57Cp9Gijl1H94Cdi7157gipIudMTTC3vSFuPQd6jY8+tUMhuLmCJWSSZEYg4DHrXJBTiuivrCGdnuGd1cJkgdDgVgdqhskbtOMZrZ064iSySJpUD5PGeetZFaFlZxTQrOzNkN90dKV7AabN6daYzAChjj60+OHI3SD6CnGLm7IaVyHbI5+UE++OKcltIWG4gD2NWgOKBXSqKW5aihMBVAAAApM0pzTD9Ca12KHg59aM4pmeKOaLgUKAxqPOepIp2Qe9cV7GJLn34pwPvUORSgkdKdyifJPenKxBABqAN61JvweaLgTg59KXODwQagD+ufypd5ouK4y9b/Qm+orM3fX8qvXzf6H/wIVQyaLjDdXQ2rf6FCP8AYFc5ures2zYw/wC6BRcVy2GxT1bioQxpwYetIRj64c30Y9I/6mqtkcalbn0kX+dWNXOdQU5z8g/rVW14voT6SL/OhMo7HOKcrEHsah3c+9OB5qgOQuv+P6f/AK6N/M1DgVPcj/TZj/tt/OrMWkX0tt5yRDBGQpPzH8KVxGfgUYFSEFTgggjsaSquDG4o49OamggkubhYYly7dK6CDw9arGDPLJI3+ydo/wAaLiRzNFb174f8uIy2bmTHJjfrj2NYn/AR+VMdiPFehaa2NGtOR/qV/lXAkZHQCu604/8AEote37pf5VMho5LXJJJtfuS5ztbYo9AKojPpVzVRnXLsjp5hqTS9Ll1CUkkxwr95/X2HvQBnBSSFAyT09TVpNL1GVcx2U5Hrtx/OuxtbG0skxbwKp7v1Y/jVrcadwOEk0zUYlzJZTqB1O3I/Sq2DkjuOor0TdjpVW8sLO9QieFS3Z14YfjU3A4XB9K0NFleHXrYocbm2MM9Qe1GpaZLp0/J3xMflk6fgfem6WP8Aic2v/XVarcDrNYOdBu/+uZrhsGu31cg6FdYP/LM1xODQgG4NJin8jtV3TtLm1CQ4ISNT8znn8B70xGfg+g/GjBrqR4dsAmC8xb+9u/pisnUdJksv3iMZIScbscg+/wDjUhaxmfhS4FOwaDn0FNjGmpbL/kJW/wD10X+dTWun3V4heGNQo/iY4BpsMUkGrRRSoUdZFyD9aTYmdcSKaTxTS2KaWFAzldTOdYuT/tmpdGJGonn/AJZn+lQX/wA2p3ByP9Yam0nK6kPdSKkSN4k5ppamsfem5oEMuW/0WX/cP8q5oEY6CuguW/0SXn+A/wAqxI7eaQZSJiPXFS1d6BYi4rV084s+OzHFU/sF3jPkn8xV21iligIkjYfNRyvsOxaiTc+484qwTxTIR+6B7nmnEdq7KUbRLirIUDigikBpC2OlXcdxeO5NISPWmluc0hYEVLYXFPWmHINBb2NISMUguZYbinAj1FQhz6CnZzXDzGROGI+lOzgZqDPpTs+vWncCXd33DPtTg1RdTjgUoJouBMDzTlbB96hU08Hii4Ed8f8ARR2O4VQ57mrl4f3C8/xVSzTGHcVuWbH7DEOPu1hAZrYs2P2OP6UAy7mnBu+QB71EGzzQwDIUYZBGDTQjL1J1kvdyOrAKBlTmoITtnjPowP61JdRJFclEGFAHXmo0UFwDyCRU3Hc6dZFfDIykeoORUitzVSGOKCPy4xhc55OamD9KsZgFQ+qlW6GbB/76rqQ9cuvGrr/12/rXRhsnv+dJEmBqyqurSYH3gGP1xVLPtWhqvOpscfwKKpiqA1dARd00mPmGFz7Vu7qxNE4Wf6j+ta2aLjJg3/665LUo1j1e4RBhd2cfUZ/rXUZrm9U/5C83HcfyFFxlIDFdpYN/xK7Yf9Ml/lXGiuvsmxpsAOM+Wv8AKhiRzGpgtrdyByfMNdbaQLa2UdumQEH5nufzrlLznXpf+u39a60t8xpjJN3vQGHv+VRbj6mjcPU0ASbh6mjdn1/lUe+jcfU0ANvYFu7KSBx94cH0PY1yumgjV7b/AK6D+ddaG5Ga5O041qE/9Nf60AdJqh/4ktyMnHlmuPya6vU2/wCJRcDvsNctSQDa6vSlWPR4AP4l3H3JrlhxXUaef+JVbj/YFDAubqhvFWWwmjbkFD/KnZqK4P8Ao0mf7jfypCZyXOOlHNOAOBRyR0NOwzp7NRFp8KDHCDtVDU1H9qWUnG4tg/gR/jV6JsW0eP7o/lVa6i824gcsQEbPHfpSjFvYaVy2W5pjSKilnYKo7mgkGkbaRgjIrX2LDkOZusNfTMCDlycj61JYOiXql3CjB5NbRAyeO9IIomYBokYe4FHsH3DkHE8ZyD9KaAXPFSeWgTaowB0AoyFAAyfpSjRb3BQGmNRGcjJxUVTO3yHoKg5reMUtEWl2HZ4p6E7TyOtRE4pyscEDpVNXGPJ7DpSds0ZxUZbPSlewhSeM0hYYxRnIxTe1IkMilzxTc5PNJuwaRIuaU9OKYWo3e9BRkA9hTgc1F1p4J7155lYkB7UvWmdetOGe/wClAyQHHXpTgajHuKeBQA7JxkUrOFUseAKQfWlwGGCARVAVriZZVULng55qAKSaszxIm0ouOveose1AXGBavQXUUcCxtuBHt71Tx6CrdvDE0SsyAn3Jp6gXwcjNOBqPr0FKDTAoXfzXjHPp/KoUAEi49aluAftL8U1VORx0pIDdznmlBIqIMfQ/hTg3sTVgZQP/ABMwTg/vc/rW5msItsvd5HAfJx9avDUof7sh/CpQFfUcm+J77RVXBNT3Myz3BkUEDAGDUXPpTuOxpaQSFmz6j+tam73rG0+4hgEglbbnGOM1d+32naY/98mhCLu6uf1AZ1OU4HUfyFaYv7Uf8tD/AN8msu7kEt48kZ3Keh/CjcZXwfSuntH/AOJfCP8ApmP5Vze0+ldDan/QIev3B0+lFxmHdnOsSnt5v9RXTluTyDXNXXOrSN/01roCfYmhCJd3+c03cfU/nTc0hOf4T+VMRJuOPejdUe7Hajd7UASBskYrmrbI1eLB/wCWv9a6LPPQVz8AP9pxn0k/rSY0bWoHOlzj/YNc3iuhvWJ06Ucj5awMEjpRcENAOa6Kzz/ZsHUfIK5/B9D+IrVtr63S0jjdyCoxjaaTYzRLD1FMmbNvIB/cP8qrHULT/noR/wABNMfULVonVXOSpHKmmIxAvA5qeG2aXk8KPzpIYTJKF7dzitJQqqFAwBWsIX1ZSVy2gCwoBjgdzTJT8y/WkEqhRwcims4Zl46Gt0WSFmPYCik5pCCasCIn5j9aAfnBppJzxQM7hQBLk0mRSc0Z9qVwGNIpUjNR5PrTnVQpOOajyewoAUk0qnbnofrTOc4xSgA55zU3Ex5bJpM0EDHQ00nFSITOO5P1oz6mm5PpmkyKVwH9+/50vAFM3igt71SQhxb6VGWNJnNNJApN2Q1sf//Z';
  // Update apple-touch-icon links
  document.querySelectorAll('link[rel="apple-touch-icon"]').forEach(el => el.href = APP_ICON_URL);
  // Update manifest icons
  const manifestEl = document.getElementById('__pwa_manifest__');
  if (manifestEl) {
    try {
      const m = {
        name:"Toukir's Flow — Muslim Daily Tracker",
        short_name:"Toukir's Flow",
        description:"Islamic daily companion: prayers, dhikr, Quran, fasting and more.",
        start_url:"./",
        scope:"./",
        display:"standalone",
        orientation:"portrait-primary",
        background_color:"#08090c",
        theme_color:"#08090c",
        icons:[
          {src: APP_ICON_URL, sizes:"192x192", type:"image/jpeg", purpose:"any"},
          {src: APP_ICON_URL, sizes:"512x512", type:"image/jpeg", purpose:"any maskable"}
        ],
        categories:["lifestyle","productivity"]
      };
      const blob = new Blob([JSON.stringify(m)],{type:'application/manifest+json'});
      manifestEl.href = URL.createObjectURL(blob);
    } catch(e){}
  }
})();

