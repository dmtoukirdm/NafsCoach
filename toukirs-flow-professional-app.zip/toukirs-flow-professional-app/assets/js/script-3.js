
// ── Hoisted early declarations (used before their definition block) ──
var _featPageOpening = false;
var _featPageStack = []; // tracks open page history

const SURAHS = [
  {n:1,ar:'الفاتحة',en:'Al-Fatiha',v:7},{n:2,ar:'البقرة',en:'Al-Baqara',v:286},
  {n:3,ar:'آل عمران',en:'Al-Imran',v:200},{n:4,ar:'النساء',en:'An-Nisa',v:176},
  {n:5,ar:'المائدة',en:"Al-Ma'ida",v:120},{n:6,ar:'الأنعام',en:"Al-An'am",v:165},
  {n:7,ar:'الأعراف',en:"Al-A'raf",v:206},{n:8,ar:'الأنفال',en:'Al-Anfal',v:75},
  {n:9,ar:'التوبة',en:'At-Tawba',v:129},{n:10,ar:'يونس',en:'Yunus',v:109},
  {n:11,ar:'هود',en:'Hud',v:123},{n:12,ar:'يوسف',en:'Yusuf',v:111},
  {n:13,ar:'الرعد',en:"Ar-Ra'd",v:43},{n:14,ar:'إبراهيم',en:'Ibrahim',v:52},
  {n:15,ar:'الحجر',en:'Al-Hijr',v:99},{n:16,ar:'النحل',en:'An-Nahl',v:128},
  {n:17,ar:'الإسراء',en:'Al-Isra',v:111},{n:18,ar:'الكهف',en:'Al-Kahf',v:110},
  {n:19,ar:'مريم',en:'Maryam',v:98},{n:20,ar:'طه',en:'Ta-Ha',v:135},
  {n:21,ar:'الأنبياء',en:'Al-Anbiya',v:112},{n:22,ar:'الحج',en:'Al-Hajj',v:78},
  {n:23,ar:'المؤمنون',en:"Al-Mu'minun",v:118},{n:24,ar:'النور',en:'An-Nur',v:64},
  {n:25,ar:'الفرقان',en:'Al-Furqan',v:77},{n:26,ar:'الشعراء',en:"Ash-Shu'ara",v:227},
  {n:27,ar:'النمل',en:'An-Naml',v:93},{n:28,ar:'القصص',en:'Al-Qasas',v:88},
  {n:29,ar:'العنكبوت',en:'Al-Ankabut',v:69},{n:30,ar:'الروم',en:'Ar-Rum',v:60},
  {n:31,ar:'لقمان',en:'Luqman',v:34},{n:32,ar:'السجدة',en:'As-Sajda',v:30},
  {n:33,ar:'الأحزاب',en:'Al-Ahzab',v:73},{n:34,ar:'سبأ',en:'Saba',v:54},
  {n:35,ar:'فاطر',en:'Fatir',v:45},{n:36,ar:'يس',en:'Ya-Sin',v:83},
  {n:37,ar:'الصافات',en:'As-Saffat',v:182},{n:38,ar:'ص',en:'Sad',v:88},
  {n:39,ar:'الزمر',en:'Az-Zumar',v:75},{n:40,ar:'غافر',en:'Ghafir',v:85},
  {n:41,ar:'فصلت',en:'Fussilat',v:54},{n:42,ar:'الشورى',en:'Ash-Shura',v:53},
  {n:43,ar:'الزخرف',en:'Az-Zukhruf',v:89},{n:44,ar:'الدخان',en:'Ad-Dukhan',v:59},
  {n:45,ar:'الجاثية',en:'Al-Jathiya',v:37},{n:46,ar:'الأحقاف',en:'Al-Ahqaf',v:35},
  {n:47,ar:'محمد',en:'Muhammad',v:38},{n:48,ar:'الفتح',en:'Al-Fath',v:29},
  {n:49,ar:'الحجرات',en:'Al-Hujurat',v:18},{n:50,ar:'ق',en:'Qaf',v:45},
  {n:51,ar:'الذاريات',en:'Az-Zariyat',v:60},{n:52,ar:'الطور',en:'At-Tur',v:49},
  {n:53,ar:'النجم',en:'An-Najm',v:62},{n:54,ar:'القمر',en:'Al-Qamar',v:55},
  {n:55,ar:'الرحمن',en:'Ar-Rahman',v:78},{n:56,ar:'الواقعة',en:"Al-Waqi'a",v:96},
  {n:57,ar:'الحديد',en:'Al-Hadid',v:29},{n:58,ar:'المجادلة',en:'Al-Mujadila',v:22},
  {n:59,ar:'الحشر',en:'Al-Hashr',v:24},{n:60,ar:'الممتحنة',en:'Al-Mumtahana',v:13},
  {n:61,ar:'الصف',en:'As-Saf',v:14},{n:62,ar:'الجمعة',en:"Al-Jumu'a",v:11},
  {n:63,ar:'المنافقون',en:'Al-Munafiqun',v:11},{n:64,ar:'التغابن',en:'At-Taghabun',v:18},
  {n:65,ar:'الطلاق',en:'At-Talaq',v:12},{n:66,ar:'التحريم',en:'At-Tahrim',v:12},
  {n:67,ar:'الملك',en:'Al-Mulk',v:30},{n:68,ar:'القلم',en:'Al-Qalam',v:52},
  {n:69,ar:'الحاقة',en:'Al-Haqqa',v:52},{n:70,ar:'المعارج',en:"Al-Ma'arij",v:44},
  {n:71,ar:'نوح',en:'Nuh',v:28},{n:72,ar:'الجن',en:'Al-Jinn',v:28},
  {n:73,ar:'المزمل',en:'Al-Muzzammil',v:20},{n:74,ar:'المدثر',en:'Al-Muddaththir',v:56},
  {n:75,ar:'القيامة',en:'Al-Qiyama',v:40},{n:76,ar:'الإنسان',en:'Al-Insan',v:31},
  {n:77,ar:'المرسلات',en:'Al-Mursalat',v:50},{n:78,ar:'النبأ',en:'An-Naba',v:40},
  {n:79,ar:'النازعات',en:"An-Nazi'at",v:46},{n:80,ar:'عبس',en:'Abasa',v:42},
  {n:81,ar:'التكوير',en:'At-Takwir',v:29},{n:82,ar:'الانفطار',en:'Al-Infitar',v:19},
  {n:83,ar:'المطففين',en:'Al-Mutaffifin',v:36},{n:84,ar:'الانشقاق',en:'Al-Inshiqaq',v:25},
  {n:85,ar:'البروج',en:'Al-Buruj',v:22},{n:86,ar:'الطارق',en:'At-Tariq',v:17},
  {n:87,ar:'الأعلى',en:"Al-A'la",v:19},{n:88,ar:'الغاشية',en:'Al-Ghashiya',v:26},
  {n:89,ar:'الفجر',en:'Al-Fajr',v:30},{n:90,ar:'البلد',en:'Al-Balad',v:20},
  {n:91,ar:'الشمس',en:'Ash-Shams',v:15},{n:92,ar:'الليل',en:'Al-Layl',v:21},
  {n:93,ar:'الضحى',en:'Ad-Duha',v:11},{n:94,ar:'الشرح',en:'Ash-Sharh',v:8},
  {n:95,ar:'التين',en:'At-Tin',v:8},{n:96,ar:'العلق',en:"Al-'Alaq",v:19},
  {n:97,ar:'القدر',en:'Al-Qadr',v:5},{n:98,ar:'البينة',en:'Al-Bayyina',v:8},
  {n:99,ar:'الزلزلة',en:'Az-Zalzala',v:8},{n:100,ar:'العاديات',en:"Al-'Adiyat",v:11},
  {n:101,ar:'القارعة',en:"Al-Qari'a",v:11},{n:102,ar:'التكاثر',en:'At-Takathur',v:8},
  {n:103,ar:'العصر',en:"Al-'Asr",v:3},{n:104,ar:'الهمزة',en:'Al-Humaza',v:9},
  {n:105,ar:'الفيل',en:'Al-Fil',v:5},{n:106,ar:'قريش',en:'Quraysh',v:4},
  {n:107,ar:'الماعون',en:"Al-Ma'un",v:7},{n:108,ar:'الكوثر',en:'Al-Kawthar',v:3},
  {n:109,ar:'الكافرون',en:'Al-Kafirun',v:6},{n:110,ar:'النصر',en:'An-Nasr',v:3},
  {n:111,ar:'المسد',en:'Al-Masad',v:5},{n:112,ar:'الإخلاص',en:'Al-Ikhlas',v:4},
  {n:113,ar:'الفلق',en:'Al-Falaq',v:5},{n:114,ar:'الناس',en:'An-Nas',v:6},
];

const SCARD_KEY = 'mrd_scard_state';
const SCARD_IDS = ['scard-appearance','scard-display','scard-prayer','scard-tracker','scard-language','scard-privacy','scard-storage','scard-cloud','scard-backup','scard-routine','scard-homescreen','scard-about'];

var DAILY_CHALLENGES = [
  { icon:'🤲', title:'Make Dua for 3 people',       desc:'Pray for your parents, a friend, and someone in hardship today.',         reward:'Dua Warrior' },
  { icon:'📖', title:'Read 1 new Surah',             desc:'Open the Quran to a surah you rarely read and reflect on its meaning.',    reward:'Quran Explorer' },
  { icon:'🌱', title:'Do one act of Sadaqah',        desc:'Give charity — even a smile is sadaqah. Do something kind today.',         reward:'Sadaqah Champion' },
  { icon:'🤫', title:'Guard your tongue for 1 hour', desc:'No backbiting, no idle talk. Be conscious of every word for one hour.',    reward:'Tongue Guardian' },
  { icon:'🌅', title:'Pray Fajr on time',            desc:'Wake before sunrise and pray Fajr in its proper time. A blessed start.',   reward:'Dawn Warrior' },
  { icon:'💧', title:'Make wudu between prayers',    desc:'Maintain your wudu throughout the day as a form of remembrance.',          reward:'Purity Keeper' },
  { icon:'📿', title:'100 extra Istighfar',          desc:'Say أَسْتَغْفِرُ اللّٰهَ 100 times today — beyond your daily count.',      reward:'Istighfar Master' },
  { icon:'🍽️', title:'Eat mindfully — Bismillah',   desc:'Say Bismillah before every meal and Alhamdulillah after. Conscious eating.',reward:'Grateful Eater' },
  { icon:'🌙', title:'Pray 2 rakat Tahajjud',        desc:'Rise in the last third of the night and pray 2 rakat for Allah\'s sake.',  reward:'Night Prayer' },
  { icon:'🤝', title:'Reconnect with someone',       desc:'Call a relative or friend you haven\'t spoken to in a while. Silatu rahim.',reward:'Kinship Keeper' },
  { icon:'📚', title:'Learn one Islamic fact',       desc:'Read about a Sahabi, a hadith, or a historical Islamic event today.',      reward:'Knowledge Seeker' },
  { icon:'🌿', title:'Fast a voluntary fast',        desc:'Fast today as a Sunnah — Monday, Thursday, or white days fast.',           reward:'Voluntary Faster' },
  { icon:'🧘', title:'5 min morning reflection',     desc:'Sit quietly after Fajr. Reflect on gratitude, goals, and your niyyah.',   reward:'Mindful Muslim' },
  { icon:'💪', title:'Help someone without being asked', desc:'Observe quietly and help someone before they ask — pure sincerity.',   reward:'Silent Helper' },
  { icon:'⭐', title:'Memorise one new Ayah',        desc:'Pick one short ayah and commit it to memory before you sleep.',            reward:'Hifz Starter' },
];

var ACHIEVEMENTS = [
  { id:'first_prayer',   icon:'🕌', title:'First Prayer',      desc:'Mark your first prayer done',              check: () => Object.values(prayerDone).some(Boolean) },
  { id:'all5_once',      icon:'⭐', title:'Full Salah Day',     desc:'Complete all 5 prayers in a day',          check: () => Object.values(prayerDone).filter(Boolean).length === 5 },
  { id:'streak3',        icon:'🔥', title:'3-Day Streak',       desc:'3 consecutive all-5-prayer days',          check: () => calcAllFivePrayerStreak() >= 3 },
  { id:'streak7',        icon:'💫', title:'Week Warrior',       desc:'7 consecutive all-5-prayer days',          check: () => calcAllFivePrayerStreak() >= 7 },
  { id:'streak30',       icon:'🌟', title:'Month of Salah',     desc:'30 consecutive all-5-prayer days',         check: () => calcAllFivePrayerStreak() >= 30 },
  { id:'dhikr100',       icon:'📿', title:'Dhikr Devotee',      desc:'Complete 100+ dhikr in a day',             check: () => dhikrCounts.reduce((a,b)=>a+b,0) >= 100 },
  { id:'quran_started',  icon:'📖', title:'Quran Journey',      desc:'Read your first Quran pages',              check: () => quranData.pages > 0 },
  { id:'fast_done',      icon:'🤍', title:'Fast & Faithful',    desc:'Log your first fast',                      check: () => Object.values(fastingData).some(Boolean) },
  { id:'challenge_done', icon:'🎯', title:'Daily Challenger',   desc:'Complete your first daily challenge',      check: () => loadChallengeState().done },
  { id:'health_full',    icon:'💚', title:'Health Conscious',   desc:'Hit all 3 health goals in one day',        check: () => { const h=loadHealth(TODAY_KEY); return h.water>=8 && h.sleep>=8 && h.steps>=10000; } },
  { id:'all_sunnah',     icon:'🌙', title:'Sunnah Champion',    desc:'Complete all Sunnah habits in a day',      check: () => sunnahDone.length > 0 && sunnahDone.every(Boolean) },
  { id:'takbir5',        icon:'🕋', title:'Takbir-ul-Ula',      desc:'Pray all 5 with Takbir-ul-Ula quality',    check: () => ['Fajr','Dhuhr','Asr','Maghrib','Isha'].every(p => prayerDone[p] && prayerQuality[p]==='takbir') },
  { id:'night_owl',      icon:'🦉', title:'Night Owl',          desc:'Log sleep less than 6 hours (Tahajjud?)',  check: () => { const h=loadHealth(TODAY_KEY); return h.sleep>0 && h.sleep<6; } },
  { id:'water_champion', icon:'💧', title:'Hydration Hero',     desc:'Drink 10+ glasses of water',               check: () => loadHealth(TODAY_KEY).water >= 10 },
  { id:'score90',        icon:'🏆', title:'Excellence Award',   desc:'Score 90%+ on your daily score',           check: () => calcDayScore(TODAY_KEY) >= 90 },
];
// ══════════════════════════════════════════════
// 99 NAMES SLIDER — vars at top to avoid TDZ
// ══════════════════════════════════════════════
var _asmaIdx = 0;
var _asmaDragStartX = 0;
var _asmaDragging = false;

function renderAsmaGrid() {
  var track = document.getElementById('asma-track');
  if(!track || track.children.length === 99) return;
  track.innerHTML = ASMA_UL_HUSNA.map(function(name) {
    return '<div class="asma-slide">'
      + '<div class="asma-slide-num">' + name.n + ' of 99</div>'
      + '<span class="asma-slide-ar">' + name.ar + '</span>'
      + '<div class="asma-slide-tr">' + name.tr + '</div>'
      + '<div class="asma-slide-en">' + name.en + '</div>'
      + '<div class="asma-slide-meaning">' + name.m + '</div>'
      + '</div>';
  }).join('');
  _asmaIdx = 0;
  _asmaUpdateUI();
  _asmaInitSwipe();
}

function _asmaUpdateUI() {
  var track = document.getElementById('asma-track');
  if(!track) return;
  track.style.transform = 'translateX(' + (-_asmaIdx * 100) + '%)';
  var cur  = document.getElementById('asma-idx-lbl') || document.getElementById('asma-cur');
  var bar  = document.getElementById('asma-progress-bar');
  var prev = document.getElementById('asma-prev');
  var next = document.getElementById('asma-next');
  if(cur)  cur.textContent  = _asmaIdx + 1;
  if(bar)  bar.style.width  = ((_asmaIdx + 1) / 99 * 100).toFixed(2) + '%';
  if(prev) prev.classList.toggle('disabled', _asmaIdx === 0);
  if(next) next.classList.toggle('disabled', _asmaIdx === 98);
}

function asmaNext() { if(_asmaIdx < 98) { _asmaIdx++; _asmaUpdateUI(); } }
function asmaPrev() { if(_asmaIdx > 0)  { _asmaIdx--; _asmaUpdateUI(); } }
function closeAsmaDetail() {}

function _asmaInitSwipe() {
  var wrap = document.getElementById('asma-slider-wrap');
  if(!wrap || wrap.dataset.swipe) return;
  wrap.dataset.swipe = '1';
  wrap.addEventListener('touchstart', function(e) {
    _asmaDragStartX = e.touches[0].clientX;
    _asmaDragging   = true;
  }, {passive: true});
  wrap.addEventListener('touchend', function(e) {
    if(!_asmaDragging) return;
    _asmaDragging = false;
    var dx = e.changedTouches[0].clientX - _asmaDragStartX;
    if(dx < -40)  asmaNext();
    else if(dx > 40) asmaPrev();
  }, {passive: true});
}


// BANGLA (BN) TRANSLATION SYSTEM
// ==============================================
const TRANSLATIONS = {
  en: {},  // English = keys themselves
  bn: {
    // -- Nav --
    'Today': 'আজ',
    'Progress': 'অগ্রগতি',
    'Settings': 'সেটিংস',

    // -- Header greetings --
    'Good morning': 'শুভ সকাল',
    'Good afternoon': 'শুভ বিকাল',
    'Good evening': 'শুভ সন্ধ্যা',
    'Stay intentional.': 'নিয়তের সাথে থাকুন।',
    'Stay intentional today.': 'আজ নিয়তের সাথে থাকুন।',
    'Personalise your experience.': 'আপনার অভিজ্ঞতা কাস্টমাইজ করুন।',

    // -- Settings header --
    'App Settings': 'অ্যাপ সেটিংস',

    // -- Section labels --
    'Prayer Times': 'নামাজের সময়',
    'Activities': 'কার্যক্রম',
    'Dhikr Counter': 'যিকর কাউন্টার',
    'Fasting': 'রোজা',
    'Quran Reading': 'কুরআন তিলাওয়াত',
    'Sunnah Habits': 'সুন্নাত আমল',
    'Prayer Streak (This Week)': 'নামাজের ধারা (এই সপ্তাহ)',
    "Today's Note": 'আজকের নোট',
    'Duas': 'দোয়া',
    'Qibla': 'কিবলা',
    'Ayah of the Day': 'আজকের আয়াত',
    'Mood Check-in': 'মেজাজ চেক-ইন',

    // -- Prayer names --
    'Fajr': 'ফজর',
    'Dhuhr': 'যোহর',
    'Asr': 'আসর',
    'Maghrib': 'মাগরিব',
    'Isha': 'ইশা',
    'Jumu\'ah': 'জুমআ',

    // -- Prayer quality --
    'Takbir': 'তাকবীর',
    'Jamaat': 'জামাত',
    'Alone': 'একা',
    'Takbir-ul-Ula': 'তাকবীরে উলা',

    // -- KPI / Score --
    'Score': 'স্কোর',
    'Prayers': 'নামাজ',
    'Sunnah': 'সুন্নাত',
    'Quran': 'কুরআন',
    'Dhikr': 'যিকর',
    'streak': 'ধারা',
    'Streak': 'ধারা',
    'days': 'দিন',

    // -- Fasting --
    'Fasting 🤍': 'রোজা 🤍',
    'Not fasting': 'রোজা নেই',
    'Ramadan Fasting': 'রমজানের রোজা',
    'days this month': 'এই মাসে দিন',
    'fasts completed': 'রোজা সম্পন্ন',

    // -- Activities --
    'No activities yet. Add some below!': 'কোনো কার্যক্রম নেই। নিচে যোগ করুন!',
    'No activities to mark': 'কোনো কার্যক্রম চিহ্নিত করার নেই',
    'Quick Add': 'দ্রুত যোগ',
    'Add Activity': 'কার্যক্রম যোগ করুন',
    'All done! Alhamdulillah 🌟': 'সব সম্পন্ন! আলহামদুলিল্লাহ 🌟',

    // -- Default activities --
    'Morning Walk': 'সকালের হাঁটা',
    'Drink Water': 'পানি পান',
    'Read Quran': 'কুরআন পড়া',
    'Meditate': 'ধ্যান',
    'Exercise': 'ব্যায়াম',
    'Study/Learn': 'পড়াশোনা/শেখা',
    'Healthy Eating': 'স্বাস্থ্যকর খাবার',
    'Morning Adhkar': 'সকালের আযকার',
    'Evening Adhkar': 'সন্ধ্যার আযকার',
    'Help Someone': 'কাউকে সাহায্য',
    'Journaling': 'জার্নালিং',
    'Good Sleep': 'ভালো ঘুম',
    'Extra Dhikr': 'অতিরিক্ত যিকর',
    'Tahajjud': 'তাহাজ্জুদ',
    'Suhoor/Iftar': 'সেহরি/ইফতার',
    'Islamic Study': 'ইসলামিক পড়াশোনা',
    'Start the day active': 'সক্রিয়ভাবে দিন শুরু',
    '8 glasses a day': 'দিনে ৮ গ্লাস',
    'Daily recitation': 'দৈনিক তিলাওয়াত',
    '10 min mindfulness': '১০ মিনিট মনোযোগ',
    'Stay physically healthy': 'শারীরিকভাবে সুস্থ থাকুন',
    'Seek beneficial knowledge': 'উপকারী জ্ঞান অর্জন',
    'Nourish your body': 'শরীরকে পুষ্টি দিন',
    'Dua & remembrance after Fajr': 'ফজরের পর দোয়া ও যিকর',
    'Dua & remembrance after Asr': 'আসরের পর দোয়া ও যিকর',
    'Act of kindness today': 'আজকের একটি ভালো কাজ',
    'Reflect on your day': 'দিনটি নিয়ে ভাবুন',
    'Sleep before midnight': 'মধ্যরাতের আগে ঘুমান',
    'Beyond daily count': 'দৈনিক গণনার বাইরে',
    'Night voluntary prayer': 'রাতের নফল নামাজ',
    'Blessed meals': 'বরকতের খাবার',
    'Deepen your knowledge': 'জ্ঞান গভীর করুন',

    // -- Viewing banner --
    'Activities': 'কার্যক্রম',
    'Prayers': 'নামাজ',
    'Sunnah': 'সুন্নাত',
    '↩ Today': '↩ আজ',
    '🕌 All Prayers': '🕌 সব নামাজ',
    '✅ All Activities': '✅ সব কার্যক্রম',
    '🌙 All Sunnah': '🌙 সব সুন্নাত',

    // -- Notes --
    'Write your thoughts...': 'আপনার ভাবনা লিখুন...',
    'Save': 'সেভ',
    'Clear': 'মুছুন',
    'words': 'শব্দ',
    'Note saved': 'নোট সেভ হয়েছে',
    "Today's Reflection": 'আজকের চিন্তা',

    // -- Stats --
    'Daily Score': 'দৈনিক স্কোর',
    'Category Breakdown': 'বিভাগ বিশ্লেষণ',
    'Quran & Fasting': 'কুরআন ও রোজা',
    'Prayer Streak': 'নামাজের ধারা',

    // -- Settings scard titles --
    'Appearance': 'চেহারা',
    'Display': 'ডিসপ্লে',
    'Prayer': 'নামাজ',
    'Tracker & Habits': 'ট্র্যাকার ও আমল',
    'Language & Names': 'ভাষা ও নাম',
    'Privacy & Security': 'গোপনীয়তা',
    'Storage & Data': 'স্টোরেজ',
    'Backup & Restore': 'ব্যাকআপ',
    'About': 'সম্পর্কে',

    // -- Settings scard subs --
    'Animations · Theme · Layout': 'অ্যানিমেশন · থিম · লেআউট',
    'Score · Clock · Hijri · Labels': 'স্কোর · ঘড়ি · হিজরি · লেবেল',
    'Method · Asr · Notifications': 'পদ্ধতি · আসর · বিজ্ঞপ্তি',
    'Dhikr · Sunnah · Activities · Quran': 'যিকর · সুন্নাত · কার্যক্রম · কুরআন',
    'Prayer names · Transliteration · Dua': 'নামাজের নাম · উচ্চারণ · দোয়া',
    'PIN lock · Background hide': 'পিন লক · ব্যাকগ্রাউন্ড লুকান',
    'Auto-save · Usage · Keys': 'অটো-সেভ · ব্যবহার · কী',
    'Save · Restore · Clear': 'সেভ · পুনরুদ্ধার · মুছুন',
    'Version · Data info': 'ভার্সন · ডেটা তথ্য',

    // -- Settings sr-labels --
    'Accent Color': 'অ্যাকসেন্ট রঙ',
    'Text Size': 'টেক্সট আকার',
    'Animations': 'অ্যানিমেশন',
    'Background Orbs': 'ব্যাকগ্রাউন্ড অর্ব',
    'Compact Mode': 'কম্প্যাক্ট মোড',
    'Theme': 'থিম',
    'Card Radius': 'কার্ড রেডিয়াস',
    'Show Composite Score': 'যৌগিক স্কোর দেখান',
    'Clock Format': 'ঘড়ির ফরম্যাট',
    'Show Seconds': 'সেকেন্ড দেখান',
    'KPI Labels': 'কেপিআই লেবেল',
    'Show Hijri Date': 'হিজরি তারিখ দেখান',
    'Hijri Date Offset': 'হিজরি তারিখ অফসেট',
    'Calculation Method': 'গণনা পদ্ধতি',
    'Asr Calculation': 'আসর গণনা',
    'Prayer Notifications': 'নামাজের বিজ্ঞপ্তি',
    'Reminder Offset': 'রিমাইন্ডার অফসেট',
    'Reset Dhikr Daily': 'প্রতিদিন যিকর রিসেট',
    'Vibrate on Dhikr Tap': 'যিকর ট্যাপে ভাইব্রেশন',
    'Reset Sunnah Daily': 'প্রতিদিন সুন্নাত রিসেট',
    'Show Completed Activities': 'সম্পন্ন কার্যক্রম দেখান',
    'Daily Activity Goal': 'দৈনিক কার্যক্রমের লক্ষ্য',
    'Week Starts On': 'সপ্তাহ শুরু',
    'Quran Daily Goal': 'কুরআনের দৈনিক লক্ষ্য',
    'Fasting Reminder': 'রোজার রিমাইন্ডার',
    'Prayer Name Style': 'নামাজের নামের ধরন',
    'Transliteration': 'অনুবর্ণ',
    'Dua Language': 'দোয়ার ভাষা',
    'App PIN Lock': 'অ্যাপ পিন লক',
    'Change PIN': 'পিন পরিবর্তন',
    'Hide on Background': 'ব্যাকগ্রাউন্ডে লুকান',
    'Auto-Save': 'অটো-সেভ',
    'Storage Used': 'স্টোরেজ ব্যবহার',
    'Days Tracked': 'ট্র্যাক করা দিন',
    'Last Saved': 'শেষ সেভ',
    'Save Backup': 'ব্যাকআপ সেভ করুন',
    'Restore Backup': 'ব্যাকআপ পুনরুদ্ধার',
    'App Language': 'অ্যাপের ভাষা',
    'Clear Today\'s Data': 'আজকের ডেটা মুছুন',

    // -- sr-sub descriptions --
    'Smooth transitions and motion': 'মসৃণ ট্রানজিশন',
    'Ambient atmosphere effect': 'পরিবেশগত প্রভাব',
    'Reduce spacing for more content': 'বেশি কন্টেন্টের জন্য কম স্পেস',
    'Dark or light appearance': 'ডার্ক বা লাইট থিম',
    'Roundness of cards and elements': 'কার্ডের গোলাকার',
    'Daily % score ring on Progress tab': 'অগ্রগতি ট্যাবে দৈনিক স্কোর',
    '12-hour or 24-hour display': '১২ বা ২৪ ঘণ্টা',
    'Show seconds on the clock': 'ঘড়িতে সেকেন্ড দেখান',
    'Show labels under KPI cards': 'কেপিআই কার্ডে লেবেল',
    'Display the Hijri date in the header': 'হেডারে হিজরি তারিখ',
    'Adjust if Hijri date is off by 1 day': 'হিজরি তারিখ ১ দিন সামঞ্জস্য',
    'Prayer time calculation standard': 'নামাজের সময় গণনা মান',
    'Standard or Hanafi method': 'স্ট্যান্ডার্ড বা হানাফি',
    'Get browser reminders at prayer times': 'নামাজের সময় রিমাইন্ডার',
    'Minutes before prayer to notify': 'নামাজের কত মিনিট আগে বিজ্ঞপ্তি',
    'Reset counts to zero each day': 'প্রতিদিন শূন্যে রিসেট',
    'Haptic feedback when tapping dhikr': 'যিকর ট্যাপে হ্যাপটিক',
    'Automatically reset sunnah each day': 'প্রতিদিন সুন্নাত স্বয়ংক্রিয়ভাবে রিসেট',
    'Keep checked items visible': 'চেক করা আইটেম দৃশ্যমান রাখুন',
    'Target number of activities per day': 'প্রতিদিনের লক্ষ্যমাত্রা',
    'First day of the week': 'সপ্তাহের প্রথম দিন',
    'Pages to read per day': 'প্রতিদিন কত পৃষ্ঠা',
    'Remind to keep fast on eligible days': 'যোগ্য দিনে রোজার রিমাইন্ডার',
    'How prayer names are displayed': 'নামাজের নাম কীভাবে দেখানো হবে',
    'Arabic romanization under dhikr': 'যিকরের নিচে আরবি রোমানাইজেশন',
    'Arabic only or with translation': 'শুধু আরবি বা অনুবাদসহ',
    'Require a PIN to open the app': 'অ্যাপ খুলতে পিন লাগবে',
    'PIN is active — tap Change to update': 'পিন সক্রিয় — পরিবর্তন করুন',
    'Hide content when app is in background': 'ব্যাকগ্রাউন্ডে কন্টেন্ট লুকান',
    'All changes save instantly to your device': 'সব পরিবর্তন সাথে সাথে সেভ হয়',
    'Download all your data as a JSON file': 'সব ডেটা JSON ফাইলে ডাউনলোড',
    'Import a previously saved JSON file': 'আগের JSON ফাইল আমদানি',
    'Reset today\'s activities, prayers and notes': 'আজকের ডেটা রিসেট করুন',
    'Switch between English and বাংলা': 'ইংরেজি ও বাংলার মধ্যে পরিবর্তন',

    // -- Mood --
    'How are you feeling?': 'আপনি কেমন অনুভব করছেন?',
    'Calm': 'শান্ত',
    'Motivated': 'অনুপ্রাণিত',
    'Struggling': 'সংগ্রামী',
    'Grateful': 'কৃতজ্ঞ',

    // -- Ishraq nudge --
    'Ishraq time': 'ইশরাকের সময়',
    'Duha time': 'দুহার সময়',

    // -- Score pill --
    'Today\'s Score': 'আজকের স্কোর',

    // -- Backup --
    'Backup saved': 'ব্যাকআপ সেভ হয়েছে',
    'Export failed': 'এক্সপোর্ট ব্যর্থ',
    'Invalid backup file': 'অবৈধ ব্যাকআপ ফাইল',
    'Restored — reloading...': 'পুনরুদ্ধার হয়েছে — পুনরায় লোড হচ্ছে...',

    // -- Misc --
    'All Five': 'পাঁচটি সম্পূর্ণ',
    'prayer streak': 'নামাজের ধারা',
    'Missed': 'মিস হয়েছে',
    'On time': 'সময়মতো',
    'pages': 'পৃষ্ঠা',
    'Page': 'পৃষ্ঠা',
    'goal': 'লক্ষ্য',
    'No note yet': 'এখনো কোনো নোট নেই',
    'Dark': 'ডার্ক',
    'Light': 'লাইট',
    'Sharp': 'শার্প',
    'Round': 'গোল',
    'Pill': 'পিল',
    'English': 'ইংরেজি',
    'Arabic': 'আরবি',
    'Both': 'উভয়',
    'Sunday': 'রবিবার',
    'Monday': 'সোমবার',
    'Saturday': 'শনিবার',
    'Standard': 'স্ট্যান্ডার্ড',
    'Hanafi': 'হানাফি',
    'min': 'মিনিট',
    'pg': 'পৃষ্ঠা',
    'version': 'ভার্সন',

    // -- Explore section --
    'Explore': '✦ &nbsp;অন্বেষণ &nbsp;✦',

    // -- Explore feat-pill labels --
    'Notes': 'নোট',
    'Tasbih': 'তাসবিহ',
    'Asma': 'আসমা',
    'Calendar': 'ক্যালেন্ডার',
    'Mood': 'মেজাজ',
    'Ayah': 'আয়াত',
    'Challenge': 'চ্যালেঞ্জ',
    'Awards': 'পুরস্কার',
    'Quiz': 'কুইজ',
    'Finance': 'ফাইন্যান্স',
    'Tafsir': 'তাফসির',
    'History': 'ইতিহাস',
    'News': 'সংবাদ',

    // -- Feature page titles --
    'Mood & Energy': '🌿 মেজাজ ও শক্তি',
    'Daily Notes': '✍️ দৈনিক নোট',
    'Dua Library': '🤲 দোয়ার ভান্ডার',
    'Qibla Direction': '🧭 কিবলার দিক',
    'Asma ul Husna': '☪️ আসমাউল হুসনা',
    'Daily Challenge': '🎯 দৈনিক চ্যালেঞ্জ',
    'Achievements': '🏆 অর্জনসমূহ',
    'Tasbih Counter': '📿 তাসবিহ কাউন্টার',
    'Islamic Calendar': '📅 ইসলামিক ক্যালেন্ডার',
    'Islamic Finance': '💰 ইসলামিক ফাইন্যান্স',
    'Tafsir Explorer': '📖 তাফসির অন্বেষক',
    'Islamic History': '🕌 ইসলামিক ইতিহাস',
    'Islamic News': '📰 ইসলামিক সংবাদ',
  }
};

let _lang = 'en'; // safe standalone var updated when settings load

function t(key) {
  if(_lang === 'en') return key;
  return TRANSLATIONS.bn[key] || key;
}


function setAppLanguage(lang, btn) {
  appSettings.language = lang;
  _lang = lang;
  saveSettings();
  // Update pill
  const toggle = document.getElementById('lang-toggle');
  if(toggle) toggle.querySelectorAll('.spt').forEach((b,i) => {
    b.classList.toggle('active', (i===0 && lang==='en') || (i===1 && lang==='bn'));
  });
  applyLanguage();
}


function renderAllSrLabels() {
  document.querySelectorAll('[data-tkey]').forEach(function(el) {
    el.textContent = t(el.getAttribute('data-tkey'));
  });
}
function applyLanguage() {
  const lang = appSettings.language || 'en';
  _lang = lang;
  document.documentElement.lang = lang === 'bn' ? 'bn' : 'en';
  // Re-render all translatable components
  try { updateHdrGreeting(); } catch(e) {}
  try { renderNavLabels(); } catch(e) {}
  try { renderSettingsView(); } catch(e) {}
  try { renderList(); } catch(e) {}
  try { renderKPI(); } catch(e) {}
  try { renderFasting(); } catch(e) {}
  try { renderPrayers(); } catch(e) {}
  try { renderSunnah(); } catch(e) {}
  try { renderViewingBanner(); } catch(e) {}
  try { renderSunnahHijriTip(); } catch(e) {}
  try { renderMoodCheckin(); } catch(e) {}
  try { renderStatsContent(); } catch(e) {}
  try { renderAllScardTitles(); } catch(e) {}
  try { renderAllSrLabels(); } catch(e) {}
}

function renderNavLabels() {
  const labels = [
    {view:'today',    label: t('Today')},
    {view:'stats',    label: t('Progress')},
    {view:'settings', label: t('Settings')},
  ];
  labels.forEach(({view, label}) => {
    const btn = document.querySelector(`.nb[data-view="${view}"]`);
    const lbl = btn ? btn.querySelector('.nb-lbl') : null;
    if(lbl) lbl.textContent = ' '+label;
  });
}

function getHeaderDisplayName(){
  try{
    const acc = JSON.parse(localStorage.getItem(ACCOUNT_KEY) || 'null');
    const raw = (acc && acc.name ? String(acc.name) : '').trim();
    if(!raw) return '';
    return raw.split(/\s+/)[0];
  }catch{return '';}
}
let heroCoachMessageTimer = null;
const HERO_COACH_MESSAGES = [
  'Protect your salah on time.',
  'Lower your gaze and guard your heart.',
  'Speak less, remember Allah more.',
  'Choose discipline over distraction.',
  'Make this moment sincere for Allah.',
  'Return softly when the heart slips.',
  'A quiet dhikr can change the day.',
  'Small consistent deeds are beloved.'
];

function updateHdrGreeting() {
  const titleEl = document.getElementById('hdr-app-title');
  const name = getHeaderDisplayName();
  if(titleEl) titleEl.textContent = name ? `Assalamu Alaikum, ${name}` : 'Assalamu Alaikum';
}

function initHeroCoachMessages() {
  const subEl = document.getElementById('hdr-s');
  if(!subEl) return;
  const messages = HERO_COACH_MESSAGES.map(m => t(m));
  let idx = 0;
  const applyMessage = (animate = false) => {
    const next = messages[idx % messages.length];
    if(animate){
      subEl.style.transition = 'opacity .24s ease, transform .24s ease';
      subEl.style.opacity = '.28';
      subEl.style.transform = 'translateY(3px)';
      setTimeout(() => {
        subEl.textContent = next;
        subEl.style.opacity = '1';
        subEl.style.transform = 'translateY(0)';
      }, 150);
    }else{
      subEl.textContent = next;
      subEl.style.opacity = '1';
      subEl.style.transform = 'translateY(0)';
    }
  };
  applyMessage(false);
  if(heroCoachMessageTimer) clearInterval(heroCoachMessageTimer);
  heroCoachMessageTimer = setInterval(() => {
    idx = (idx + 1) % messages.length;
    applyMessage(true);
  }, 4200);
}

function renderAllScardTitles() {
  const map = {
    'scard-appearance': { title: t('Appearance'),        sub: t('Animations · Theme · Layout') },
    'scard-display':    { title: t('Display'),           sub: t('Score · Clock · Hijri · Labels') },
    'scard-prayer':     { title: t('Prayer'),            sub: t('Method · Asr · Notifications') },
    'scard-tracker':    { title: t('Tracker & Habits'),  sub: t('Dhikr · Sunnah · Activities · Quran') },
    'scard-language':   { title: t('Language & Names'),  sub: t('Prayer names · Transliteration · Dua') },
    'scard-privacy':    { title: t('Privacy & Security'),sub: t('PIN lock · Background hide') },
    'scard-storage':    { title: t('Storage & Data'),    sub: t('Auto-save · Usage · Keys') },
    'scard-cloud':      { title: 'Cloud Sync',           sub: 'Sign in · Sync · Backup' },
  'scard-backup':     { title: t('Backup & Restore'),  sub: t('Save · Restore · Clear') },
    'scard-about':      { title: t('About'),             sub: t('Version · Data info') },
  };
  Object.entries(map).forEach(([id, {title, sub}]) => {
    const card = document.getElementById(id);
    if(!card) return;
    const titleEl = card.querySelector('.scard-title');
    const subEl   = card.querySelector('.scard-sub');
    if(titleEl) titleEl.textContent = title;
    if(subEl)   subEl.textContent   = sub;
  });
}




const ASMA_UL_HUSNA = [
  {n:1,  ar:'ٱللَّه',        tr:'Allah',       en:'The Greatest Name',          m:'The name that encompasses all divine attributes.'},
  {n:2,  ar:'ٱلرَّحْمَٰن',   tr:'Ar-Rahman',   en:'The Most Gracious',          m:'The one whose mercy encompasses all of creation.'},
  {n:3,  ar:'ٱلرَّحِيم',     tr:'Ar-Raheem',   en:'The Most Merciful',          m:'The one whose mercy is reserved especially for believers.'},
  {n:4,  ar:'ٱلْمَلِك',      tr:'Al-Malik',    en:'The King',                   m:'The sovereign owner and ruler of all existence.'},
  {n:5,  ar:'ٱلْقُدُّوس',    tr:'Al-Quddus',   en:'The Most Holy',              m:'The one free from all imperfection and deficiency.'},
  {n:6,  ar:'ٱلسَّلَام',     tr:'As-Salam',    en:'The Source of Peace',        m:'The one who bestows peace and security upon His servants.'},
  {n:7,  ar:'ٱلْمُؤْمِن',    tr:'Al-Mu\'min',  en:'The Guardian of Faith',      m:'The one who grants safety and confirms the truth.'},
  {n:8,  ar:'ٱلْمُهَيْمِن',  tr:'Al-Muhaymin', en:'The Protector',              m:'The one who watches over and preserves all things.'},
  {n:9,  ar:'ٱلْعَزِيز',     tr:'Al-Aziz',     en:'The Almighty',               m:'The one who is powerful and cannot be overcome.'},
  {n:10, ar:'ٱلْجَبَّار',    tr:'Al-Jabbar',   en:'The Compeller',              m:'The one who restores what is broken and compels as He wills.'},
  {n:11, ar:'ٱلْمُتَكَبِّر', tr:'Al-Mutakabbir',en:'The Supreme',              m:'The one who is supremely great above all creation.'},
  {n:12, ar:'ٱلْخَالِق',     tr:'Al-Khaliq',   en:'The Creator',                m:'The one who brings everything into existence from nothing.'},
  {n:13, ar:'ٱلْبَارِئ',     tr:'Al-Bari\'',   en:'The Evolver',                m:'The one who creates things with distinctions and differences.'},
  {n:14, ar:'ٱلْمُصَوِّر',   tr:'Al-Musawwir', en:'The Fashioner',              m:'The one who gives shape and form to all things.'},
  {n:15, ar:'ٱلْغَفَّار',    tr:'Al-Ghaffar',  en:'The Perpetual Forgiver',     m:'The one who forgives sins repeatedly without weariness.'},
  {n:16, ar:'ٱلْقَهَّار',    tr:'Al-Qahhar',   en:'The Subduer',                m:'The one who overpowers all and subdues everything.'},
  {n:17, ar:'ٱلْوَهَّاب',    tr:'Al-Wahhab',   en:'The Bestower',               m:'The one who gives freely and generously without limit.'},
  {n:18, ar:'ٱلرَّزَّاق',    tr:'Ar-Razzaq',   en:'The Provider',               m:'The one who provides sustenance for all of creation.'},
  {n:19, ar:'ٱلْفَتَّاح',    tr:'Al-Fattah',   en:'The Opener',                 m:'The one who opens doors of mercy, provision, and solutions.'},
  {n:20, ar:'ٱلْعَلِيم',     tr:'Al-Alim',     en:'The All-Knowing',            m:'The one whose knowledge encompasses everything perfectly.'},
  {n:21, ar:'ٱلْقَابِض',     tr:'Al-Qabid',    en:'The Withholder',             m:'The one who withholds and takes with wisdom and justice.'},
  {n:22, ar:'ٱلْبَاسِط',     tr:'Al-Basit',    en:'The Expander',               m:'The one who expands and extends provision and mercy.'},
  {n:23, ar:'ٱلْخَافِض',     tr:'Al-Khafid',   en:'The Abaser',                 m:'The one who lowers whom He wills with wisdom.'},
  {n:24, ar:'ٱلرَّافِع',     tr:'Ar-Rafi\'',   en:'The Exalter',                m:'The one who raises and elevates whom He wills.'},
  {n:25, ar:'ٱلْمُعِز',      tr:'Al-Mu\'izz',  en:'The Honorer',                m:'The one who grants honor and dignity to whom He wills.'},
  {n:26, ar:'ٱلْمُذِل',      tr:'Al-Mudhill',  en:'The Humiliator',             m:'The one who humiliates and dishonors whom He wills.'},
  {n:27, ar:'ٱلسَّمِيع',     tr:'As-Sami\'',   en:'The All-Hearing',            m:'The one who hears all sounds, spoken and unspoken.'},
  {n:28, ar:'ٱلْبَصِير',     tr:'Al-Basir',    en:'The All-Seeing',             m:'The one who sees all things, visible and hidden.'},
  {n:29, ar:'ٱلْحَكَم',      tr:'Al-Hakam',    en:'The Judge',                  m:'The one who judges between all things with perfect justice.'},
  {n:30, ar:'ٱلْعَدْل',      tr:'Al-Adl',      en:'The Just',                   m:'The one who is perfectly equitable in all His judgments.'},
  {n:31, ar:'ٱللَّطِيف',     tr:'Al-Latif',    en:'The Subtle',                 m:'The one who is kind and subtle in providing for His servants.'},
  {n:32, ar:'ٱلْخَبِير',     tr:'Al-Khabir',   en:'The All-Aware',              m:'The one who has full knowledge of all hidden things.'},
  {n:33, ar:'ٱلْحَلِيم',     tr:'Al-Halim',    en:'The Forbearing',             m:'The one who is slow to anger and abundant in patience.'},
  {n:34, ar:'ٱلْعَظِيم',     tr:'Al-Azim',     en:'The Magnificent',            m:'The one whose greatness is beyond all comprehension.'},
  {n:35, ar:'ٱلْغَفُور',     tr:'Al-Ghafur',   en:'The Forgiving',              m:'The one who pardons sins and covers faults abundantly.'},
  {n:36, ar:'ٱلشَّكُور',     tr:'Ash-Shakur',  en:'The Appreciative',           m:'The one who rewards generously even the smallest deed.'},
  {n:37, ar:'ٱلْعَلِىّ',     tr:'Al-Aliyy',    en:'The Most High',              m:'The one who is exalted above all in status and rank.'},
  {n:38, ar:'ٱلْكَبِير',     tr:'Al-Kabir',    en:'The Most Great',             m:'The one who is incomparably great in every way.'},
  {n:39, ar:'ٱلْحَفِيظ',     tr:'Al-Hafiz',    en:'The Preserver',              m:'The one who protects and preserves all things from harm.'},
  {n:40, ar:'ٱلْمُقِيت',     tr:'Al-Muqit',    en:'The Sustainer',              m:'The one who provides and maintains the sustenance of all.'},
  {n:41, ar:'ٱلْحَسِيب',     tr:'Al-Hasib',    en:'The Reckoner',               m:'The one who takes account of all things and suffices.'},
  {n:42, ar:'ٱلْجَلِيل',     tr:'Al-Jalil',    en:'The Majestic',               m:'The one who possesses attributes of majestic grandeur.'},
  {n:43, ar:'ٱلْكَرِيم',     tr:'Al-Karim',    en:'The Most Generous',          m:'The one who is infinitely generous and noble.'},
  {n:44, ar:'ٱلرَّقِيب',     tr:'Ar-Raqib',    en:'The Watchful',               m:'The one who observes all things with constant vigilance.'},
  {n:45, ar:'ٱلْمُجِيب',     tr:'Al-Mujib',    en:'The Responder',              m:'The one who answers the call of those who call on Him.'},
  {n:46, ar:'ٱلْوَاسِع',     tr:'Al-Wasi\'',   en:'The All-Encompassing',       m:'The one whose mercy, knowledge and bounty are boundless.'},
  {n:47, ar:'ٱلْحَكِيم',     tr:'Al-Hakim',    en:'The All-Wise',               m:'The one whose wisdom pervades all His acts and decrees.'},
  {n:48, ar:'ٱلْوَدُود',     tr:'Al-Wadud',    en:'The Loving',                 m:'The one who loves His righteous servants immensely.'},
  {n:49, ar:'ٱلْمَجِيد',     tr:'Al-Majid',    en:'The Glorious',               m:'The one who is glorious in attributes and boundless in grace.'},
  {n:50, ar:'ٱلْبَاعِث',     tr:'Al-Ba\'ith',  en:'The Resurrector',            m:'The one who raises the dead on the Day of Judgment.'},
  {n:51, ar:'ٱلشَّهِيد',     tr:'Ash-Shahid',  en:'The Witness',                m:'The one who witnesses all that occurs throughout creation.'},
  {n:52, ar:'ٱلْحَق',        tr:'Al-Haqq',     en:'The Truth',                  m:'The one who is the absolute and eternal truth.'},
  {n:53, ar:'ٱلْوَكِيل',     tr:'Al-Wakil',    en:'The Trustee',                m:'The one who is the best disposer of affairs for His servants.'},
  {n:54, ar:'ٱلْقَوِى',      tr:'Al-Qawiyy',   en:'The Most Strong',            m:'The one who has inexhaustible and absolute strength.'},
  {n:55, ar:'ٱلْمَتِين',     tr:'Al-Matin',    en:'The Firm',                   m:'The one whose strength is solid and impenetrable.'},
  {n:56, ar:'ٱلْوَلِى',      tr:'Al-Waliyy',   en:'The Protecting Friend',      m:'The one who is the guardian and helper of the believers.'},
  {n:57, ar:'ٱلْحَمِيد',     tr:'Al-Hamid',    en:'The Praiseworthy',           m:'The one who is deserving of all praise and gratitude.'},
  {n:58, ar:'ٱلْمُحْصِى',    tr:'Al-Muhsi',    en:'The All-Enumerating',        m:'The one who has counted and recorded everything precisely.'},
  {n:59, ar:'ٱلْمُبْدِئ',    tr:'Al-Mubdi\'',  en:'The Originator',             m:'The one who creates without any prior example or model.'},
  {n:60, ar:'ٱلْمُعِيد',     tr:'Al-Mu\'id',   en:'The Restorer',               m:'The one who brings back what was destroyed or ended.'},
  {n:61, ar:'ٱلْمُحْيِى',    tr:'Al-Muhyi',    en:'The Giver of Life',          m:'The one who gives life to all living things.'},
  {n:62, ar:'ٱلْمُمِيت',     tr:'Al-Mumit',    en:'The Taker of Life',          m:'The one who causes death at the appointed time.'},
  {n:63, ar:'ٱلْحَى',        tr:'Al-Hayy',     en:'The Ever-Living',            m:'The one who is eternally alive and never ceases to exist.'},
  {n:64, ar:'ٱلْقَيُّوم',    tr:'Al-Qayyum',   en:'The Self-Existing',          m:'The one upon whom all creation depends for its existence.'},
  {n:65, ar:'ٱلْوَاجِد',     tr:'Al-Wajid',    en:'The Finder',                 m:'The one who finds what He wills, nothing is hidden from Him.'},
  {n:66, ar:'ٱلْمَاجِد',     tr:'Al-Majid',    en:'The Noble',                  m:'The one who is noble, generous and distinguished.'},
  {n:67, ar:'ٱلْوَاحِد',     tr:'Al-Wahid',    en:'The One',                    m:'The one who is unique and singular with no partner.'},
  {n:68, ar:'ٱلْأَحَد',      tr:'Al-Ahad',     en:'The Unique',                 m:'The one who is indivisible, absolutely one in essence.'},
  {n:69, ar:'ٱلصَّمَد',      tr:'As-Samad',    en:'The Eternal',                m:'The one who is self-sufficient and upon whom all depend.'},
  {n:70, ar:'ٱلْقَادِر',     tr:'Al-Qadir',    en:'The Capable',                m:'The one who has power to do all things without limitation.'},
  {n:71, ar:'ٱلْمُقْتَدِر',  tr:'Al-Muqtadir', en:'The All-Powerful',           m:'The one who dominates all things with infinite power.'},
  {n:72, ar:'ٱلْمُقَدِّم',   tr:'Al-Muqaddim', en:'The Expediter',              m:'The one who brings forward whom He wills.'},
  {n:73, ar:'ٱلْمُؤَخِّر',   tr:'Al-Mu\'akhkhir',en:'The Delayer',              m:'The one who delays and puts back whom He wills.'},
  {n:74, ar:'ٱلْأَوَّل',     tr:'Al-Awwal',    en:'The First',                  m:'The one who existed before everything without beginning.'},
  {n:75, ar:'ٱلْآخِر',       tr:'Al-Akhir',    en:'The Last',                   m:'The one who remains after everything else has ceased.'},
  {n:76, ar:'ٱلظَّاهِر',     tr:'Az-Zahir',    en:'The Manifest',               m:'The one who is apparent through the signs of creation.'},
  {n:77, ar:'ٱلْبَاطِن',     tr:'Al-Batin',    en:'The Hidden',                 m:'The one who is hidden and cannot be perceived by senses.'},
  {n:78, ar:'ٱلْوَالِى',     tr:'Al-Wali',     en:'The Governor',               m:'The one who governs and manages all affairs of the universe.'},
  {n:79, ar:'ٱلْمُتَعَالِ',  tr:'Al-Muta\'ali',en:'The Most Exalted',           m:'The one who is supremely exalted beyond all comprehension.'},
  {n:80, ar:'ٱلْبَر',        tr:'Al-Barr',     en:'The Source of Goodness',     m:'The one who is the source of all goodness and kindness.'},
  {n:81, ar:'ٱلتَّوَّاب',    tr:'At-Tawwab',   en:'The Acceptor of Repentance', m:'The one who continually accepts sincere repentance.'},
  {n:82, ar:'ٱلْمُنْتَقِم',  tr:'Al-Muntaqim', en:'The Avenger',                m:'The one who punishes those who persist in wrongdoing.'},
  {n:83, ar:'ٱلْعَفُو',      tr:'Al-Afu',      en:'The Pardoner',               m:'The one who erases sins and wipes away their record.'},
  {n:84, ar:'ٱلرَّءُوف',     tr:'Ar-Ra\'uf',   en:'The Most Kind',              m:'The one who shows extreme tenderness and compassion.'},
  {n:85, ar:'مَالِكُ ٱلْمُلْك',tr:'Malikul Mulk',en:'Master of the Kingdom',   m:'The one who holds all sovereignty and dominion.'},
  {n:86, ar:'ذُو ٱلْجَلَال',  tr:'Dhul Jalal',  en:'Lord of Majesty',           m:'The one who possesses all glory, honor, and majesty.'},
  {n:87, ar:'ٱلْمُقْسِط',    tr:'Al-Muqsit',   en:'The Equitable',              m:'The one who is just and equitable in all His dealings.'},
  {n:88, ar:'ٱلْجَامِع',     tr:'Al-Jami\'',   en:'The Gatherer',               m:'The one who gathers all on the Day of Resurrection.'},
  {n:89, ar:'ٱلْغَنِى',      tr:'Al-Ghani',    en:'The Self-Sufficient',        m:'The one who is free of all need and completely independent.'},
  {n:90, ar:'ٱلْمُغْنِى',    tr:'Al-Mughni',   en:'The Enricher',               m:'The one who enriches and fulfills the needs of others.'},
  {n:91, ar:'ٱلْمَانِع',     tr:'Al-Mani\'',   en:'The Preventer',              m:'The one who prevents and withholds what He wills.'},
  {n:92, ar:'ٱلضَّار',       tr:'Ad-Darr',     en:'The Distresser',             m:'The one who creates adversity for whoever He wills.'},
  {n:93, ar:'ٱلنَّافِع',     tr:'An-Nafi\'',   en:'The Benefiter',              m:'The one who creates benefit and good for His servants.'},
  {n:94, ar:'ٱلنُّور',       tr:'An-Nur',      en:'The Light',                  m:'The one who is the light of the heavens and earth.'},
  {n:95, ar:'ٱلْهَادِى',     tr:'Al-Hadi',     en:'The Guide',                  m:'The one who guides His servants to the right path.'},
  {n:96, ar:'ٱلْبَدِيع',     tr:'Al-Badi\'',   en:'The Originator of all',      m:'The one who creates things of wonderful beauty and novelty.'},
  {n:97, ar:'ٱلْبَاقِى',     tr:'Al-Baqi',     en:'The Everlasting',            m:'The one who is permanent while all else passes away.'},
  {n:98, ar:'ٱلْوَارِث',     tr:'Al-Warith',   en:'The Ultimate Inheritor',     m:'The one who inherits all after everything else has perished.'},
  {n:99, ar:'ٱلرَّشِيد',     tr:'Ar-Rashid',   en:'The Guide to the Right Path',m:'The one who guides all things to their perfect destination.'},
];

// ══════════════════════════════════════════════
// SUPABASE — Cloud Sync & Auth
// ══════════════════════════════════════════════
const SUPA_URL = 'https://rpdygvfjfudhlmvqnvok.supabase.co';
const SUPA_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJwZHlndmZqZnVkaGxtdnFudm9rIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU0MDE4OTAsImV4cCI6MjA5MDk3Nzg5MH0.ZtcHxrK-_fs8GPXzRjFFfCMoowSPIbMUaloU7ildVA8';

// _supa assigned inside _supaInit after defer script loads
let _supa = null;
let _supaUser = null;
let _supaInitSyncDone = false; // prevents double-sync on app start

// -- Auth helpers --
async function supaSignUp(email, password) {
  const { data, error } = await _supa.auth.signUp({ email, password });
  if (error) throw error;
  _supaUser = data.user;
  return data;
}
async function supaSignIn(email, password) {
  const { data, error } = await _supa.auth.signInWithPassword({ email, password });
  if (error) throw error;
  _supaUser = data.user;
  return data;
}
async function supaSignOut() {
  supaStopRealtime();
  await _supa.auth.signOut();
  _supaUser = null;
}
async function supaGetSession() {
  const { data } = await _supa.auth.getSession();
  _supaUser = data?.session?.user || null;
  return _supaUser;
}

// -- Profile sync --
async function supaPushProfile(acc) {
  if (!_supaUser || !acc) return;
  const payload = {
    user_id: _supaUser.id,
    name: acc.name || '',
    avatar: acc.avatar || '',
    photo_url: acc.photoURL || '',
    joined: acc.joined || new Date().toISOString(),
    settings: appSettings || {},
    updated_at: new Date().toISOString()
  };
  const { error } = await _supa.from('user_profiles').upsert(payload, { onConflict: 'user_id' });
  if (error) console.warn('[Supa] push profile error:', error.message);
}

async function supaPullProfile() {
  if (!_supaUser) return null;
  const { data, error } = await _supa.from('user_profiles')
    .select('*').eq('user_id', _supaUser.id).single();
  if (error || !data) return null;
  // Restore account locally
  const acc = {
    name: data.name || '',
    avatar: data.avatar || '',
    photoURL: data.photo_url || '',
    joined: data.joined || new Date().toISOString(),
    initial: (data.name || '').charAt(0).toUpperCase()
  };
  saveAccount(acc);
  // Restore settings
  if (data.settings && typeof data.settings === 'object') {
    appSettings = { ...SETTINGS_DEFAULTS, ...data.settings };
    try { localStorage.setItem('mrd_settings', JSON.stringify(appSettings)); } catch {}
  }
  return acc;
}

// Auth state listener — registered lazily inside _supaInit after SDK is ready

// -- Daily data sync --
async function supaPushDay(dateKey) {
  if (!_supaUser) return;
  const isToday = dateKey === TODAY_KEY;
  // Build a complete payload — merge live vars for today, use daily[] for past
  const base = daily[dateKey] || {};
  const payload = {
    acts:          base.acts          ?? [],
    prayers:       isToday ? {...prayerDone}    : (base.prayers    || {}),
    prayerQuality: isToday ? {...prayerQuality} : (base.prayerQuality || {}),
    fasting:       isToday ? (fastingData[dateKey] ?? false) : (base.fasting ?? false),
    dhikr:         isToday ? [...dhikrCounts]   : (base.dhikr      || []),
    quranPages:    isToday ? quranData.pages     : (base.quranPages  ?? 0),
    quranGoal:     isToday ? quranData.goal      : (base.quranGoal   ?? 604),
    sunnah:        isToday ? [...sunnahDone]     : (base.sunnah      || []),
    sunnahLen:     isToday ? getSunnahList().length : (base.sunnahLen ?? 0),
    energyMood:    base.energyMood  ?? null,
    noteText:      base.noteText    ?? '',
    noteMoods:     base.noteMoods   ?? [],
    noteTags:      base.noteTags    ?? [],
    noteTs:        base.noteTs      ?? null,
    health:        (() => { try { const h = JSON.parse(localStorage.getItem('mrd_health') || '{}'); return h[dateKey] || null; } catch { return null; } })(),
  };
  // Mark this push so the realtime echo guard can suppress the bounce-back.
  // Stored at module level so it works even before realtime channel is created.
  _supaLastPushedKey = dateKey;

  const { error } = await _supa.from('daily_data').upsert({
    user_id: _supaUser.id,
    date_key: dateKey,
    payload,
    updated_at: new Date().toISOString()
  }, { onConflict: 'user_id,date_key' });
  if (error) console.warn('[Supa] push day error:', error.message);
}

async function supaPullAllDaily() {
  if (!_supaUser) return;
  const { data, error } = await _supa.from('daily_data')
    .select('date_key, payload')
    .eq('user_id', _supaUser.id)
    .order('date_key', { ascending: false })
    .limit(365);
  if (error || !data) return;
  data.forEach(row => {
    if (row.date_key === TODAY_KEY) {
      // Merge: local (live) wins for today
      daily[row.date_key] = { ...row.payload, ...daily[row.date_key] };
    } else {
      daily[row.date_key] = row.payload;
    }
    // Restore health data (per-date) from payload into mrd_health
    if (row.payload && row.payload.health) {
      try {
        const hAll = JSON.parse(localStorage.getItem('mrd_health') || '{}');
        if (!hAll[row.date_key]) {
          hAll[row.date_key] = row.payload.health;
          localStorage.setItem('mrd_health', JSON.stringify(hAll));
        }
      } catch {}
    }
  });
  try { localStorage.setItem('mrd4_daily', JSON.stringify(daily)); } catch {}
}

// -- Settings sync --
async function supaPushSettings() {
  if (!_supaUser) return;
  const fasting = JSON.parse(localStorage.getItem('mrd3_fasting') || '{}');
  const quran   = JSON.parse(localStorage.getItem('mrd3_quran')   || '{}');
  const hifzP   = JSON.parse(localStorage.getItem('mrd_qr_hifz_prog') || '{}');
  const hifzL   = JSON.parse(localStorage.getItem('mrd_qr_hifz') || '[]');

  // Extra keys that were missing from sync
  const extraKeys = [
    'mrd3_prayers', 'mrd3_pdone', 'mrd3_dhikr', 'mrd3_sunnah',
    'mrd3_custom_dhikr', 'mrd3_custom_sunnah', 'mrd3_ayah',
    'mrd3_dayacts', 'mrd3_qibla', 'mrd_qr_prog', 'mrd_qr_bm',
    'mrd_qr2', 'mrd_qr_last_open', 'mrd_pquality', 'mrd_mood_ci',
    'mrd_health', 'mrd_challenge', 'mrd_achievements', 'mrd_xp_v1',
    'pq_custom_types',
    'mrd_custom_goals_v2', 'mrd_goals_meta', 'mrd_goal_snapshots_v1'
  ];
  const extra_data = {};
  extraKeys.forEach(k => {
    const v = localStorage.getItem(k);
    if (v !== null) {
      try { extra_data[k] = JSON.parse(v); } catch { extra_data[k] = v; }
    }
  });

  const { error } = await _supa.from('user_settings').upsert({
    user_id: _supaUser.id,
    settings: appSettings || {},
    fasting_data: fasting,
    quran_data: quran,
    hifz_prog: hifzP,
    hifz_list: hifzL,
    extra_data,
    updated_at: new Date().toISOString()
  }, { onConflict: 'user_id' });
  if (error) console.warn('[Supa] push settings error:', error.message);
}

async function supaPullSettings() {
  if (!_supaUser) return;
  const { data, error } = await _supa.from('user_settings')
    .select('*').eq('user_id', _supaUser.id).single();
  if (error || !data) return;

  // Existing fields
  if (data.fasting_data && Object.keys(data.fasting_data).length) {
    fastingData = { ...data.fasting_data, ...fastingData };
    try { localStorage.setItem('mrd3_fasting', JSON.stringify(fastingData)); } catch {}
  }
  if (data.quran_data && data.quran_data.pages !== undefined) {
    try { localStorage.setItem('mrd3_quran', JSON.stringify(data.quran_data)); } catch {}
  }
  if (data.hifz_prog) {
    try { localStorage.setItem('mrd_qr_hifz_prog', JSON.stringify(data.hifz_prog)); } catch {}
  }
  if (data.hifz_list) {
    try { localStorage.setItem('mrd_qr_hifz', JSON.stringify(data.hifz_list)); } catch {}
  }

  // Restore extra_data keys (only if local is empty/missing)
  // Exception: pq_custom_types is merged (union) so custom types from all devices are combined
  if (data.extra_data && typeof data.extra_data === 'object') {
    Object.entries(data.extra_data).forEach(([k, v]) => {
      if (k === 'pq_custom_types') {
        // Merge arrays — union of local + cloud, deduplicate case-insensitively
        try {
          const local = JSON.parse(localStorage.getItem('pq_custom_types') || '[]');
          const cloud = Array.isArray(v) ? v : [];
          const merged = [...local];
          cloud.forEach(ct => {
            if (!merged.some(m => m.toLowerCase() === ct.toLowerCase())) merged.push(ct);
          });
          localStorage.setItem('pq_custom_types', JSON.stringify(merged));
        } catch {}
      } else if (localStorage.getItem(k) === null) {
        try { localStorage.setItem(k, JSON.stringify(v)); } catch {}
      }
    });
  }

  // Restore appSettings from cloud if present
  if (data.settings && Object.keys(data.settings).length) {
    appSettings = { ...SETTINGS_DEFAULTS, ...data.settings, ...appSettings };
    try { localStorage.setItem('mrd_settings', JSON.stringify(appSettings)); } catch {}
  }
}

// -- Full sync (login / app start) --
async function supaFullSync() {
  if (!_supaUser) return;
  try {
    // Snapshot today's data BEFORE pulling so we can detect real changes
    const _beforeToday = JSON.stringify(daily[TODAY_KEY] || {});

    await supaPullSettings();
    await supaPullAllDaily();

    // Only re-render home widgets if today's data actually changed from cloud.
    // This prevents a full home repaint (visible blink) when sync finds no new data.
    const _afterToday = JSON.stringify(daily[TODAY_KEY] || {});
    if (_beforeToday !== _afterToday) {
      try { if(typeof renderAllForDate==='function') renderAllForDate(TODAY_KEY); } catch{}
    }

    // Stats re-render is non-visible so always update
    try { if(typeof renderStats==='function') renderStats(); } catch{}

    showSettingsToast('☁️ Cloud sync complete');
    // Refresh cloud sync card if settings view open
    const card = document.getElementById('supa-auth-card');
    if (card) card.innerHTML = _supaLoggedInHTML();
    _renderCloudTopCard();
    // Start realtime listeners after full sync
    supaStartRealtime();
  } catch(e) {
    console.warn('[Supa] fullSync error:', e.message);
  }
}
// -- Realtime sync --
let _supaRealtimeChannel = null;
let _supaLastPushedKey = null; // echo-suppression key — set before every upsert

function supaStartRealtime() {
  if (!_supaUser) return;
  // Remove existing channel if any (e.g. re-login)
  if (_supaRealtimeChannel) {
    _supa.removeChannel(_supaRealtimeChannel);
    _supaRealtimeChannel = null;
  }

  _supaRealtimeChannel = _supa
    .channel('realtime:user_' + _supaUser.id)

    // daily_data changes
    .on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'daily_data',
      filter: 'user_id=eq.' + _supaUser.id
    }, async (payload) => {
      // Ignore if this device just pushed (avoid echo loop)
      if (_supaLastPushedKey === payload.new?.date_key) {
        _supaLastPushedKey = null;
        return;
      }
      const row = payload.new;
      if (!row?.date_key || !row?.payload) return;
      const key = row.date_key;
      // Snapshot before merge so we can skip re-render if nothing changed
      const _beforeSnap = JSON.stringify(daily[key] || {});
      if (key === TODAY_KEY) {
        // Merge: remote fills in anything missing locally
        daily[key] = { ...row.payload, ...daily[key] };
      } else {
        daily[key] = row.payload;
      }
      const _afterSnap = JSON.stringify(daily[key] || {});
      try { localStorage.setItem('mrd4_daily', JSON.stringify(daily)); } catch {}
      // Only re-render if data actually changed — avoids blink on own-echo
      if (_beforeSnap === _afterSnap) return;
      // Re-render whichever date the user is currently viewing
      // Use selective renders to avoid full innerHTML wipe blink
      try {
        if (typeof viewingDate !== 'undefined' && viewingDate === key) {
          const prev = JSON.parse(_beforeSnap);
          const next = daily[key];
          // Only call each render if its specific data changed
          if (JSON.stringify(prev.prayers) !== JSON.stringify(next.prayers) ||
              JSON.stringify(prev.prayerQuality) !== JSON.stringify(next.prayerQuality)) {
            if (typeof renderPrayers === 'function') renderPrayers();
          }
          if (JSON.stringify(prev.dhikr) !== JSON.stringify(next.dhikr)) {
            if (typeof renderDhikrCard === 'function') renderDhikrCard();
            if (typeof renderDhikrTabs === 'function') renderDhikrTabs();
          }
          if (prev.fasting !== next.fasting) {
            if (typeof renderFasting === 'function') renderFasting();
          }
          if (prev.quranPages !== next.quranPages || prev.quranGoal !== next.quranGoal) {
            if (typeof renderQuran === 'function') renderQuran();
          }
          if (JSON.stringify(prev.sunnah) !== JSON.stringify(next.sunnah)) {
            if (typeof renderSunnah === 'function') renderSunnah();
          }
          if (JSON.stringify(prev.acts) !== JSON.stringify(next.acts)) {
            if (typeof renderList === 'function') renderList();
          }
          // KPI always updates (it's already diff-patched, no flash)
          if (typeof renderKPI === 'function') renderKPI();
        }
        if (typeof renderStats === 'function') renderStats();
        if (typeof renderDateStrip === 'function') renderDateStrip();
      } catch {}
    })

    // user_settings changes
    .on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'user_settings',
      filter: 'user_id=eq.' + _supaUser.id
    }, async (payload) => {
      const data = payload.new;
      if (!data) return;
      // Restore settings
      if (data.settings && Object.keys(data.settings).length) {
        appSettings = { ...SETTINGS_DEFAULTS, ...data.settings };
        try { localStorage.setItem('mrd_settings', JSON.stringify(appSettings)); } catch {}
        try { if (typeof applySettings === 'function') applySettings(); } catch {}
      }
      // Restore fasting
      if (data.fasting_data && Object.keys(data.fasting_data).length) {
        fastingData = { ...data.fasting_data, ...fastingData };
        try { localStorage.setItem('mrd3_fasting', JSON.stringify(fastingData)); } catch {}
        try { if (typeof renderFasting === 'function') renderFasting(); } catch {}
      }
      // Restore quran
      if (data.quran_data && data.quran_data.pages !== undefined) {
        try { localStorage.setItem('mrd3_quran', JSON.stringify(data.quran_data)); } catch {}
        try { if (typeof renderQuran === 'function') renderQuran(); } catch {}
      }
      // Restore extra_data keys (custom dhikrs, sunnah, ayah, etc.)
      if (data.extra_data && typeof data.extra_data === 'object') {
        Object.entries(data.extra_data).forEach(([k, v]) => {
          try { localStorage.setItem(k, JSON.stringify(v)); } catch {}
        });
        // Re-render affected sections
        try { if (typeof renderDhikrTabs === 'function') renderDhikrTabs(); } catch {}
        try { if (typeof renderSunnah === 'function') renderSunnah(); } catch {}
      }
    })

    .subscribe((status) => {
      if (status === 'SUBSCRIBED') {
        console.log('[Supa] Realtime connected ✓');
      }
    });
}

function supaStopRealtime() {
  if (_supaRealtimeChannel) {
    _supa.removeChannel(_supaRealtimeChannel);
    _supaRealtimeChannel = null;
  }
}

// -- Auth UI helpers --
function _supaLoggedInHTML() {
  return `
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
      <div style="width:38px;height:38px;border-radius:50%;background:rgba(var(--accent-rgb),.18);display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0">☁️</div>
      <div style="min-width:0">
        <div style="font-size:0.8125rem;font-weight:600;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${_supaUser.email}</div>
        <div style="font-size:0.6875rem;color:var(--green);margin-top:2px">✓ Synced to cloud</div>
      </div>
    </div>
    <div style="display:flex;gap:8px">
      <button onclick="supaFullSync()" style="flex:1;padding:10px;border-radius:12px;background:rgba(var(--teal-rgb),.1);border:1px solid rgba(var(--teal-rgb),.25);color:var(--teal);font-family:'Manrope',sans-serif;font-size:0.75rem;cursor:pointer;-webkit-tap-highlight-color:transparent">↻ Sync Now</button>
      <button onclick="supaSignOut().then(()=>{renderSettingsView();showSettingsToast('Signed out')})" style="flex:1;padding:10px;border-radius:12px;background:rgba(var(--rose-rgb),.08);border:1px solid rgba(var(--rose-rgb),.2);color:var(--rose);font-family:'Manrope',sans-serif;font-size:0.75rem;cursor:pointer;-webkit-tap-highlight-color:transparent">Sign Out</button>
    </div>`;
}

function _supaAuthFormHTML() {
  return `
    <div style="margin-bottom:14px">
      <div style="font-size:0.875rem;font-weight:600;color:var(--text);margin-bottom:4px">☁️ Cloud Backup & Sync</div>
      <div style="font-size:0.6875rem;color:var(--t3);line-height:1.5">Sign in to sync your data across devices and keep an automatic cloud backup.</div>
    </div>
    <input id="supa-email" type="email" placeholder="Email address" autocomplete="email"
      style="width:100%;padding:11px 14px;border-radius:12px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:var(--text);font-family:'Manrope',sans-serif;font-size:0.8125rem;margin-bottom:8px;outline:none;-webkit-appearance:none">
    <input id="supa-pass" type="password" placeholder="Password" autocomplete="current-password"
      style="width:100%;padding:11px 14px;border-radius:12px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:var(--text);font-family:'Manrope',sans-serif;font-size:0.8125rem;margin-bottom:12px;outline:none;-webkit-appearance:none">
    <div style="display:flex;gap:8px">
      <button onclick="_supaAuthAction('signin')" style="flex:1;padding:10px;border-radius:12px;background:rgba(var(--accent-rgb),.15);border:1px solid rgba(var(--accent-rgb),.3);color:var(--gold);font-family:'Manrope',sans-serif;font-size:0.75rem;cursor:pointer;-webkit-tap-highlight-color:transparent">Sign In</button>
      <button onclick="_supaAuthAction('signup')" style="flex:1;padding:10px;border-radius:12px;background:rgba(var(--teal-rgb),.1);border:1px solid rgba(var(--teal-rgb),.2);color:var(--teal);font-family:'Manrope',sans-serif;font-size:0.75rem;cursor:pointer;-webkit-tap-highlight-color:transparent">Create Account</button>
    </div>
    <div id="supa-auth-err" style="font-size:0.6875rem;color:var(--rose);margin-top:8px;min-height:16px;text-align:center"></div>`;
}

async function _supaAuthAction(type) {
  const email = document.getElementById('supa-email')?.value?.trim();
  const pass  = document.getElementById('supa-pass')?.value;
  const err   = document.getElementById('supa-auth-err');
  if (!email || !pass) {
    if(err) err.textContent = 'Email ও password দাও';
    return;
  }
  if(err) err.textContent = type === 'signup' ? 'Creating account...' : 'Signing in...';
  try {
    if (type === 'signup') await supaSignUp(email, pass);
    else await supaSignIn(email, pass);
    const card = document.getElementById('supa-auth-card');
    if(card) card.innerHTML = _supaLoggedInHTML();
    showSettingsToast('✓ ' + (type === 'signup' ? 'Account created! Check email.' : 'Signed in!'));
    supaFullSync();
  } catch(e) {
    if(err) err.textContent = e.message || 'Something went wrong';
  }
}

// Critical constants hoisted to prevent TDZ errors
const VIEW_ORDER    = ['today','explore','stats','settings'];
const ACCOUNT_KEY   = 'mrd_account';
const OB_EMOJIS     = ['🌙','⭐','☪️','🤲','📿','🕌','🌿','🦋','🌺','✨','🌸','💎','🔥','🌊','🕊️','🧭'];
let obSelectedEmoji = '🌙';
let obCurrentStep   = 0;
const EXPAND_KEY      = 'mrd_expand';
const EXPAND_DEFAULTS = {'exp-mood':false,'exp-ayah':false,'exp-notes':false,'exp-dua':false,'exp-qibla':false,'exp-asma':false,'exp-challenge':false,'exp-achievements':false,'exp-quran-player':false};
const DHIKR_BUILTIN = [
  {ar:'سُبْحَانَ اللّٰهِ',          tr:'Subhanallah',       target:33,  custom:false},
  {ar:'الْحَمْدُ لِلّٰهِ',          tr:'Alhamdulillah',     target:33,  custom:false},
  {ar:'اللّٰهُ أَكْبَرُ',           tr:'Allahu Akbar',      target:34,  custom:false},
  {ar:'لَا إِلَٰهَ إِلَّا اللّٰهُ', tr:'La ilaha illallah', target:100, custom:false},
  {ar:'أَسْتَغْفِرُ اللّٰهَ',       tr:'Astaghfirullah',    target:100, custom:false},
];

// Suggested daily activities shown as quick-add chips
const DEFAULT_ACTIVITIES = [
  // ── Islamic essentials ──
  { icon:'📖', name:'Read Quran',        meta:'Daily recitation',               color:'#c9a96e' },
  { icon:'🌅', name:'Morning Adhkar',    meta:'Dua & remembrance after Fajr',   color:'var(--gold2)' },
  { icon:'🌙', name:'Evening Adhkar',    meta:'Dua & remembrance after Asr',    color:'#7b9fe0' },
  { icon:'🤲', name:'Tahajjud',          meta:'Night voluntary prayer',         color:'#ffb74d' },
  { icon:'📿', name:'Extra Dhikr',       meta:'Beyond daily count',             color:'#c9a96e' },
  { icon:'🧠', name:'Islamic Study',     meta:'Deepen your knowledge',          color:'#e07b8a' },
  { icon:'🕌', name:'Attend Masjid',     meta:'Pray in congregation',           color:'#c9a96e' },
  { icon:'📜', name:'Memorise Quran',    meta:'Hifz practice today',            color:'var(--gold2)' },
  { icon:'🤝', name:'Help Someone',      meta:'Act of kindness today',          color:'#e07b8a' },
  { icon:'💸', name:'Give Sadaqah',      meta:'Charity — even a smile counts',  color:'var(--green)' },
  { icon:'☎️', name:'Call Family',       meta:'Maintain family ties (Silah)',   color:'#5bbfb5' },
  { icon:'🍽️', name:'Suhoor/Iftar',     meta:'Blessed meals',                  color:'var(--green)' },
  { icon:'🙏', name:'Duha Prayer',       meta:'2–12 rakat after sunrise',       color:'#ffb74d' },
  { icon:'🌿', name:'Read Islamic Book', meta:'Grow in knowledge of Deen',      color:'#82c784' },
  { icon:'✋', name:'Avoid Haram',       meta:'Lower gaze, guard tongue',       color:'#ce93d8' },
  { icon:'🤍', name:'Make Istighfar',    meta:'Seek forgiveness 100×',          color:'#7b9fe0' },
  // ── Health & body ──
  { icon:'🚶', name:'Morning Walk',      meta:'Start the day active',           color:'#5bbfb5' },
  { icon:'💧', name:'Drink Water',       meta:'8 glasses a day',                color:'#7b9fe0' },
  { icon:'💪', name:'Exercise',          meta:'Stay physically healthy',        color:'var(--green)' },
  { icon:'🥗', name:'Healthy Eating',    meta:'Nourish your body',              color:'#82c784' },
  { icon:'🛌', name:'Good Sleep',        meta:'Sleep before midnight',          color:'#5bbfb5' },
  { icon:'🚴', name:'Cycling',           meta:'Cardio & fresh air',             color:'#5bbfb5' },
  { icon:'🧘', name:'Stretching',        meta:'Flexibility & recovery',         color:'#ce93d8' },
  { icon:'🍎', name:'Eat Fruit',         meta:'A daily sunnah habit',           color:'#82c784' },
  { icon:'😴', name:'Power Nap',         meta:'Qailulah — Sunnah midday rest',  color:'#7b9fe0' },
  { icon:'🚫', name:'No Junk Food',      meta:'Guard your health',              color:'#e07b8a' },
  // ── Mind & growth ──
  { icon:'📚', name:'Study / Learn',     meta:'Seek beneficial knowledge',      color:'#ffb74d' },
  { icon:'✍️', name:'Journaling',        meta:'Reflect on your day',            color:'#ce93d8' },
  { icon:'🧠', name:'Deep Work',         meta:'Focused, undistracted session',  color:'#e07b8a' },
  { icon:'📰', name:'Read a Book',       meta:'30 min of reading',              color:'#ffb74d' },
  { icon:'🎯', name:'Review Goals',      meta:'Track your progress',            color:'#5bbfb5' },
  { icon:'🗂️', name:'Plan Tomorrow',    meta:'Set intentions the night before',color:'#7b9fe0' },
  { icon:'📵', name:'Screen-Free Hour',  meta:'Disconnect to reconnect',        color:'#ce93d8' },
  { icon:'🌱', name:'Learn a New Skill', meta:'Consistent growth',              color:'var(--green)' },
  // ── Productivity & chores ──
  { icon:'🧹', name:'Clean Home',        meta:'Cleanliness is from Iman',       color:'#5bbfb5' },
  { icon:'🛒', name:'Groceries / Errands',meta:'Take care of responsibilities', color:'#ffb74d' },
  { icon:'📧', name:'Clear Inbox',       meta:'Stay on top of messages',        color:'#7b9fe0' },
  { icon:'💼', name:'Work Task',         meta:'Key priority for the day',       color:'#c9a96e' },
  { icon:'🍳', name:'Cook a Meal',       meta:'Eat well, eat halal',            color:'#82c784' },
  { icon:'💰', name:'Track Finances',    meta:'Spend wisely, give generously',  color:'var(--green)' },
];

// ==============================================
// CONSTANTS & UTILS
// ==============================================
const ICONS  = ['🏃','🧘','💪','📚','🎨','🎵','🥗','💧','🌿','🛌','✍️','🧠','🚴','🤸','🍳','🧪','🕌','📿','☪️','🌙'];
const COLORS = ['#5bbfb5','#c9a96e','#e07b8a','#7b9fe0','#82c784','#ce93d8','#ffb74d','#d4d4d4'];
const BARCOL = ['#5bbfb5','#7b9fe0','#c9a96e','#82c784','#ce93d8','#e07b8a','#ffb74d'];
const PRAYERS = ['Fajr','Dhuhr','Asr','Maghrib','Isha'];

let pIcon = ICONS[0], pColor = COLORS[0];

const now = new Date();

function dateKey(d) {
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
function ha(hex, a) {
  const r=parseInt(hex.slice(1,3),16), g=parseInt(hex.slice(3,5),16), b=parseInt(hex.slice(5,7),16);
  return `rgba(${r},${g},${b},${a})`;
}
function fmtTime(t) {
  if(!t) return '--:--';
  const [h,m] = t.split(':').map(Number);
  const ampm = h>=12?'PM':'AM';
  return `${h%12||12}:${String(m).padStart(2,'0')} ${ampm}`;
}
function fmtTimeParts(t) {
  if(!t) return { main:'—', suffix:'' };
  const [h,m] = t.split(':').map(Number);
  return {
    main: `${h%12||12}:${String(m).padStart(2,'0')}`,
    suffix: h>=12 ? 'PM' : 'AM'
  };
}
function setClockFastTime(el, t) {
  if(!el) return;
  if(!t) {
    el.textContent = '—';
    el.classList.add('muted');
    return;
  }
  const parts = fmtTimeParts(t);
  el.innerHTML = `<span class="clock-fast-time-main">${parts.main}</span><span class="clock-fast-time-suffix">${parts.suffix}</span>`;
  el.classList.remove('muted');
}
function minsSinceMidnight(t) {
  if(!t) return -1;
  const [h,m] = t.split(':').map(Number);
  return h*60+m;
}

// ==============================================
// STATE LOADERS
// ==============================================
const TODAY_KEY = dateKey(now);

// -- Unified daily snapshot store --------------
// mrd4_daily[date] = { acts[], prayers{}, fasting, dhikr[], quranPages }
function loadDaily() {
  try { const r=localStorage.getItem('mrd4_daily'); if(r) return JSON.parse(r); } catch{}
  return {};
}

// -- Per-day activities (still separate for date-strip UI) --
function loadDayActs() {
  // Migrate from mrd4_daily if it has acts
  const daily = loadDaily();
  const merged = {};
  Object.keys(daily).forEach(k => { if(daily[k].acts) merged[k] = daily[k].acts; });
  // Also check old key
  try { const r=localStorage.getItem('mrd3_dayacts'); if(r) {
    const old = JSON.parse(r);
    Object.keys(old).forEach(k => { if(!merged[k]) merged[k] = old[k]; });
  }} catch{}
  return merged;
}

function loadPrayers() {
  try { const r=localStorage.getItem('mrd3_prayers'); if(r) return JSON.parse(r); } catch{}
  return {Fajr:'05:00',Sunrise:'06:15',Dhuhr:'12:30',Asr:'15:45',Maghrib:'18:15',Isha:'20:00'};
}
function loadPrayerDone() {
  // Check unified daily first
  try {
    const daily = loadDaily();
    if(daily[TODAY_KEY]?.prayers) return daily[TODAY_KEY].prayers;
  } catch{}
  try {
    const r=localStorage.getItem('mrd3_pdone'); if(r){
      const p=JSON.parse(r);
      if(p.date===TODAY_KEY) return p.done;
    }
  } catch{}
  return {Fajr:false,Dhuhr:false,Asr:false,Maghrib:false,Isha:false};
}

function loadPrayerQuality() {
  try {
    const daily = loadDaily();
    if(daily[TODAY_KEY]?.prayerQuality) return daily[TODAY_KEY].prayerQuality;
  } catch{}
  try {
    const r = localStorage.getItem('mrd_pquality');
    if(r) { const p=JSON.parse(r); if(p.date===TODAY_KEY) return p.quality; }
  } catch{}
  return {Fajr:null,Dhuhr:null,Asr:null,Maghrib:null,Isha:null};
}

function savePrayerQuality() {
  try { localStorage.setItem('mrd_pquality', JSON.stringify({date:TODAY_KEY,quality:prayerQuality})); } catch{}
}
function loadDhikr() {
  try {
    const daily = loadDaily();
    if(daily[TODAY_KEY]?.dhikr) return daily[TODAY_KEY].dhikr;
  } catch{}
  try {
    const r=localStorage.getItem('mrd3_dhikr'); if(r){
      const p=JSON.parse(r);
      if(p.date===TODAY_KEY) return p.counts;
    }
  } catch{}
  return DHIKR_BUILTIN.map(()=>0); // sized to built-ins at init; extended lazily in renderDhikrCard
}
function loadFasting() {
  try { const r=localStorage.getItem('mrd3_fasting'); if(r) return JSON.parse(r); } catch{}
  const f={};
  for(let i=6;i>=0;i--){
    const d=new Date(now); d.setDate(d.getDate()-i);
    f[dateKey(d)]=false;
  }
  return f;
}
function loadQuran() {
  try { const r=localStorage.getItem('mrd3_quran'); if(r) return JSON.parse(r); } catch{}
  return {pages:0, goal:604};
}

let daily        = loadDaily();       // unified { date: {acts,prayers,fasting,dhikr,quranPages} }
let dayActs      = loadDayActs();     // { date: acts[] } — for date-strip UI
let prayerTimes  = loadPrayers();
let prayerDone    = loadPrayerDone();
let prayerQuality = loadPrayerQuality();
let dhikrCounts  = loadDhikr();
let fastingData  = loadFasting();
let quranData    = loadQuran();
let activeDhikr  = 0;
let viewingDate  = TODAY_KEY;

function getActs(key){ return dayActs[key] || []; }
function setActs(key, arr){ dayActs[key] = arr; if(!daily[key]) daily[key]={}; daily[key].acts = arr; }
function todayActs(){ return getActs(TODAY_KEY); }

// ==============================================
// UNIFIED DAILY SAVE
// ==============================================
// mrd4_daily[date] = { acts[], prayers{}, fasting, dhikr[], quranPages, quranGoal }

function saveDay(key) {
  if(!daily[key]) daily[key] = {};
  daily[key].acts          = dayActs[key] || [];
  daily[key].prayers       = key === TODAY_KEY ? {...prayerDone}      : (daily[key].prayers || {});
  daily[key].prayerQuality = key === TODAY_KEY ? {...prayerQuality}   : (daily[key].prayerQuality || {});
  daily[key].fasting       = fastingData[key] || false;
  daily[key].dhikr         = key === TODAY_KEY ? [...dhikrCounts]     : (daily[key].dhikr   || []);
  daily[key].quranPages    = key === TODAY_KEY ? quranData.pages      : (daily[key].quranPages || 0);
  daily[key].quranGoal     = key === TODAY_KEY ? quranData.goal       : (daily[key].quranGoal  || 604);
  daily[key].sunnah        = key === TODAY_KEY ? [...sunnahDone]      : (daily[key].sunnah   || []);
  daily[key].sunnahLen     = key === TODAY_KEY ? getSunnahList().length : (daily[key].sunnahLen || 0);
  daily[key].energyMood    = key === TODAY_KEY ? (daily[key].energyMood ?? null) : (daily[key].energyMood ?? null);
  // Note fields are saved directly via saveNote() - preserve them here
  daily[key].noteText   = daily[key]?.noteText  ?? '';
  daily[key].noteMoods  = daily[key]?.noteMoods ?? [];
  daily[key].noteTags   = daily[key]?.noteTags  ?? [];
  daily[key].noteTs     = daily[key]?.noteTs    ?? null;
  try { localStorage.setItem('mrd4_daily', JSON.stringify(daily)); } catch{}
}

function persist() {
  saveDay(TODAY_KEY);
  // also keep dayActs synced for date-strip
  try { localStorage.setItem('mrd3_dayacts', JSON.stringify(dayActs)); } catch{}
  // stamp last-save timestamp for settings view
  if(typeof stampLastSave === 'function') stampLastSave();
  // refresh home extras (score pill, dhikr total)
  if(typeof refreshHomeExtras === 'function') refreshHomeExtras();
  renderWaterTracker();
  renderStreakRow();
  // check for milestone celebrations
  if(typeof checkMilestones === 'function') checkMilestones();
  // ☁️ Supabase debounced push
  clearTimeout(persist._supaTimer);
  persist._supaTimer = setTimeout(() => { supaPushDay(TODAY_KEY); }, 3000);
}

// Universal persist for any date key (today OR past)
function persistDay(key) {
  if(!daily[key]) daily[key] = {};
  daily[key].acts       = dayActs[key] || [];
  // For today, also sync live vars
  if(key === TODAY_KEY) {
    daily[key].prayers       = {...prayerDone};
    daily[key].prayerQuality = {...prayerQuality};
    daily[key].fasting    = fastingData[TODAY_KEY] || false;
    daily[key].dhikr      = [...dhikrCounts];
    daily[key].quranPages = quranData.pages;
    daily[key].quranGoal  = quranData.goal;
    daily[key].sunnah     = [...sunnahDone];
    daily[key].sunnahLen  = getSunnahList().length;
  }
  // Preserve note/mood fields for ALL dates (never overwrite with empty)
  daily[key].noteText  = daily[key].noteText  ?? '';
  daily[key].noteMoods = daily[key].noteMoods ?? [];
  daily[key].noteTags  = daily[key].noteTags  ?? [];
  daily[key].noteTs    = daily[key].noteTs    ?? null;
  daily[key].energyMood = daily[key].energyMood ?? null;
  try { localStorage.setItem('mrd4_daily', JSON.stringify(daily)); } catch{}
  try { localStorage.setItem('mrd3_dayacts', JSON.stringify(dayActs)); } catch{}
  if(typeof stampLastSave === 'function') stampLastSave();
  // ☁️ Supabase debounced push for any date (today or past)
  if(!persistDay._supaTimers) persistDay._supaTimers = {};
  clearTimeout(persistDay._supaTimers[key]);
  persistDay._supaTimers[key] = setTimeout(() => { supaPushDay(key); }, 3000);
}

function persistPrayerDone() { daily[TODAY_KEY] = daily[TODAY_KEY]||{}; persist(); setTimeout(checkAchievements, 300); }
function persistDhikr()      { persist(); setTimeout(checkAchievements, 300); }
function persistFasting()    {
  try { localStorage.setItem('mrd3_fasting', JSON.stringify(fastingData)); } catch{}
  // update fasting in daily for each changed key
  Object.keys(fastingData).forEach(k => {
    if(!daily[k]) daily[k] = {};
    daily[k].fasting = fastingData[k];
    // ☁️ push each changed date to Supabase
    if(!persistFasting._supaTimers) persistFasting._supaTimers = {};
    clearTimeout(persistFasting._supaTimers[k]);
    persistFasting._supaTimers[k] = setTimeout(() => { supaPushDay(k); }, 3000);
  });
  try { localStorage.setItem('mrd4_daily', JSON.stringify(daily)); } catch{}
}
function persistQuran()      { persist(); }

// -- Composite score for a date -----------------
// Returns 0-100 combining: activities, prayers, fasting, dhikr, quran
function calcDayScore(key) {
  const snap = daily[key];
  const isToday = key === TODAY_KEY;

  // Activities
  const acts = isToday ? todayActs() : (snap?.acts || []);
  const actPct = acts.length ? (acts.filter(a=>a.done).length / acts.length) : 0;

  // Prayers
  const prayers = isToday ? prayerDone : (snap?.prayers || {});
  const prayerPct = Object.values(prayers).filter(Boolean).length / 5;

  // Fasting
  const fasted = isToday ? (fastingData[key]||false) : (snap?.fasting || false);
  const fastPct = fasted ? 1 : 0;

  // Dhikr
  const dhikr = isToday ? dhikrCounts : (snap?.dhikr || []);
  const dhikrPct = dhikr.length
    ? dhikr.reduce((sm,c,i) => sm + Math.min(c/(getDhikrList()[i]?.target||33), 1), 0) / dhikr.length
    : 0;

  // Quran
  const qPages = isToday ? quranData.pages : (snap?.quranPages || 0);
  const qGoal  = isToday ? quranData.goal  : (snap?.quranGoal  || 604);
  const quranPct = qGoal ? Math.min(qPages / qGoal, 1) : 0;

  // Sunnah
  const sunnah    = isToday ? sunnahDone      : (snap?.sunnah    || []);
  const sunnahLen = isToday ? getSunnahList().length : (snap?.sunnahLen || sunnah.length || 1);
  const sunnahPct = sunnahLen ? (sunnah.filter(Boolean).length / sunnahLen) : 0;

  // Takbir-ul-Ula bonus
  const _pq = isToday ? prayerQuality : (snap?.prayerQuality || {});
  const _pd = isToday ? prayerDone    : (snap?.prayers || {});
  const _takbirCount = ['Fajr','Dhuhr','Asr','Maghrib','Isha'].filter(p => _pd[p] && _pq[p] === 'takbir').length;
  const _takbirPct   = _takbirCount / 5;

  // Fixed weights: prayer 25, acts 20, sunnah 15, dhikr 15, quran 15, fasting 10
  return Math.round(prayerPct*15 + _takbirPct*10 + actPct*20 + sunnahPct*15 + dhikrPct*15 + quranPct*15 + fastPct*10);
}

// Individual category percentages for a date (for stacked bar)
function calcDayBreakdown(key) {
  const snap = daily[key];
  const isToday = key === TODAY_KEY;

  const actsRaw    = isToday ? todayActs() : (snap?.acts || []);
  const acts       = actsRaw.filter(a => !a.hidden);           // exclude hidden
  const actPct     = acts.length ? (acts.filter(a=>a.done).length / acts.length * 100) : 0;

  const prayers = isToday ? prayerDone : (snap?.prayers || {});
  const prayerPct = Object.values(prayers).filter(Boolean).length / 5 * 100;

  const fasted = isToday ? (fastingData[key]||false) : (snap?.fasting || false);
  const fastPct = fasted ? 100 : 0;

  const dhikr = isToday ? dhikrCounts : (snap?.dhikr || []);
  const dhikrPct = dhikr.length
    ? dhikr.reduce((s,c,i) => s + Math.min(c/(getDhikrList()[i]?.target||33), 1), 0) / dhikr.length * 100
    : 0;

  const qPages = isToday ? quranData.pages : (snap?.quranPages || 0);
  const qGoal  = isToday ? quranData.goal  : (snap?.quranGoal  || 604);
  const quranPct = qGoal ? Math.min(qPages / qGoal * 100, 100) : 0;

  const sunnah    = isToday ? sunnahDone      : (snap?.sunnah    || []);
  const sunnahLen = isToday ? getSunnahList().length : (snap?.sunnahLen || sunnah.length || 1);
  const sunnahPct = sunnahLen ? Math.min(sunnah.filter(Boolean).length / sunnahLen * 100, 100) : 0;

  // Takbir-ul-Ula: count prayers with 'takbir' quality out of 5
  const pq = isToday ? prayerQuality : (snap?.prayerQuality || {});
  const PRAYER_NAMES = ['Fajr','Dhuhr','Asr','Maghrib','Isha'];
  const prDone = isToday ? prayerDone : (snap?.prayers || {});
  const takbirCount = PRAYER_NAMES.filter(p => prDone[p] && pq[p] === 'takbir').length;
  const takbirPct   = takbirCount / 5 * 100;

  return { actPct, prayerPct, fastPct, dhikrPct, quranPct, sunnahPct, takbirPct, takbirCount };
}

function syncHist(){
  // no-op: score now calculated live from daily snapshot
}

// ==============================================
// HIJRI DATE SYSTEM
// ==============================================
const HIJRI_MONTHS_EN = ['Muharram','Safar','Rabi al-Awwal','Rabi al-Thani','Jumada al-Ula','Jumada al-Thani','Rajab',"Sha'ban",'Ramadan','Shawwal',"Dhu al-Qi'dah",'Dhu al-Hijjah'];
const HIJRI_MONTHS_AR = ['مُحَرَّم','صَفَر','رَبِيعُ الأَوَّل','رَبِيعُ الثَّانِي','جُمَادَى الأُولَى','جُمَادَى الثَّانِيَة','رَجَب','شَعْبَان','رَمَضَان','شَوَّال','ذُو القَعْدَة','ذُو الحِجَّة'];

function toHijriObj(date) {
  const jd = Math.floor((date.getTime()/86400000)+2440587.5);
  const l = jd - 1948440 + 10632;
  const n = Math.floor((l-1)/10631);
  const l2 = l - 10631*n + 354;
  const j = Math.floor((10985-l2)/5316)*Math.floor((50*l2)/17719) + Math.floor(l2/5670)*Math.floor((43*l2)/15238);
  const l3 = l2 - Math.floor((30-j)/15)*Math.floor((17719*j)/50) - Math.floor(j/16)*Math.floor((15238*j)/43) + 29;
  const month = Math.floor((24*l3)/709);
  const day = l3 - Math.floor((709*month)/24);
  const year = 30*n + j - 30;
  return { day, month, year };
}

// Hijri date aware of Maghrib — Islamic day starts at Maghrib
function getHijriForDisplay(gregorianDate) {
  // Parse Maghrib time from stored prayer times
  const maghribStr = (prayerTimes && prayerTimes.Maghrib) ? prayerTimes.Maghrib : '18:15';
  const [mh, mm] = maghribStr.split(':').map(Number);
  const now = new Date();
  const maghribMins = mh * 60 + mm;
  const nowMins     = now.getHours() * 60 + now.getMinutes();

  // If we're past Maghrib today, the Islamic date has already advanced
  // So compute Hijri for tomorrow's Gregorian date
  const refDate = new Date(gregorianDate);
  if(nowMins >= maghribMins) {
    refDate.setDate(refDate.getDate() + 1);
  }
  return toHijriObj(refDate);
}
function toHijri(date) {
  const h = toHijriObj(date);
  return `${h.day} ${HIJRI_MONTHS_EN[h.month-1]} ${h.year} AH`;
}
function toHijriArabic(date) {
  const h = toHijriObj(date);
  // Arabic-Indic numerals
  const toArabicNum = n => String(n).replace(/[0-9]/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
  return `${toArabicNum(h.day)} ${HIJRI_MONTHS_AR[h.month-1]} ${toArabicNum(h.year)} هـ`;
}

// Live realtime clock updating badge every minute
function updateHijriBadge() {
  // legacy hijri-badge (may not exist anymore)
  const badge = document.getElementById('hdr-hijri-en');
  if(badge) {
    // Use Maghrib-aware date
    const now = new Date();
    const h   = getHijriForDisplay(now);
    const toAr = n => String(n).replace(/[0-9]/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
    const hAr = `${toAr(h.day)} ${HIJRI_MONTHS_AR[h.month-1]} ${toAr(h.year)} هـ`;
    const hEn = `${h.day} ${HIJRI_MONTHS_EN[h.month-1]} ${h.year} AH`;
    badge.innerHTML = `🌙 <span title="${hEn}" style="direction:rtl;unicode-bidi:embed">${hAr}</span>`;
  }
  // Update the header English hijri date
  if(typeof renderIslamicDayBadge === 'function') renderIslamicDayBadge();
}
updateHijriBadge();
setInterval(updateHijriBadge, 60000);

// ==============================================
// LIVE CLOCK + PRAYER COUNTDOWN
// ==============================================
function getPrayerBoundaries() {
  const fajr = minsSinceMidnight(prayerTimes.Fajr);
  const sunriseRaw = minsSinceMidnight(prayerTimes.Sunrise);
  const sunrise = sunriseRaw >= 0 ? sunriseRaw : (fajr >= 0 ? fajr + 90 : -1);
  const dhuhr = minsSinceMidnight(prayerTimes.Dhuhr);
  const asr = minsSinceMidnight(prayerTimes.Asr);
  const maghrib = minsSinceMidnight(prayerTimes.Maghrib);
  const isha = minsSinceMidnight(prayerTimes.Isha);
  return { fajr, sunrise, dhuhr, asr, maghrib, isha };
}

function getCurrentPrayerState(date = new Date()) {
  const nowMins = date.getHours() * 60 + date.getMinutes();
  const b = getPrayerBoundaries();
  const windows = [
    { name:'Fajr', start:b.fajr, end:b.sunrise },
    { name:'Dhuhr', start:b.dhuhr, end:b.asr },
    { name:'Asr', start:b.asr, end:b.maghrib },
    { name:'Maghrib', start:b.maghrib, end:b.isha },
    { name:'Isha', start:b.isha, end:1440 }
  ].filter(w => w.start >= 0 && w.end > w.start);
  const current = windows.find(w => nowMins >= w.start && nowMins < w.end) || null;
  return { current, nowMins, boundaries:b, hasAccurateSunrise: b.sunrise >= 0 };
}

function getNextPrayer() {
  const live = new Date();
  const nowMins = live.getHours()*60 + live.getMinutes();
  for(let i=0; i<PRAYERS.length; i++){
    const t = minsSinceMidnight(prayerTimes[PRAYERS[i]]);
    if(t > nowMins) return { name: PRAYERS[i], mins: t };
  }
  // Wrap to next day Fajr
  return { name: 'Fajr', mins: minsSinceMidnight(prayerTimes['Fajr']) + 1440 };
}

function updateClock() {
  const live = new Date();
  const h24 = live.getHours(), min = live.getMinutes(), sec = live.getSeconds();
  const ampm = h24 >= 12 ? 'PM' : 'AM';
  const h12 = h24 % 12 || 12;
  const pad = n => String(n).padStart(2,'0');

  const hEl  = document.getElementById('clock-h');
  const mEl  = document.getElementById('clock-m');
  const sEl  = document.getElementById('clock-s');
  const apEl = document.getElementById('clock-ap');
  const dlEl = document.getElementById('clock-date-line');
  const activePrayerEl = document.getElementById('clock-active-prayer');
  const activePrayerNoteEl = document.getElementById('clock-active-prayer-note');
  const nextAtEl = document.getElementById('clock-next-at');
  const nextAtNoteEl = document.getElementById('clock-next-at-note');
  // clock-current-prayer-chip removed (replaced by Goals chip)
  const ramadanMini = document.getElementById('clock-ramadan-mini');
  const suhoorEl = document.getElementById('clock-suhoor-time');
  const iftarEl = document.getElementById('clock-iftar-time');

  if(hEl)  hEl.textContent  = pad(h12);
  if(mEl)  mEl.textContent  = pad(min);
  if(sEl)  sEl.textContent  = pad(sec);
  if(apEl) apEl.textContent = ampm;

  const hObj  = getHijriForDisplay(live);
  const hDate = `${hObj.day} ${HIJRI_MONTHS_AR[hObj.month-1]}`;
  if(dlEl) {
    const greg  = live.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'});
    dlEl.innerHTML = `${greg}<span style="margin-left:10px;opacity:.58;font-size:.86em;direction:rtl;unicode-bidi:embed">${hDate}</span>`;
  }

  const cdPrayer = document.getElementById('cd-prayer');
  const cdTime   = document.getElementById('cd-time');
  const cdSub    = document.getElementById('cd-sub');
  const hasTimes = Object.values(prayerTimes).some(t => t && t !== '--:--');

  if(ramadanMini) ramadanMini.classList.remove('show');
  setClockFastTime(suhoorEl, prayerTimes.Fajr || '');
  setClockFastTime(iftarEl, prayerTimes.Maghrib || '');

  if(hasTimes && cdPrayer && cdTime) {
    const next = getNextPrayer();
    const state = getCurrentPrayerState(live);
    const activePrayer = state.current ? state.current.name : null;
    const nowSecs = h24*3600 + min*60 + sec;
    let diff = next.mins * 60 - nowSecs;
    if(diff < 0) diff += 86400;

    const dh = Math.floor(diff / 3600);
    const dm = Math.floor((diff % 3600) / 60);
    const ds = diff % 60;

    cdPrayer.textContent = next.name;
    cdTime.textContent   = dh > 0 ? `${pad(dh)}:${pad(dm)}:${pad(ds)}` : `${pad(dm)}:${pad(ds)}`;
    cdTime.className     = 'countdown-time' + (diff < 300 ? ' urgent' : '');
    if(cdSub) {
      if(activePrayer) {
        cdSub.textContent = diff < 60 ? 'Wudu time now' : diff < 300 ? 'Prepare for salah' : 'Adhan at ' + fmtTime(prayerTimes[next.name]);
      } else {
        cdSub.textContent = 'No active salah time · Next adhan ' + fmtTime(prayerTimes[next.name]);
      }
    }
    if(activePrayerEl) activePrayerEl.textContent = activePrayer || 'No active waqt';
    if(activePrayerNoteEl) activePrayerNoteEl.textContent = activePrayer ? `${activePrayer} time is active now.` : 'Waiting for the next salah window.';
    if(nextAtEl) nextAtEl.innerHTML = `${fmtTime(prayerTimes[next.name])}<span class="suffix">${next.name}</span>`;
    if(nextAtNoteEl) nextAtNoteEl.textContent = diff < 60 ? 'Starting very soon.' : diff < 300 ? 'Prepare for adhan.' : `About ${dh > 0 ? `${dh} hr ` : ''}${dm} min left.`;
    // (prayer chip removed)
    const arc = document.getElementById('cd-ring-arc');
    if(arc) {
      const circumference = 245.04;
      const progressWindow = Math.max(1800, Math.min(diff + 1800, 21600));
      const frac = Math.max(0, Math.min(1, 1 - diff / progressWindow));
      arc.style.strokeDasharray = circumference.toFixed(2);
      arc.style.strokeDashoffset = (circumference - frac * circumference).toFixed(2);
    }
  } else if(cdPrayer) {
    cdPrayer.textContent = 'Set times';
    if(cdTime) cdTime.textContent = '--:--';
    if(cdSub)  cdSub.textContent  = 'Set prayer times';
    if(activePrayerEl) activePrayerEl.textContent = '—';
    if(activePrayerNoteEl) activePrayerNoteEl.textContent = 'Set prayer times to unlock this card.';
    if(nextAtEl) nextAtEl.innerHTML = 'Tap Auto<span class="suffix">Setup</span>';
    if(nextAtNoteEl) nextAtNoteEl.textContent = 'Prayer time will appear here.';
    if(currentPrayerChip) currentPrayerChip.textContent = 'Current · —';
  }
  _skyUpdate(h24, min);
}
updateClock();
setInterval(updateClock, 1000);

// ══════════════════════════════════════════════
//  SKY BANNER — sun by day, moon by night
//  Orbit arc + salah time markers
// ══════════════════════════════════════════════
var _skyLastMinute = -1;

// Convert "HH:MM" to minutes since midnight
function _skyTimeToMins(t) {
  if (!t || t === '--:--') return null;
  const p = t.split(':');
  return parseInt(p[0]) * 60 + parseInt(p[1]);
}

// Given a progress pct (0-1) along the arc, return {x,y} in SVG coords (400x120 viewBox)
// Arc: parabola from (8,108) peak at (200, 8) to (392,108)
function _skyArcPoint(pct) {
  const x = 8 + pct * 384;
  const y = 108 - Math.sin(pct * Math.PI) * 100;
  return { x, y };
}

// ─────────────────────────────────────────────────────────
// SKY BANNER — stable DOM helpers (no innerHTML on animated
// elements — prevents animation-restart blink)
// ─────────────────────────────────────────────────────────
var _skyBodyIsDay = null; // track last state to skip redundant rebuilds

function _skyEnsureSun(bodyEl) {
  if (_skyBodyIsDay === true) return; // already sun, skip
  _skyBodyIsDay = true;
  // Build sun once; subsequent calls only update filter/position
  bodyEl.innerHTML = `<svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <radialGradient id="sunCore" cx="50%" cy="50%" r="50%">
        <stop offset="0%"   stop-color="rgba(255,245,150,1)"/>
        <stop offset="60%"  stop-color="rgba(255,210,50,1)"/>
        <stop offset="100%" stop-color="rgba(255,170,20,0.9)"/>
      </radialGradient>
      <filter id="sg" x="-80%" y="-80%" width="260%" height="260%">
        <feGaussianBlur stdDeviation="8" result="b"/>
        <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
      </filter>
    </defs>
    <circle cx="20" cy="20" r="8" fill="url(#sunCore)" filter="url(#sg)"/>
    <g stroke="rgba(255,210,60,.85)" stroke-width="1.7" stroke-linecap="round">
      <line x1="20" y1="3"  x2="20" y2="7.5"/>
      <line x1="20" y1="32.5" x2="20" y2="37"/>
      <line x1="3"  y1="20" x2="7.5"  y2="20"/>
      <line x1="32.5" y1="20" x2="37"  y2="20"/>
      <line x1="6.8"  y1="6.8"  x2="10" y2="10"/>
      <line x1="30"   y1="30"   x2="33.2" y2="33.2"/>
      <line x1="33.2" y1="6.8"  x2="30"   y2="10"/>
      <line x1="10"   y1="30"   x2="6.8"  y2="33.2"/>
    </g>
  </svg>`;
  bodyEl.className = 'sky-body is-day';
}

function _skyEnsureMoon(bodyEl) {
  if (_skyBodyIsDay === false) return; // already moon, skip
  _skyBodyIsDay = false;
  bodyEl.innerHTML = `<svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <filter id="mg" x="-60%" y="-60%" width="220%" height="220%">
        <feGaussianBlur stdDeviation="3" result="b"/>
        <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
      </filter>
      <radialGradient id="moonGrad" cx="40%" cy="35%" r="60%">
        <stop offset="0%"   stop-color="rgba(245,240,255,1)"/>
        <stop offset="100%" stop-color="rgba(190,175,240,0.92)"/>
      </radialGradient>
    </defs>
    <path d="M25 8A14 14 0 1 1 10 30a10 10 0 0 0 15-22z" fill="url(#moonGrad)" filter="url(#mg)"/>
    <circle cx="16" cy="14" r="1.2" fill="rgba(180,165,230,0.45)"/>
    <circle cx="22" cy="22" r="0.9" fill="rgba(180,165,230,0.35)"/>
    <circle cx="14" cy="24" r="0.7" fill="rgba(180,165,230,0.3)"/>
  </svg>`;
  bodyEl.className = 'sky-body is-night';
}

function _skyEnsureClouds(bgEl, bannerEl) {
  if (bgEl._cloudsInit) return;
  bgEl._cloudsInit = true;
  bannerEl.querySelectorAll('.sky-cloud').forEach(c => c.remove());
  [{top:16,w:70,opacity:.12,dur:40,delay:0},{top:30,w:52,opacity:.08,dur:55,delay:-15},
   {top:20,w:84,opacity:.07,dur:46,delay:-24},{top:44,w:42,opacity:.10,dur:62,delay:-8}]
  .forEach(c => {
    const el = document.createElement('div');
    el.className = 'sky-cloud';
    // opacity set once via CSS var — never touched again, prevents animation restart
    el.style.cssText = `position:absolute;top:${c.top}%;--cloud-op:${c.opacity};animation:cloudDrift ${c.dur}s ${c.delay}s linear infinite`;
    el.innerHTML = `<svg viewBox="0 0 120 45" width="${c.w}" height="${Math.round(c.w*.38)}" fill="white" xmlns="http://www.w3.org/2000/svg"><ellipse cx="60" cy="30" rx="52" ry="15"/><ellipse cx="40" cy="24" rx="28" ry="16"/><ellipse cx="72" cy="22" rx="24" ry="14"/><ellipse cx="55" cy="18" rx="18" ry="12"/></svg>`;
    bannerEl.appendChild(el);
  });
}

function _skyEnsureStars(starsEl) {
  if (starsEl._starsInit) return; // already built — never rebuild (prevents twinkle restart)
  starsEl._starsInit = true;
  starsEl.innerHTML = Array.from({length:32}, () => {
    const x = Math.random()*100, y = Math.random()*88;
    const s = (.8 + Math.random()*1.5).toFixed(1);
    const delay = (Math.random()*4).toFixed(1);
    const dur   = (1.6 + Math.random()*3).toFixed(1);
    const bright = Math.random() > .8 ? 'rgba(225,232,255,.95)' : 'rgba(200,210,255,.58)';
    return `<span style="left:${x}%;top:${y}%;width:${s}px;height:${s}px;background:${bright};--d:${dur}s;--delay:${delay}s"></span>`;
  }).join('');
}

function _skyUpdate(h24, min) {
  if (h24 * 60 + min === _skyLastMinute) return;
  _skyLastMinute = h24 * 60 + min;

  const bodyEl  = document.getElementById('sky-body');
  const bgEl    = document.getElementById('sky-bg');
  const starsEl = document.getElementById('sky-stars');
  const arcEl   = document.getElementById('orbit-arc');
  const dotsEl  = document.getElementById('salah-dots');
  if (!bodyEl || !bgEl) return;

  const totalMins = h24 * 60 + min;
  const DAWN = 360, DUSK = 1080;
  const isDay = totalMins >= DAWN && totalMins < DUSK;
  const daySpan   = DUSK - DAWN;
  const nightSpan = 1440 - daySpan;

  let pct;
  if (isDay) {
    pct = (totalMins - DAWN) / daySpan;
  } else {
    const nightMin = totalMins >= DUSK ? totalMins - DUSK : totalMins + (1440 - DUSK);
    pct = nightMin / nightSpan;
  }

  // ── Orbit arc path (SVG quadratic Bézier) ──
  if (arcEl) {
    if (isDay) {
      arcEl.setAttribute('d', 'M 8 122 Q 200 6 392 122');
      arcEl.setAttribute('stroke', 'url(#orbitGradDay)');
    } else {
      arcEl.setAttribute('d', 'M 8 122 Q 200 38 392 122');
      arcEl.setAttribute('stroke', 'url(#orbitGradNight)');
    }
    arcEl.setAttribute('opacity', '0.75');
  }

  // ── Body position: follow actual quadratic Bézier arc ──
  const dayCtrlY   = 6;
  const nightCtrlY = 38;
  const ctrlY = isDay ? dayCtrlY : nightCtrlY;
  const t = isDay ? pct : 1 - pct;
  const bx = (1-t)*(1-t)*8   + 2*t*(1-t)*200 + t*t*392;
  const by = (1-t)*(1-t)*122 + 2*t*(1-t)*ctrlY + t*t*122;

  const leftPct   = (bx / 400) * 100;
  const bottomPct = ((130 - by) / 130) * 100;

  // ── Sky background ──
  if (isDay) {
    const dawn    = pct < .12;
    const golden  = pct > .88;
    const midday  = pct > .38 && pct < .62;
    let skyColor;
    if (dawn)        skyColor = 'linear-gradient(180deg,rgba(255,110,30,.32) 0%,rgba(255,165,55,.18) 38%,rgba(var(--accent-rgb),.07) 72%,transparent 100%), radial-gradient(ellipse at 92% 60%, rgba(160,140,220,.10) 0%, transparent 55%)';
    else if (golden) skyColor = 'linear-gradient(180deg,rgba(200,60,20,.26) 0%,rgba(225,100,30,.14) 38%,rgba(170,90,20,.06) 72%,transparent 100%), radial-gradient(ellipse at 88% 50%, rgba(140,120,255,.13) 0%, transparent 50%)';
    else if (midday) skyColor = 'linear-gradient(180deg,rgba(15,70,170,.18) 0%,rgba(35,115,195,.10) 42%,rgba(80,180,170,.05) 78%,transparent 100%)';
    else             skyColor = 'linear-gradient(180deg,rgba(25,90,195,.13) 0%,rgba(80,180,170,.07) 48%,transparent 100%)';
    bgEl.style.background = skyColor;

    // Stars: fade out smoothly (never rebuild — prevents twinkle reset)
    _skyEnsureStars(starsEl);
    starsEl.style.opacity = '0';

    // Clouds: build once, show
    const bannerEl = document.getElementById('sky-banner');
    if (bannerEl) _skyEnsureClouds(bgEl, bannerEl);
    document.querySelectorAll('.sky-cloud').forEach(c => { c.classList.remove('cloud-hidden'); });

    // Sun: build only once (stable SVG → no sunSpin restart)
    _skyEnsureSun(bodyEl);
  } else {
    // Night
    const nightStart = pct < .08;
    const preDawn    = pct > .92;
    let nightSky = 'linear-gradient(180deg,rgba(6,8,32,.58) 0%,rgba(12,8,42,.30) 45%,rgba(18,8,38,.09) 80%,transparent 100%)';
    if (nightStart) {
      nightSky += ', radial-gradient(ellipse at 12% 70%, rgba(200,80,20,.12) 0%, transparent 45%)';
      nightSky += ', radial-gradient(ellipse at 85% 65%, rgba(160,140,240,.10) 0%, transparent 45%)';
    } else if (preDawn) {
      nightSky += ', radial-gradient(ellipse at 10% 65%, rgba(240,130,30,.14) 0%, transparent 50%)';
      nightSky += ', radial-gradient(ellipse at 88% 60%, rgba(200,190,255,.07) 0%, transparent 40%)';
    }
    bgEl.style.background = nightSky;

    // Stars: build once, fade in (stable DOM → no twinkle restart blink)
    _skyEnsureStars(starsEl);
    starsEl.style.opacity = (0.25 + Math.sin(pct * Math.PI) * 0.75).toFixed(2);

    // Clouds: hide (keep DOM for when day returns — no re-inject needed)
    document.querySelectorAll('.sky-cloud').forEach(c => { c.classList.add('cloud-hidden'); });

    // Moon: build only once (stable SVG → no moonFloat restart)
    _skyEnsureMoon(bodyEl);
  }

  // ── Salah dots on orbit ──
  if (dotsEl) {
    const isFriday = new Date().getDay() === 5;
    const SALAH_CONFIG = [
      { key:'Fajr',    label:'ফজর',                        color:'rgba(140,180,255,0.95)', outline:'rgba(100,150,255,0.5)', isDay:false },
      { key:'Dhuhr',   label: isFriday ? "জুমু'আ" : 'যোহর', color:'rgba(255,215,60,0.95)',  outline:'rgba(255,180,20,0.5)',  isDay:true  },
      { key:'Asr',     label:'আসর',                        color:'rgba(255,165,40,0.95)',  outline:'rgba(255,130,10,0.5)',  isDay:true  },
      { key:'Maghrib', label:'মাগরিব',                     color:'rgba(255,110,70,0.95)',  outline:'rgba(220,70,30,0.5)',   isDay:false },
      { key:'Isha',    label:'এশা',                        color:'rgba(190,160,255,0.95)', outline:'rgba(150,120,230,0.5)', isDay:false },
    ];

    let dots = '';
    SALAH_CONFIG.forEach(s => {
      const salahMins = _skyTimeToMins(prayerTimes && prayerTimes[s.key]);
      if (salahMins === null) return;

      let sPct;
      const inDayRange = salahMins >= DAWN && salahMins < DUSK;
      if (inDayRange) {
        sPct = (salahMins - DAWN) / daySpan;
      } else {
        const nm = salahMins >= DUSK ? salahMins - DUSK : salahMins + (1440 - DUSK);
        sPct = nm / nightSpan;
      }

      if (inDayRange !== isDay) return;

      const st = inDayRange ? sPct : 1 - sPct;
      const svgX = (1-st)*(1-st)*8   + 2*st*(1-st)*200 + st*st*392;
      const svgY = (1-st)*(1-st)*122 + 2*st*(1-st)*ctrlY + st*st*122;

      const isPassed = totalMins > salahMins;
      const isNext   = !isPassed && (totalMins >= salahMins - 15);
      const dotR     = isNext ? 4 : 2.8;
      const dotOpacity = isPassed ? 0.45 : 1;

      const labelY = isDay ? Math.max(svgY - 8, 10) : Math.min(svgY + 13, 126);

      dots += `
        <g opacity="${dotOpacity}" filter="url(#dotGlow)">
          <circle cx="${svgX.toFixed(1)}" cy="${svgY.toFixed(1)}" r="${dotR + 3}" fill="${s.outline}" opacity="0.3"/>
          <circle cx="${svgX.toFixed(1)}" cy="${svgY.toFixed(1)}" r="${dotR}" fill="${s.color}" ${isNext ? 'style="animation:salahPulse 1.8s ease-in-out infinite"' : ''}/>
          ${isPassed ? `<line x1="${svgX.toFixed(1)}" y1="${(svgY-dotR-1).toFixed(1)}" x2="${svgX.toFixed(1)}" y2="${(svgY+dotR+1).toFixed(1)}" stroke="rgba(255,255,255,0.6)" stroke-width="1" stroke-linecap="round"/>` : ''}
        </g>
        <text x="${svgX.toFixed(1)}" y="${labelY.toFixed(1)}" text-anchor="middle" font-family="'Manrope',sans-serif" font-size="6.5" fill="${s.color}" opacity="${isPassed ? 0.35 : 0.9}" letter-spacing="0.2">${s.label}</text>
      `;
    });
    dotsEl.innerHTML = dots;
  }

  // ── Sun/Moon glow & position (applied to existing stable element) ──
  const glowColor = isDay
    ? `rgba(255,205,50,${pct < .12 || pct > .88 ? '.5' : '.85'})`
    : 'rgba(200,180,255,.72)';
  bodyEl.style.filter  = `drop-shadow(0 0 ${isDay ? 10 + Math.sin(pct*Math.PI)*8 : 8}px ${glowColor})`;
  bodyEl.style.opacity = (pct < .025 || pct > .975) ? '0.3' : '1';
  bodyEl.style.left   = leftPct + '%';
  bodyEl.style.bottom = bottomPct + '%';
  bodyEl.style.top    = 'auto';
}

// ==============================================
// PRAYER TIMES - AUTO LOCATION
// ==============================================
function fetchPrayersByLocation() {
  const btn = document.getElementById('loc-btn');
  const status = document.getElementById('prayer-loc-status');
  if(btn) { btn.disabled=true; btn.textContent='📍 Detecting location…'; }
  if(status) status.textContent = 'Requesting location access…';

  if(!navigator.geolocation) {
    if(status) status.style.color='var(--rose)', status.textContent='Geolocation not supported on this device.';
    if(btn) { btn.disabled=false; btn.innerHTML='📍 Auto-detect from Location'; }
    return;
  }

  navigator.geolocation.getCurrentPosition(async pos => {
    const lat = pos.coords.latitude, lng = pos.coords.longitude;
    if(status) status.textContent = `📍 Got location (${lat.toFixed(2)}°, ${lng.toFixed(2)}°) — fetching times…`;

    try {
      const y = now.getFullYear(), m = now.getMonth()+1, d = now.getDate();
      const url = `https://api.aladhan.com/v1/timings/${d}-${m}-${y}?latitude=${lat}&longitude=${lng}&method=2`;
      const resp = await fetch(url);
      const json = await resp.json();
      if(json.code===200 && json.data?.timings) {
        const t = json.data.timings;
        // Populate inputs
        ['Fajr','Dhuhr','Asr','Maghrib','Isha'].forEach(p => {
          const inp = document.getElementById('pt-'+p);
          if(inp && t[p]) inp.value = t[p].slice(0,5);
        });
        // Get city name
        const loc = json.data.meta?.timezone || `${lat.toFixed(1)}°, ${lng.toFixed(1)}°`;
        if(status) { status.style.color='var(--green)'; status.textContent=`✓ Times loaded for ${loc}. Review & save.`; }
      } else {
        throw new Error('Bad response');
      }
    } catch(err) {
      if(status) { status.style.color='var(--rose)'; status.textContent='Could not fetch times. Check your connection or enter manually.'; }
    }
    if(btn) { btn.disabled=false; btn.innerHTML='📍 Auto-detect from Location'; }
  }, () => {
    if(status) { status.style.color='var(--rose)'; status.textContent='Location access denied. Please enter times manually.'; }
    if(btn) { btn.disabled=false; btn.innerHTML='📍 Auto-detect from Location'; }
  });
}

// Quick auto-fetch from Today view (no modal needed)
async function quickFetchPrayers() {
  const btn = document.getElementById('quick-loc-btn');
  if(btn) { btn.textContent='⏳ Fetching…'; btn.style.pointerEvents='none'; }
  if(!navigator.geolocation) {
    if(btn) { btn.textContent='📍 Auto'; btn.style.pointerEvents=''; }
    alert('Geolocation not available. Please use ⚙ Edit to enter times manually.');
    return;
  }
  navigator.geolocation.getCurrentPosition(async pos => {
    try {
      const lat=pos.coords.latitude, lng=pos.coords.longitude;
      const y=now.getFullYear(),m=now.getMonth()+1,d=now.getDate();
      const resp=await fetch(`https://api.aladhan.com/v1/timings/${d}-${m}-${y}?latitude=${lat}&longitude=${lng}&method=2`);
      const json=await resp.json();
      if(json.code===200 && json.data?.timings){
        const t=json.data.timings;
        ['Fajr','Sunrise','Dhuhr','Asr','Maghrib','Isha'].forEach(p=>{ if(t[p]) prayerTimes[p]=t[p].slice(0,5); });
        try{localStorage.setItem('mrd3_prayers',JSON.stringify(prayerTimes));}catch{}
        renderPrayers();
        if(btn){ btn.textContent='✓ Updated'; setTimeout(()=>{ btn.textContent='📍 Auto'; btn.style.pointerEvents=''; },2000); }
      } else throw new Error();
    } catch {
      if(btn){ btn.textContent='✗ Failed'; btn.style.color='var(--rose)'; setTimeout(()=>{ btn.textContent='📍 Auto'; btn.style.color='var(--teal)'; btn.style.pointerEvents=''; },2500); }
    }
  }, () => {
    if(btn){ btn.textContent='✗ Denied'; btn.style.color='var(--rose)'; setTimeout(()=>{ btn.textContent='📍 Auto'; btn.style.color='var(--teal)'; btn.style.pointerEvents=''; },2500); }
  });
}
// ==============================================
// Initialize header date label
updateHdrDateLabel();
updateHdrGreeting();
initHeroCoachMessages();

// ==============================================
// PRAYER TIMES
// ==============================================
function getActivePrayer() {
  const state = getCurrentPrayerState(new Date());
  return state.current ? state.current.name : null;
}

function pqLabel(q) {
  if(q==='foroj')  return {icon:'Foroj',   short:'Foroj',  tip:'Tap to change · Foroj prayer',    cls:'pq-foroj'};
  if(q==='takbir') return {icon:t('Takbir'),short:'Takbir',tip:'Tap to change · Takbir-ul-Ula',cls:'pq-takbir'};
  if(q==='jamaat') return {icon:t('Jamaat'), short:'Jamaat',tip:'Tap to change · With Jamaat',  cls:'pq-jamaat'};
  if(q==='alone')  return {icon:t('Alone'),  short:'Alone', tip:'Tap to change · Prayed alone', cls:'pq-alone'};
  if(q==='qaza')   return {icon:'Qaza',      short:'Qaza',  tip:'Tap to change · Qaza prayer',  cls:'pq-qaza'};
  return null;
}

function _prayerCardHTML(p, {isActive,done,q,isMissed,isJumuah,isWarn,isToday}) {
  const onclick = isToday ? `togglePrayerDone('${p}')` : `togglePastPrayer('${p}')`;
  const qLabel = _pqLabel(q);
  const qCls   = _pqBadgeCls(q);
  const badgeHTML = done
    ? `<div class="pq-badge" onclick="event.stopPropagation();openPqSheet('${p}',${isToday})" title="Tap to set quality"><span class="pq-badge-inner ${qCls}">${qLabel}</span></div>`
    : '<div class="pq-empty-ph"></div>';
  return `<div class="prayer-card glass ${isActive?'active-prayer':''} ${done?'pcard-done':''} ${isMissed?'pcard-not-done':''} ${isWarn?'pcard-warn':''} ${isJumuah?'pcard-jumuah':''}" onclick="${onclick}" style="cursor:pointer;position:relative" data-p="${p}">
    ${isMissed ? '<div class="notdone-dot"></div>' : ''}
    ${isWarn   ? '<div class="warn-dot"></div>'   : ''}
    <div class="prayer-name" data-prayer="${p}">${p}</div>
    ${isJumuah ? '<div class="jumuah-lbl">Jumu&#x02BC;ah</div>' : ''}
    <div class="prayer-time" onclick="event.stopPropagation();${done?`openPqSheet('${p}',${isToday})`:onclick}">${fmtTime(prayerTimes[p])}</div>
    ${badgeHTML}
    <div class="prayer-done-dot ${done?'done':''}"></div>
  </div>`;
}

function _pqLabel(q) {
  if (!q || q === 'none') return '—';
  if (q.startsWith('custom:')) return q.slice(7);
  const map = {jamaat:'Jamaat',takbir:'Takbir',alone:'Alon',foroj:'Foroj',qaza:'Qaza'};
  return map[q] || q;
}

function _pqBadgeCls(q) {
  if (!q || q === 'none') return 'pq-badge-none';
  if (q.startsWith('custom:')) return 'pq-badge-custom';
  return 'pq-badge-' + q;
}

function _patchPrayerRow(el, cards) {
  // Smart patch: avoid full innerHTML wipe to prevent blink
  // cards = [{p, isActive, done, q, isMissed, isJumuah, isWarn, isToday}, ...]
  const existing = el.querySelectorAll('.prayer-card[data-p]');
  if (existing.length !== cards.length) {
    // Structure mismatch → full build once (first paint or prayer count changed)
    el.innerHTML = cards.map(c => _prayerCardHTML(c.p, c)).join('');
    return;
  }
  cards.forEach((c, i) => {
    const card = existing[i];
    // Class update (no full redraw)
    const cls = ['prayer-card','glass',
      c.isActive  ? 'active-prayer'   : '',
      c.done      ? 'pcard-done'      : '',
      c.isMissed  ? 'pcard-not-done'  : '',
      c.isWarn    ? 'pcard-warn'      : '',
      c.isJumuah  ? 'pcard-jumuah'    : '',
    ].filter(Boolean).join(' ');
    if (card.className !== cls) card.className = cls;

    // Dots
    const hasMissedDot = !!card.querySelector('.notdone-dot');
    if (c.isMissed && !hasMissedDot) { const d=document.createElement('div'); d.className='notdone-dot'; card.insertBefore(d,card.firstChild); }
    if (!c.isMissed && hasMissedDot) card.querySelector('.notdone-dot').remove();
    const hasWarnDot = !!card.querySelector('.warn-dot');
    if (c.isWarn && !hasWarnDot) { const d=document.createElement('div'); d.className='warn-dot'; card.insertBefore(d,card.firstChild); }
    if (!c.isWarn && hasWarnDot) card.querySelector('.warn-dot').remove();

    // Jumuah label
    const hasJumuah = !!card.querySelector('.jumuah-lbl');
    if (c.isJumuah && !hasJumuah) { const d=document.createElement('div'); d.className='jumuah-lbl'; d.innerHTML="Jumu&#x02BC;ah"; card.querySelector('.prayer-time').after(d); }
    if (!c.isJumuah && hasJumuah) card.querySelector('.jumuah-lbl').remove();

    // Prayer time text
    const timeEl = card.querySelector('.prayer-time');
    const newTime = fmtTime(prayerTimes[c.p]);
    if (timeEl && timeEl.textContent !== newTime) timeEl.textContent = newTime;

    // Done dot
    const dot = card.querySelector('.prayer-done-dot');
    if (dot) { if (c.done) dot.classList.add('done'); else dot.classList.remove('done'); }

    // Update prayer-time onclick (today↔past sync)
    if (timeEl) {
      const tOnclick = c.done
        ? `event.stopPropagation();openPqSheet('${c.p}',${c.isToday})`
        : `event.stopPropagation();${c.isToday ? `togglePrayerDone('${c.p}')` : `togglePastPrayer('${c.p}')`}`;
      timeEl.setAttribute('onclick', tOnclick);
    }

    // Quality badge vs empty placeholder
    const hasBadge = !!card.querySelector('.pq-badge');
    if (c.done && !hasBadge) {
      card.querySelector('.pq-empty-ph')?.remove();
      const wrap = document.createElement('div');
      wrap.className = 'pq-badge';
      wrap.setAttribute('onclick', `event.stopPropagation();openPqSheet('${c.p}',${c.isToday})`);
      wrap.title = 'Tap to set quality';
      const inner = document.createElement('span');
      inner.className = `pq-badge-inner ${_pqBadgeCls(c.q)}`;
      inner.textContent = _pqLabel(c.q);
      wrap.appendChild(inner);
      card.querySelector('.prayer-done-dot').before(wrap);
    } else if (!c.done && hasBadge) {
      card.querySelector('.pq-badge').remove();
      if (!card.querySelector('.pq-empty-ph')) {
        const ph = document.createElement('div'); ph.className = 'pq-empty-ph';
        card.querySelector('.prayer-done-dot').before(ph);
      }
    } else if (c.done && hasBadge) {
      const badge = card.querySelector('.pq-badge');
      const expectedOnclick = `event.stopPropagation();openPqSheet('${c.p}',${c.isToday})`;
      if (badge.getAttribute('onclick') !== expectedOnclick) badge.setAttribute('onclick', expectedOnclick);
      const inner = badge.querySelector('.pq-badge-inner');
      if (inner) {
        const newLabel = _pqLabel(c.q);
        const newCls   = `pq-badge-inner ${_pqBadgeCls(c.q)}`;
        if (inner.textContent !== newLabel) inner.textContent = newLabel;
        if (inner.className   !== newCls)   inner.className   = newCls;
      }
    }
  });
}

function renderPrayers() {
  if(typeof viewingDate !== 'undefined' && viewingDate !== TODAY_KEY) {
    renderPrayersForSnap(getDateSnapshot(viewingDate)); return;
  }
  const active = getActivePrayer();
  const el = document.getElementById('prayer-row');
  const hasTimes = Object.values(prayerTimes).some(t=>t);
  if(!hasTimes){
    if(el.children.length !== 1 || !el.querySelector('.prayer-setup-hint'))
      el.innerHTML=`<div class="prayer-setup-hint">Tap ⚙ Setup to enter your prayer times</div>`;
    return;
  }
  const missedPrayers = getMissedPrayers();
  const isFriday = new Date().getDay() === 5;
  const cards = PRAYERS.map(p => ({
    p,
    isActive : p === active,
    done     : !!prayerDone[p],
    q        : prayerQuality[p] || null,
    isMissed : !prayerDone[p] && missedPrayers.includes(p),
    isJumuah : isFriday && p === 'Dhuhr',
    isWarn   : !!prayerDone[p] && (!prayerQuality[p] || prayerQuality[p] === 'none'),
    isToday  : true,
  }));
  _patchPrayerRow(el, cards);
  updatePrayerStreakBadge();
}

function cyclePrayerQuality(p) {
  // Cycle: null to foroj to alone to jamaat to takbir to null
  const cycle = [null,'foroj','alone','jamaat','takbir'];
  const cur = prayerQuality[p] || null;
  const next = cycle[(cycle.indexOf(cur) + 1) % cycle.length];
  prayerQuality[p] = next;
  savePrayerQuality();
  persist();
  renderPrayers();
}

function setPrayerQualityDirect(p, val) {
  prayerQuality[p] = (val === '' || val === 'none') ? 'none' : (val || null);
  savePrayerQuality();
  persist();
  renderPrayers();
  renderStats();
  updateScorePill();
}

function cyclePastPrayerQuality(p) {
  const KEY = viewingDate;
  if(!daily[KEY]) daily[KEY] = {};
  if(!daily[KEY].prayerQuality) daily[KEY].prayerQuality = {};
  const cycle = ['jamaat','takbir','alone','foroj'];
  const cur = daily[KEY].prayerQuality[p] || 'foroj';
  daily[KEY].prayerQuality[p] = cycle[(cycle.indexOf(cur) + 1) % cycle.length];
  persistDay(KEY);
  renderPrayersForSnap(getDateSnapshot(KEY));
}

function togglePrayerDone(p) {
  if(viewingDate !== TODAY_KEY) { togglePastPrayer(p); return; }
  if(!prayerDone[p]) {
    // First tap: mark done, default = Foroj
    prayerDone[p] = true;
    prayerQuality[p] = 'jamaat';
  } else {
    // Already done: cycle  jamaat → takbir → alone → foroj → jamaat
    const cycle = ['jamaat','takbir','alone','foroj'];
    const cur   = prayerQuality[p] || 'foroj';
    const idx   = cycle.indexOf(cur);
    prayerQuality[p] = cycle[(idx + 1) % cycle.length];
  }
  savePrayerQuality();
  persistPrayerDone();
  renderPrayers();
  renderStats();
  updateScorePill();
}

function openPrayerSetup() {
  const el = document.getElementById('prayer-inputs');
  el.innerHTML = `<div class="prayer-time-row">${
    PRAYERS.map(p=>`
      <div class="pt-group">
        <label class="pt-lbl">${p}</label>
        <input class="pt-inp" type="time" id="pt-${p}" value="${prayerTimes[p]||''}">
      </div>`).join('')
  }</div>`;
  document.getElementById('prayer-ovl').classList.add('open');
}
function closePrayerOvl(e){
  if(e.target===document.getElementById('prayer-ovl')||e.target.classList.contains('ovl-bg'))
    document.getElementById('prayer-ovl').classList.remove('open');
}
function savePrayerTimes(){
  PRAYERS.forEach(p=>{
    const v=document.getElementById('pt-'+p)?.value;
    if(v) prayerTimes[p]=v;
  });
  try{localStorage.setItem('mrd3_prayers',JSON.stringify(prayerTimes));}catch{}
  document.getElementById('prayer-ovl').classList.remove('open');
  renderPrayers();
}

// ==============================================
// KPI
// ==============================================
function _kpiApply(data) {
  const el = document.getElementById('kpi');
  if (!el) return;
  const cards = el.querySelectorAll('.kpi-c');
  if (cards.length !== data.length) {
    // First paint — build structure once
    el.innerHTML = data.map(d=>`
    <div class="kpi-c glass">
      <span class="kpi-icon">${d.ic}</span>
      <div class="kpi-lbl">${d.l}</div>
      <div class="kpi-val" style="color:${d.col}">${d.v}</div>
      <div class="kpi-bar"><div class="kpi-fill" style="width:${d.p}%;background:${d.col}"></div></div>
    </div>`).join('');
    return;
  }
  // Subsequent updates — patch only what changed (no full innerHTML wipe = no blink)
  cards.forEach((card, i) => {
    const d = data[i];
    const valEl  = card.querySelector('.kpi-val');
    const fillEl = card.querySelector('.kpi-fill');
    const lblEl  = card.querySelector('.kpi-lbl');
    if (valEl  && valEl.textContent !== d.v)           { valEl.textContent = d.v; valEl.style.color = d.col; }
    if (fillEl && fillEl.style.width !== d.p+'%')      { fillEl.style.width = d.p+'%'; fillEl.style.background = d.col; }
    if (lblEl  && lblEl.textContent !== d.l)           { lblEl.textContent = d.l; }
  });
}

function renderKPI(){
  // Always render for viewingDate so past dates show correct data
  if(viewingDate !== TODAY_KEY) {
    renderKPIForSnap(getDateSnapshot(viewingDate), viewingDate);
    return;
  }
  const ta=todayActs(), total=ta.length, done=ta.filter(a=>a.done).length, pct=total?Math.round(done/total*100):0;
  const pDone=Object.values(prayerDone).filter(Boolean).length;
  const isFasting = fastingData[TODAY_KEY]||false;
  const sunnahList = getSunnahList();
  const sunnahDoneCount = sunnahDone.filter(Boolean).length;
  const sunnahTotal = sunnahList.length;
  const sunnahPct = sunnahTotal ? Math.round(sunnahDoneCount/sunnahTotal*100) : 0;
  const _kpiPQ = prayerQuality || {};
  const _kpiTakbir = ['Fajr','Dhuhr','Asr','Maghrib','Isha'].filter(p=>prayerDone[p]&&_kpiPQ[p]==='takbir').length;
  _kpiApply([
    {l:t('Activities'), ic:'⚡', v:`${done}/${total}`,            p:pct,                                              col:'var(--accent-main)'},
    {l:t('Prayers'),    ic:'🕌', v:`${pDone}/5`,                  p:pDone/5*100,                                      col:'var(--accent-2)'},
    {l:t('Takbir'),     ic:'🌙', v:`${_kpiTakbir}/5`,              p:_kpiTakbir/5*100,                                 col:'var(--accent-3)'},
    {l:t('Sunnah'),     ic:'☀️', v:`${sunnahDoneCount}/${sunnahTotal}`, p:sunnahPct,                                   col:'var(--accent-4)'},
    {l:t('Quran'),      ic:'📖', v:`${quranData.pages}p`,          p:Math.min(quranData.pages/quranData.goal*100,100), col:'var(--accent-5)'},
    {l:t('Fasting'),    ic:'💧', v:isFasting?'✓':'—',              p:isFasting?100:0,                                  col:'var(--accent-6)'},
  ]);
}

// ==============================================
// SNAPSHOT RENDER FUNCTIONS (past-day view)
// ==============================================

function renderKPIForSnap(s, key) {
  const acts = s.acts, total = acts.length, done = acts.filter(a=>a.done).length;
  const pct = total ? Math.round(done/total*100) : 0;
  const pDone = Object.values(s.prayers).filter(Boolean).length;
  const sunnahTotal = s.sunnah.length;
  const sunnahDoneCount = s.sunnah.filter(Boolean).length;
  const sunnahPct = sunnahTotal ? Math.round(sunnahDoneCount/sunnahTotal*100) : 0;
  const _snapPQ = s.prayerQuality || {};
  const _snapTakbir = ['Fajr','Dhuhr','Asr','Maghrib','Isha'].filter(p=>s.prayers[p]&&_snapPQ[p]==='takbir').length;
  const data = [
    {l:t('Activities'), ic:'⚡', v:`${done}/${total}`,                  p:pct,                                        col:'var(--accent-main)'},
    {l:t('Prayers'),    ic:'🕌', v:`${pDone}/5`,                        p:pDone/5*100,                                col:'var(--accent-2)'},
    {l:t('Takbir'),     ic:'🌙', v:`${_snapTakbir}/5`,                    p:_snapTakbir/5*100,                          col:'var(--accent-3)'},
    {l:t('Sunnah'),     ic:'☀️', v:`${sunnahDoneCount}/${sunnahTotal}`, p:sunnahPct,                                  col:'var(--accent-4)'},
    {l:t('Quran'),      ic:'📖', v:`${s.quranPages}p`,                  p:Math.min(s.quranPages/s.quranGoal*100,100), col:'var(--accent-5)'},
    {l:t('Fasting'),    ic:'💧', v:s.fasting?'✓':'—',                   p:s.fasting?100:0,                            col:'var(--accent-6)'},
  ];
  _kpiApply(data);
}

// Prayers - interactive for past dates
function renderPrayersForSnap(s) {
  const el = document.getElementById('prayer-row');
  if(!el) return;
  const KEY = viewingDate;
  const isPastDate = KEY !== TODAY_KEY;
  const cards = PRAYERS.map(p => ({
    p,
    isActive : false,
    done     : !!(s.prayers[p]),
    q        : (s.prayerQuality || {})[p] || null,
    isMissed : isPastDate && !(s.prayers[p]),
    isJumuah : false,
    isWarn   : !!(s.prayers[p]) && (!(s.prayerQuality||{})[p] || (s.prayerQuality||{})[p] === 'none'),
    isToday  : false,
  }));
  _patchPrayerRow(el, cards);
}

function setPastPrayerQualityDirect(p, val) {
  const KEY = viewingDate;
  if(!daily[KEY]) daily[KEY] = {};
  if(!daily[KEY].prayerQuality) daily[KEY].prayerQuality = {};
  daily[KEY].prayerQuality[p] = (val === '' || val === 'none') ? 'none' : (val || null);
  persistDay(KEY);
  renderPrayersForSnap(getDateSnapshot(KEY));
  renderStatsDebounced();
}

// ── Prayer Quality Bottom Sheet ──
const PQ_OPTS = [
  { val:'jamaat', icon:'🕌', label:'Jamaat',      sub:'With congregation',   col:'var(--teal)',   bg:'rgba(var(--teal-rgb),.12)',  border:'rgba(var(--teal-rgb),.4)' },
  { val:'takbir', icon:'⭐', label:'Takbir-i-Ula',sub:'Caught 1st takbir',  col:'var(--gold)',   bg:'rgba(var(--accent-rgb),.12)',  border:'rgba(var(--accent-rgb),.4)' },
  { val:'alone',  icon:'🤲', label:'Alone',        sub:'Prayed individually', col:'var(--purple)', bg:'rgba(var(--purple-rgb),.12)',border:'rgba(var(--purple-rgb),.4)' },
  { val:'foroj',  icon:'📿', label:'Foroj',        sub:'Obligatory prayer',   col:'#a0c4ff',      bg:'rgba(160,196,255,.12)',border:'rgba(160,196,255,.4)' },
  { val:'qaza',   icon:'⏰', label:'Qaza',         sub:'Made up missed',      col:'var(--rose)',   bg:'rgba(var(--rose-rgb),.12)',border:'rgba(var(--rose-rgb),.4)' },
  { val:'none',   icon:'—',  label:'None',          sub:'Clear quality',       col:'rgba(240,242,248,.3)', bg:'rgba(255,255,255,.04)', border:'rgba(255,255,255,.1)' },
];

// Custom types — persisted in localStorage
function _loadPqCustomTypes() {
  try { return JSON.parse(localStorage.getItem('pq_custom_types') || '[]'); } catch { return []; }
}
function _savePqCustomTypes(arr) {
  try { localStorage.setItem('pq_custom_types', JSON.stringify(arr)); } catch {}
}

let _pqSheetPrayer  = null;
let _pqSheetIsToday = true;

function openPqSheet(p, isToday) {
  _pqSheetPrayer  = p;
  _pqSheetIsToday = isToday;

  const curQ = isToday
    ? (prayerQuality[p] || 'none')
    : ((daily[viewingDate]?.prayerQuality || {})[p] || 'none');

  document.getElementById('pqs-prayer-name').textContent = p + ' Salah';

  // Render built-in options grid
  const grid = document.getElementById('pqs-grid');
  grid.innerHTML = PQ_OPTS.map(o => `
    <div class="pqs-opt ${curQ === o.val ? 'selected' : ''}"
         style="${curQ===o.val ? `border-color:${o.border};background:${o.bg};color:${o.col}` : ''}"
         onclick="selectPqOpt('${o.val}')">
      ${curQ===o.val ? `<div style="position:absolute;top:6px;right:8px;font-size:0.45rem;color:${o.col};font-weight:800">✓</div>` : ''}
      <div class="pqs-opt-icon">${o.icon}</div>
      <div class="pqs-opt-label" style="${curQ===o.val?`color:${o.col}`:''}">${o.label}</div>
      <div class="pqs-opt-sub">${o.sub}</div>
    </div>`).join('');

  // Render custom chips
  _renderPqCustomChips(curQ);

  // Reset add-input state
  cancelPqAddInput();

  document.getElementById('pq-sheet-overlay').classList.add('open');
  document.getElementById('pq-sheet').classList.add('open');
  const nav = document.getElementById('main-nav');
  if(nav) nav.style.display = 'none';
}

function _renderPqCustomChips(curQ) {
  const customs = _loadPqCustomTypes();
  const row = document.getElementById('pqs-custom-row');
  if (!row) return;
  if (customs.length === 0) {
    row.innerHTML = '';
    return;
  }
  row.innerHTML = customs.map((t, i) => {
    const val = 'custom:' + t;
    const isSel = curQ === val;
    return `<div class="pqs-custom-chip ${isSel ? 'selected' : ''}" onclick="selectPqOpt('${val.replace(/'/g,"\\'")}')">
      <span class="pqs-custom-chip-lbl">${t}</span>
      <button class="pqs-custom-chip-del" onclick="event.stopPropagation();deletePqCustomType(${i})" title="Remove">✕</button>
    </div>`;
  }).join('');
}

function showPqAddInput() {
  document.getElementById('pqs-add-btn').style.display = 'none';
  document.getElementById('pqs-add-input-row').style.display = 'flex';
  setTimeout(() => document.getElementById('pqs-add-input')?.focus(), 80);
}

function cancelPqAddInput() {
  const inp = document.getElementById('pqs-add-input');
  if (inp) inp.value = '';
  const row = document.getElementById('pqs-add-input-row');
  if (row) row.style.display = 'none';
  const btn = document.getElementById('pqs-add-btn');
  if (btn) btn.style.display = '';
}

function savePqCustomType() {
  const inp = document.getElementById('pqs-add-input');
  const raw = (inp?.value || '').trim();
  if (!raw) { inp?.focus(); return; }

  const customs = _loadPqCustomTypes();
  // Deduplicate (case-insensitive)
  if (!customs.some(c => c.toLowerCase() === raw.toLowerCase())) {
    customs.push(raw);
    _savePqCustomTypes(customs);
  }

  // Auto-select the new type
  const val = 'custom:' + raw;
  _renderPqCustomChips(val);
  cancelPqAddInput();
  selectPqOpt(val);
}

function deletePqCustomType(idx) {
  const customs = _loadPqCustomTypes();
  customs.splice(idx, 1);
  _savePqCustomTypes(customs);
  // Re-render chips with current selected value
  const curQ = _pqSheetIsToday
    ? (prayerQuality[_pqSheetPrayer] || 'none')
    : ((daily[viewingDate]?.prayerQuality || {})[_pqSheetPrayer] || 'none');
  _renderPqCustomChips(curQ);
}

function closePqSheet() {
  document.getElementById('pq-sheet-overlay').classList.remove('open');
  document.getElementById('pq-sheet').classList.remove('open');
  const nav = document.getElementById('main-nav');
  if(nav) nav.style.display = '';
}

function selectPqOpt(val) {
  if (!_pqSheetPrayer) return;
  if (_pqSheetIsToday) {
    setPrayerQualityDirect(_pqSheetPrayer, val);
  } else {
    setPastPrayerQualityDirect(_pqSheetPrayer, val);
  }
  closePqSheet();
}

function togglePastPrayer(p) {
  const KEY = viewingDate;
  if(!daily[KEY]) daily[KEY] = {};
  if(!daily[KEY].prayers) daily[KEY].prayers = {};
  if(!daily[KEY].prayerQuality) daily[KEY].prayerQuality = {};
  if(!daily[KEY].prayers[p]) {
    // First tap: mark done + default Foroj
    daily[KEY].prayers[p]       = true;
    daily[KEY].prayerQuality[p] = 'jamaat';
  } else {
    // Cycle: jamaat → takbir → alone → foroj → jamaat
    const cycle = ['jamaat','takbir','alone','foroj'];
    const cur   = daily[KEY].prayerQuality[p] || 'foroj';
    const idx   = cycle.indexOf(cur);
    daily[KEY].prayerQuality[p] = cycle[(idx + 1) % cycle.length];
  }
  persistDay(KEY);
  const s = getDateSnapshot(KEY);
  renderPrayersForSnap(s);
  renderKPIForSnap(s, KEY);
  renderStatsDebounced();
}

// Fasting - interactive toggle for past dates
function renderFastingForSnap(s, key) {
  const el = document.getElementById('fast-card');
  if(!el) return;
  el.innerHTML = `
    <div class="fast-header">
      <div class="fast-title">Fasting</div>
      <label class="fast-toggle">
        <input type="checkbox" ${s.fasting?'checked':''} onchange="togglePastFast('${key}')">
        <div class="fast-slider"></div>
      </label>
    </div>
    <div class="fast-row">
      <div class="fast-info">
        <div class="fast-status" style="color:${s.fasting?'var(--green)':'var(--t2)'}">${s.fasting?'Fasted 🤍':'Did not fast'}</div>
        <div class="fast-sub">Tap to update this day's fasting record</div>
      </div>
    </div>`;
}

function togglePastFast(key) {
  if(!daily[key]) daily[key] = {};
  daily[key].fasting = !daily[key].fasting;
  fastingData[key] = daily[key].fasting;
  persistDay(key);
  try { localStorage.setItem('mrd3_fasting', JSON.stringify(fastingData)); } catch{}
  const s = getDateSnapshot(key);
  renderFastingForSnap(s, key);
  renderKPIForSnap(s, key);
  renderStats();
}

// Quran - interactive +/- for past dates
function renderQuranForSnap(s) {
  const p   = s.quranPages || 0;
  const g   = s.quranGoal  || quranData.goal || 5;
  const pct  = Math.min(p/g*100,100);
  const done = p >= g;
  const goalLabel = g===604 ? 'Full Quran' : g + ' pg';
  const el = document.getElementById('quran-card');
  if(!el) return;

  const r = 29, circ = 2 * Math.PI * r;
  const offset = circ - (pct / 100) * circ;

  el.innerHTML = `
    <div class="qr-new-card">
      <div class="qr-shimmer"></div>
      <div class="qr-head-row">
        <div class="qr-head-left">
          <div class="qr-title">Quran Reading</div>
          <div class="qr-arabic-lbl">اقرأ</div>
          <div class="qr-progress-nums">
            <span class="qr-big-pages ${done?'done':''}">${p}</span>
            <span class="qr-slash-goal">/ ${g}</span>
            <span class="qr-pages-word">pages</span>
          </div>
          ${done ? `<div style="font-size:0.5625rem;color:var(--green);letter-spacing:.1em;margin-top:4px;display:flex;align-items:center;gap:5px"><span>✦</span><span>Goal complete</span></div>` : ''}
        </div>
        <div class="qr-ring-wrap">
          <svg class="qr-ring-svg" viewBox="0 0 72 72">
            <defs>
              <linearGradient id="qr-grad-snap" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#d4a853"/>
                <stop offset="50%" stop-color="var(--gold2)"/>
                <stop offset="100%" stop-color="var(--teal)"/>
              </linearGradient>
            </defs>
            <circle class="qr-ring-bg" cx="36" cy="36" r="${r}"/>
            <circle class="qr-ring-track" cx="36" cy="36" r="${r}"/>
            <circle class="qr-ring-fg" cx="36" cy="36" r="${r}"
              stroke="url(#qr-grad-snap)"
              stroke-dasharray="${circ.toFixed(1)}"
              stroke-dashoffset="${offset.toFixed(1)}"/>
          </svg>
          <div class="qr-ring-center">
            ${done
              ? `<span class="qr-ring-done-icon">✦</span>`
              : `<span class="qr-ring-pct">${Math.round(pct)}%</span><span class="qr-ring-sub">done</span>`}
          </div>
        </div>
      </div>
      <div class="qr-bar-wrap">
        <div class="qr-bar-fill" style="width:${pct}%"></div>
      </div>
      <div class="qr-goal-inline">
        <span class="qr-goal-label">Daily goal</span>
        <div class="qr-goal-stepper">
          <button class="qr-goal-btn" onclick="setPastQuranGoal(-1)">−</button>
          <span class="qr-goal-val">${goalLabel}</span>
          <button class="qr-goal-btn" onclick="setPastQuranGoal(1)">＋</button>
        </div>
      </div>
      <div class="qr-btn-row">
        <button class="qr-pg-btn qr-minus"  onclick="addPastPages(-1)">−1</button>
        <button class="qr-pg-btn qr-plus"   onclick="addPastPages(1)">+1</button>
        <button class="qr-pg-btn qr-plus5"  onclick="addPastPages(5)">+5</button>
        <button class="qr-pg-btn qr-plus10" onclick="addPastPages(10)">+10</button>
      </div>
    </div>`;
}

function addPastPages(n) {
  const KEY = viewingDate;
  if(!daily[KEY]) daily[KEY] = {};
  const snap = daily[KEY];
  const goal = snap.quranGoal || quranData.goal || 5;
  snap.quranPages = Math.max(0, Math.min(goal, (snap.quranPages||0) + n));
  persistDay(KEY);
  const s = getDateSnapshot(KEY);
  renderQuranForSnap(s);
  renderKPIForSnap(s, KEY);
  renderStats();
}

function setPastQuranGoal(dir) {
  const KEY = viewingDate;
  if(!daily[KEY]) daily[KEY] = {};
  const goals = [1,2,3,4,5,10,20,30,100,200,604];
  const snap = daily[KEY];
  let idx = goals.indexOf(snap.quranGoal || quranData.goal || 5);
  if(idx===-1) idx = 4;
  idx = Math.max(0, Math.min(goals.length-1, idx+dir));
  snap.quranGoal  = goals[idx];
  snap.quranPages = Math.min(snap.quranPages||0, snap.quranGoal);
  persistDay(KEY);
  const s = getDateSnapshot(KEY);
  renderQuranForSnap(s);
  renderKPIForSnap(s, KEY);
}

// Sunnah - interactive checkboxes for past dates
function renderSunnahForSnap(s) {
  const KEY = viewingDate;
  const list = getSunnahList();
  const el = document.getElementById('sunnah-card');
  if(!el) return;
  el.innerHTML = list.map((h,i) => {
    const isDone = s.sunnah[i] || false;
    return `<div class="sunnah-item ${isDone?'done':''}" onclick="togglePastSunnah(${i})" style="cursor:pointer">
      <div class="sunnah-icon" style="background:${ha(h.color,.12)};border-color:${ha(h.color,.2)}">${h.icon}</div>
      <div class="sunnah-body">
        <div class="sunnah-name">${h.name}</div>
        <div class="sunnah-desc">${h.desc}</div>
      </div>
      <div class="sunnah-chk ${isDone?'done':''}">${isDone?'✓':''}</div>
    </div>`;
  }).join('');
}

function togglePastSunnah(i) {
  const KEY = viewingDate;
  if(!daily[KEY]) daily[KEY] = {};
  const list = getSunnahList();
  const arr = daily[KEY].sunnah || list.map(()=>false);
  while(arr.length < list.length) arr.push(false);
  arr[i] = !arr[i];
  daily[KEY].sunnah    = arr;
  daily[KEY].sunnahLen = list.length;
  persistDay(KEY);
  const s = getDateSnapshot(KEY);
  renderSunnahForSnap(s);
  renderKPIForSnap(s, KEY);
  renderStats();
}

// Dhikr - interactive counter for past dates
function renderDhikrForSnap(s) {
  const list = getDhikrList();
  const counts = s.dhikr && s.dhikr.length ? [...s.dhikr] : list.map(()=>0);
  const d = list[activeDhikr] || list[0];
  if(!d) return;
  const el = document.getElementById('dhikr-card');
  if(!el) return;
  const cnt = counts[activeDhikr] || 0;
  el.innerHTML = dhikrCardHTML(d, cnt, {
    onTap: 'tapPastDhikr()',
    onUndo: 'decPastDhikr()',
    onReset: 'resetPastDhikr()',
    onDel: ''
  });
}

function tapPastDhikr() {
  const KEY = viewingDate;
  if(!daily[KEY]) daily[KEY] = {};
  const list = getDhikrList();
  const arr = daily[KEY].dhikr && daily[KEY].dhikr.length ? [...daily[KEY].dhikr] : list.map(()=>0);
  while(arr.length < list.length) arr.push(0);
  const tgt = list[activeDhikr]?.target || 33;
  arr[activeDhikr] = (arr[activeDhikr]||0) + 1;
  daily[KEY].dhikr = arr;
  persistDay(KEY);
  renderDhikrForSnap(getDateSnapshot(KEY));
  renderKPIForSnap(getDateSnapshot(KEY), KEY);
}
function decPastDhikr() {
  const KEY = viewingDate;
  if(!daily[KEY]) daily[KEY] = {};
  const list = getDhikrList();
  const arr = daily[KEY].dhikr && daily[KEY].dhikr.length ? [...daily[KEY].dhikr] : list.map(()=>0);
  while(arr.length < list.length) arr.push(0);
  if(arr[activeDhikr] > 0) arr[activeDhikr]--;
  daily[KEY].dhikr = arr;
  persistDay(KEY);
  renderDhikrForSnap(getDateSnapshot(KEY));
  renderKPIForSnap(getDateSnapshot(KEY), KEY);
}

function resetPastDhikr() {
  const KEY = viewingDate;
  if(!daily[KEY]) daily[KEY] = {};
  const list = getDhikrList();
  const arr = daily[KEY].dhikr && daily[KEY].dhikr.length ? [...daily[KEY].dhikr] : list.map(()=>0);
  arr[activeDhikr] = 0;
  daily[KEY].dhikr = arr;
  persistDay(KEY);
  renderDhikrForSnap(getDateSnapshot(KEY));
}

// ==============================================
// DHIKR COUNTER  (built-in + custom)
// ==============================================
// DHIKR_BUILTIN hoisted to top of script

function loadCustomDhikrs() {
  try { const r=localStorage.getItem('mrd3_custom_dhikr'); if(r) return JSON.parse(r); } catch{}
  return [];
}
function saveCustomDhikrs(list) {
  try { localStorage.setItem('mrd3_custom_dhikr', JSON.stringify(list)); } catch{}
}

let customDhikrs = loadCustomDhikrs();

// Full merged list (built-in + custom)
function getDhikrList() { return [...DHIKR_BUILTIN, ...customDhikrs]; }

function renderDhikrTabs(){
  const list = getDhikrList();
  document.getElementById('dhikr-tabs').innerHTML =
    list.map((d,i)=>{
      const cnt  = (dhikrCounts[i]||0);
      const done = cnt >= d.target;
      const shortLabel = (d.tr || 'Dhikr').length > 18 ? (d.tr || 'Dhikr').slice(0,18) + '…' : (d.tr || 'Dhikr');
      return `<button class="dhikr-tab ${i===activeDhikr?'active':''} ${done?'tab-done':''}" onclick="setDhikr(${i})" title="${d.tr || 'Dhikr'}">${shortLabel}${done?' ✓':''}</button>`;
    }).join('') +
    `<button class="dhikr-tab add-tab" onclick="openDhikrModal()" title="Add another custom dhikr">＋ Add custom</button>`;
}

function dhikrCardHTML(d, c, opts) {
  // opts: { onTap, onUndo, onReset, onDel, isPast }
  const tgt  = d.target || 33;
  const pct  = Math.min(c / tgt * 100, 100);
  const done = c >= tgt;
  const remaining = Math.max(0, tgt - c);
  const isCustom = d.custom === true;
  const arc  = 2 * Math.PI * 52;
  const off  = (arc * (1 - pct / 100)).toFixed(2);
  const meanings = {
    'Subhanallah':'Glory be to Allah',
    'Alhamdulillah':'Praise be to Allah',
    'Allahu Akbar':'Allah is the Greatest',
    'La ilaha illallah':'There is no god but Allah',
    'Astaghfirullah':'I seek forgiveness from Allah'
  };
  const meaning = meanings[d.tr] || '';
  return `
    <div class="dhikr-main-card ${done?'done-card':''}" onclick="${opts.onTap}" style="position:relative">
      ${isCustom ? `<button class="dhikr-del-btn" onclick="${opts.onDel}">✕</button>` : ''}
      <svg class="dhikr-arc-wrap" width="110" height="110" viewBox="0 0 120 120">
        <circle cx="60" cy="60" r="52" fill="none" stroke="${done?'var(--green)':'var(--gold)'}" stroke-width="6"
          stroke-linecap="round" stroke-dasharray="${arc.toFixed(2)}" stroke-dashoffset="${off}"
          transform="rotate(-90 60 60)" style="transition:stroke-dashoffset .45s cubic-bezier(.22,1,.36,1)"/>
      </svg>
      <div class="dhikr-inner">
        <div class="dhikr-text-col">
          ${d.ar ? `<div class="dhikr-ar">${d.ar}</div>` : ''}
          <div class="dhikr-tr">${d.tr}</div>
          ${meaning ? `<div class="dhikr-meaning">${meaning}</div>` : ''}
        </div>
        <div class="dhikr-count-col">
          <div class="dhikr-count-big ${done?'done':''}">${c}</div>
          <div class="dhikr-count-of">/ ${tgt}</div>
        </div>
      </div>
      <div class="dhikr-prog-bar"><div class="dhikr-prog-fill ${done?'done':''}" style="width:${pct}%"></div></div>
    </div>
    <div class="dhikr-micro-row">
      <button class="dhikr-reset-btn2" onclick="${opts.onReset}">↺ reset</button>
      ${done
        ? `<span class="dhikr-done-badge">✓ complete</span>`
        : `<span class="dhikr-remain-lbl">${remaining} left</span>`
      }
      <button class="dhikr-undo-btn" onclick="${opts.onUndo}">− undo</button>
    </div>`;
}

function renderDhikrCard(){
  if(typeof viewingDate !== 'undefined' && viewingDate !== TODAY_KEY) {
    renderDhikrForSnap(getDateSnapshot(viewingDate)); return;
  }
  const list = getDhikrList();
  if(!list[activeDhikr]) activeDhikr = 0;
  const d = list[activeDhikr];
  if(!d) return;
  while(dhikrCounts.length < list.length) dhikrCounts.push(0);
  const c = dhikrCounts[activeDhikr] || 0;
  const isCustom = d.custom === true;
  const delStr = isCustom ? `deleteCustomDhikr(${activeDhikr - DHIKR_BUILTIN.length},event)` : '';
  document.getElementById('dhikr-card').innerHTML = dhikrCardHTML(d, c, {
    onTap: 'incrementDhikr()',
    onUndo: 'decrementDhikr()',
    onReset: 'resetDhikr()',
    onDel: delStr
  });
}
function setDhikr(i){
  activeDhikr=i;
  renderDhikrTabs();
  if(viewingDate !== TODAY_KEY) {
    renderDhikrForSnap(getDateSnapshot(viewingDate));
  } else {
    renderDhikrCard();
  }
}
function resetDhikr(){
  if(viewingDate !== TODAY_KEY) return;
  const list = getDhikrList();
  while(dhikrCounts.length < list.length) dhikrCounts.push(0);
  dhikrCounts[activeDhikr] = 0;
  persistDhikr(); renderDhikrCard(); renderDhikrTabs(); renderKPI(); updateDhikrTotal();
}

function incrementDhikr(){
  if(viewingDate !== TODAY_KEY) { tapPastDhikr(); return; }
  const list = getDhikrList();
  while(dhikrCounts.length < list.length) dhikrCounts.push(0);
  dhikrCounts[activeDhikr]++;
  const d = list[activeDhikr];
  const justDone = d && dhikrCounts[activeDhikr] === d.target;
  persistDhikr();
  renderDhikrCard();
  renderKPI();
  updateDhikrTotal();
  // Auto-advance to next incomplete dhikr after brief delay
  if(justDone) {
    const nextIdx = list.findIndex((x,i) => i > activeDhikr && (dhikrCounts[i]||0) < x.target);
    if(nextIdx !== -1) {
      setTimeout(() => { activeDhikr = nextIdx; renderDhikrTabs(); renderDhikrCard(); }, 900);
    } else {
      renderDhikrTabs();
    }
  }
}
function decrementDhikr(){
  if(viewingDate !== TODAY_KEY) { decPastDhikr(); return; }
  const list = getDhikrList();
  while(dhikrCounts.length < list.length) dhikrCounts.push(0);
  if(dhikrCounts[activeDhikr] > 0) dhikrCounts[activeDhikr]--;
  persistDhikr();
  renderDhikrCard();
  renderKPI();
}

// -- Custom dhikr modal -------------------------
function openDhikrModal() {
  const existing = customDhikrs[0];
  document.getElementById('cd-ar').value     = existing ? existing.ar  : '';
  document.getElementById('cd-tr').value     = existing ? existing.tr  : '';
  document.getElementById('cd-target').value = existing ? existing.target : 33;
  // highlight current target button
  document.querySelectorAll('.cd-tgt-btn').forEach(b => {
    const isActive = parseInt(b.dataset.val) === (existing ? existing.target : 33);
    b.style.cssText = isActive
      ? 'padding:7px 14px;border-radius:10px;border:1px solid var(--gold);background:rgba(var(--accent-rgb),.15);color:var(--gold);font-family:\'Outfit\',sans-serif;font-size:12px;cursor:pointer;transition:all .18s'
      : 'padding:7px 14px;border-radius:10px;border:1px solid var(--bd);background:transparent;color:var(--t3);font-family:\'Outfit\',sans-serif;font-size:12px;cursor:pointer;transition:all .18s';
  });
  const modal = document.getElementById('dhikr-ovl');
  modal.classList.add('open');
  setTimeout(()=>document.getElementById('cd-tr').focus(), 350);
}

function closeDhikrOvl(e) {
  if(e.target===document.getElementById('dhikr-ovl')||e.target.classList.contains('ovl-bg'))
    document.getElementById('dhikr-ovl').classList.remove('open');
}
function pickDhikrTarget(n, el) {
  document.getElementById('cd-target').value = n;
  document.querySelectorAll('.cd-tgt-btn').forEach(b => { b.style.background='transparent'; b.style.borderColor='var(--bd)'; b.style.color='var(--t3)'; });
  el.style.background='rgba(var(--accent-rgb),.15)'; el.style.borderColor='rgba(var(--accent-rgb),.5)'; el.style.color='var(--gold)';
}
function saveCustomDhikr() {
  const ar  = document.getElementById('cd-ar').value.trim();
  const tr  = document.getElementById('cd-tr').value.trim();
  const tgt = parseInt(document.getElementById('cd-target').value) || 33;
  if(!tr) {
    const inp = document.getElementById('cd-tr');
    inp.style.borderColor = 'var(--rose)';
    inp.style.boxShadow   = '0 0 0 2px rgba(var(--accent-rgb),.25)';
    setTimeout(()=>{ inp.style.borderColor=''; inp.style.boxShadow=''; }, 1200);
    return;
  }
  const entry = {ar, tr, target:tgt, custom:true};
  const modal = document.getElementById('dhikr-ovl');
  const editIndexRaw = modal.dataset.editIndex;
  const editIndex = editIndexRaw === '' ? -1 : parseInt(editIndexRaw, 10);

  if(Number.isInteger(editIndex) && editIndex >= 0 && customDhikrs[editIndex]) {
    customDhikrs[editIndex] = entry;
    activeDhikr = DHIKR_BUILTIN.length + editIndex;
  } else {
    customDhikrs.push(entry);
    dhikrCounts.push(0);
    activeDhikr = DHIKR_BUILTIN.length + customDhikrs.length - 1;
  }

  while(dhikrCounts.length < getDhikrList().length) dhikrCounts.push(0);
  saveCustomDhikrs(customDhikrs);
  persistDhikr();
  modal.classList.remove('open');
  modal.dataset.editIndex = '';
  renderDhikrTabs();
  renderDhikrCard();
  renderKPI();
}

function deleteCustomDhikr(customIdx, e) {
  e && e.stopPropagation();
  if(customIdx < 0 || customIdx >= customDhikrs.length) return;
  customDhikrs.splice(customIdx, 1);
  const absoluteIdx = DHIKR_BUILTIN.length + customIdx;
  if(dhikrCounts.length > absoluteIdx) dhikrCounts.splice(absoluteIdx, 1);
  saveCustomDhikrs(customDhikrs);
  persistDhikr();
  activeDhikr = Math.min(activeDhikr, getDhikrList().length - 1);
  if(activeDhikr < 0) activeDhikr = 0;
  renderDhikrTabs();
  renderDhikrCard();
  renderKPI();
}

function renderFasting(){
  if(viewingDate !== TODAY_KEY) { renderFastingForSnap(getDateSnapshot(viewingDate), viewingDate); return; }
  const todayK=dateKey(now);
  const isFasting=fastingData[todayK]||false;
  // Hijri context for this date
  const _hObj = toHijriObj(now);
  const _isRamadan   = _hObj.month === 9;
  const _isMonOrThu  = now.getDay()===1 || now.getDay()===4;
  const _isDhulHijjah= _hObj.month===12 && _hObj.day<=10;
  const _isAshura    = _hObj.month===1  && (_hObj.day===9||_hObj.day===10);
  // last 7 days
  const days7=[];
  for(let i=6;i>=0;i--){
    const d=new Date(now); d.setDate(d.getDate()-i);
    days7.push({key:dateKey(d),label:d.toLocaleDateString('en-US',{weekday:'short'}).slice(0,2),isToday:i===0});
  }
  // count this month
  const monthFasts=Object.entries(fastingData).filter(([k,v])=>v&&k.startsWith(now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0'))).length;
  // Sunnah days: 13,14,15 of Hijri (approximate - show tip)
  // Ramadan: count fasts in this Hijri month
  let ramadanFasted = 0, ramadanDay = _hObj.day;
  if(_isRamadan) {
    for(let d=1; d<=ramadanDay; d++) {
      // approximate Gregorian key for each Ramadan day
      const gd = new Date(now); gd.setDate(gd.getDate() - (ramadanDay - d));
      if(fastingData[dateKey(gd)]) ramadanFasted++;
    }
  }
  // Context tip
  let ctxTip = '';
  if(_isRamadan)     ctxTip = `🌙 Ramadan day ${_hObj.day} of 30 — ${ramadanFasted} fasts completed`;
  else if(_isAshura) ctxTip = `✨ Fast today & yesterday for Ashura (Muharram ${_hObj.day})`;
  else if(_isDhulHijjah && _hObj.day===9) ctxTip = `🤲 Today is Arafah — fasting expiates two years`;
  else if(_isMonOrThu)  ctxTip = `🤍 Sunnah fast — ${now.getDay()===1?'Monday':'Thursday'}`;
  else if(_hObj.day===13||_hObj.day===14||_hObj.day===15) ctxTip = `🌕 Ayyam al-Beed — white days fast (${_hObj.day} ${HIJRI_MONTHS_EN[_hObj.month-1]})`;

  const fastCardBorder = (_isRamadan||_isMonOrThu||_isDhulHijjah&&_hObj.day===9||_isAshura)
    ? 'border-color:rgba(var(--accent-rgb),.3);' : '';

  document.getElementById('fast-card').style.cssText += fastCardBorder;
  document.getElementById('fast-card').innerHTML=`
    <div class="fast-header">
      <div class="fast-title">${_isRamadan ? 'Ramadan Fasting' : 'Fasting Today'}</div>
      <label class="fast-toggle">
        <input type="checkbox" ${isFasting?'checked':''} onchange="toggleFast()">
        <div class="fast-slider"></div>
      </label>
    </div>
    <div class="fast-row">
      <div class="fast-info">
        <div class="fast-status" style="color:${isFasting?'var(--green)':'var(--t2)'}">${isFasting?t('Fasting 🤍'):t('Not fasting')}</div>
        <div class="fast-sub">${monthFasts} day${monthFasts!==1?'s':''} this month · Tap to toggle</div>
      </div>
    </div>
    <div class="fast-progress"><div class="fast-fill" style="width:${Math.min(monthFasts/30*100,100)}%"></div></div>
    ${_isRamadan ? `
    <div style="padding:0 14px 10px;display:flex;align-items:center;gap:8px">
      <div style="flex:1;height:4px;border-radius:99px;background:rgba(255,255,255,.07);overflow:hidden">
        <div style="height:100%;border-radius:99px;background:var(--gold);width:${(ramadanDay/30*100).toFixed(1)}%;transition:width .6s"></div>
      </div>
      <div style="font-size:10px;color:var(--gold);opacity:.8;white-space:nowrap">${ramadanDay}/30</div>
    </div>` : ''}
    ${ctxTip ? `<div style="margin:0 14px 12px;padding:7px 11px;border-radius:10px;background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.18);font-size:11px;color:var(--t2);line-height:1.4">${ctxTip}</div>` : ''}
    <div class="fast-days">
      ${days7.map(d=>`
        <div style="flex:1;text-align:center">
          <div class="fast-day-dot ${fastingData[d.key]?'fasted':''} ${d.isToday?'today-dot':''}" onclick="toggleFastDay('${d.key}')" title="${d.key}">
            ${fastingData[d.key]?'🤍':''}
          </div>
          <div class="fast-day">${d.label}</div>
        </div>`).join('')}
    </div>`;
}
function toggleFast(){
  if(viewingDate !== TODAY_KEY) { togglePastFast(viewingDate); return; }
  fastingData[TODAY_KEY]=!fastingData[TODAY_KEY];
  persistFasting();
  renderFasting();
}
function toggleFastDay(key){
  fastingData[key]=!fastingData[key];
  persistFasting();
  renderFasting();
}

// ==============================================
// QURAN MEMORIZER SECTION
// ==============================================
let _hifzTab = 'surah'; // 'surah' | 'juz' | 'ayah'

function _hifzGetProgress() {
  // Returns { surahNum: ayahsMemorized }
  try { return JSON.parse(localStorage.getItem('mrd_qr_hifz_prog') || '{}'); } catch { return {}; }
}
function _hifzSetProgress(obj) {
  try { localStorage.setItem('mrd_qr_hifz_prog', JSON.stringify(obj)); } catch {}
}
function _hifzGetHifzList() {
  // Legacy: fully memorized surahs
  try { return JSON.parse(localStorage.getItem('mrd_qr_hifz') || '[]'); } catch { return []; }
}
function _hifzLastOpened() {
  // Returns { surahNum: timestamp }
  try { return JSON.parse(localStorage.getItem('mrd_qr_last_open') || '{}'); } catch { return {}; }
}

function _hifzRingColor(pct) {
  if (pct >= 100) return 'var(--green)'; // green
  if (pct >= 50)  return '#d4a853'; // gold
  if (pct > 0)    return 'var(--teal)'; // teal
  return 'rgba(255,255,255,.15)';   // empty
}

function _hifzFormatLastOpened(ts) {
  if (!ts) return 'Never';
  const d = new Date(ts);
  const mo = d.toLocaleString('en', {month:'short', day:'numeric', year:'numeric'});
  const hr = d.getHours() % 12 || 12;
  const mn = String(d.getMinutes()).padStart(2,'0');
  const ap = d.getHours() >= 12 ? 'PM' : 'AM';
  return `${mo} - ${hr}:${mn} ${ap}`;
}

function _hifzRingHTML(pct, size=44) {
  const r = (size/2) - 4, circ = 2 * Math.PI * r;
  const offset = circ - (Math.min(pct,100)/100)*circ;
  const col = _hifzRingColor(pct);
  const label = pct >= 100 ? '100%' : (pct > 0 ? Math.round(pct)+'%' : '0%');
  return `<div class="hifz-ring">
    <svg viewBox="0 0 ${size} ${size}">
      <circle class="hifz-ring-bg" cx="${size/2}" cy="${size/2}" r="${r}"/>
      <circle class="hifz-ring-fg" cx="${size/2}" cy="${size/2}" r="${r}"
        stroke="${col}" stroke-dasharray="${circ.toFixed(1)}" stroke-dashoffset="${offset.toFixed(1)}"/>
    </svg>
    <div class="hifz-ring-pct" style="color:${col}">${label}</div>
  </div>`;
}

function renderQuran(){
  if(typeof viewingDate !== 'undefined' && viewingDate !== TODAY_KEY) {
    renderQuranForSnap(getDateSnapshot(viewingDate)); return;
  }

  const hifzList  = _hifzGetHifzList();   // fully memorized surah numbers
  const hifzProg  = _hifzGetProgress();   // { surahNum: memorizedAyahs }
  const lastOpen  = _hifzLastOpened();

  // Compute global stats
  const totalAyahs  = SURAHS.reduce((s,x) => s + x.v, 0); // 6236
  const totalSurahs = SURAHS.length; // 114
  const TOTAL_JUZ   = 30;

  // Ayah memorized = sum of hifzProg values + full surahs in hifzList
  let ayahMem = 0;
  SURAHS.forEach(s => {
    if (hifzList.includes(s.n)) { ayahMem += s.v; }
    else if (hifzProg[s.n] > 0) { ayahMem += Math.min(hifzProg[s.n]||0, s.v); }
  });

  // Surah memorized count
  const surahMem = hifzList.length + SURAHS.filter(s => !hifzList.includes(s.n) && hifzProg[s.n] >= s.v).length;

  // Juz: simple estimate from ayah progress (each juz ≈ 6236/30)
  const juzMem = Math.floor(ayahMem / (totalAyahs / TOTAL_JUZ));

  // Overall pct
  const hifzPct = Math.min(100, ayahMem / totalAyahs * 100);

  // Reading pages tracker (compact)
  const p = quranData.pages, g = quranData.goal;
  const readPct = Math.min(p/g*100, 100);
  const goalLabel = g===604 ? 'Full Quran' : g + ' pg';

  // Build surah rows for current tab
  let listHTML = '';
  if (_hifzTab === 'surah') {
    const rows = SURAHS.map(s => {
      const isFullMem = hifzList.includes(s.n) || hifzProg[s.n] >= s.v;
      const memAyahs  = isFullMem ? s.v : (hifzProg[s.n]||0);
      const pct       = Math.min(100, memAyahs / s.v * 100);
      const lo        = lastOpen[s.n];
      const loTxt     = lo ? _hifzFormatLastOpened(lo) : 'Never';
      return { s, pct, memAyahs, lo, loTxt };
    });
    // Sort: memorized first, then by number
    rows.sort((a,b) => b.pct - a.pct || a.s.n - b.s.n);

    listHTML = rows.map(({s, pct, memAyahs, loTxt}) => `
      <div class="hifz-row" onclick="event.stopPropagation();_hifzTrackOpen(${s.n});openFeatPage('page-quran');setTimeout(()=>qrSelectSurah(${s.n}),240)">
        ${_hifzRingHTML(pct)}
        <div class="hifz-row-info">
          <div class="hifz-row-name">${s.n}. ${s.ar} | ${s.en}</div>
          <div class="hifz-row-meta">Ayah Memorized: ${memAyahs}/${s.v} &nbsp;·&nbsp; Last Opened: ${loTxt}</div>
        </div>
        <div class="hifz-row-open">›</div>
      </div>`).join('');

  } else if (_hifzTab === 'juz') {
    // Juz list 1–30
    const JUZ_SURAH = [2,2,2,2,4,5,6,7,8,9,11,12,15,17,18,20,23,25,27,29,31,33,35,36,39,42,46,49,51,54,77];
    listHTML = Array.from({length:30},(_,i)=>i+1).map(jNum => {
      // Each juz: estimate progress
      const juzAyahTotal  = Math.round(totalAyahs / TOTAL_JUZ);
      const juzStart      = (jNum-1) * juzAyahTotal;
      const juzEnd        = jNum * juzAyahTotal;
      // Rough: count memorized ayahs that fall in this juz range
      let mem = 0, total = 0, cumulAyah = 0;
      for (const s of SURAHS) {
        const sStart = cumulAyah, sEnd = cumulAyah + s.v;
        const overlap = Math.max(0, Math.min(sEnd,juzEnd) - Math.max(sStart,juzStart));
        if (overlap > 0) {
          total += overlap;
          const sMemAyahs = hifzList.includes(s.n) ? s.v : Math.min(hifzProg[s.n]||0, s.v);
          mem += Math.round(overlap * sMemAyahs / s.v);
        }
        cumulAyah += s.v;
      }
      const pct = total > 0 ? Math.min(100, mem/total*100) : 0;
      return `<div class="hifz-row" onclick="event.stopPropagation()">
        ${_hifzRingHTML(pct)}
        <div class="hifz-row-info">
          <div class="hifz-row-name">Juz ${jNum}</div>
          <div class="hifz-row-meta">Ayah Memorized: ${mem}/${total}</div>
        </div>
        <div class="hifz-row-open">›</div>
      </div>`;
    }).join('');

  } else {
    // Ayah tab — show ayah-level breakdown per surah (same as surah but sorted by last opened)
    const rows = SURAHS.map(s => {
      const memAyahs = hifzList.includes(s.n) ? s.v : (hifzProg[s.n]||0);
      const pct = Math.min(100, memAyahs/s.v*100);
      const lo = lastOpen[s.n]||0;
      return {s, pct, memAyahs, lo};
    }).sort((a,b) => b.lo - a.lo || a.s.n - b.s.n);

    listHTML = rows.map(({s, pct, memAyahs, lo}) => `
      <div class="hifz-row" onclick="event.stopPropagation();_hifzTrackOpen(${s.n});openFeatPage('page-quran');setTimeout(()=>qrSelectSurah(${s.n}),240)">
        ${_hifzRingHTML(pct)}
        <div class="hifz-row-info">
          <div class="hifz-row-name">${s.n}. ${s.ar} | ${s.en}</div>
          <div class="hifz-row-meta">Ayah: ${memAyahs}/${s.v} &nbsp;·&nbsp; ${lo ? _hifzFormatLastOpened(lo) : 'Never opened'}</div>
        </div>
        <div class="hifz-row-open">›</div>
      </div>`).join('');
  }

  document.getElementById('quran-card').innerHTML = `
    <div style="padding:16px 16px 14px">

      <!-- Stats grid (2x2) -->
      <div class="hifz-stats-grid">
        <div class="hifz-stat-card" style="border-color:rgba(var(--accent-rgb),.18);background:linear-gradient(135deg,rgba(var(--accent-rgb),.09),rgba(var(--accent-rgb),.03))">
          <div class="hifz-stat-left">
            <div class="hifz-stat-lbl">Hifz Progress</div>
            <div class="hifz-stat-val">${hifzPct.toFixed(2)}<span>%</span></div>
          </div>
          <div class="hifz-stat-icon">☑️</div>
        </div>
        <div class="hifz-stat-card" style="border-color:rgba(var(--teal-rgb),.18);background:linear-gradient(135deg,rgba(var(--teal-rgb),.07),rgba(var(--teal-rgb),.02))">
          <div class="hifz-stat-left">
            <div class="hifz-stat-lbl">Surah Hifz</div>
            <div class="hifz-stat-val">${surahMem}<span>/ ${totalSurahs}</span></div>
          </div>
          <div class="hifz-stat-icon">📖</div>
        </div>
        <div class="hifz-stat-card" style="border-color:rgba(var(--purple-rgb),.18);background:linear-gradient(135deg,rgba(var(--purple-rgb),.07),rgba(var(--purple-rgb),.02))">
          <div class="hifz-stat-left">
            <div class="hifz-stat-lbl">Juz Hifz</div>
            <div class="hifz-stat-val">${juzMem}<span>/ 30</span></div>
          </div>
          <div class="hifz-stat-icon">📋</div>
        </div>
        <div class="hifz-stat-card" style="border-color:rgba(var(--green-rgb),.18);background:linear-gradient(135deg,rgba(var(--green-rgb),.07),rgba(var(--green-rgb),.02))">
          <div class="hifz-stat-left">
            <div class="hifz-stat-lbl">Ayah Hifz</div>
            <div class="hifz-stat-val">${ayahMem}<span>/ ${totalAyahs}</span></div>
          </div>
          <div class="hifz-stat-icon">📝</div>
        </div>
      </div>

      <!-- Reading tracker (compact row) -->
      <div onclick="event.stopPropagation()" style="display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:13px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);margin-bottom:12px">
        <span style="font-size:0.4375rem;letter-spacing:.14em;text-transform:uppercase;color:var(--t3);flex-shrink:0">Today's Reading</span>
        <div style="flex:1;height:3px;border-radius:99px;background:rgba(255,255,255,.07);overflow:hidden">
          <div style="height:100%;width:${readPct}%;background:linear-gradient(90deg,rgba(var(--accent-rgb),.7),var(--gold));border-radius:99px;transition:width .8s cubic-bezier(.22,1,.36,1)"></div>
        </div>
        <span style="font-size:0.625rem;color:var(--gold);font-weight:600;white-space:nowrap">${p} / ${goalLabel}</span>
        <div style="display:flex;gap:4px;flex-shrink:0">
          <button onclick="addPages(-1)" style="width:22px;height:22px;border-radius:50%;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);color:var(--t2);font-size:0.75rem;cursor:pointer;display:flex;align-items:center;justify-content:center;-webkit-tap-highlight-color:transparent">−</button>
          <button onclick="addPages(1)"  style="width:22px;height:22px;border-radius:50%;border:1px solid rgba(var(--accent-rgb),.3);background:rgba(var(--accent-rgb),.1);color:var(--gold);font-size:0.75rem;cursor:pointer;display:flex;align-items:center;justify-content:center;-webkit-tap-highlight-color:transparent">+</button>
        </div>
      </div>

      <!-- Surah / Juz / Ayah tabs -->
      <div class="hifz-tabs" onclick="event.stopPropagation()">
        <button class="hifz-tab ${_hifzTab==='surah'?'active':''}" onclick="_hifzSetTab('surah')">Surah</button>
        <button class="hifz-tab ${_hifzTab==='juz'?'active':''}"   onclick="_hifzSetTab('juz')">Juz</button>
        <button class="hifz-tab ${_hifzTab==='ayah'?'active':''}"  onclick="_hifzSetTab('ayah')">Ayah</button>
      </div>

      <!-- List -->
      <div class="hifz-list" onclick="event.stopPropagation()">
        ${listHTML}
      </div>

      <!-- Open full reader button -->
      <button class="hifz-view-all" onclick="event.stopPropagation();openFeatPage('page-quran')">
        📖 Open Quran Reader
      </button>

    </div>`;
}

function _hifzSetTab(tab) {
  _hifzTab = tab;
  renderQuran();
}
function _hifzTrackOpen(surahNum) {
  try {
    const obj = JSON.parse(localStorage.getItem('mrd_qr_last_open')||'{}');
    obj[surahNum] = Date.now();
    localStorage.setItem('mrd_qr_last_open', JSON.stringify(obj));
  } catch {}
}
function _hifzMarkAyah(surahNum, ayahCount) {
  const prog = _hifzGetProgress();
  prog[surahNum] = Math.max(prog[surahNum]||0, ayahCount);
  _hifzSetProgress(prog);
  renderQuran();
}
function addPages(n){
  quranData.pages=Math.max(0,Math.min(quranData.goal,quranData.pages+n));
  persistQuran(); renderQuran(); renderKPI(); renderStats();
}
function setQuranGoal(dir){
  const goals=[1,2,3,4,5,10,20,30,100,200,604];
  let idx=goals.indexOf(quranData.goal);
  if(idx===-1) idx=goals.length-1;
  idx=Math.max(0,Math.min(goals.length-1,idx+dir));
  quranData.goal=goals[idx];
  quranData.pages=Math.min(quranData.pages,quranData.goal);
  persistQuran(); renderQuran();
}

// ==============================================
// DATE STRIP + ACTIVITY LIST (PER-DAY)
// ==============================================
function renderDateStrip() {
  const strip = document.getElementById('date-strip');
  if(!strip) return;
  const chips = [];
  for(let i=13; i>=0; i--) {
    const d = new Date(now); d.setDate(d.getDate()-i);
    const k = dateKey(d);
    const isToday  = k === TODAY_KEY;
    const isActive = k === viewingDate;
    const hasActs  = (dayActs[k]||[]).length > 0 ||
      (daily[k]?.prayers && Object.values(daily[k].prayers).some(Boolean));
    chips.push({key:k, dow:isToday?'Today':d.toLocaleDateString('en-US',{weekday:'short'}).slice(0,2), num:d.getDate(), isToday, isActive, hasActs});
  }
  strip.innerHTML = chips.map(c => {
    const cls = ['date-chip',
      c.isActive ? 'active'      : '',
      c.isToday  ? 'today-chip'  : '',
      c.hasActs  ? 'has-acts'    : '',
    ].filter(Boolean).join(' ');
    return `<button class="${cls}" onclick="switchDate('${c.key}')">
      <span class="dc-dow">${c.dow}</span>
      <span class="dc-num">${c.num}</span>
      <span class="dc-dot"></span>
    </button>`;
  }).join('');
  requestAnimationFrame(()=>{
    const active = strip.querySelector('.date-chip.active');
    if(active) {
      const stripEl = active.closest('#date-strip') || active.parentElement;
      if(stripEl) {
        const chipCenter = active.offsetLeft + active.offsetWidth / 2;
        stripEl.scrollLeft = chipCenter - stripEl.clientWidth / 2;
      }
    }
  });
}


function saveTodaySnapshot() {
  if(!daily[TODAY_KEY]) daily[TODAY_KEY] = {};
  daily[TODAY_KEY].acts        = dayActs[TODAY_KEY] || [];
  daily[TODAY_KEY].prayers     = {...prayerDone};
  daily[TODAY_KEY].fasting     = fastingData[TODAY_KEY] || false;
  daily[TODAY_KEY].dhikr       = [...dhikrCounts];
  daily[TODAY_KEY].quranPages  = quranData.pages;
  daily[TODAY_KEY].quranGoal   = quranData.goal;
  daily[TODAY_KEY].sunnah        = [...sunnahDone];
  daily[TODAY_KEY].sunnahLen     = getSunnahList().length;
  daily[TODAY_KEY].prayerQuality = {...prayerQuality};
}

// Load a past day's snapshot into display variables (read-only view)
// Returns an object with the day's data for render functions
function getDateSnapshot(key) {
  const snap = daily[key] || {};
  return {
    acts:        snap.acts        || [],
    prayers:     snap.prayers     || {Fajr:false,Dhuhr:false,Asr:false,Maghrib:false,Isha:false},
    prayerQuality: snap.prayerQuality || {Fajr:null,Dhuhr:null,Asr:null,Maghrib:null,Isha:null},
    fasting:     snap.fasting     || false,
    dhikr:       snap.dhikr       || getDhikrList().map(()=>0),
    quranPages:  snap.quranPages  ?? 0,
    quranGoal:   snap.quranGoal   ?? quranData.goal,
    sunnah:      snap.sunnah      || getSunnahList().map(()=>false),
    sunnahLen:   snap.sunnahLen   ?? getSunnahList().length,
    noteText:    snap.noteText    || '',
    noteMoods:   snap.noteMoods   || [],
    health:      snap.health      || loadHealth(key),
  };
}

function switchDate(key) {
  // Save today before leaving (so returning restores correctly)
  saveTodaySnapshot();
  persist();

  viewingDate  = key;
  statsViewDate = key;  // keep Progress tab in sync with home date selection

  // Reset expanded state so Top 5 collapses fresh for each day
  activitiesExpanded = false;
  sunnahExpanded     = false;

  // Sync date picker
  const dp = document.getElementById('date-picker');
  if(dp) dp.value = key;

  // Re-render all today-view widgets with the correct day's data
  renderAllForDate(key);

  renderIslamicDayBadge();
  renderSunnahHijriTip();
  renderDateStrip();
  renderViewingBanner();
  // No auto-scroll on date change — user stays at current scroll position

  // Show Add button for all dates (past days are now editable)
  const addWrap = document.getElementById('add-wrap');
  if(addWrap) addWrap.style.display = '';

  switchNoteDate(key);
  updateHdrDateLabel();
  // Update prayer date nav label if present
  if (typeof window._updatePrayerDateLabel === 'function') window._updatePrayerDateLabel(key);
}

// Re-render ALL today-view widgets for a given date key
function renderAllForDate(key) {
  const isToday = key === TODAY_KEY;

  // Mood checkin — only relevant for today
  const moodCard = document.getElementById('mood-checkin-card');
  if (moodCard) moodCard.style.display = isToday ? '' : 'none';
  if(typeof renderNafsCoach === 'function') renderNafsCoach(key);

  if(isToday) {
    // Restore live today variables from saved snapshot so renders are accurate
    const snap = daily[TODAY_KEY] || {};
    if(snap.prayers)       Object.assign(prayerDone, snap.prayers);
    if(snap.prayerQuality) Object.assign(prayerQuality, snap.prayerQuality);
    if(snap.dhikr)         dhikrCounts = [...snap.dhikr];
    if(snap.sunnah)        sunnahDone  = [...snap.sunnah];
    if(snap.quranPages !== undefined) quranData.pages = snap.quranPages;
    if(snap.quranGoal  !== undefined) quranData.goal  = snap.quranGoal;
    renderList(); renderKPI(); renderFasting(); renderQuran();
    renderSunnah(); renderDhikrTabs(); renderDhikrCard(); renderPrayers();
    renderHealthTracker();
    if(typeof renderMoodCheckin === 'function') renderMoodCheckin();
renderNafsCoach();
  } else {
    const s = getDateSnapshot(key);
    renderList();
    renderKPIForSnap(s, key);
    renderFastingForSnap(s, key);
    renderQuranForSnap(s);
    renderSunnahForSnap(s);
    renderDhikrForSnap(s);
    renderPrayersForSnap(s);
    renderHealthTrackerForSnap(s);
  }
}

// ==============================================
// HEADER DATE PICKER SHEET
// ==============================================

function openDateSheet() {
  // If already on a past date, one tap jumps back to today
  // Otherwise open the sheet
  renderHdrSheet();
  document.getElementById('hdr-date-sheet').classList.add('open');
  document.getElementById('hdr-sheet-overlay').classList.add('open');
  // Set the jump picker to current viewingDate
  const picker = document.getElementById('hdr-sheet-picker');
  if(picker) {
    picker.value = viewingDate;
    picker.min = '1900-01-01';
    picker.max = '2200-12-31';
  }
  // Scroll active chip to center
  requestAnimationFrame(()=>{
    const strip = document.getElementById('hdr-sheet-strip');
    const active = strip && strip.querySelector('.hdr-chip.active');
    if(active) active.scrollIntoView({behavior:'smooth',inline:'center',block:'nearest'});
  });
}

function closeDateSheet() {
  document.getElementById('hdr-date-sheet').classList.remove('open');
  document.getElementById('hdr-sheet-overlay').classList.remove('open');
}

function renderHdrSheet() {
  const strip = document.getElementById('hdr-sheet-strip');
  if(!strip) return;
  // 30-day rolling window, oldest left to today right
  const chips = [];
  for(let i=29; i>=0; i--) {
    const d = new Date(now); d.setDate(d.getDate()-i);
    const k = dateKey(d);
    const snap = daily[k];
    const hasData = snap && (
      (snap.acts && snap.acts.length) ||
      (snap.prayers && Object.values(snap.prayers).some(Boolean)) ||
      snap.fasting || (snap.noteText && snap.noteText.trim()) ||
      (snap.dhikr && snap.dhikr.some(c=>c>0)) ||
      (snap.quranPages && snap.quranPages>0)
    );
    chips.push({key:k, dow:d.toLocaleDateString('en-US',{weekday:'short'}), num:d.getDate(), isToday:i===0, hasData});
  }
  strip.innerHTML = chips.map(c=>`
    <div class="hdr-chip ${c.key===viewingDate?'active':''} ${c.isToday?'today-chip':''} ${c.hasData?'has-data':''}"
      onclick="selectHdrDate('${c.key}')">
      <div class="hdr-chip-dow">${c.isToday?'Today':c.dow}</div>
      <div class="hdr-chip-num">${c.num}</div>
      <div class="hdr-chip-dot"></div>
    </div>`).join('');
}

function selectHdrDate(key) {
  closeDateSheet();
  switchDate(key);
  // Scroll the view to the top so user sees header date changed
  const todayView = document.getElementById('view-today');
  if(todayView) todayView.scrollTo({ top: 0, behavior: 'smooth' });
}

function onHdrPickerChange(val) {
  if(!val) return;
  selectHdrDate(val);
}

function hdrJumpToToday() {
  closeDateSheet();
  switchDate(TODAY_KEY);
}

function updateHdrDateLabel() {
  const lbl  = document.getElementById('hdr-eye-date');
  const back = document.getElementById('hdr-eye-back');
  if(!lbl) return;
  const isPast = viewingDate !== TODAY_KEY;
  if(isPast) {
    const d = new Date(viewingDate+'T00:00:00');
    lbl.textContent = d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});
    lbl.classList.add('past');
    if(back) back.classList.add('show');
  } else {
    lbl.textContent = now.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});
    lbl.classList.remove('past');
    if(back) back.classList.remove('show');
  }
  // Brief flash to confirm the label changed
  lbl.style.transition = 'none';
  lbl.style.opacity = '0.3';
  requestAnimationFrame(() => {
    lbl.style.transition = 'opacity .25s';
    lbl.style.opacity = '1';
  });
}

function jumpToToday() {
  switchDate(TODAY_KEY);
  const dp = document.getElementById('date-picker');
  if(dp) dp.value = TODAY_KEY;
  updateHdrDateLabel();
}

function onDatePickerChange(val) {
  if(!val) return;
  const dp = document.getElementById('date-picker');
  if(dp) dp.value = val;
  switchDate(val);
  renderDateStrip();
}

function renderViewingBanner() {
  const banner = document.getElementById('viewing-banner');
  if(!banner) return;
  if(viewingDate === TODAY_KEY) {
    banner.style.display = 'none';
    return;
  }
  const d = new Date(viewingDate+'T00:00:00');
  const label = d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});
  const hDate = toHijri(d);
  const snap  = getDateSnapshot(viewingDate);
  const actsDone  = snap.acts.filter(a=>a.done).length;
  const actsTotal = snap.acts.length;
  const praysDone = Object.values(snap.prayers).filter(Boolean).length;
  const sunnahDoneCount = snap.sunnah.filter(Boolean).length;
  const sunnahTotal = getSunnahList().length;

  banner.style.display = 'block';
  banner.className = 'viewing-banner past';
  banner.innerHTML = `
    <div class="vb-top-row">
      <div class="vb-left">
        <span class="vb-icon">✏️</span>
        <div>
          <div style="font-size:12px;font-weight:600;color:var(--gold)">${label}</div>
          <div style="font-size:10px;opacity:.65;margin-top:1px">${hDate}</div>
        </div>
      </div>
      <button class="vb-back" onclick="jumpToToday()">↩ Today</button>
    </div>
    <div class="vb-score-row">
      <div class="vb-stat"><span style="color:var(--teal)">${actsDone}/${actsTotal}</span><span>${t('Activities')}</span></div>
      <div class="vb-stat"><span style="color:var(--gold)">${praysDone}/5</span><span>${t('Prayers')}</span></div>
      <div class="vb-stat"><span style="color:var(--amber)">${sunnahDoneCount}/${sunnahTotal}</span><span>${t('Sunnah')}</span></div>
      <div class="vb-stat"><span style="color:${snap.fasting?'var(--green)':'var(--t3)'}">${snap.fasting?'✓':'—'}</span><span>${t('Fasting')}</span></div>
    </div>
    <div class="vb-actions">
      <button class="vb-act-btn" onclick="catchUpAllPrayers()">${t('🕌 All Prayers')}</button>
      <button class="vb-act-btn" onclick="catchUpAllActivities()">${t('✅ All Activities')}</button>
      <button class="vb-act-btn" onclick="catchUpAllSunnah()">${t('🌙 All Sunnah')}</button>
    </div>`;
}

// -- Catch-up batch functions ------------------
function catchUpAllPrayers() {
  const KEY = viewingDate;
  if(!daily[KEY]) daily[KEY] = {};
  if(!daily[KEY].prayers) daily[KEY].prayers = {};
  PRAYERS.forEach(p => { daily[KEY].prayers[p] = true; });
  persistDay(KEY);
  renderAllForDate(KEY); renderViewingBanner(); renderStats();
}

function catchUpAllActivities() {
  const KEY = viewingDate;
  const list = getActs(KEY);
  if(!list.length) { showSettingsToast('No activities to mark'); return; }
  const allDone = list.every(a=>a.done);
  list.forEach(a => a.done = !allDone); // toggle all: if all done to undo, else mark all
  setActs(KEY, list);
  persistDay(KEY);
  renderList(); renderViewingBanner();
  renderKPIForSnap(getDateSnapshot(KEY), KEY);
  renderStats();
}

function catchUpAllSunnah() {
  const KEY = viewingDate;
  if(!daily[KEY]) daily[KEY] = {};
  const list = getSunnahList();
  const arr  = daily[KEY].sunnah || list.map(()=>false);
  while(arr.length < list.length) arr.push(false);
  const allDone = arr.every(Boolean);
  daily[KEY].sunnah    = arr.map(()=>!allDone);
  daily[KEY].sunnahLen = list.length;
  persistDay(KEY);
  const s = getDateSnapshot(KEY);
  renderSunnahForSnap(s);
  renderKPIForSnap(s, KEY);
  renderViewingBanner();
  renderStats();
}

function renderList() {
  const el   = document.getElementById('list');
  const sugg = document.getElementById('act-suggestions');
  if(!el) return;
  const list = getActs(viewingDate);

  // Essentiality ranking: assign a category weight so Islamic essentials surface first
  const ESSENTIAL_NAMES = [
    'Morning Adhkar','Evening Adhkar','Read Quran','Memorise Quran','Make Istighfar',
    'Extra Dhikr','Islamic Study','Attend Masjid','Tahajjud','Duha Prayer',
    'Read Islamic Book','Give Sadaqah','Help Someone','Call Family','Avoid Haram',
    'Suhoor/Iftar'
  ];
  const HEALTH_NAMES = [
    'Morning Walk','Drink Water','Exercise','Healthy Eating','Good Sleep',
    'Cycling','Stretching','Eat Fruit','Power Nap','No Junk Food'
  ];
  function essentialityScore(a) {
    if (a.hidden) return 1000; // always last
    if (a.done)   return 500 + (ESSENTIAL_NAMES.includes(a.name) ? 0 : HEALTH_NAMES.includes(a.name) ? 10 : 20);
    // undone: Islamic essentials = 0-15, Health = 20-35, rest = 40+
    if (ESSENTIAL_NAMES.includes(a.name)) return 0;
    if (HEALTH_NAMES.includes(a.name))    return 20;
    return 40;
  }

  // Sort: by essentiality (undone Islamic first, then health, then rest, then done, then hidden)
  const sorted = list
    .map((a,i) => ({...a, _i:i}))
    .sort((a,b) => essentialityScore(a) - essentialityScore(b));

  const VISIBLE_COUNT = 5;
  const mainItems   = sorted.slice(0, VISIBLE_COUNT);
  const hiddenItems = sorted.slice(VISIBLE_COUNT);

  // Update activity count label (now that sorted is available)
  const cntEl = document.getElementById('act-count-lbl');
  const top5Lbl = document.getElementById('act-top5-lbl');

  // Update Daily Top 5 label — show "· Daily Top 5" for today, "· Top 5" for past dates
  if (top5Lbl) {
    const isToday = (typeof viewingDate === 'undefined' || viewingDate === TODAY_KEY);
    top5Lbl.textContent = isToday ? '· Daily Top 5' : '· Top 5';
  }

  if(cntEl) {
    const visible = list.filter(a=>!a.hidden);
    const done    = visible.filter(a=>a.done).length;
    const hiddenC = list.filter(a=>a.hidden).length;
    const total5  = Math.min(visible.length, 5);
    const done5   = sorted.slice(0, 5).filter(a => a.done && !a.hidden).length;
    cntEl.textContent = list.length
      ? (visible.length > 5
          ? `${done5}/${total5} shown${hiddenC ? ` (+${hiddenC} hidden)` : ''}`
          : (hiddenC ? `${done}/${visible.length} (+${hiddenC} hidden)` : `${done}/${visible.length}`))
      : '';
  }

  function actHTML(a) {
    return `
    <div class="itm glass ${a.hidden?'itm-hidden':''} ${a.done&&!a.hidden?'done':''}" style="--i:${a._i};${a.hidden?'opacity:.42':''}" onclick="${a.hidden?'':('toggleAct('+a._i+',event)')}">
      <div class="itm-stripe" style="background:${a.hidden?'var(--t3)':a.color}"></div>
      <div class="itm-icon" style="background:${a.hidden?'rgba(255,255,255,.04)':ha(a.color,.14)};border-color:${a.hidden?'rgba(255,255,255,.07)':ha(a.color,.2)}">${a.icon}</div>
      <div class="itm-body">
        <div class="itm-name" style="${a.hidden?'color:var(--t2)':''}">${a.name}</div>
        <div class="itm-meta">${a.hidden?'<span style="font-size:0.5625rem;color:var(--t3);letter-spacing:.06em">HIDDEN · not counted</span>':a.meta}</div>
      </div>
      <div class="itm-end" style="display:flex;align-items:center;gap:6px;width:auto">
        ${a.hidden ? `<button class="itm-hide-btn" onclick="toggleHideAct(${a._i},event)" title="Show"
          style="font-size:0.625rem;color:var(--teal);background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.2);border-radius:8px;padding:4px 9px;cursor:pointer;-webkit-tap-highlight-color:transparent;white-space:nowrap">Show</button>` : `
        <button class="itm-hide-btn" onclick="toggleHideAct(${a._i},event)" title="Hide"
          style="font-size:0.625rem;color:var(--t3);background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);border-radius:8px;padding:4px 9px;cursor:pointer;-webkit-tap-highlight-color:transparent;white-space:nowrap;opacity:.6">Hide</button>
        <div class="itm-chk ${a.done?'done':''}" style="${a.done?'':'opacity:.45'}">${a.done?'✓':''}</div>`}
        <div class="itm-del" onclick="delAct(${a._i},event)">✕</div>
      </div>
    </div>`;
  }

  // Render empty state or items
  let html = '';
  if(sorted.length === 0) {
    html = `<div class="empty" style="padding:32px 20px;font-size:1.0rem">No activities yet · tap Add Activity below</div>`;
  } else {
    html = mainItems.map(actHTML).join('');

    if(hiddenItems.length) {
      const hiddenDone = hiddenItems.filter(a => a.done && !a.hidden).length;
      html += `
        <div style="margin-top:6px">
          <button onclick="activitiesExpanded=!activitiesExpanded;renderList()"
            style="width:100%;display:flex;align-items:center;justify-content:space-between;padding:11px 16px;border-radius:16px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.03);color:var(--t2);font-family:'Manrope',sans-serif;font-size:0.75rem;cursor:pointer;-webkit-tap-highlight-color:transparent;touch-action:manipulation;transition:background .15s">
            <span style="display:flex;align-items:center;gap:7px">
              <span>${activitiesExpanded ? '▲' : '▼'}</span>
              <span>${activitiesExpanded ? 'Show less' : `${hiddenItems.length} more · lower priority`}</span>
            </span>
            <span style="font-size:0.625rem;color:${hiddenDone===hiddenItems.filter(a=>!a.hidden).length&&hiddenItems.length?'var(--green)':'var(--t3)'}">${hiddenDone}/${hiddenItems.filter(a=>!a.hidden).length} done</span>
          </button>
          ${activitiesExpanded ? `<div style="margin-top:6px">${hiddenItems.map(actHTML).join('')}</div>` : ''}
        </div>`;
    }
  }

  el.innerHTML = html;

  // Render Top 5 inline suggestions on home screen
  if(sugg) {
    const addedNames = new Set(getActs(viewingDate).map(a => a.name));
    const available  = DEFAULT_ACTIVITIES.filter(a => !addedNames.has(a.name));

    const ESSENTIAL_ORDER = [
      'Morning Adhkar','Evening Adhkar','Read Quran','Memorise Quran','Make Istighfar',
      'Extra Dhikr','Islamic Study','Attend Masjid','Tahajjud','Duha Prayer',
      'Read Islamic Book','Give Sadaqah','Help Someone','Call Family','Avoid Haram','Suhoor/Iftar'
    ];
    const HEALTH_ORDER = [
      'Morning Walk','Drink Water','Exercise','Healthy Eating','Good Sleep',
      'Cycling','Stretching','Eat Fruit','Power Nap','No Junk Food'
    ];
    function suggPriority(a) {
      const ei = ESSENTIAL_ORDER.indexOf(a.name);
      if (ei !== -1) return ei;
      const hi = HEALTH_ORDER.indexOf(a.name);
      if (hi !== -1) return 100 + hi;
      return 200;
    }

    const top5 = [...available].sort((a,b) => suggPriority(a) - suggPriority(b)).slice(0, 5);

    if(top5.length) {
      sugg.innerHTML = `
        <div style="padding:8px 0 4px">
          <div style="font-size:0.4375rem;letter-spacing:.2em;text-transform:uppercase;color:var(--gold);opacity:.75;margin-bottom:8px;display:flex;align-items:center;gap:8px;padding:0 14px">
            ⭐ Suggested for today
            <span style="flex:1;height:1px;background:rgba(var(--accent-rgb),.2);display:block"></span>
          </div>
          <div style="display:flex;gap:8px;overflow-x:auto;padding:2px 14px 6px;scrollbar-width:none;-webkit-overflow-scrolling:touch">
            ${available.sort((a,b) => suggPriority(a) - suggPriority(b)).map(a => `
              <button onclick="quickAddAct(${JSON.stringify(a).replace(/"/g,'&quot;')})"
                style="flex:0 0 auto;display:flex;flex-direction:column;align-items:center;gap:6px;padding:12px 10px 10px;border-radius:18px;border:1px solid rgba(var(--accent-rgb),.2);background:rgba(var(--accent-rgb),.06);color:var(--t2);font-family:'Manrope',sans-serif;cursor:pointer;-webkit-tap-highlight-color:transparent;touch-action:manipulation;transition:all .18s;width:80px;min-width:80px">
                <span style="width:36px;height:36px;border-radius:11px;background:rgba(var(--accent-rgb),.1);border:1px solid rgba(var(--accent-rgb),.2);display:flex;align-items:center;justify-content:center;font-size:1.125rem">${a.icon}</span>
                <span style="font-size:0.5625rem;color:var(--text);font-weight:500;text-align:center;line-height:1.3;word-break:break-word">${a.name}</span>
              </button>`).join('')}
          </div>
        </div>`;
    } else {
      sugg.innerHTML = '';
    }
  }
}

function toggleQADropdown(e) {
  e && e.stopPropagation();
  const menu  = document.getElementById('qa-menu');
  const arrow = document.getElementById('qa-arrow');
  const dd    = document.getElementById('qa-dropdown');
  if(!menu) return;
  const open = menu.classList.toggle('open');
  if(arrow) arrow.style.transform = open ? 'rotate(180deg)' : '';
  if(dd)    dd.classList.toggle('open', open);
  if(open) {
    // Close when tapping outside
    setTimeout(() => {
      document.addEventListener('click', closeQADropdown, {once:true});
    }, 10);
  }
}
function closeQADropdown() {
  const menu  = document.getElementById('qa-menu');
  const arrow = document.getElementById('qa-arrow');
  const dd    = document.getElementById('qa-dropdown');
  if(menu)  menu.classList.remove('open');
  if(arrow) arrow.style.transform = '';
  if(dd)    dd.classList.remove('open');
}

function quickAddAct(a) {
  const key  = viewingDate;
  const list = getActs(key);
  list.push({ icon: a.icon, name: a.name, meta: a.meta, color: a.color, done: false });
  setActs(key, list);
  persistDay(key);
  renderList();
  renderKPIDebounced();
  renderStatsDebounced();
  updateScorePill();
}

function toggleAct(i,e){
  if(e.target.closest('.itm-del')) return;
  const list = getActs(viewingDate);
  list[i].done = !list[i].done;
  setActs(viewingDate, list);
  // ripple
  const el=e.currentTarget, bnd=el.getBoundingClientRect();
  const rip=document.createElement('div');
  rip.className='rip-el';
  rip.style.cssText=`left:${e.clientX-bnd.left-11}px;top:${e.clientY-bnd.top-11}px;background:${list[i].color}`;
  el.appendChild(rip);
  setTimeout(()=>rip.remove(),750);
  persistDay(viewingDate); renderList(); renderKPI(); renderStats(); renderDateStrip();
}

// Keep old name for backward compat
function toggle(i,e){ toggleAct(i,e); }

function delAct(i,e){
  e.stopPropagation();
  const list = getActs(viewingDate);
  list.splice(i,1);
  setActs(viewingDate, list);
  persistDay(viewingDate); renderList(); renderKPI(); renderStats(); renderDateStrip();
}

function toggleHideAct(i, e) {
  e && e.stopPropagation();
  const list = getActs(viewingDate);
  if(!list[i]) return;
  list[i].hidden = !list[i].hidden;
  // If hiding a done act, also uncheck it so score doesn't count it
  if(list[i].hidden) list[i].done = false;
  setActs(viewingDate, list);
  persistDay(viewingDate);
  renderList();
  renderKPI();
  updateScorePill();
  renderStatsDebounced();
}

// ==============================================
// STATS VIEW - UNIFIED ISLAMIC SCORE
// ==============================================
// ==============================================
// STATS DATE STATE
// ==============================================
let statsViewDate = TODAY_KEY;   // which day the Progress tab is showing

function renderStatsDateStrip() {
  const strip = document.getElementById('stats-date-strip');
  if(!strip) return;
  const chips = [];
  // 30 days rolling window, oldest left to today right
  for(let i=29; i>=0; i--) {
    const d = new Date(now); d.setDate(d.getDate()-i);
    const k = dateKey(d);
    const snap = daily[k];
    const hasData = snap && (
      (snap.acts && snap.acts.length) ||
      (snap.prayers && Object.values(snap.prayers).some(Boolean)) ||
      snap.fasting || (snap.noteText && snap.noteText.trim()) ||
      (snap.dhikr && snap.dhikr.some(c=>c>0)) ||
      (snap.quranPages && snap.quranPages>0)
    );
    chips.push({ key:k, dow: d.toLocaleDateString('en-US',{weekday:'short'}), num: d.getDate(), isToday: i===0, hasData });
  }
  strip.innerHTML = chips.map(c=>`
    <div class="sdc ${c.key===statsViewDate?'active':''} ${c.isToday?'today-sdc':''} ${c.hasData?'has-data':''}"
      onclick="switchStatsDate('${c.key}')">
      <div class="sdc-dow">${c.isToday?'Today':c.dow}</div>
      <div class="sdc-num">${c.num}</div>
      <div class="sdc-dot"></div>
    </div>`).join('');
  // Auto-scroll active chip into view
  requestAnimationFrame(()=>{
    const active = strip.querySelector('.sdc.active');
    if(active) active.scrollIntoView({behavior:'smooth',block:'nearest',inline:'center'});
  });
}

function updateStatsDateBar() {
  const lbl = document.getElementById('stats-date-lbl');
  const btn = document.getElementById('stats-back-today-btn');
  if(!lbl) return;
  if(statsViewDate === TODAY_KEY) {
    lbl.innerHTML = '<strong>Today</strong> · ' + new Date(statsViewDate+'T00:00:00').toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'});
    if(btn) btn.style.display = 'none';
  } else {
    const d = new Date(statsViewDate+'T00:00:00');
    const label = d.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'});
    lbl.innerHTML = `<strong>${label}</strong>`;
    if(btn) btn.style.display = '';
  }
  // Also update the score card label
  const bigLbl = document.getElementById('stats-score-lbl');
  if(bigLbl) bigLbl.textContent = statsViewDate===TODAY_KEY ? "Today's Islamic Score" : "Islamic Score";
}

function switchStatsDate(key) {
  statsViewDate = key;
  viewingDate   = key;  // keep home page in sync with Progress tab date selection
  renderStatsDateStrip();
  updateStatsDateBar();
  // Animate content out then back in
  const wrap = document.getElementById('stats-content-wrap');
  if(wrap) {
    wrap.style.opacity = '0';
    wrap.style.transform = 'translateY(4px)';
    wrap.style.transition = 'opacity .15s, transform .15s';
    setTimeout(()=>{
      renderStatsContent();
      wrap.style.opacity = '1';
      wrap.style.transform = 'translateY(0)';
    }, 150);
  } else {
    renderStatsContent();
  }
}

function statsJumpToToday() {
  switchStatsDate(TODAY_KEY);
}

function renderStats(){
  renderStatsDateStrip();
  updateStatsDateBar();
  renderStatsContent();
}

function renderStatsContent(){
  renderNotePreview();
  const KEY = statsViewDate;

  // ── Score ring & bar ──────────────────────────
  const score  = calcDayScore(KEY);
  const bigNum = document.getElementById('big-num');
  const pbarEl = document.getElementById('sp-pbar-fill') || document.getElementById('pbar');
  const arc    = document.getElementById('score-arc');

  if(bigNum) bigNum.innerHTML = `${score}<span style="font-size:.5em">%</span>`;
  if(pbarEl) pbarEl.style.width = score + '%';
  if(arc) {
    const circ  = 226.2;
    arc.style.strokeDashoffset = circ - (circ * score / 100);
    arc.style.stroke = score >= 80 ? 'var(--teal)' : score >= 50 ? 'var(--gold)' : 'var(--rose)';
  }
  // Also update the sp-pbar-fill id
  const spBar = document.getElementById('pbar');
  if(spBar) spBar.style.width = score + '%';

  // ── Category mini-bars inside score card ──────
  const cats = document.getElementById('score-cats');
  if(cats) {
    const bd = calcDayBreakdown(KEY);
    const catDefs = [
      {l:t('Activities'),    v:bd.actPct,       col:'var(--accent-main)', val:null},
      {l:t('Prayers'),       v:bd.prayerPct,    col:'var(--accent-2)', val:null},
      {l:t('Takbir-ul-Ula'), v:bd.takbirPct||0, col:'var(--accent-3)', val:`${bd.takbirCount||0}/5`, sub:true},
      {l:t('Fasting'),       v:bd.fastPct,      col:'var(--accent-6)', val:null},
      {l:t('Dhikr'),         v:bd.dhikrPct,     col:'#ce93d8', val:null},
      {l:t('Quran'),         v:bd.quranPct,     col:'var(--accent-5)', val:null},
      {l:t('Sunnah'),        v:bd.sunnahPct,    col:'var(--accent-4)', val:null},
    ];
    cats.innerHTML = catDefs.map(c=>`
      <div style="display:flex;align-items:center;gap:6px;${c.sub?'padding-left:8px':''}">
        <div style="font-size:8px;color:${c.sub?'var(--accent-3)':'var(--t3)'};width:${c.sub?60:50}px;flex-shrink:0;letter-spacing:.04em">${c.sub?'↳ ':''}${c.l}</div>
        <div style="flex:1;height:${c.sub?2:3}px;border-radius:99px;background:rgba(255,255,255,.07);overflow:hidden">
          <div style="height:100%;border-radius:99px;background:${c.col};width:${Math.round(c.v)}%;transition:width .8s cubic-bezier(.22,1,.36,1)"></div>
        </div>
        <div style="font-size:8px;color:${c.col};width:26px;text-align:right">${c.val!==null?c.val:Math.round(c.v)+'%'}</div>
      </div>`).join('');
  }

  // ── 30-day scrollable bar chart ─────────────
  const BAR_H = 100;
  const days = [];
  // Always build 30 days up to today (oldest → newest, today at far right)
  for(let i=29; i>=0; i--) {
    const d = new Date(now); d.setDate(d.getDate()-i);
    const k = dateKey(d);
    days.push({
      label: d.toLocaleDateString('en-US',{weekday:'short'}).slice(0,2),
      num:   d.getDate(),
      key:k, composite:calcDayScore(k), bd:calcDayBreakdown(k),
      isSelected:k===KEY, isToday:k===TODAY_KEY
    });
  }

  document.getElementById('wk-bars').innerHTML = days.map((d,i)=>`
    <div class="bc ${d.isSelected?'sel':''} ${d.isToday?'today':''}" onclick="switchStatsDate('${d.key}')">
      <div class="bo-wrap"><div class="bo" id="bo-${i}">
        <div id="bar-acts-${i}"   style="position:absolute;bottom:0;left:0;right:0;height:0;background:#5bbfb5;transition:height .5s ${(i*.02).toFixed(2)}s cubic-bezier(.22,1,.36,1)"></div>
        <div id="bar-pray-${i}"   style="position:absolute;bottom:0;left:0;right:0;height:0;background:#c9a96e;transition:height .5s ${(i*.02+.04).toFixed(2)}s cubic-bezier(.22,1,.36,1)"></div>
        <div id="bar-fast-${i}"   style="position:absolute;bottom:0;left:0;right:0;height:0;background:var(--green);transition:height .5s ${(i*.02+.08).toFixed(2)}s cubic-bezier(.22,1,.36,1)"></div>
        <div id="bar-dhikr-${i}"  style="position:absolute;bottom:0;left:0;right:0;height:0;background:#ce93d8;transition:height .5s ${(i*.02+.12).toFixed(2)}s cubic-bezier(.22,1,.36,1)"></div>
        <div id="bar-quran-${i}"  style="position:absolute;bottom:0;left:0;right:0;height:0;background:#e07b8a;transition:height .5s ${(i*.02+.16).toFixed(2)}s cubic-bezier(.22,1,.36,1)"></div>
        <div id="bar-sunnah-${i}" style="position:absolute;bottom:0;left:0;right:0;height:0;background:#ffb74d;transition:height .5s ${(i*.02+.20).toFixed(2)}s cubic-bezier(.22,1,.36,1)"></div>
      </div></div>
      <div class="bd2">${d.label}</div>
      <div class="bd3" style="color:${d.composite>0?(d.isSelected||d.isToday?'var(--gold)':'var(--t2)'):'var(--t3)'}">${d.composite||''}</div>
    </div>`).join('');

  // Animate bar heights
  requestAnimationFrame(()=>requestAnimationFrame(()=>{
    days.forEach((d,i)=>{
      const bo = document.getElementById('bo-'+i);
      const totalH = (bo&&bo.clientHeight>0) ? bo.clientHeight : BAR_H;
      const segs = [
        {id:`bar-acts-${i}`,   c:d.bd.actPct   *20/100},
        {id:`bar-pray-${i}`,   c:d.bd.prayerPct*25/100},
        {id:`bar-fast-${i}`,   c:d.bd.fastPct  *10/100},
        {id:`bar-dhikr-${i}`,  c:d.bd.dhikrPct *15/100},
        {id:`bar-quran-${i}`,  c:d.bd.quranPct *15/100},
        {id:`bar-sunnah-${i}`, c:d.bd.sunnahPct*15/100},
      ];
      let bot = 0;
      segs.forEach(s=>{
        const el = document.getElementById(s.id);
        if(!el) return;
        const h = Math.round(totalH * s.c / 100);
        el.style.bottom = bot+'px';
        el.style.height = h+'px';
        bot += h;
      });
    });
    // Scroll so today (rightmost) is visible
    const scroll = document.querySelector('.sp-chart-scroll');
    if(scroll) scroll.scrollLeft = scroll.scrollWidth;
  }));

  // ── Activity Trends (replaces Category Breakdown) ────
  renderActivityTrends();

  // ── Prayer streak ─────────────────────────────
  const psg = document.getElementById('prayer-stat-grid');
  if(psg){
    psg.innerHTML = PRAYERS.map(p=>{
      let count=0;
      for(let i=0;i<7;i++){
        const d2=new Date(KEY+'T00:00:00'); d2.setDate(d2.getDate()-i);
        const k2=dateKey(d2);
        if(k2===TODAY_KEY){ if(prayerDone[p]) count++; }
        else { if(daily[k2]?.prayers?.[p]) count++; }
      }
      const pct = count/7;
      return `<div class="ps-cell glass" style="border-color:${pct>=1?'rgba(var(--accent-rgb),.3)':pct>=0.5?'rgba(var(--accent-rgb),.2)':'var(--bd)'}">
        <div class="ps-name">${p.slice(0,3)}</div>
        <div class="ps-num" style="color:${pct>=1?'var(--gold)':pct>=0.5?'var(--teal)':'var(--text)'}">${count}</div>
        <div class="ps-lbl">/ 7</div>
      </div>`;
    }).join('');
  }

  // ── Activities summary ────────────────────────
  const snapActs = KEY===TODAY_KEY ? todayActs() : (daily[KEY]?.acts||[]);
  const snapDone = snapActs.filter(a=>a.done).length;
  const detGrid  = document.getElementById('det-grid');
  if(detGrid) detGrid.innerHTML=`
    <div class="det-c glass"><div class="det-n" style="color:var(--teal)">${snapDone}</div><div class="det-l">Completed</div></div>
    <div class="det-c glass"><div class="det-n" style="color:var(--rose)">${snapActs.length-snapDone}</div><div class="det-l">Remaining</div></div>`;

  // ── Quran & Fasting ───────────────────────────
  const qfg = document.getElementById('qf-grid');
  if(qfg){
    const keyMonth   = KEY.slice(0,7);
    const monthFasts = Object.entries(fastingData).filter(([k,v])=>v&&k.startsWith(keyMonth)).length
      + Object.entries(daily).filter(([k,v])=>v?.fasting&&k.startsWith(keyMonth)&&!fastingData[k]).length;
    const snapQ  = KEY===TODAY_KEY ? quranData.pages : (daily[KEY]?.quranPages||0);
    const snapQG = KEY===TODAY_KEY ? quranData.goal  : (daily[KEY]?.quranGoal||604);
    qfg.innerHTML=`
      <div class="det-c glass"><div class="det-n" style="color:var(--gold)">${snapQ}</div><div class="det-l">Pages Read</div></div>
      <div class="det-c glass"><div class="det-n" style="color:var(--green)">${monthFasts}</div><div class="det-l">Days Fasted</div></div>`;
  }
}



// ==============================================
// ACTIVITY TRENDS SYSTEM
// ==============================================
let _trendPeriod = 'alltime';

function setTrendPeriod(period, btn) {
  _trendPeriod = period;
  document.querySelectorAll('.trend-pill').forEach(b => b.classList.remove('active'));
  if(btn) btn.classList.add('active');
  renderActivityTrends();
}

function _getTrendDays(period) {
  const today = new Date(now);
  const days = [];
  let count;
  if(period === 'weekly')  count = 7;
  else if(period === 'monthly') count = 30;
  else if(period === '6months') count = 180;
  else if(period === 'yearly')  count = 365;
  else {
    // All time: use all keys in daily
    const keys = Object.keys(daily).sort();
    if(!keys.length) return [];
    const first = new Date(keys[0]+'T00:00:00');
    const diff  = Math.ceil((today - first) / 86400000) + 1;
    count = Math.max(diff, 7);
  }
  for(let i = count - 1; i >= 0; i--) {
    const d = new Date(today); d.setDate(d.getDate() - i);
    days.push(dateKey(d));
  }
  return days;
}

function _getPrevPeriodDays(period, currentDays) {
  if(!currentDays.length) return [];
  const count = currentDays.length;
  const firstCurrent = new Date(currentDays[0]+'T00:00:00');
  const days = [];
  for(let i = count; i >= 1; i--) {
    const d = new Date(firstCurrent); d.setDate(d.getDate() - i);
    days.push(dateKey(d));
  }
  return days;
}

function _calcPeriodStats(dayKeys) {
  let totalScore = 0, counted = 0;
  let prayers = 0, prayerDays = 0;
  let fastDays = 0;
  let dhikrTotal = 0, dhikrDays = 0;
  let quranPages = 0, quranDays = 0;
  let actsDone = 0, actsTotal = 0, actDays = 0;
  let sunnahDoneCount = 0, sunnahDays = 0;
  let activeDays = 0;

  dayKeys.forEach(k => {
    const snap = k === TODAY_KEY ? null : daily[k];
    const score = calcDayScore(k);
    const pr = k === TODAY_KEY ? prayerDone : (snap?.prayers || {});
    const pd = Object.values(pr).filter(Boolean).length;
    const fa = k === TODAY_KEY ? (fastingData[k]||false) : (snap?.fasting||false);
    const dk = k === TODAY_KEY ? dhikrCounts : (snap?.dhikr || []);
    const dt = dk.reduce((s,c)=>s+c,0);
    const qp = k === TODAY_KEY ? quranData.pages : (snap?.quranPages||0);
    const acts = k === TODAY_KEY ? todayActs() : (snap?.acts||[]);
    const sd = k === TODAY_KEY ? sunnahDone : (snap?.sunnah||[]);

    const hasAnyData = pd > 0 || fa || dt > 0 || qp > 0 || acts.some(a=>a.done) || sd.some(Boolean);
    if(!hasAnyData && !daily[k]) return;

    activeDays++;
    totalScore += score; counted++;
    if(pd > 0) { prayers += pd; prayerDays++; }
    if(fa) fastDays++;
    if(dt > 0) { dhikrTotal += dt; dhikrDays++; }
    if(qp > 0) { quranPages += qp; quranDays++; }
    if(acts.length) { actsDone += acts.filter(a=>a.done).length; actsTotal += acts.length; actDays++; }
    if(sd.length) { sunnahDoneCount += sd.filter(Boolean).length; sunnahDays++; }
  });

  const totalDays = Math.max(dayKeys.length, 1);
  return {
    avgScore:    counted ? Math.round(totalScore / counted) : 0,
    activeDays,
    totalDays,
    consistency: Math.round(activeDays / totalDays * 100),
    prayerAvg:   prayerDays ? (prayers / prayerDays).toFixed(1) : 0,
    prayerPct:   Math.round(prayers / (prayerDays||1) / 5 * 100),
    fastDays,
    dhikrAvg:    dhikrDays ? Math.round(dhikrTotal / dhikrDays) : 0,
    dhikrPct:    Math.min(Math.round(dhikrDays / totalDays * 100), 100),
    quranPages,
    quranPct:    Math.min(Math.round(quranDays / totalDays * 100), 100),
    actPct:      actsTotal ? Math.round(actsDone / actsTotal * 100) : 0,
    sunnahPct:   sunnahDays ? Math.round(sunnahDoneCount / (sunnahDays * getSunnahList().length) * 100) : 0,
  };
}

function _changeClass(delta) {
  if(delta > 5)  return 'trend-up';
  if(delta < -5) return 'trend-down';
  return 'trend-neutral';
}
function _changeLabel(delta) {
  if(delta > 0) return '▲ +' + Math.round(delta) + '%';
  if(delta < 0) return '▼ ' + Math.round(delta) + '%';
  return '— Same';
}

// ==============================================
// ALERT SECTION NAVIGATION
// ==============================================
function navigateToAlertSection(sectionId, todayTarget) {
  if(!sectionId) return;
  const statsView = document.getElementById('view-stats');
  const target = document.getElementById(sectionId);
  if(statsView && target) {
    setTimeout(() => {
      const offset = target.offsetTop - 72;
      statsView.scrollTo({ top: Math.max(0, offset), behavior: 'smooth' });
      // Flash highlight with box-shadow instead of outline for reliability
      const origShadow = target.style.boxShadow;
      target.style.transition = 'box-shadow .2s ease';
      target.style.boxShadow = '0 0 0 2px rgba(255,255,255,.22), 0 0 20px rgba(255,255,255,.07)';
      target.style.borderRadius = '18px';
      setTimeout(() => {
        target.style.transition = 'box-shadow .5s ease';
        target.style.boxShadow = origShadow || '';
        setTimeout(() => { target.style.transition = ''; }, 520);
      }, 700);
    }, 100);
  }
}

function navigateToToday(todayTargetId) {
  if(!todayTargetId) return;
  // Switch to Today tab
  const todayBtn = document.querySelector('.nb[data-view="today"]');
  if(todayBtn) goView(todayBtn);
  // After tab switch animation, scroll to target
  setTimeout(() => {
    const todayView = document.getElementById('view-today');
    const target = document.getElementById(todayTargetId);
    if(!todayView || !target) return;
    const offset = target.offsetTop - 72;
    todayView.scrollTo({ top: Math.max(0, offset), behavior: 'smooth' });
    // Pulse the target
    const origShadow = target.style.boxShadow;
    target.style.transition = 'box-shadow .2s ease';
    target.style.boxShadow = '0 0 0 2px rgba(var(--accent-rgb),.35), 0 0 24px rgba(var(--accent-rgb),.15)';
    setTimeout(() => {
      target.style.transition = 'box-shadow .6s ease';
      target.style.boxShadow = origShadow || '';
      setTimeout(() => { target.style.transition = ''; }, 620);
    }, 800);
  }, 380);
}

// ==============================================
// SMART ALERT ENGINE
// ==============================================
function _buildSmartAlerts(cur, prev, curDays, prevDays) {
  const alerts = [];
  const hasPrev = prevDays.length > 0 && prev.avgScore > 0;
  const totalDays = cur.totalDays || 1;

  // ─── CRITICAL: Prayer alerts (highest priority) ───────────────
  if(cur.prayerPct < 40 && cur.activeDays >= 2) {
    alerts.push({
      sev:1, icon:'🚨', title:'Prayer Consistency Critical',
      msg:`Only ${cur.prayerAvg}/5 prayers on average. Salah is the pillar of the deen — everything else rests on it.`,
      tip:'Set phone alarms for each prayer time to never miss one.',
      color:'#ff6b6b', bg:'rgba(255,107,107,.09)', border:'rgba(255,107,107,.3)', badge:'Needs Attention', target:'section-prayer-streak', todayTarget:'prayer-strip-fixed'
    });
  } else if(hasPrev && (cur.prayerPct - prev.prayerPct) < -20) {
    const drop = Math.abs(Math.round(cur.prayerPct - prev.prayerPct));
    alerts.push({
      sev:1, icon:'⚠️', title:'Prayer Declining',
      msg:`Prayer completion dropped ${drop}% vs previous period. The Prophet ﷺ said: "The first thing a person will be accountable for is his prayer."`,
      tip:'Track each prayer as soon as you perform it to stay consistent.',
      color:'var(--rose)', bg:'rgba(var(--rose-rgb),.08)', border:'rgba(var(--rose-rgb),.28)', badge:`-${drop}%`, target:'section-prayer-streak', todayTarget:'prayer-strip-fixed'
    });
  } else if(cur.prayerPct >= 95 && cur.activeDays >= 5) {
    alerts.push({
      sev:5, icon:'✨', title:'Prayer Excellence',
      msg:`Near-perfect prayer consistency — ${cur.prayerAvg}/5 prayers. MashaAllah! You are guarding the most important pillar.`,
      tip:null, color:'var(--gold)', bg:'rgba(var(--accent-rgb),.08)', border:'rgba(var(--accent-rgb),.28)', badge:'Excellent', target:'section-prayer-streak'
    });
  }

  // ─── Consistency / Active Days ────────────────────────────────
  const consistPct = Math.round(cur.activeDays / totalDays * 100);
  if(cur.activeDays < Math.max(2, Math.floor(totalDays * 0.25)) && totalDays > 6) {
    alerts.push({
      sev:1, icon:'📉', title:'Low Consistency',
      msg:`Only ${cur.activeDays} active days out of ${totalDays} (${consistPct}%). The Prophet ﷺ loved deeds done consistently, even if small.`,
      tip:'Open the app daily — even logging one prayer counts as an active day.',
      color:'var(--rose)', bg:'rgba(var(--rose-rgb),.07)', border:'rgba(var(--rose-rgb),.22)', badge:`${consistPct}% active`, target:'section-activities', todayTarget:'list'
    });
  } else if(consistPct >= 85 && totalDays >= 7) {
    alerts.push({
      sev:5, icon:'🔥', title:'Great Consistency!',
      msg:`${cur.activeDays}/${totalDays} days active (${consistPct}%). Sustained habits are the most beloved deeds to Allah ﷻ.`,
      tip:null, color:'var(--teal)', bg:'rgba(var(--teal-rgb),.07)', border:'rgba(var(--teal-rgb),.25)', badge:`${cur.activeDays}d streak`, target:'section-activities'
    });
  }

  // ─── Overall Score Change ─────────────────────────────────────
  if(hasPrev) {
    const scoreDelta = cur.avgScore - prev.avgScore;
    if(scoreDelta <= -15) {
      alerts.push({
        sev:2, icon:'📊', title:'Overall Decline Detected',
        msg:`Average score dropped ${Math.abs(Math.round(scoreDelta))}% (${prev.avgScore}% → ${cur.avgScore}%). Multiple areas need attention.`,
        tip:'Focus on just 2–3 core habits before expanding — prayer + one activity + dhikr.',
        color:'#ffb74d', bg:'rgba(255,183,77,.08)', border:'rgba(255,183,77,.28)', badge:`-${Math.abs(Math.round(scoreDelta))}pts`, target:'section-activities', todayTarget:'list'
      });
    } else if(scoreDelta >= 15) {
      alerts.push({
        sev:5, icon:'📈', title:'Strong Progress!',
        msg:`Score improved ${Math.round(scoreDelta)}% vs previous period (${prev.avgScore}% → ${cur.avgScore}%). Alhamdulillah — keep going!`,
        tip:null, color:'var(--green)', bg:'rgba(var(--green-rgb),.08)', border:'rgba(var(--green-rgb),.28)', badge:`+${Math.round(scoreDelta)}pts`, target:'section-activities'
      });
    }
  }

  // ─── Dhikr ─────────────────────────────────────────────────────
  if(cur.dhikrPct < 20 && cur.activeDays >= 3) {
    alerts.push({
      sev:3, icon:'📿', title:'Dhikr Needs Attention',
      msg:`Dhikr only active ${cur.dhikrPct}% of the time. The tongue in remembrance of Allah finds peace — even 33 Subhanallahs count.`,
      tip:'Attach dhikr to an existing habit: after Fajr, before sleep, while commuting.',
      color:'#ce93d8', bg:'rgba(var(--accent-rgb),.07)', border:'rgba(var(--accent-rgb),.22)', target:'section-activities', todayTarget:'dhikr-card'
    });
  } else if(hasPrev && cur.dhikrAvg > prev.dhikrAvg * 1.3 && cur.dhikrAvg > 20) {
    alerts.push({
      sev:5, icon:'📿', title:'Dhikr Increasing',
      msg:`Daily dhikr up ${Math.round((cur.dhikrAvg - prev.dhikrAvg))} avg vs before (now ${cur.dhikrAvg}/day). "Verily, in the remembrance of Allah do hearts find rest." — 13:28`,
      tip:null, color:'#ce93d8', bg:'rgba(var(--accent-rgb),.07)', border:'rgba(var(--accent-rgb),.22)', badge:'Improving', target:'section-activities'
    });
  }

  // ─── Quran ────────────────────────────────────────────────────
  if(cur.quranPages === 0 && totalDays >= 7) {
    alerts.push({
      sev:3, icon:'📖', title:'No Quran Logged',
      msg:`No Quran pages logged this period. The best of you are those who learn the Quran and teach it — even one page a day builds the habit.`,
      tip:'Log even 1 page daily. Small consistent reading beats occasional large sessions.',
      color:'#e07b8a', bg:'rgba(var(--rose-rgb),.07)', border:'rgba(var(--rose-rgb),.2)', target:'section-quran-fasting', todayTarget:'quran-card'
    });
  } else if(hasPrev && cur.quranPages > prev.quranPages * 1.25 && cur.quranPages > 5) {
    alerts.push({
      sev:5, icon:'📖', title:'Quran Reading Up',
      msg:`${cur.quranPages} pages this period vs ${prev.quranPages} before — that's a ${Math.round((cur.quranPages/Math.max(prev.quranPages,1)-1)*100)}% increase. MashaAllah!`,
      tip:null, color:'#e07b8a', bg:'rgba(var(--rose-rgb),.06)', border:'rgba(var(--rose-rgb),.2)', badge:'Improving', target:'section-quran-fasting'
    });
  }

  // ─── Activities ───────────────────────────────────────────────
  if(hasPrev && (cur.actPct - prev.actPct) < -20 && prev.actPct > 30) {
    const drop = Math.abs(Math.round(cur.actPct - prev.actPct));
    alerts.push({
      sev:2, icon:'📋', title:'Activity Completion Dropped',
      msg:`Activity completion fell ${drop}% (${prev.actPct}% → ${cur.actPct}%). Consider reducing your daily goal to a more achievable number.`,
      tip:`If goal is too high, reduce it in Settings → Tracker & Habits → Daily Activity Goal.`,
      color:'#5bbfb5', bg:'rgba(var(--teal-rgb),.06)', border:'rgba(var(--teal-rgb),.22)', badge:`-${drop}%`, target:'section-activities', todayTarget:'list'
    });
  }

  // ─── Sunnah ───────────────────────────────────────────────────
  if(cur.sunnahPct < 15 && cur.activeDays >= 3) {
    alerts.push({
      sev:4, icon:'🌙', title:'Sunnah Habits Inactive',
      msg:`Sunnah completion is very low (${cur.sunnahPct}%). Small Sunnahs like morning adhkar, miswak, and eating with the right hand take under a minute.`,
      tip:'Check off 1–2 easy Sunnahs daily to start building the habit.',
      color:'#ffb74d', bg:'rgba(255,183,77,.07)', border:'rgba(255,183,77,.2)', target:'section-activities', todayTarget:'sunnah-card'
    });
  }

  // ─── Fasting opportunity ──────────────────────────────────────
  const todayDow = new Date().getDay();
  if(cur.fastDays === 0 && totalDays >= 7 && (todayDow === 1 || todayDow === 4)) {
    alerts.push({
      sev:4, icon:'🤍', title:'Sunnah Fast Opportunity',
      msg:`Today is ${todayDow===1?'Monday':'Thursday'} — a Sunnah fasting day. No fasts logged this period yet. The Prophet ﷺ fasted most Mondays and Thursdays.`,
      tip:'Mark fasting in the Fasting Tracker on the Today tab.',
      color:'var(--green)', bg:'rgba(var(--accent-rgb),.07)', border:'rgba(var(--accent-rgb),.22)', target:'section-quran-fasting', todayTarget:'fast-card'
    });
  }

  // ─── Perfect performance ──────────────────────────────────────
  if(cur.avgScore >= 80 && cur.activeDays >= 5 && consistPct >= 80) {
    alerts.push({
      sev:5, icon:'🏆', title:'Outstanding Performance',
      msg:`Score ${cur.avgScore}%, consistency ${consistPct}%, active ${cur.activeDays}/${totalDays} days. You are building a life the Prophet ﷺ described as the best.`,
      tip:null, color:'var(--gold)', bg:'rgba(var(--accent-rgb),.09)', border:'rgba(var(--accent-rgb),.3)', badge:'Mashallah!', target:'section-activities'
    });
  }

  // Sort: critical first (sev 1), positive last (sev 5), max 4 alerts
  alerts.sort((a,b) => a.sev - b.sev);
  return alerts.slice(0, 4);
}

function renderActivityTrends() {
  const curDays  = _getTrendDays(_trendPeriod);
  const prevDays = _getPrevPeriodDays(_trendPeriod, curDays);
  const cur  = _calcPeriodStats(curDays);
  const prev = _calcPeriodStats(prevDays);

  // Consistency badge
  const badge = document.getElementById('trend-consist-badge');
  if(badge) {
    if(cur.consistency >= 70) { badge.textContent = '✓ ' + cur.consistency + '% consistent'; badge.style.display = ''; }
    else if(cur.consistency > 0) { badge.textContent = cur.consistency + '% active'; badge.style.display = ''; badge.style.background='rgba(255,183,77,.1)'; badge.style.borderColor='rgba(255,183,77,.3)'; badge.style.color='#ffb74d'; }
    else badge.style.display = 'none';
  }

  // Consistency bar
  const consistBar = document.getElementById('trend-consist-bar');
  if(consistBar && cur.activeDays > 0) {
    const dots = curDays.slice(-14).map(k => {
      const snap = k === TODAY_KEY ? null : daily[k];
      const sc = calcDayScore(k);
      const col = sc >= 70 ? 'var(--teal)' : sc >= 30 ? 'var(--gold)' : sc > 0 ? 'var(--rose)' : 'rgba(255,255,255,.1)';
      return `<div class="trend-dot" style="background:${col}" title="${k}: ${sc}%"></div>`;
    }).join('');
    consistBar.innerHTML = `<div style="display:flex;align-items:center;gap:6px"><span style="font-size:0.5rem;color:var(--t3);letter-spacing:.1em;text-transform:uppercase;white-space:nowrap">Last 14d</span><div style="display:flex;gap:3px;flex-wrap:wrap">${dots}</div><span style="font-size:0.5rem;color:var(--teal);margin-left:2px">${cur.consistency}%</span></div>`;
  } else if(consistBar) { consistBar.innerHTML = ''; }

  // ── Smart Alert Engine ──────────────────────
  const warnEl = document.getElementById('trend-warnings');
  if(warnEl) {
    const alerts = _buildSmartAlerts(cur, prev, curDays, prevDays);
    if(alerts.length) {
      const sevClass = {1:'sev-1',2:'sev-2',3:'sev-3',4:'sev-4',5:'sev-5'};
      warnEl.innerHTML = '<div class="alert-cards-wrap">' + alerts.map(a => {
        const sev = a.sev || 3;
        const isWarning = sev <= 4;
        const hasTarget = !!a.target;
        const hasTodayTarget = !!a.todayTarget;
        const badgeHtml = a.badge
          ? `<span class="alert-card-badge" style="color:${a.color};border-color:${a.border};background:${a.bg}">${a.badge}</span>`
          : '';
        const arrowHtml = hasTarget
          ? `<span class="alert-card-arrow" style="color:${a.color};opacity:.55">›</span>`
          : '';
        const tipHtml = a.tip
          ? `<div class="alert-card-tip"><span class="alert-card-tip-icon">💡</span><span style="color:${a.color};opacity:.7;font-style:italic">${a.tip}</span></div>`
          : '';
        const fixBtnHtml = isWarning && hasTodayTarget
          ? `<div class="alert-card-footer" style="border-top:1px solid ${a.border};padding:7px 12px 7px 18px;display:flex;justify-content:flex-end">
              <button class="alert-fix-btn" onclick="event.stopPropagation();navigateToToday('${a.todayTarget}')" style="background:${a.bg};border:1px solid ${a.border};color:${a.color};border-radius:99px;padding:4px 13px;font-family:'Manrope',sans-serif;font-size:0.5rem;font-weight:700;letter-spacing:.09em;text-transform:uppercase;cursor:pointer;display:flex;align-items:center;gap:5px;-webkit-tap-highlight-color:transparent;transition:opacity .15s">
                Fix it <span style="font-size:0.75rem;line-height:1">→</span>
              </button>
            </div>`
          : '';
        const glowStyle = sev === 1 ? `--alert-glow:${a.border.replace(/rgba\(([^,]+,[^,]+,[^,]+),[\d.]+\)/, 'rgba($1,.22)')}` : '';
        const clickAttr = hasTarget
          ? `onclick="navigateToAlertSection('${a.target}')" style="background:${a.bg};border-color:${a.border};${glowStyle};cursor:pointer"`
          : `style="background:${a.bg};border-color:${a.border};${glowStyle}"`;
        return `<div class="alert-card ${sevClass[sev]||''}" ${clickAttr}>
          <div class="alert-card-accent" style="background:${a.color}"></div>
          <div class="alert-card-body">
            <div class="alert-card-icon" style="background:${a.bg};border-color:${a.border}">${a.icon}</div>
            <div class="alert-card-content">
              <div class="alert-card-header">
                <div class="alert-card-title" style="color:${a.color}">${a.title}</div>
                ${badgeHtml}${arrowHtml}
              </div>
              <div class="alert-card-msg" style="color:${a.color}">${a.msg}</div>
              ${tipHtml}
            </div>
          </div>
          ${fixBtnHtml}
        </div>`;
      }).join('') + '</div>';
    } else { warnEl.innerHTML = ''; }
  }

  // Category rows
  const hasPrev = prevDays.length > 0 && prev.avgScore > 0;
  const cats = [
    { icon:'🕌', name:'Prayers',    pct:cur.prayerPct,  prevPct: hasPrev ? prev.prayerPct  : null, col:'var(--accent-2)', detail:`${cur.prayerAvg}/5 avg` },
    { icon:'📋', name:'Activities', pct:cur.actPct,     prevPct: hasPrev ? prev.actPct     : null, col:'var(--accent-main)', detail:`${cur.actPct}% completed` },
    { icon:'🌙', name:'Sunnah',     pct:cur.sunnahPct,  prevPct: hasPrev ? prev.sunnahPct  : null, col:'var(--accent-4)', detail:`${cur.sunnahPct}% done` },
    { icon:'📿', name:'Dhikr',      pct:cur.dhikrPct,   prevPct: hasPrev ? prev.dhikrPct   : null, col:'#ce93d8', detail:`${cur.dhikrAvg} avg/day` },
    { icon:'📖', name:'Quran',      pct:cur.quranPct,   prevPct: hasPrev ? prev.quranPct   : null, col:'var(--accent-5)', detail:`${cur.quranPages} pages` },
    { icon:'🤍', name:'Fasting',    pct:Math.min(Math.round(cur.fastDays/(cur.totalDays||1)*100),100), prevPct: hasPrev ? Math.min(Math.round(prev.fastDays/(prevDays.length||1)*100),100) : null, col:'var(--accent-6)', detail:`${cur.fastDays} days` },
  ];

  const bEl = document.getElementById('trend-breakdown');
  if(!bEl) return;
  if(!cur.activeDays) {
    bEl.innerHTML = `<div class="trend-empty">No activity data for this period yet.</div>`;
    return;
  }
  bEl.innerHTML = cats.map((c, i) => {
    const delta = c.prevPct !== null ? (c.pct - c.prevPct) : null;
    const changeHtml = delta !== null
      ? `<span class="trend-change ${_changeClass(delta)}">${_changeLabel(delta)}</span>`
      : '';
    return `<div class="trend-item ${i === cats.length-1 ? 'last':''}">
      <span class="trend-icon">${c.icon}</span>
      <div class="trend-body">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
          <span class="trend-name">${c.name}</span>
          <div style="display:flex;align-items:center;gap:6px">${changeHtml}<span style="font-size:0.5625rem;color:var(--t3)">${c.detail}</span></div>
        </div>
        <div class="trend-bar-row">
          <div class="trend-bar-bg"><div class="trend-bar-fill" style="width:${c.pct}%;background:${c.col}"></div></div>
          <span class="trend-pct" style="color:${c.col}">${c.pct}%</span>
        </div>
      </div>
    </div>`;
  }).join('') + `<div style="padding:10px 16px 12px;border-top:1px solid rgba(255,255,255,.05);display:flex;align-items:center;justify-content:space-between">
    <span style="font-size:0.5625rem;letter-spacing:.1em;text-transform:uppercase;color:var(--t3)">Avg Score · ${cur.activeDays} active days</span>
    <span style="font-family:'Playfair Display',serif;font-size:1.25rem;font-weight:300;color:${cur.avgScore>=70?'var(--teal)':cur.avgScore>=40?'var(--gold)':'var(--rose)'}">${cur.avgScore}%</span>
  </div>`;
}

// ==============================================
// SALAH TYPE TRACKER
// ==============================================
let _salahTypePeriod = 'weekly';
let _salahTypePanelOpen = false;
let _salahCustomFrom = null; // 'YYYY-MM-DD'
let _salahCustomTo   = null; // 'YYYY-MM-DD'

function toggleSalahTypePanel() {
  _salahTypePanelOpen = !_salahTypePanelOpen;
  const panel = document.getElementById('salah-type-panel');
  const arrow = document.getElementById('salah-type-arrow');
  if(!panel) return;
  if(_salahTypePanelOpen) {
    panel.style.maxHeight = '800px';
    panel.style.opacity = '1';
    panel.style.pointerEvents = 'all';
    if(arrow) arrow.style.transform = 'rotate(180deg)';
    renderSalahTypeGrid();
  } else {
    panel.style.maxHeight = '0';
    panel.style.opacity = '0';
    panel.style.pointerEvents = 'none';
    if(arrow) arrow.style.transform = '';
  }
}

function setSalahTypePeriod(period, btn) {
  _salahTypePeriod = period;
  // Update pill styles
  ['weekly','monthly','yearly','custom'].forEach(p => {
    const el = document.getElementById('stp-pill-' + p);
    if(!el) return;
    if(p === period) {
      if(p === 'custom') {
        el.style.background = 'rgba(var(--purple-rgb),.15)';
        el.style.borderColor = 'rgba(var(--purple-rgb),.5)';
        el.style.color = 'var(--purple)';
        el.style.borderStyle = 'solid';
      } else {
        el.style.background = 'rgba(var(--accent-rgb),.13)';
        el.style.borderColor = 'rgba(var(--accent-rgb),.35)';
        el.style.color = 'var(--gold)';
      }
    } else {
      el.style.background = 'transparent';
      el.style.borderColor = p === 'custom' ? 'rgba(var(--purple-rgb),.4)' : 'rgba(255,255,255,.1)';
      el.style.borderStyle = p === 'custom' ? 'dashed' : 'solid';
      el.style.color = 'var(--t3)';
    }
  });

  // Show/hide custom range picker
  const customRange = document.getElementById('stp-custom-range');
  if(customRange) {
    if(period === 'custom') {
      customRange.style.display = 'block';
      // Pre-fill dates if not set
      const fromInp = document.getElementById('stp-custom-from');
      const toInp   = document.getElementById('stp-custom-to');
      if(fromInp && !fromInp.value) {
        // Default: last 14 days
        const d = new Date(now); d.setDate(d.getDate() - 13);
        fromInp.value = dateKey(d);
        fromInp.max = TODAY_KEY;
        fromInp.min = '2020-01-01';
      }
      if(toInp && !toInp.value) {
        toInp.value = TODAY_KEY;
        toInp.max = TODAY_KEY;
        toInp.min = '2020-01-01';
      }
      _salahCustomFrom = document.getElementById('stp-custom-from')?.value || null;
      _salahCustomTo   = document.getElementById('stp-custom-to')?.value   || null;
    } else {
      customRange.style.display = 'none';
    }
  }

  renderSalahTypeGrid();
}

function applySalahCustomRange() {
  const fromInp = document.getElementById('stp-custom-from');
  const toInp   = document.getElementById('stp-custom-to');
  if(!fromInp || !toInp) return;

  // Clamp: from must not be after to
  if(fromInp.value && toInp.value && fromInp.value > toInp.value) {
    // Swap silently
    const tmp = fromInp.value;
    fromInp.value = toInp.value;
    toInp.value = tmp;
  }

  _salahCustomFrom = fromInp.value || null;
  _salahCustomTo   = toInp.value   || null;

  const hint = document.getElementById('stp-custom-hint');
  if(hint && _salahCustomFrom && _salahCustomTo) {
    const days = _getSalahCustomDayCount();
    hint.textContent = `${days} day${days !== 1 ? 's' : ''} selected`;
  }

  if(_salahTypePeriod === 'custom') renderSalahTypeGrid();
}

function _getSalahCustomDayCount() {
  if(!_salahCustomFrom || !_salahCustomTo) return 0;
  const a = new Date(_salahCustomFrom + 'T00:00:00');
  const b = new Date(_salahCustomTo   + 'T00:00:00');
  return Math.max(1, Math.round((b - a) / 86400000) + 1);
}

function _getSalahTypeDays() {
  const days = [];
  if(_salahTypePeriod === 'custom') {
    if(!_salahCustomFrom || !_salahCustomTo) return [TODAY_KEY];
    const a = new Date(_salahCustomFrom + 'T00:00:00');
    const b = new Date(_salahCustomTo   + 'T00:00:00');
    const cap = new Date(TODAY_KEY + 'T00:00:00');
    const end = b > cap ? cap : b;
    for(let d = new Date(a); d <= end; d.setDate(d.getDate() + 1)) {
      days.push(dateKey(new Date(d)));
    }
    return days.length ? days : [TODAY_KEY];
  }
  let count = _salahTypePeriod === 'weekly' ? 7 : _salahTypePeriod === 'monthly' ? 30 : 365;
  for(let i = count - 1; i >= 0; i--) {
    const d = new Date(now); d.setDate(d.getDate() - i);
    days.push(dateKey(d));
  }
  return days;
}

function _getSalahTypeStats(days) {
  // For each prayer and each quality type, count occurrences
  const allTypes = ['jamaat','takbir','alone','foroj','qaza','none'];
  const result = {};
  PRAYERS.forEach(p => {
    result[p] = { jamaat:0, takbir:0, alone:0, foroj:0, qaza:0, none:0, total:0 };
  });
  const totals = { jamaat:0, takbir:0, alone:0, foroj:0, qaza:0, none:0, total:0 };

  days.forEach(k => {
    let prayers, quality;
    if(k === TODAY_KEY) {
      prayers = {...prayerDone};
      quality = {...prayerQuality};
    } else {
      const snap = daily[k] || {};
      prayers = snap.prayers || {};
      quality = snap.prayerQuality || {};
    }
    PRAYERS.forEach(p => {
      if(prayers[p]) {
        // normalise: null/undefined/empty/'none' all count as 'none'
        const raw = quality[p];
        const q = (!raw || raw === 'none') ? 'none' : raw;
        result[p][q] = (result[p][q] || 0) + 1;
        result[p].total++;
        totals[q] = (totals[q] || 0) + 1;
        totals.total++;
      }
    });
  });
  return { byPrayer: result, totals };
}

// Shared type definitions — single source of truth used by grid + drill page
const SQ_TYPE_DEFS = [
  { key:'jamaat', label:'Jamaat',        ar:'جماعت', col:'var(--teal)',  bg:'rgba(var(--teal-rgb),.12)',   icon:'🕌' },
  { key:'takbir', label:'Takbir-ul-Ula', ar:'تكبير', col:'var(--accent-3)',  bg:'rgba(232,196,122,.12)',  icon:'⭐' },
  { key:'alone',  label:'Alone',         ar:'اکیلا', col:'var(--purple)',  bg:'rgba(var(--purple-rgb),.12)',  icon:'🧎' },
  { key:'foroj',  label:'Foroj',         ar:'فرض',   col:'var(--accent-2)',  bg:'rgba(var(--accent-rgb),.12)',  icon:'📿' },
  { key:'qaza',   label:'Qaza',          ar:'قضا',   col:'var(--rose)',  bg:'rgba(var(--rose-rgb),.12)',  icon:'⏰' },
  { key:'none',   label:'None',          ar:'—',     col:'rgba(240,242,248,.2)', bg:'rgba(255,255,255,.05)', icon:'○' },
];

function renderSalahTypeGrid() {
  const grid = document.getElementById('salah-type-grid');
  const totalsEl = document.getElementById('salah-type-totals');
  const summary = document.getElementById('salah-type-summary');
  if(!grid) return;

  const days = _getSalahTypeDays();
  const { byPrayer, totals } = _getSalahTypeStats(days);
  const daysCount = days.length;
  const typeDefs = SQ_TYPE_DEFS;
  const colCount = typeDefs.length;

  // Update summary text
  let periodLabel;
  if(_salahTypePeriod === 'custom' && _salahCustomFrom && _salahCustomTo) {
    const fmtD = k => { const d = new Date(k+'T00:00:00'); return d.toLocaleDateString('en-US',{month:'short',day:'numeric'}); };
    const daysCnt = _getSalahCustomDayCount();
    periodLabel = `${fmtD(_salahCustomFrom)} – ${fmtD(_salahCustomTo)} (${daysCnt}d)`;
  } else {
    periodLabel = _salahTypePeriod === 'weekly' ? 'last 7 days' : _salahTypePeriod === 'monthly' ? 'last 30 days' : 'this year';
  }
  const jPct = totals.total ? Math.round(totals.jamaat / totals.total * 100) : 0;
  const tPct = totals.total ? Math.round(totals.takbir / totals.total * 100) : 0;
  if(summary) summary.textContent = `Jamaat ${jPct}% · Takbir-ul-Ula ${tPct}% · ${periodLabel}`;

  // Header row — scrollable wrapper so 7 cols fit on small screen
  let html = `<div style="overflow-x:auto;scrollbar-width:none;-webkit-overflow-scrolling:touch">
  <div style="min-width:340px">
  <div style="display:grid;grid-template-columns:58px repeat(${colCount},1fr);gap:0;margin-bottom:8px">
    <div style="font-size:0.4375rem;color:var(--t3);letter-spacing:.08em;text-transform:uppercase;padding:0 0 0 2px">Prayer</div>
    ${typeDefs.map(t => `<div style="text-align:center;cursor:pointer;-webkit-tap-highlight-color:transparent" onclick="openSqDrill('${t.key}')">
      <div style="font-size:0.5rem;color:${t.col};font-weight:700">${t.icon}</div>
      <div style="font-size:0.3125rem;color:var(--t3);letter-spacing:.05em;text-transform:uppercase;margin-top:1px;white-space:nowrap">${t.label}</div>
    </div>`).join('')}
  </div>`;

  // Per-prayer rows
  PRAYERS.forEach((p, idx) => {
    const stats = byPrayer[p];
    const total = stats.total || 0;
    const maxPossible = daysCount;
    html += `<div style="margin-bottom:${idx < PRAYERS.length-1 ? '10px' : '0'}">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
        <div style="font-size:0.5625rem;font-weight:600;color:var(--text);width:56px;flex-shrink:0">${p}<span style="font-size:0.375rem;color:var(--t3);margin-left:4px">${total}/${maxPossible}</span></div>
        <div style="flex:1;height:4px;border-radius:99px;background:rgba(255,255,255,.06);overflow:hidden;position:relative">
          ${buildSalahTypeStackedBar(stats, total, typeDefs)}
        </div>
        <div style="font-size:0.5rem;color:${total >= maxPossible*0.8 ? 'var(--teal)' : total > 0 ? 'var(--gold)' : 'var(--t3)'};width:28px;text-align:right;font-weight:600">${total > 0 ? Math.round(total/maxPossible*100)+'%' : '—'}</div>
      </div>
      <div style="display:grid;grid-template-columns:58px repeat(${colCount},1fr);gap:2px">
        <div></div>
        ${typeDefs.map(td => {
          const cnt = stats[td.key] || 0;
          const pct = total ? Math.round(cnt/total*100) : 0;
          return `<div style="text-align:center;padding:3px 1px;border-radius:6px;background:${cnt > 0 ? td.bg : 'transparent'};cursor:${cnt>0?'pointer':'default'};-webkit-tap-highlight-color:transparent"
            ${cnt > 0 ? `onclick="openSqDrill('${td.key}')"` : ''}>
            <div style="font-family:'Playfair Display',serif;font-size:0.875rem;font-weight:300;color:${cnt > 0 ? td.col : 'var(--t4)'};line-height:1">${cnt > 0 ? cnt : '—'}</div>
            ${cnt > 0 ? `<div style="font-size:0.3125rem;color:${td.col};opacity:.7;margin-top:1px">${pct}%</div>` : ''}
          </div>`;
        }).join('')}
      </div>
    </div>`;
  });

  html += `</div></div>`;
  grid.innerHTML = html;

  // Totals row — clickable chips open drill page
  if(totalsEl) {
    const maxTotal = daysCount * 5;
    totalsEl.innerHTML = `
      <div style="font-size:0.5rem;letter-spacing:.12em;text-transform:uppercase;color:var(--t3);margin-bottom:8px">All Prayers · ${totals.total} of ${maxTotal} total</div>
      <div style="display:flex;gap:6px;flex-wrap:wrap">
        ${typeDefs.map(td => {
          const cnt = totals[td.key] || 0;
          const pct = totals.total ? Math.round(cnt/totals.total*100) : 0;
          if(cnt === 0) return '';
          return `<div onclick="openSqDrill('${td.key}')" style="display:flex;align-items:center;gap:5px;padding:6px 10px;border-radius:10px;background:${td.bg};border:1px solid rgba(255,255,255,.12);flex:0 0 auto;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:opacity .15s;active:opacity:.7">
            <span style="font-size:0.875rem">${td.icon}</span>
            <div>
              <div style="font-size:0.6875rem;font-weight:700;color:${td.col};line-height:1">${cnt}</div>
              <div style="font-size:0.4375rem;color:${td.col};opacity:.7;letter-spacing:.06em;text-transform:uppercase">${td.label} · ${pct}%</div>
            </div>
            <span style="font-size:0.5rem;color:${td.col};opacity:.5;margin-left:2px">›</span>
          </div>`;
        }).filter(Boolean).join('')}
        ${totals.total === 0 ? `<div style="font-size:0.625rem;color:var(--t3);font-style:italic;padding:6px 2px">No prayer data for this period yet</div>` : ''}
      </div>
      <!-- Type quality progress bars — clickable -->
      <div style="margin-top:12px;display:flex;flex-direction:column;gap:6px">
        ${typeDefs.map(td => {
          const cnt = totals[td.key] || 0;
          const pct = totals.total ? Math.round(cnt/totals.total*100) : 0;
          if(cnt === 0) return '';
          return `<div style="display:flex;align-items:center;gap:8px;cursor:pointer;-webkit-tap-highlight-color:transparent" onclick="openSqDrill('${td.key}')">
            <div style="font-size:0.5rem;color:var(--t3);width:76px;flex-shrink:0;letter-spacing:.04em">${td.icon} ${td.label}</div>
            <div style="flex:1;height:5px;border-radius:99px;background:rgba(255,255,255,.07);overflow:hidden">
              <div style="height:100%;border-radius:99px;background:${td.col};width:${pct}%;transition:width .9s cubic-bezier(.22,1,.36,1)"></div>
            </div>
            <div style="font-size:0.5rem;color:${td.col};width:30px;text-align:right;font-weight:600">${pct}%</div>
            <div style="font-size:0.5625rem;color:${td.col};opacity:.4">›</div>
          </div>`;
        }).filter(Boolean).join('')}
      </div>`;
  }
}

function buildSalahTypeStackedBar(stats, total, typeDefs) {
  if(!total) return '';
  let leftPct = 0;
  // Exclude 'none' from stacked bar so bar only shows quality types
  return typeDefs.filter(td => td.key !== 'none').map(td => {
    const cnt = stats[td.key] || 0;
    if(!cnt) return '';
    const w = cnt / total * 100;
    const seg = `<div style="position:absolute;top:0;left:${leftPct}%;width:${w}%;height:100%;background:${td.col}"></div>`;
    leftPct += w;
    return seg;
  }).join('');
}

// ==============================================
// SALAH QUALITY DRILL PAGE
// ==============================================
function openSqDrill(typeKey) {
  const nav = document.getElementById('main-nav');
  if(nav) nav.style.display = 'none';
  const td = SQ_TYPE_DEFS.find(t => t.key === typeKey);
  if(!td) return;

  const page   = document.getElementById('sq-drill-page');
  const title  = document.getElementById('sqd-title');
  const sub    = document.getElementById('sqd-sub');
  const badge  = document.getElementById('sqd-badge');
  const body   = document.getElementById('sqd-body');
  if(!page || !body) return;

  // Header
  if(title) title.textContent = td.label + ' Salah';
  if(badge) { badge.textContent = td.icon; badge.style.background = td.bg; }

  // Scan ALL stored days (+ today) for this type
  const allKeys = Object.keys(daily).concat([TODAY_KEY]);
  const seen = new Set();
  const entries = []; // { dateKey, date, prayers[] }

  allKeys.forEach(k => {
    if(seen.has(k)) return;
    seen.add(k);
    let prayers, quality;
    if(k === TODAY_KEY) {
      prayers = {...prayerDone};
      quality = {...prayerQuality};
    } else {
      const snap = daily[k] || {};
      prayers = snap.prayers || {};
      quality = snap.prayerQuality || {};
    }
    const matchedPrayers = [];
    PRAYERS.forEach(p => {
      if(!prayers[p]) return;
      const raw = quality[p];
      const q = (!raw || raw === 'none') ? 'none' : raw;
      if(q === typeKey) matchedPrayers.push(p);
    });
    if(matchedPrayers.length > 0) {
      entries.push({ k, matchedPrayers });
    }
  });

  // Sort chronologically newest → oldest
  entries.sort((a, b) => b.k.localeCompare(a.k));

  if(sub) sub.textContent = entries.length + ' day' + (entries.length !== 1 ? 's' : '') + ' recorded';

  if(entries.length === 0) {
    body.innerHTML = `<div class="sqd-empty">
      <div class="sqd-empty-icon">${td.icon}</div>
      <div class="sqd-empty-text">No <strong>${td.label}</strong> prayers recorded yet.</div>
    </div>`;
  } else {
    // Group by month
    let lastMonth = '';
    let html = '';
    entries.forEach(({ k, matchedPrayers }) => {
      // Parse date from key (format: YYYY-MM-DD)
      const [yr, mo, dy] = k.split('-').map(Number);
      const d = new Date(yr, mo - 1, dy);
      const monthLabel = d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      const dayLabel   = d.toLocaleDateString('en-US', { weekday: 'long' });
      const dateNum    = d.toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' });
      const isToday    = k === TODAY_KEY;

      if(monthLabel !== lastMonth) {
        lastMonth = monthLabel;
        html += `<div class="sqd-month-label">${monthLabel}</div>`;
      }

      const prayerChips = matchedPrayers.map(p =>
        `<span class="sqd-prayer-chip" style="color:${td.col};border-color:${td.col};background:${td.bg}">${p}</span>`
      ).join('');

      html += `<div class="sqd-entry sqd-entry-tappable" onclick="drillGoToDate('${k}')" style="cursor:pointer">
        <div class="sqd-entry-dot" style="background:${td.col}"></div>
        <div class="sqd-entry-date">
          <div class="sqd-entry-dow">${isToday ? 'Today · ' : ''}${dayLabel}</div>
          <div class="sqd-entry-d">${dateNum}</div>
        </div>
        <div class="sqd-entry-prayers">${prayerChips}</div>
        <div class="sqd-entry-nav-hint">→</div>
      </div>`;
    });
    body.innerHTML = html;
  }

  page.classList.add('open');
}

function closeSqDrill() {
  const page = document.getElementById('sq-drill-page');
  if(page) page.classList.remove('open');
  const nav = document.getElementById('main-nav');
  if(nav) nav.style.display = '';
}

function drillGoToDate(key) {
  // 1. Close drill page + restore nav
  closeSqDrill();

  // 2. Switch to Today tab if not already there
  const todayBtn = document.querySelector('.nb[data-view="today"]');
  const todayView = document.getElementById('view-today');
  if (todayBtn && todayView && !todayView.classList.contains('active')) {
    goView(todayBtn);
  }

  // 3. Switch to the selected date
  switchDate(key);

  // 4. Scroll to prayer strip after a short delay (allow render)
  setTimeout(() => {
    const strip = document.getElementById('prayer-strip-fixed');
    const view  = document.getElementById('view-today');
    if (strip && view) {
      view.scrollTo({ top: strip.offsetTop - 60, behavior: 'smooth' });
    }
  }, 120);
}

function countPrayerWeek(prayer){
  let count = 0;
  for(let i=0;i<7;i++){
    const d = new Date(now); d.setDate(d.getDate()-i);
    const k = dateKey(d);
    const snap = daily[k];
    if(k===TODAY_KEY){ if(prayerDone[prayer]) count++; }
    else if(snap?.prayers?.[prayer]) count++;
  }
  return count;
}

// ==============================================
// ADD ACTIVITY MODAL
// ==============================================
function buildModal(){
  const addedNames = new Set(getActs(viewingDate).map(a => a.name));
  const available  = DEFAULT_ACTIVITIES.filter(a => !addedNames.has(a.name));

  // Group by category
  const groups = [
    { label:'🕌 Islamic', items: available.filter(a => ['Read Quran','Morning Adhkar','Evening Adhkar','Tahajjud','Extra Dhikr','Islamic Study','Attend Masjid','Memorise Quran','Help Someone','Give Sadaqah','Call Family','Suhoor/Iftar','Duha Prayer','Read Islamic Book','Avoid Haram','Make Istighfar'].includes(a.name)) },
    { label:'💪 Health',  items: available.filter(a => ['Morning Walk','Drink Water','Exercise','Healthy Eating','Good Sleep','Cycling','Stretching','Eat Fruit','Power Nap','No Junk Food'].includes(a.name)) },
    { label:'📚 Growth',  items: available.filter(a => ['Study / Learn','Journaling','Deep Work','Read a Book','Review Goals','Plan Tomorrow','Screen-Free Hour','Learn a New Skill'].includes(a.name)) },
    { label:'🏠 Daily',   items: available.filter(a => ['Clean Home','Groceries / Errands','Clear Inbox','Work Task','Cook a Meal','Track Finances'].includes(a.name)) },
  ].filter(g => g.items.length > 0);

  // Build Top 5 most important suggestions (Islamic first, then Health, then Growth/Daily)
  const ESSENTIAL_ORDER = [
    'Morning Adhkar','Evening Adhkar','Read Quran','Memorise Quran','Make Istighfar',
    'Extra Dhikr','Islamic Study','Attend Masjid','Tahajjud','Duha Prayer',
    'Read Islamic Book','Give Sadaqah','Help Someone','Call Family','Avoid Haram','Suhoor/Iftar'
  ];
  const HEALTH_ORDER = [
    'Morning Walk','Drink Water','Exercise','Healthy Eating','Good Sleep',
    'Cycling','Stretching','Eat Fruit','Power Nap','No Junk Food'
  ];
  function suggestionPriority(a) {
    const ei = ESSENTIAL_ORDER.indexOf(a.name);
    if (ei !== -1) return ei;
    const hi = HEALTH_ORDER.indexOf(a.name);
    if (hi !== -1) return 100 + hi;
    return 200;
  }
  const top5 = [...available].sort((a,b) => suggestionPriority(a) - suggestionPriority(b)).slice(0, 5);

  const top5Html = top5.length ? `
    <div style="margin-bottom:14px">
      <div style="font-size:0.5rem;letter-spacing:.18em;text-transform:uppercase;color:var(--gold);margin-bottom:8px;display:flex;align-items:center;gap:8px;opacity:.85">
        ⭐ Top 5 for Today <span style="flex:1;height:1px;background:rgba(var(--accent-rgb),.25);display:block"></span>
      </div>
      <div style="display:flex;flex-wrap:wrap;gap:6px">
        ${top5.map(a => `
          <button onclick="quickPickActivity(${JSON.stringify(a).replace(/"/g,'&quot;')})"
            style="display:flex;align-items:center;gap:6px;padding:8px 14px;border-radius:99px;border:1px solid rgba(var(--accent-rgb),.35);background:rgba(var(--accent-rgb),.09);color:var(--gold);font-family:'Manrope',sans-serif;font-size:0.6875rem;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:all .18s;touch-action:manipulation;font-weight:500">
            <span>${a.icon}</span><span>${a.name}</span>
          </button>`).join('')}
      </div>
    </div>
    <div style="height:1px;background:var(--bd);margin:0 0 14px"></div>` : '';

  const suggestHtml = groups.length ? `
    <div style="margin-bottom:14px">
      ${top5Html}
      <div style="font-size:0.5rem;letter-spacing:.18em;text-transform:uppercase;color:var(--t3);margin-bottom:8px;display:flex;align-items:center;gap:8px">
        All Activities <span style="flex:1;height:1px;background:var(--bd);display:block"></span>
      </div>
      ${groups.map(g => `
        <div style="margin-bottom:10px">
          <div style="font-size:0.5rem;color:var(--t3);letter-spacing:.1em;margin-bottom:5px">${g.label}</div>
          <div style="display:flex;flex-wrap:wrap;gap:5px">
            ${g.items.map(a => `
              <button onclick="quickPickActivity(${JSON.stringify(a).replace(/"/g,'&quot;')})"
                style="display:flex;align-items:center;gap:5px;padding:6px 11px;border-radius:99px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);color:var(--t2);font-family:'Manrope',sans-serif;font-size:0.625rem;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:all .15s;touch-action:manipulation">
                <span>${a.icon}</span><span>${a.name}</span>
              </button>`).join('')}
          </div>
        </div>`).join('')}
      <div style="height:1px;background:var(--bd);margin:10px 0 14px"></div>
      <div style="font-size:0.5rem;letter-spacing:.18em;text-transform:uppercase;color:var(--t3);margin-bottom:10px">Or create custom</div>
    </div>` : top5Html ? `
    <div style="margin-bottom:14px">
      ${top5Html}
      <div style="font-size:0.5rem;letter-spacing:.18em;text-transform:uppercase;color:var(--t3);margin-bottom:10px">Or create custom</div>
    </div>` : '';

  const suggestEl = document.getElementById('act-suggest-area');
  if(suggestEl) suggestEl.innerHTML = suggestHtml;

  document.getElementById('ipkr').innerHTML=ICONS.map(ic=>`
    <div class="io ${ic===pIcon?'sel':''}" onclick="pickI('${ic}',this)">${ic}</div>`).join('');
  document.getElementById('cpkr').innerHTML=COLORS.map(c=>`
    <div class="cd ${c===pColor?'sel':''}" style="background:${c}" onclick="pickC('${c}',this)"></div>`).join('');
}

function quickPickActivity(a) {
  // Directly add it without filling the form
  const targetKey = viewingDate;
  const list = getActs(targetKey);
  list.push({id:Date.now(), name:a.name, meta:a.meta, icon:a.icon, color:a.color, done:false});
  setActs(targetKey, list);
  persistDay(targetKey);
  document.getElementById('ovl').classList.remove('open');
  renderDateStrip(); renderViewingBanner(); renderList(); renderKPI(); renderStats();
}
document.getElementById('opn-btn').addEventListener('click',()=>{
  const actPage = document.getElementById('page-activities');
  const openModal = () => {
    document.getElementById('i-name').value='';
    document.getElementById('i-meta').value='';
    buildModal();
    document.getElementById('ovl').classList.add('open');
    setTimeout(()=>document.getElementById('i-name').focus(),120);
  };
  if(actPage && !actPage.classList.contains('open')) {
    openFeatPage('page-activities');
    setTimeout(openModal, 120);
    return;
  }
  openModal();
});
function closeOvl(e){ if(e.target===document.getElementById('ovl')||e.target.classList.contains('ovl-bg')) document.getElementById('ovl').classList.remove('open'); }
function pickI(ic,el){ pIcon=ic; document.querySelectorAll('.io').forEach(x=>x.classList.remove('sel')); el.classList.add('sel'); }
function pickC(c,el) { pColor=c; document.querySelectorAll('.cd').forEach(x=>x.classList.remove('sel')); el.classList.add('sel'); }
function saveAct(){
  const name=document.getElementById('i-name').value.trim(), meta=document.getElementById('i-meta').value.trim();
  if(!name){
    const inp=document.getElementById('i-name');
    inp.style.borderColor='var(--rose)'; inp.style.boxShadow='0 0 0 3px rgba(var(--accent-rgb),.12)'; inp.focus();
    setTimeout(()=>{inp.style.borderColor='';inp.style.boxShadow='';},1200); return;
  }
  // Save to whatever date is currently being viewed (today OR past)
  const targetKey = viewingDate;
  const list = getActs(targetKey);
  list.push({id:Date.now(),name,meta:meta||'·',icon:pIcon,color:pColor,done:false});
  setActs(targetKey, list);
  persistDay(targetKey);
  document.getElementById('ovl').classList.remove('open');
  renderDateStrip(); renderViewingBanner(); renderList(); renderKPI(); renderStats();
}

// ==============================================
// NAV
// ==============================================
function navTapFeedback(btn){
  if(!btn) return;
  btn.classList.remove('tap-feedback');
  void btn.offsetWidth;
  btn.classList.add('tap-feedback');
  clearTimeout(btn._tapFeedbackTimer);
  btn._tapFeedbackTimer = setTimeout(()=>btn.classList.remove('tap-feedback'), 520);
}

function goView(btn){
  navTapFeedback(btn);
  const views = document.querySelectorAll('.view');
  const btns  = document.querySelectorAll('.nb');
  const toId  = btn.dataset.view;
  const fromEl = document.querySelector('.view.active');
  const fromId = fromEl ? fromEl.id.replace('view-','') : null;
  const prevBtn = document.querySelector('.nb.active');
  if(fromId === toId) return;

  if(prevBtn && prevBtn !== btn){
    prevBtn.classList.add('nav-leaving');
    setTimeout(() => prevBtn.classList.remove('nav-leaving'), 360);
  }

  if(fromEl) fromEl.classList.remove('active');
  views.forEach(v => v.classList.remove('active','slide-left','slide-right','exiting-left','exiting-right'));
  btns.forEach(b => {
    if(b !== btn) b.classList.remove('active');
    b.classList.remove('nb-near','nav-entering');
  });

  const toEl = document.getElementById('view-'+toId);
  if(!toEl) return;
  toEl.scrollTop = 0;
  toEl.classList.add('active');

  requestAnimationFrame(() => {
    btn.classList.add('active','nav-entering');
    setTimeout(() => btn.classList.remove('nav-entering'), 560);
  });

  const btnArr = Array.from(btns);
  const idx = btnArr.indexOf(btn);
  if(idx > 0) btnArr[idx-1].classList.add('nb-near');
  if(idx < btnArr.length-1) btnArr[idx+1].classList.add('nb-near');

  if(toId === 'stats')    { setTimeout(renderStats, 50); }
  if(toId === 'settings') { setTimeout(() => { renderSettingsView(); try{ window.applySvgEmojiReplacement?.(document.getElementById('view-settings')); }catch(e){} }, 50); }
  if(toId === 'explore')  { setTimeout(() => { _syncExploreBadges(); try{ window.applySvgEmojiReplacement?.(document.getElementById('view-explore')); }catch(e){} }, 50); }

  try{ window.applySvgEmojiReplacement?.(toEl); }catch(e){}
  _clearDomCache();

  const qnav = document.getElementById('quick-nav');
  if(qnav) {
    qnav.style.display  = toId === 'today' ? '' : 'none';
    qnav.style.opacity  = toId === 'today' ? '' : '0';
  }
}


// Extra tactile feedback for bottom nav press states
(function initNavPressFX(){
  const bind = () => {
    document.querySelectorAll('.nb').forEach(btn => {
      if(btn.dataset.pressFxBound === '1') return;
      btn.dataset.pressFxBound = '1';
      const setDown = () => btn.style.setProperty('--nb-shift', btn.classList.contains('active') ? '-22px' : '0px');
      const clearDown = () => btn.style.removeProperty('--nb-shift');
      btn.addEventListener('pointerdown', setDown, {passive:true});
      btn.addEventListener('pointerup', clearDown, {passive:true});
      btn.addEventListener('pointercancel', clearDown, {passive:true});
      btn.addEventListener('pointerleave', clearDown, {passive:true});
    });
  };
  if(document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bind, {once:true});
  } else {
    bind();
  }
})();

// ==============================================
// CALENDAR
// ==============================================
let calDate=new Date(now.getFullYear(),now.getMonth(),1);
let calSel=new Date(now.getFullYear(),now.getMonth(),now.getDate());

function openCal(){
  calDate=new Date(now.getFullYear(),now.getMonth(),1);
  calSel=new Date(now.getFullYear(),now.getMonth(),now.getDate());
  renderCal();
  document.getElementById('cal-ovl').classList.add('open');
}
function closeCalOvl(e){
  if(e.target===document.getElementById('cal-ovl')||e.target.classList.contains('ovl-bg'))
    document.getElementById('cal-ovl').classList.remove('open');
}
function calNav(dir){ calDate.setMonth(calDate.getMonth()+dir); renderCal(); }

function toggleCalYearJump() {
  const wrap = document.getElementById('cal-year-jump');
  const inp  = document.getElementById('cal-year-inp');
  if(!wrap) return;
  const open = wrap.style.display === 'none';
  wrap.style.display = open ? 'flex' : 'none';
  if(open && inp) {
    inp.value = calDate.getFullYear();
    inp.focus();
    inp.select();
  }
}

function calGoYear() {
  const inp = document.getElementById('cal-year-inp');
  const wrap = document.getElementById('cal-year-jump');
  if(!inp) return;
  const y = parseInt(inp.value, 10);
  if(isNaN(y) || y < 1900 || y > 2200) return;
  calDate.setFullYear(y);
  if(wrap) wrap.style.display = 'none';
  renderCal();
}


function calSelect(y,m,d){ calSel=new Date(y,m,d); renderCal(); }

function renderCal(){
  const MN=['January','February','March','April','May','June','July','August','September','October','November','December'];
  document.getElementById('cal-month-label').textContent=`${MN[calDate.getMonth()]} ${calDate.getFullYear()}`;

  // Hijri month label for the 1st of displayed month
  const firstOfMonth = new Date(calDate.getFullYear(), calDate.getMonth(), 1);
  const hFirst = toHijriObj(firstOfMonth);
  const lastOfMonth = new Date(calDate.getFullYear(), calDate.getMonth()+1, 0);
  const hLast = toHijriObj(lastOfMonth);
  const hijriRange = hFirst.month===hLast.month
    ? `${HIJRI_MONTHS_EN[hFirst.month-1]} ${hFirst.year} AH`
    : `${HIJRI_MONTHS_EN[hFirst.month-1]} – ${HIJRI_MONTHS_EN[hLast.month-1]} ${hLast.year} AH`;
  const hijriLabel = document.getElementById('cal-hijri-label');
  if(hijriLabel) hijriLabel.textContent = hijriRange;

  document.getElementById('cal-dow').innerHTML=['Su','Mo','Tu','We','Th','Fr','Sa'].map(d=>`<div class="cal-dow-lbl">${d}</div>`).join('');
  const year=calDate.getFullYear(),month=calDate.getMonth();
  const firstDay=new Date(year,month,1).getDay();
  const dim=new Date(year,month+1,0).getDate();
  const dip=new Date(year,month,0).getDate();
  const todayK=dateKey(now), selK=dateKey(calSel);
  let dayData={};
  try{dayData=dayActs;}catch{}  // use global dayActs object
  let cells='';
  for(let i=firstDay-1;i>=0;i--) {
    const prevD = new Date(year,month-1,dip-i);
    const hd = toHijriObj(prevD).day;
    cells+=`<div class="cal-day other-month"><span class="cal-day-greg">${dip-i}</span><span class="cal-day-hijri">${hd}</span></div>`;
  }
  for(let d=1;d<=dim;d++){
    const dd=new Date(year,month,d);
    const key=dateKey(dd);
    const isFasted=fastingData[key];
    const hd = toHijriObj(dd).day;
    // Highlight Ayyam al-Bid (13, 14, 15 Hijri) with subtle gold ring
    const hObj = toHijriObj(dd);
    const isAyyamBid = hObj.day>=13 && hObj.day<=15;
    const hasData = (dayActs[key]||[]).length > 0;
    cells+=`<div class="cal-day ${key===todayK?'today':''} ${key===selK?'selected':''} ${hasData?'has-data':''}"
      onclick="calSelect(${year},${month},${d})"
      style="${isFasted?'box-shadow:inset 0 0 0 1.5px var(--green);':''}${isAyyamBid&&key!==selK?'border-color:rgba(var(--accent-rgb),.2);':''}"
      title="${key}${isAyyamBid?' · Ayyam al-Bid':''}"
    >
      <span class="cal-day-greg">${d}${isFasted?'<sup style="font-size:6px;position:relative;top:-2px">🤍</sup>':''}</span>
      <span class="cal-day-hijri" style="${hObj.day===1?'color:var(--gold);font-weight:600':''}">${hd}</span>
    </div>`;
  }
  const tc=Math.ceil((firstDay+dim)/7)*7;
  for(let d=1;d<=tc-(firstDay+dim);d++) {
    const nextD = new Date(year,month+1,d);
    const hd = toHijriObj(nextD).day;
    cells+=`<div class="cal-day other-month"><span class="cal-day-greg">${d}</span><span class="cal-day-hijri">${hd}</span></div>`;
  }
  document.getElementById('cal-grid').innerHTML=cells;
  renderCalSelected();
}
function renderCalSelected(){
  const key=dateKey(calSel);
  const MN=['January','February','March','April','May','June','July','August','September','October','November','December'];
  const label=`${MN[calSel.getMonth()]} ${calSel.getDate()}, ${calSel.getFullYear()}`;
  const hijriDay = toHijri(calSel);
  const calActs = getActs(key);
  const snap = daily[key];
  const isFasted = snap?.fasting || fastingData[key] || false;
  const pDone = key===TODAY_KEY ? Object.values(prayerDone).filter(Boolean).length
    : Object.values(snap?.prayers||{}).filter(Boolean).length;
  const composite = calcDayScore(key);
  const info=document.getElementById('cal-selected-info');
  const fastBadge=isFasted?`<span style="font-size:11px;background:rgba(var(--accent-rgb),.15);border:1px solid var(--green);padding:2px 9px;border-radius:99px;color:var(--green)">🤍 Fasted</span>`:'';

  const islamicSummary = `
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 12px">
      <span style="font-size:10px;padding:3px 9px;border-radius:99px;border:1px solid rgba(var(--accent-rgb),.25);color:var(--gold)">🕌 ${pDone}/5 prayers</span>
      ${isFasted?`<span style="font-size:10px;padding:3px 9px;border-radius:99px;border:1px solid rgba(var(--accent-rgb),.25);color:var(--green)">🤍 Fasting</span>`:''}
      <span style="font-size:10px;padding:3px 9px;border-radius:99px;border:1px solid rgba(var(--accent-rgb),.25);color:var(--teal)">Score: ${composite}%</span>
    </div>`;

  const noteSnap = daily[key];
  const noteText = noteSnap?.noteText || '';
  const noteMoods = noteSnap?.noteMoods || [];
  const noteSection = (noteText.trim() || noteMoods.length) ? `
    <div style="margin-top:10px;padding:10px 13px;border-radius:12px;background:rgba(var(--accent-rgb),.06);border:1px solid rgba(var(--accent-rgb),.15)">
      ${noteMoods.length ? `<div style="display:flex;gap:5px;flex-wrap:wrap;margin-bottom:6px">${noteMoods.map(m=>`<span style="font-size:12px">${m.e}</span>`).join('')}</div>` : ''}
      ${noteText.trim() ? `<div style="font-size:12px;color:var(--t2);font-style:italic;line-height:1.6">${noteText.trim().slice(0,120)}${noteText.trim().length>120?'…':''}</div>` : ''}
    </div>` : '';

  if(!calActs.length){
    info.innerHTML=`
      <div class="cal-sel-date" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">${label}
        <div style="font-size:10px;color:var(--gold);opacity:.7">${hijriDay}</div>
      </div>
      ${islamicSummary}
      ${noteSection}
      <div class="cal-no-acts">No activities recorded</div>`;
    return;
  }
  const done=calActs.filter(a=>a.done).length;
  const pct=Math.round(done/calActs.length*100);
  info.innerHTML=`
    <div class="cal-sel-date" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
      ${label} — <span style="color:var(--teal)">${pct}% activities</span> ${fastBadge}
    </div>
    <div style="font-size:10px;color:var(--gold);opacity:.7;margin-bottom:6px">${hijriDay}</div>
    ${islamicSummary}
    ${noteSection}
    ${calActs.map(a=>`
      <div class="cal-act-row">
        <div class="cal-act-icon" style="background:${ha(a.color,.15)};border:1px solid ${ha(a.color,.25)}">${a.icon}</div>
        <div style="flex:1">
          <div class="cal-act-name" style="${a.done?'opacity:.4;text-decoration:line-through':''}">${a.name}</div>
          <div class="cal-act-meta">${a.meta}</div>
        </div>
        <div style="font-size:15px;${a.done?`color:${a.color}`:'color:var(--t3)'}">${a.done?'✓':'○'}</div>
      </div>`).join('')}`;
}

// ==============================================
// AYAH OF THE DAY
// ==============================================
const AYAHS = [
  {ar:'وَبَشِّرِ الصَّابِرِينَ', trans:'And give good tidings to the patient.', ref:'Al-Baqarah 2:155'},
  {ar:'إِنَّ مَعَ الْعُسْرِ يُسْرًا', trans:'Indeed, with hardship comes ease.', ref:'Ash-Sharh 94:6'},
  {ar:'وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ', trans:'And whoever relies upon Allah — then He is sufficient for him.', ref:'At-Talaq 65:3'},
  {ar:'فَاذْكُرُونِي أَذْكُرْكُمْ', trans:'So remember Me; I will remember you.', ref:'Al-Baqarah 2:152'},
  {ar:'وَاللَّهُ يُحِبُّ الْمُحْسِنِينَ', trans:'And Allah loves the doers of good.', ref:"Al-Imran 3:134"},
  {ar:'إِنَّ اللَّهَ مَعَ الصَّابِرِينَ', trans:'Indeed, Allah is with the patient.', ref:'Al-Baqarah 2:153'},
  {ar:'وَهُوَ مَعَكُمْ أَيْنَ مَا كُنتُمْ', trans:'And He is with you wherever you are.', ref:'Al-Hadid 57:4'},
  {ar:'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً', trans:'Our Lord, give us in this world good and in the Hereafter good.', ref:'Al-Baqarah 2:201'},
  {ar:'وَلَا تَيْأَسُوا مِن رَّوْحِ اللَّهِ', trans:'And do not despair of relief from Allah.', ref:'Yusuf 12:87'},
  {ar:'حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ', trans:'Sufficient for us is Allah, and He is the best disposer of affairs.', ref:"Al-Imran 3:173"},
  {ar:'وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ', trans:'My success is not but through Allah.', ref:'Hud 11:88'},
  {ar:'يَا أَيُّهَا الَّذِينَ آمَنُوا اسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ', trans:'O you who believe, seek help through patience and prayer.', ref:'Al-Baqarah 2:153'},
  {ar:'إِنَّ اللَّهَ لَا يُضِيعُ أَجْرَ الْمُحْسِنِينَ', trans:'Indeed, Allah does not allow to be lost the reward of those who do good.', ref:'Hud 11:115'},
  {ar:'وَاللَّهُ غَفُورٌ رَّحِيمٌ', trans:'And Allah is Forgiving and Merciful.', ref:'Al-Baqarah 2:173'},
];

function loadAyahState() {
  try {
    const r = localStorage.getItem('mrd3_ayah');
    if (r) {
      const p = JSON.parse(r);
      if (p.date === dateKey(now)) return p;
    }
  } catch {}
  const idx = now.getDate() % AYAHS.length;
  return { date: dateKey(now), idx, favs: [] };
}
let ayahState = loadAyahState();

function renderAyah() {
  const a = AYAHS[ayahState.idx];
  const isFav = ayahState.favs.includes(ayahState.idx);
  document.getElementById('ayah-card').innerHTML = `
    <div class="ayah-top">
      <div class="ayah-label">Verse of the Day</div>
      <div class="ayah-ref">${a.ref}</div>
    </div>
    <div class="ayah-arabic">${a.ar}</div>
    <div class="ayah-trans">"${a.trans}"</div>
    <div class="ayah-footer">
      <button class="ayah-next" onclick="nextAyah()">↻ Next verse</button>
      <button class="ayah-fav" onclick="favAyah()" title="${isFav?'Unfavourite':'Save'}">${isFav?'⭐':'☆'}</button>
    </div>`;
}
function nextAyah() {
  ayahState.idx = (ayahState.idx + 1) % AYAHS.length;
  persistAyah(); renderAyah();
}
function favAyah() {
  const i = ayahState.idx;
  const fi = ayahState.favs.indexOf(i);
  if (fi === -1) ayahState.favs.push(i); else ayahState.favs.splice(fi, 1);
  persistAyah(); renderAyah();
}
function persistAyah() {
  try { localStorage.setItem('mrd3_ayah', JSON.stringify(ayahState)); } catch {}
}

// ==============================================
// QURAN VERSE SECTION  (home screen inline reader)
// ==============================================
// Extended curated verse collection — categorised by theme
const QVS_VERSES = [
  // Tawakkul (Trust in Allah)
  {ar:'وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ', trans:'And whoever relies upon Allah — then He is sufficient for him.', ref:'At-Talaq 65:3', theme:'Tawakkul', surah:65, ayah:3},
  {ar:'حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ', trans:'Sufficient for us is Allah, and He is the best disposer of affairs.', ref:'Al-Imran 3:173', theme:'Tawakkul', surah:3, ayah:173},
  {ar:'وَعَلَى اللَّهِ فَتَوَكَّلُوا إِن كُنتُم مُّؤْمِنِينَ', trans:'And upon Allah rely, if you should be believers.', ref:'Al-Maidah 5:23', theme:'Tawakkul', surah:5, ayah:23},
  // Sabr (Patience)
  {ar:'وَبَشِّرِ الصَّابِرِينَ', trans:'And give good tidings to the patient.', ref:'Al-Baqarah 2:155', theme:'Sabr', surah:2, ayah:155},
  {ar:'إِنَّ اللَّهَ مَعَ الصَّابِرِينَ', trans:'Indeed, Allah is with the patient.', ref:'Al-Baqarah 2:153', theme:'Sabr', surah:2, ayah:153},
  {ar:'إِنَّ مَعَ الْعُسْرِ يُسْرًا', trans:'Indeed, with hardship comes ease.', ref:'Ash-Sharh 94:6', theme:'Sabr', surah:94, ayah:6},
  {ar:'وَلَنَبْلُوَنَّكُم بِشَيْءٍ مِّنَ الْخَوْفِ وَالْجُوعِ', trans:'And We will surely test you with something of fear and hunger...', ref:'Al-Baqarah 2:155', theme:'Sabr', surah:2, ayah:155},
  // Dhikr (Remembrance)
  {ar:'فَاذْكُرُونِي أَذْكُرْكُمْ', trans:'So remember Me; I will remember you.', ref:'Al-Baqarah 2:152', theme:'Dhikr', surah:2, ayah:152},
  {ar:'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ', trans:'Verily, in the remembrance of Allah do hearts find rest.', ref:'Ar-Ra\'d 13:28', theme:'Dhikr', surah:13, ayah:28},
  {ar:'وَاذْكُر رَّبَّكَ فِي نَفْسِكَ تَضَرُّعًا وَخِيفَةً', trans:'And remember your Lord within yourself in humility and fear.', ref:'Al-A\'raf 7:205', theme:'Dhikr', surah:7, ayah:205},
  // Hope & Mercy
  {ar:'وَلَا تَيْأَسُوا مِن رَّوْحِ اللَّهِ', trans:'And do not despair of relief from Allah.', ref:'Yusuf 12:87', theme:'Hope', surah:12, ayah:87},
  {ar:'وَرَحْمَتِي وَسِعَتْ كُلَّ شَيْءٍ', trans:'And My mercy encompasses all things.', ref:'Al-A\'raf 7:156', theme:'Hope', surah:7, ayah:156},
  {ar:'إِنَّ رَبَّكَ وَاسِعُ الْمَغْفِرَةِ', trans:'Indeed, your Lord is vast in forgiveness.', ref:'An-Najm 53:32', theme:'Hope', surah:53, ayah:32},
  // Gratitude
  {ar:'لَئِن شَكَرْتُمْ لَأَزِيدَنَّكُمْ', trans:'If you are grateful, I will surely increase you in favour.', ref:'Ibrahim 14:7', theme:'Shukr', surah:14, ayah:7},
  {ar:'وَاللَّهُ يُحِبُّ الْمُحْسِنِينَ', trans:'And Allah loves the doers of good.', ref:'Al-Imran 3:134', theme:'Ihsan', surah:3, ayah:134},
  // Du'a & Prayer
  {ar:'ادْعُونِي أَسْتَجِبْ لَكُمْ', trans:'Call upon Me; I will respond to you.', ref:'Ghafir 40:60', theme:'Dua', surah:40, ayah:60},
  {ar:'وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ', trans:'And when My servants ask you about Me — I am near.', ref:'Al-Baqarah 2:186', theme:'Dua', surah:2, ayah:186},
  {ar:'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً', trans:'Our Lord, give us good in this world and good in the Hereafter.', ref:'Al-Baqarah 2:201', theme:'Dua', surah:2, ayah:201},
  // Taqwa & Guidance
  {ar:'ذَٰلِكَ الْكِتَابُ لَا رَيْبَ فِيهِ هُدًى لِّلْمُتَّقِينَ', trans:'This is the Book about which there is no doubt, a guidance for the God-fearing.', ref:'Al-Baqarah 2:2', theme:'Quran', surah:2, ayah:2},
  {ar:'وَمَن يَتَّقِ اللَّهَ يَجْعَل لَّهُ مَخْرَجًا', trans:'And whoever fears Allah — He will make for him a way out.', ref:'At-Talaq 65:2', theme:'Taqwa', surah:65, ayah:2},
  {ar:'يَا أَيُّهَا الَّذِينَ آمَنُوا اتَّقُوا اللَّهَ حَقَّ تُقَاتِهِ', trans:'O you who believe, fear Allah as He should be feared.', ref:'Al-Imran 3:102', theme:'Taqwa', surah:3, ayah:102},
  // Allah's Presence
  {ar:'وَهُوَ مَعَكُمْ أَيْنَ مَا كُنتُمْ', trans:'And He is with you wherever you are.', ref:'Al-Hadid 57:4', theme:'Presence', surah:57, ayah:4},
  {ar:'إِنَّ اللَّهَ لَا يُضِيعُ أَجْرَ الْمُحْسِنِينَ', trans:'Indeed, Allah does not allow to be lost the reward of those who do good.', ref:'Hud 11:115', theme:'Reward', surah:11, ayah:115},
  {ar:'وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ', trans:'My success is not but through Allah.', ref:'Hud 11:88', theme:'Tawakkul', surah:11, ayah:88},
  // Light & Guidance
  {ar:'اللَّهُ نُورُ السَّمَاوَاتِ وَالْأَرْضِ', trans:'Allah is the Light of the heavens and the earth.', ref:'An-Nur 24:35', theme:'Light', surah:24, ayah:35},
  {ar:'يَهْدِي اللَّهُ لِنُورِهِ مَن يَشَاءُ', trans:'Allah guides to His light whom He wills.', ref:'An-Nur 24:35', theme:'Light', surah:24, ayah:35},
  // Salah
  {ar:'وَأَقِيمُوا الصَّلَاةَ وَآتُوا الزَّكَاةَ', trans:'Establish prayer and give zakah.', ref:'Al-Baqarah 2:43', theme:'Salah', surah:2, ayah:43},
  {ar:'إِنَّ الصَّلَاةَ تَنْهَىٰ عَنِ الْفَحْشَاءِ وَالْمُنكَرِ', trans:'Indeed, prayer prohibits immorality and wrongdoing.', ref:'Al-Ankabut 29:45', theme:'Salah', surah:29, ayah:45},
];

// Theme colours
const QVS_THEME_COLORS = {
  Tawakkul: '#5bbfb5', Sabr: 'var(--purple)', Dhikr: '#c9a96e',
  Hope: 'var(--green)', Shukr: '#ffb74d', Ihsan: 'var(--accent-3)',
  Dua: '#5bbfb5', Quran: '#c9a96e', Taqwa: '#ce93d8',
  Presence: '#5bbfb5', Reward: 'var(--green)', Light: 'var(--gold2)',
  Salah: '#c9a96e', default: '#c9a96e'
};

let _qvsIdx = 0;
let _qvsAutoTimer = null;

function _qvsLoad() {
  try {
    const r = localStorage.getItem('mrd_qvs_idx');
    if (r !== null) _qvsIdx = parseInt(r) || 0;
  } catch {}
  // Seed index for the day
  if (!localStorage.getItem('mrd_qvs_idx')) {
    const seed = new Date().toISOString().slice(0,10).replace(/-/g,'');
    _qvsIdx = parseInt(seed) % QVS_VERSES.length;
  }
}

function renderQVS() {
  const card = document.getElementById('qvs-card');
  if (!card) return;
  if (_qvsIdx < 0 || _qvsIdx >= QVS_VERSES.length) _qvsIdx = 0;

  const v = QVS_VERSES[_qvsIdx];
  const color = QVS_THEME_COLORS[v.theme] || QVS_THEME_COLORS.default;

  // Dot navigation (show window of 5 around current)
  const total = QVS_VERSES.length;
  const winStart = Math.max(0, Math.min(_qvsIdx - 2, total - 5));
  const dots = Array.from({length: Math.min(5, total)}, (_, i) => {
    const idx = winStart + i;
    return `<span class="qvs-dot ${idx === _qvsIdx ? 'active' : ''}" onclick="qvsGoTo(${idx})"></span>`;
  }).join('');

  card.innerHTML = `
    <div class="qvs-top">
      <div class="qvs-label">
        <span style="font-size:0.75rem">📖</span>
        Quran Verses
        <span class="qvs-surah-badge" style="border-color:${color}40;color:${color};background:${color}18">${v.theme}</span>
      </div>
      <div style="font-size:0.5rem;color:var(--t3);letter-spacing:.06em">${_qvsIdx + 1}/${total}</div>
    </div>
    <div class="qvs-arabic" id="qvs-arabic">${v.ar}</div>
    <div class="qvs-trans" id="qvs-trans">"${v.trans}"</div>
    <div class="qvs-ayah-ref">${v.ref}</div>
    <div class="qvs-footer">
      <div class="qvs-nav">
        <button class="qvs-nav-btn" onclick="qvsPrev()" title="Previous verse">‹ Prev</button>
        <div class="qvs-dots">${dots}</div>
        <button class="qvs-nav-btn" onclick="qvsNext()" title="Next verse">Next ›</button>
      </div>
      <div style="display:flex;gap:5px;align-items:center">
        <button title="Copy ayah" onclick="qvsCopyAyah()" style="width:28px;height:28px;border-radius:50%;border:1px solid var(--bd);background:rgba(255,255,255,.04);color:var(--t3);font-size:0.6875rem;cursor:pointer;display:flex;align-items:center;justify-content:center;-webkit-tap-highlight-color:transparent;transition:all .18s" id="qvs-copy-btn">⎘</button>
        <button class="qvs-read-btn" onclick="qvsOpenReader()" title="Open full Quran reader">Quran ↗</button>
      </div>
    </div>`;

  // Subtle animated top-border tint matching theme
  card.style.setProperty('--qvs-color', color);
  try { localStorage.setItem('mrd_qvs_idx', _qvsIdx); } catch {}
}

function _qvsAnimate(dir) {
  const ar = document.getElementById('qvs-arabic');
  const tr = document.getElementById('qvs-trans');
  if (ar && tr) {
    ar.style.opacity = '0'; ar.style.transform = `translateX(${dir * 16}px)`;
    tr.style.opacity = '0';
    setTimeout(() => {
      renderQVS();
      const ar2 = document.getElementById('qvs-arabic');
      const tr2 = document.getElementById('qvs-trans');
      if (ar2) { ar2.style.transition = 'none'; ar2.style.transform = `translateX(${-dir * 16}px)`; ar2.style.opacity = '0'; requestAnimationFrame(() => { ar2.style.transition = 'opacity .3s,transform .3s cubic-bezier(.22,1,.36,1)'; ar2.style.opacity = '1'; ar2.style.transform = 'translateX(0)'; }); }
      if (tr2) { tr2.style.transition = 'none'; tr2.style.opacity = '0'; requestAnimationFrame(() => { tr2.style.transition = 'opacity .35s .05s'; tr2.style.opacity = '1'; }); }
    }, 160);
  } else {
    renderQVS();
  }
}

function qvsNext() {
  _qvsIdx = (_qvsIdx + 1) % QVS_VERSES.length;
  _qvsAnimate(1);
  _qvsResetAutoTimer();
}

function qvsCopyAyah() {
  const v = QVS_VERSES[_qvsIdx];
  if (!v) return;
  const text = `${v.ar}\n\n"${v.trans}"\n— ${v.ref}`;
  navigator.clipboard?.writeText(text).then(() => {
    const btn = document.getElementById('qvs-copy-btn');
    if (btn) { btn.textContent = '✓'; btn.style.color = 'var(--green)'; btn.style.borderColor = 'rgba(var(--green-rgb),.4)'; setTimeout(() => { btn.textContent = '⎘'; btn.style.color = ''; btn.style.borderColor = ''; }, 1800); }
  }).catch(() => showToast('Could not copy'));
}

function qvsPrev() {
  _qvsIdx = (_qvsIdx - 1 + QVS_VERSES.length) % QVS_VERSES.length;
  _qvsAnimate(-1);
  _qvsResetAutoTimer();
}

function qvsGoTo(idx) {
  const dir = idx > _qvsIdx ? 1 : -1;
  _qvsIdx = idx;
  _qvsAnimate(dir);
  _qvsResetAutoTimer();
}

function qvsOpenReader() {
  openFeatPage('page-quran');
}

// Auto-advance every 45 seconds
function _qvsResetAutoTimer() {
  if (_qvsAutoTimer) clearInterval(_qvsAutoTimer);
  _qvsAutoTimer = setInterval(() => {
    _qvsIdx = (_qvsIdx + 1) % QVS_VERSES.length;
    renderQVS(); // quiet update, no animation flash
  }, 45000);
}

// Swipe support for QVS card
function _qvsInitSwipe() {
  const card = document.getElementById('qvs-card');
  if (!card || card.dataset.swipe) return;
  card.dataset.swipe = '1';
  let startX = 0;
  card.addEventListener('touchstart', e => { startX = e.touches[0].clientX; }, { passive: true });
  card.addEventListener('touchend', e => {
    const dx = e.changedTouches[0].clientX - startX;
    if (dx < -40) qvsNext();
    else if (dx > 40) qvsPrev();
  }, { passive: true });
}

function initQVS() {
  _qvsLoad();
  renderQVS();
  _qvsResetAutoTimer();
  // Defer swipe init until rendered
  setTimeout(_qvsInitSwipe, 200);
}

// ==============================================
// SUNNAH HABITS  (built-in + custom)
// ==============================================
const SUNNAH_BUILTIN = [
  { icon:'🌅', name:'Pray Tahajjud',      desc:'Night voluntary prayer before Fajr',            color:'#c9a96e' },
  { icon:'📿', name:'Morning Adhkar',     desc:'Recite morning remembrances after Fajr',        color:'#5bbfb5' },
  { icon:'🌙', name:'Evening Adhkar',     desc:'Recite evening remembrances after Asr',         color:'#7b9fe0' },
  { icon:'🦷', name:'Use Miswak',         desc:'Clean teeth before prayer',                     color:'#82c784' },
  { icon:'🤲', name:'Dua After Adhan',    desc:'Make dua when you hear the adhan',              color:'#ce93d8' },
  { icon:'🍽️', name:'Eat with Right Hand',desc:'Bismillah before eating, Alhamdulillah after', color:'#ffb74d' },
  { icon:'💤', name:'Sleep on Right Side',desc:'Recite Ayat al-Kursi before sleeping',          color:'#e07b8a' },
  { icon:'🤝', name:'Greet with Salam',   desc:'Spread salaam to those you know and don\'t know', color:'#5bbfb5' },
];

// ═══════════════════════════════════════════════════
// ADMIN OVERRIDE — sync data from Admin Panel
// Admin app saves to mrd_admin_* keys.
// On load, if those keys exist, replace the built-in
// arrays so the whole app uses admin-managed content.
// ═══════════════════════════════════════════════════
function applyAdminOverrides() {
  function loadAdmin(key) {
    try { const r = localStorage.getItem(key); if (r) return JSON.parse(r); } catch {}
    return null;
  }

  // 1. Dhikr
  const adminDhikr = loadAdmin('mrd_admin_dhikr');
  if (adminDhikr && Array.isArray(adminDhikr) && adminDhikr.length) {
    DHIKR_BUILTIN.length = 0;
    adminDhikr.forEach(d => DHIKR_BUILTIN.push({ar: d.ar, tr: d.tr, target: d.target, custom: false}));
  }

  // 2. Sunnah habits
  const adminSunnah = loadAdmin('mrd_admin_sunnah');
  if (adminSunnah && Array.isArray(adminSunnah) && adminSunnah.length) {
    SUNNAH_BUILTIN.length = 0;
    adminSunnah.forEach(s => SUNNAH_BUILTIN.push({icon: s.icon, name: s.name, desc: s.desc, color: s.color}));
  }

  // 3. Default Activities
  const adminActs = loadAdmin('mrd_admin_acts');
  if (adminActs && Array.isArray(adminActs) && adminActs.length) {
    DEFAULT_ACTIVITIES.length = 0;
    adminActs.forEach(a => DEFAULT_ACTIVITIES.push({icon: a.icon, name: a.name, meta: a.meta, color: a.color, cat: a.cat}));
  }

  // 4. Ayah pool (motivational ayahs shown on home)
  const adminAyahs = loadAdmin('mrd_admin_ayahs');
  if (adminAyahs && Array.isArray(adminAyahs) && adminAyahs.length) {
    AYAHS.length = 0;
    adminAyahs.forEach(a => AYAHS.push({ar: a.ar, trans: a.trans, ref: a.ref}));
  }

  // 5. Quran Verse Spotlight
  const adminQvs = loadAdmin('mrd_admin_qvs');
  if (adminQvs && Array.isArray(adminQvs) && adminQvs.length) {
    QVS_VERSES.length = 0;
    adminQvs.forEach(v => QVS_VERSES.push({ar: v.ar, trans: v.trans, ref: v.ref, theme: v.theme || 'Tawakkul', surah: v.surah || 1, ayah: v.ayah || 1}));
    // Reset QVS index so it doesn't go out of bounds
    try { const idx = parseInt(localStorage.getItem('mrd_qvs_idx') || '0');
      if (idx >= QVS_VERSES.length) localStorage.setItem('mrd_qvs_idx', '0'); } catch {}
  }

  // 6. Dua categories — admin stores per-category via mrd_duas_<cat>
  // Map admin cat IDs → DUA_CATS keys
  const duaCatMap = {
    morning: 'Morning', evening: 'Evening', sleep: 'Sleep',
    wake: 'Masnun', eating: 'Eating', travel: 'Travel',
    stress: 'Hardship', dua_masnun: 'Masnun'
  };
  Object.entries(duaCatMap).forEach(([adminCat, appCat]) => {
    const stored = loadAdmin('mrd_duas_' + adminCat);
    if (stored && Array.isArray(stored) && stored.length && DUA_CATS[appCat]) {
      // Append admin duas (avoid duplicates by title)
      const existingTitles = new Set(DUA_CATS[appCat].map(d => d.title));
      stored.forEach(d => {
        if (!existingTitles.has(d.title)) {
          DUA_CATS[appCat].push({title: d.title || '', ar: d.ar || '', trans: d.trans || ''});
          existingTitles.add(d.title);
        }
      });
    }
  });

  console.log('[Admin] Overrides applied:', {
    dhikr: DHIKR_BUILTIN.length,
    sunnah: SUNNAH_BUILTIN.length,
    activities: DEFAULT_ACTIVITIES.length,
    ayahs: AYAHS.length,
    qvs: QVS_VERSES.length
  });
}
// Run immediately — before any DOMContentLoaded rendering
applyAdminOverrides();

function loadCustomSunnah() {
  try { const r=localStorage.getItem('mrd3_custom_sunnah'); if(r) return JSON.parse(r); } catch{}
  return [];
}
function saveCustomSunnah(list) {
  try { localStorage.setItem('mrd3_custom_sunnah', JSON.stringify(list)); } catch{}
}
let customSunnah = loadCustomSunnah();
function getSunnahList() { return [...SUNNAH_BUILTIN, ...customSunnah]; }

function loadSunnah() {
  try {
    const r = localStorage.getItem('mrd3_sunnah');
    if (r) { const p = JSON.parse(r); if (p.date === dateKey(now)) return p.done; }
  } catch {}
  return SUNNAH_BUILTIN.map(() => false);
}
let sunnahDone = loadSunnah();

// Emoji options for custom sunnah
const SUNNAH_EMOJIS = ['🌅','🌙','📿','🤲','🕌','☪️','📖','✨','🤍','🌿','🧘','💫','🌺','🕊️','🎯','⭐','🌟','🏃','💪','🍎'];
let sunnahAddOpen = false;
let pickedSunnahEmoji = '⭐';

function toggleSunnahAddRow() {
  sunnahAddOpen = !sunnahAddOpen;
  pickedSunnahEmoji = '⭐';
  renderSunnah();
  if(sunnahAddOpen) setTimeout(()=>document.getElementById('sunnah-new-name')?.focus(), 100);
}

// ==============================================
// SMART SUNNAH — time-aware quick selection
// ==============================================
function _getSunnahTimeContext() {
  const hr = new Date().getHours();
  if (hr >= 3  && hr < 7)  return { label: 'Pre-Fajr',   icon: '🌙', suggested: [0, 2] };   // Tahajjud, Evening Adhkar
  if (hr >= 7  && hr < 10) return { label: 'Morning',    icon: '🌅', suggested: [1, 3, 4] }; // Morning Adhkar, Miswak, Dua after Adhan
  if (hr >= 10 && hr < 12) return { label: 'Forenoon',   icon: '☀️', suggested: [5, 3, 4] }; // Eat right hand, Miswak, Dua Adhan
  if (hr >= 12 && hr < 15) return { label: 'Afternoon',  icon: '🕛', suggested: [4, 5, 7] }; // Dua Adhan, Eat Right Hand, Greet
  if (hr >= 15 && hr < 18) return { label: 'After Asr',  icon: '🌤️', suggested: [2, 7, 5] }; // Evening Adhkar, Greet, Eat
  if (hr >= 18 && hr < 20) return { label: 'Evening',    icon: '🌆', suggested: [2, 4, 7] }; // Evening Adhkar, Dua Adhan, Greet
  if (hr >= 20 && hr < 23) return { label: 'Night',      icon: '🌃', suggested: [6, 2, 1] }; // Sleep right side, Evening Adhkar, Morning
  return                           { label: 'Late Night', icon: '🌙', suggested: [0, 6, 2] }; // Tahajjud, Sleep, Evening
}

let sunnahExpanded = false;
let activitiesExpanded = false;

function toggleSunnahExpand() {
  sunnahExpanded = !sunnahExpanded;
  renderSunnah();
}

function renderSunnah() {
  if(typeof viewingDate !== 'undefined' && viewingDate !== TODAY_KEY) {
    renderSunnahForSnap(getDateSnapshot(viewingDate)); return;
  }
  const list = getSunnahList();
  while(sunnahDone.length < list.length) sunnahDone.push(false);
  const doneCount = sunnahDone.filter(Boolean).length;

  const VISIBLE_COUNT = 5; // always show first 5
  const visibleList  = list.slice(0, VISIBLE_COUNT);
  const hiddenList   = list.slice(VISIBLE_COUNT);

  const ctx = _getSunnahTimeContext();
  const suggestedIdx = ctx.suggested.filter(i => i < list.length);

  function itemHTML(i) {
    const s      = list[i];
    const isCustom = i >= SUNNAH_BUILTIN.length;
    const isSugg   = suggestedIdx.includes(i) && !sunnahDone[i];
    const isDone   = sunnahDone[i];
    return `
      <div class="sunnah-item ${isDone?'done':''} ${isSugg&&!isDone?'is-suggested':''}" onclick="toggleSunnah(${i})">
        <div class="sunnah-icon" style="background:${ha(s.color||'#c9a96e',.14)};border-color:${ha(s.color||'#c9a96e',.22)};font-size:1.15rem">${s.icon}</div>
        <div class="sunnah-body">
          <div class="sunnah-name">${s.name}${isSugg && !isDone ? ' <span style="font-size:0.4375rem;background:rgba(var(--accent-rgb),.15);color:var(--gold);border:1px solid rgba(var(--accent-rgb),.3);border-radius:99px;padding:1px 6px;margin-left:5px;vertical-align:middle;letter-spacing:.06em">NOW</span>' : ''}</div>
          ${s.desc ? `<div class="sunnah-desc">${s.desc}</div>` : ''}
        </div>
        <div class="sunnah-chk ${isDone?'done':''}" style="${isDone?'':'opacity:.55'}">${isDone?'✓':''}</div>
        ${isCustom ? `<button class="sunnah-del" onclick="deleteCustomSunnah(${i - SUNNAH_BUILTIN.length},event)" title="Remove" style="position:static;opacity:.35;margin-left:2px">✕</button>` : ''}
      </div>`;
  }

  // Always-visible 5 items
  const mainItems = visibleList.map((_,i) => itemHTML(i)).join('');

  // Dropdown for the rest
  const hiddenDoneCount = hiddenList.filter((_,j) => sunnahDone[VISIBLE_COUNT + j]).length;
  const dropdownHtml = hiddenList.length ? `
    <div style="margin-top:4px">
      <button onclick="toggleSunnahExpand()"
        style="width:100%;display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-radius:13px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.03);color:var(--t2);font-family:'Manrope',sans-serif;font-size:0.75rem;cursor:pointer;-webkit-tap-highlight-color:transparent;touch-action:manipulation;transition:background .15s">
        <span style="display:flex;align-items:center;gap:7px">
          <span style="font-size:0.875rem">${sunnahExpanded ? '▲' : '▼'}</span>
          <span>${sunnahExpanded ? 'Show less' : `${hiddenList.length} more habits`}</span>
        </span>
        <span style="font-size:0.625rem;color:${hiddenDoneCount===hiddenList.length?'var(--green)':'var(--t3)'}">${hiddenDoneCount}/${hiddenList.length} done</span>
      </button>
      ${sunnahExpanded ? `<div style="margin-top:6px">${hiddenList.map((_,j) => itemHTML(VISIBLE_COUNT + j)).join('')}</div>` : ''}
    </div>` : '';

  const addRow = sunnahAddOpen ? `
    <div class="sunnah-add-row" id="sunnah-add-area">
      <div style="width:100%">
        <div class="emoji-row" id="sunnah-emoji-row">
          ${SUNNAH_EMOJIS.map(e=>`<button class="emoji-opt ${e===pickedSunnahEmoji?'sel':''}" onclick="pickSunnahEmoji('${e}',this)">${e}</button>`).join('')}
        </div>
        <div style="display:flex;gap:8px">
          <input class="sunnah-add-inp" id="sunnah-new-name" placeholder="Habit name…" maxlength="48" onkeydown="if(event.key==='Enter')addCustomSunnah()">
          <button class="sunnah-add-btn" onclick="addCustomSunnah()">Add</button>
          <button class="sunnah-add-btn" onclick="toggleSunnahAddRow()" style="background:rgba(255,255,255,.06);color:var(--t3);border:1px solid var(--bd)">✕</button>
        </div>
      </div>
    </div>` : '';

  // Progress bar
  const pct = list.length ? Math.round(doneCount / list.length * 100) : 0;
  const allDone = pct === 100;
  const progressBar = `
    <div style="margin-top:10px;padding-top:10px;border-top:1px solid rgba(255,255,255,.05)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:7px">
        <span style="font-size:0.5rem;letter-spacing:.1em;text-transform:uppercase;color:var(--t3)">Today's Sunnah</span>
        <div style="display:flex;align-items:center;gap:8px">
          ${!allDone ? `<button onclick="markAllSunnah()" style="font-size:0.5rem;padding:2px 9px;border-radius:99px;border:1px solid rgba(var(--accent-rgb),.28);background:rgba(var(--accent-rgb),.08);color:var(--gold);font-family:'Manrope',sans-serif;letter-spacing:.06em;cursor:pointer;-webkit-tap-highlight-color:transparent">Mark All</button>` : ''}
          <span style="font-size:0.625rem;color:${allDone?'var(--green)':'var(--t3)'};font-weight:600">${doneCount}/${list.length}</span>
        </div>
      </div>
      <div style="height:5px;border-radius:99px;background:rgba(255,255,255,.07);overflow:hidden">
        <div style="height:100%;border-radius:99px;background:${allDone?'var(--green)':'linear-gradient(90deg,var(--gold),var(--accent-3))'};width:${pct}%;transition:width .5s cubic-bezier(.22,1,.36,1)"></div>
      </div>
      ${allDone ? `<div style="text-align:center;margin-top:8px;font-size:0.5625rem;color:var(--green);letter-spacing:.08em;padding:6px;border-radius:10px;background:rgba(var(--accent-rgb),.07)">✦ All Sunnah Complete · Mashallah!</div>` : ''}
    </div>`;

  document.getElementById('sunnah-card').innerHTML =
    mainItems +
    dropdownHtml +
    addRow +
    progressBar;
}

function toggleSunnah(i) {
  if(viewingDate !== TODAY_KEY) { togglePastSunnah(i); return; }
  while(sunnahDone.length < getSunnahList().length) sunnahDone.push(false);
  sunnahDone[i] = !sunnahDone[i];
  try { localStorage.setItem('mrd3_sunnah', JSON.stringify({ date: dateKey(now), done: sunnahDone })); } catch {}
  renderSunnah(); renderKPI();
}

function markAllSunnah() {
  if(viewingDate !== TODAY_KEY) return;
  const list = getSunnahList();
  while(sunnahDone.length < list.length) sunnahDone.push(false);
  sunnahDone = sunnahDone.map(() => true);
  try { localStorage.setItem('mrd3_sunnah', JSON.stringify({ date: dateKey(now), done: sunnahDone })); } catch {}
  renderSunnah(); renderKPI();
}

function pickSunnahEmoji(e, el) {
  pickedSunnahEmoji = e;
  document.querySelectorAll('.emoji-opt').forEach(b=>b.classList.remove('sel'));
  el.classList.add('sel');
}

function addCustomSunnah() {
  const name = document.getElementById('sunnah-new-name')?.value.trim();
  if(!name) {
    const inp = document.getElementById('sunnah-new-name');
    if(inp){ inp.style.borderColor='var(--rose)'; setTimeout(()=>inp.style.borderColor='',1200); inp.focus(); }
    return;
  }
  customSunnah.push({ icon: pickedSunnahEmoji, name, desc:'', color:'#c9a96e', custom:true });
  saveCustomSunnah(customSunnah);
  sunnahDone.push(false);
  sunnahAddOpen = false;
  renderSunnah(); renderKPI();
}

function deleteCustomSunnah(customIdx, e) {
  e && e.stopPropagation();
  if(customIdx < 0 || customIdx >= customSunnah.length) return;
  const globalIdx = SUNNAH_BUILTIN.length + customIdx;
  customSunnah.splice(customIdx, 1);
  sunnahDone.splice(globalIdx, 1);
  saveCustomSunnah(customSunnah);
  try { localStorage.setItem('mrd3_sunnah', JSON.stringify({ date: dateKey(now), done: sunnahDone })); } catch {}
  renderSunnah(); renderKPI();
}

// ==============================================
// DAILY NOTES  (smart journaling feature)
// ==============================================

const NOTE_MAX = 3000; // character limit
const NOTE_WARN = 2400; // warn threshold

const NOTE_TAGS = [
  {l:'Gratitude', c:'rgba(var(--accent-rgb),.5)', bg:'rgba(var(--accent-rgb),.1)', col:'var(--gold)'},
  {l:'Dua', c:'rgba(var(--teal-rgb),.5)', bg:'rgba(var(--teal-rgb),.1)', col:'var(--teal)'},
  {l:'Reflection', c:'rgba(var(--purple-rgb),.5)', bg:'rgba(var(--purple-rgb),.1)', col:'var(--purple)'},
  {l:'Lesson', c:'rgba(var(--green-rgb),.5)', bg:'rgba(var(--green-rgb),.1)', col:'var(--green)'},
  {l:'Struggle', c:'rgba(var(--rose-rgb),.5)', bg:'rgba(var(--rose-rgb),.1)', col:'var(--rose)'},
  {l:'Goal', c:'rgba(var(--amber-rgb),.5)', bg:'rgba(var(--amber-rgb),.1)', col:'var(--amber)'},
];

const MOODS = [
  {e:'🤲', l:'Grateful'},
  {e:'✨', l:'Inspired'},
  {e:'😌', l:'Peaceful'},
  {e:'💪', l:'Motivated'},
  {e:'😔', l:'Struggling'},
  {e:'🤔', l:'Reflecting'},
  {e:'😴', l:'Tired'},
  {e:'🌱', l:'Growing'},
];

// Contextual smart prompts
const NOTE_PROMPTS = [
  'What is one thing you\'re grateful to Allah ﷻ for today?',
  'How did today\'s prayers make you feel?',
  'What is a quality you want to strengthen in yourself?',
  'What challenged your patience today, and how did you respond?',
  'Write about a moment of peace you felt today.',
  'What does الحمد لله mean to you right now?',
  'Is there something weighing on your heart? Write it out as a dua.',
  'What did you learn or reflect upon from today\'s Quran reading?',
  'How are you nurturing your relationship with Allah ﷻ this week?',
  'What intention (niyyah) do you want to carry into tomorrow?',
  'Describe a small act of kindness you gave or received today.',
  'What is one sunnah you want to improve on?',
];

let noteDebounceTimer = null;
let noteViewDate = TODAY_KEY; // tracks which day notes are being shown

function loadNote(key) {
  const snap = daily[key];
  return { text: snap?.noteText || '', moods: snap?.noteMoods || [], ts: snap?.noteTs || null, tags: snap?.noteTags || [] };
}

function saveNote(key, text, moods, tags) {
  if(!daily[key]) daily[key] = {};
  daily[key].noteText  = text;
  daily[key].noteMoods = moods;
  daily[key].noteTags  = tags || [];
  daily[key].noteTs    = text.trim() ? new Date().toISOString() : null;
  try { localStorage.setItem('mrd4_daily', JSON.stringify(daily)); } catch{}
  // ☁️ Supabase push for notes (today AND past dates)
  if(!saveNote._supaTimers) saveNote._supaTimers = {};
  clearTimeout(saveNote._supaTimers[key]);
  saveNote._supaTimers[key] = setTimeout(() => { supaPushDay(key); }, 2000);
}

// Rotating daily prompt - deterministic per day
// Hijri-aware prompts for sacred seasons
const HIJRI_PROMPTS = {
  9:  [ // Ramadan
    'What Quranic verse moved your heart today in Ramadan?',
    'How has fasting changed your perspective today?',
    'Write a dua you made today — pour your heart out.',
    'What habit from Ramadan do you want to keep after it ends?',
    'Who can you make iftar with or send food to?',
    'How did tarawih feel tonight? What stayed with you?',
    'What sin are you asking Allah ﷻ to forgive this Ramadan?',
    'Which name of Allah ﷻ resonates most with you right now?',
  ],
  12: [ // Dhul Hijjah
    'What sacrifice — of time, habit or attachment — can you make for Allah ﷻ?',
    'The Prophet ﷺ said no days are better than these 10. How are you using them?',
    'Write a prayer for the Hujjaj making Hajj today.',
    'What does the spirit of Eid al-Adha mean to you personally?',
  ],
  1:  [ // Muharram
    'A new Hijri year has begun. What do you want this year to stand for?',
    'The Prophet ﷺ called Muharram the month of Allah. How will you honour it?',
    'What from last year do you want to leave behind?',
  ],
  7:  [ // Rajab
    'Rajab is a gate to Ramadan. What are you preparing spiritually?',
    'Write about a quality of the Prophet ﷺ you admire on this Isra & Miʿraj month.',
  ],
  8:  [ // Shaʼban
    "The Prophet ﷺ fasted most in Sha'ban. What act of worship can you increase?",
    'Shaʼban is when deeds are raised to Allah ﻾. Are you at peace with yours?',
  ],
};

function getDailyPrompt(key) {
  // Try Hijri-aware prompt first
  try {
    const d    = new Date(key + 'T12:00:00');
    const hObj = toHijriObj(d);
    const pool = HIJRI_PROMPTS[hObj.month];
    if(pool) {
      const seed = key.replace(/-/g,'').split('').reduce((a,c)=>a+c.charCodeAt(0),0);
      return pool[seed % pool.length];
    }
  } catch(e) {}
  const seed = key.replace(/-/g,'').split('').reduce((a,c)=>a+c.charCodeAt(0),0);
  return NOTE_PROMPTS[seed % NOTE_PROMPTS.length];
}

// Simple markdown-lite: **bold**, *italic*, - list
function renderNoteMarkdown(text) {
  if(!text) return '';
  return String(text)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>')
    .replace(/\*(.+?)\*/g,'<em>$1</em>')
    .replace(/^- (.+)$/gm,'• $1');
}

function getNoteStreak() {
  let streak = 0;
  const d = new Date();
  while(true) {
    const k = dateKey(d);
    const n = daily[k];
    if((n?.noteText||'').trim() || (n?.noteMoods||[]).length) streak++;
    else break;
    d.setDate(d.getDate() - 1);
    if(streak > 365) break;
  }
  return streak;
}

function getReadingTime(text) {
  const words = (text||'').trim().split(/\s+/).filter(Boolean).length;
  if(!words) return '';
  const secs = Math.round(words / 3);
  if(secs < 60) return secs + 's read';
  return Math.ceil(secs / 60) + ' min read';
}

function renderNoteCard() {
  const card = document.getElementById('notes-card');
  if(!card) return;
  const isToday = noteViewDate === TODAY_KEY;
  const note = loadNote(noteViewDate);
  const prompt = getDailyPrompt(noteViewDate);
  const wc = (note.text||'').trim() ? (note.text||'').trim().split(/\s+/).length : 0;
  const cc = (note.text||'').length;
  const wcClass = cc >= NOTE_MAX ? 'limit' : cc >= NOTE_WARN ? 'warn' : '';
  const rt = getReadingTime(note.text);
  const streak = getNoteStreak();

  const moodHtml = MOODS.map(m =>
    `<button class="mood-tag ${note.moods.find(x=>x.l===m.l)?'sel':''}" onclick="toggleNoteMood('${m.e}','${m.l}')">${m.e} ${m.l}</button>`
  ).join('');

  const tagHtml = NOTE_TAGS.map(t =>
    `<button class="note-tag-btn ${(note.tags||[]).includes(t.l)?'sel':''}" style="${(note.tags||[]).includes(t.l)?`border-color:${t.c};background:${t.bg};color:${t.col}`:''}" onclick="toggleNoteTag('${t.l}')">${t.l}</button>`
  ).join('');

  const titleLabel = isToday ? "Today's Note" : (() => {
    const d = new Date(noteViewDate + 'T00:00:00');
    return d.toLocaleDateString('en-US', {weekday:'short', month:'short', day:'numeric'});
  })();

  card.innerHTML = `
    ${!isToday ? `<div style="font-size:0.5rem;letter-spacing:.12em;text-transform:uppercase;color:var(--gold);opacity:.75;margin-bottom:8px;padding:4px 2px;display:flex;align-items:center;gap:6px">✏️ Editing past note</div>` : ''}
    <div class="notes-hdr">
      <div class="notes-title">${titleLabel}${streak>=2?`<span class="note-streak-pill">🔥 ${streak}d</span>`:''}</div>
      <div class="notes-meta">
        <span class="notes-saved" id="notes-saved">✓ Saved</span>
        ${note.ts ? `<span class="notes-time">${formatNoteTime(note.ts)}</span>` : ''}
      </div>
    </div>
    <div class="mood-row" id="mood-row">${moodHtml}</div>
    <div class="note-tags-row" id="note-tags-row">${tagHtml}</div>
    <div class="notes-act-bar">
      <button class="notes-fmt-btn" onclick="insertFmt('**','**')" title="Bold"><b>B</b></button>
      <button class="notes-fmt-btn" onclick="insertFmt('*','*')" title="Italic"><i>I</i></button>
      <button class="notes-fmt-btn" onclick="insertFmt('\u000a> ','')" title="Quote">❝</button>
      <button class="notes-fmt-btn" onclick="insertFmt('- ','')" title="Bullet">•</button>
      <button class="notes-fmt-btn" onclick="insertFmt('الحمد لله ','')" title="Alhamdulillah" style="font-family:serif;font-size:0.75rem">ٱ</button>
      <button class="notes-fmt-btn" onclick="insertFmt('\u000a---\u000a','')" title="Divider">—</button>
      <div style="flex:1"></div>
      <button class="notes-act-btn focus-btn" onclick="openNotesFocus()">⛶ Focus</button>
    </div>
    <div class="notes-prompt" id="notes-prompt" onclick="cyclePrompt()" title="Tap for a new prompt">${prompt}</div>
    <textarea class="notes-ta" id="notes-ta"
      placeholder="${prompt}"
      maxlength="${NOTE_MAX}"
      oninput="onNoteInput()"
      onfocus="this.parentElement.style.boxShadow='0 0 0 1.5px rgba(var(--accent-rgb),.22)'"
      onblur="this.parentElement.style.boxShadow=''"
    >${note.text}</textarea>
    <div class="notes-footer">
      <span class="notes-wc ${wcClass}" id="notes-wc">${wc} word${wc!==1?'s':''} · ${cc}/${NOTE_MAX}${rt?' · '+rt:''}</span>
      <div class="notes-actions">
        ${note.text ? `<button class="notes-act-btn copy-btn" onclick="copyNote()" style="font-size:0.5rem;height:24px;padding:0 8px">⎘ Copy</button>` : ''}
        ${note.text ? `<button class="notes-clear" onclick="clearNote()">Clear</button>` : ''}
      </div>
    </div>`;

  setTimeout(()=>{
    const ta = document.getElementById('notes-ta');
    if(ta) autoResizeTA(ta);
  }, 50);

  renderNotesHistory();
}

function autoResizeTA(ta) {
  ta.style.height = 'auto';
  ta.style.height = Math.min(ta.scrollHeight, 320) + 'px';
}

function formatNoteTime(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
  } catch { return ''; }
}

let promptIndex = -1;
function cyclePrompt() {
  promptIndex = (promptIndex + 1) % NOTE_PROMPTS.length;
  const el = document.getElementById('notes-prompt');
  const ta = document.getElementById('notes-ta');
  if(!el) return;
  el.style.opacity = '0';
  setTimeout(() => {
    el.textContent = NOTE_PROMPTS[promptIndex];
    el.style.opacity = '1';
    if(ta) ta.placeholder = NOTE_PROMPTS[promptIndex];
  }, 200);
}

function onNoteInput() {
  const ta = document.getElementById('notes-ta');
  if(!ta) return;
  autoResizeTA(ta);
  const text = ta.value;
  const wc = text.trim() ? text.trim().split(/\s+/).length : 0;
  const cc = text.length;
  const rt = getReadingTime(text);
  const wcEl = document.getElementById('notes-wc');
  if(wcEl) {
    const cls = cc >= NOTE_MAX ? 'limit' : cc >= NOTE_WARN ? 'warn' : '';
    wcEl.className = 'notes-wc ' + cls;
    wcEl.textContent = `${wc} word${wc!==1?'s':''} · ${cc}/${NOTE_MAX}${rt?' · '+rt:''}`;
  }
  // Also sync focus mode textarea if open
  const fta = document.getElementById('notes-focus-ta');
  if(fta && fta !== ta) fta.value = text;
  clearTimeout(noteDebounceTimer);
  noteDebounceTimer = setTimeout(() => {
    const cur = loadNote(noteViewDate);
    saveNote(noteViewDate, ta.value, cur.moods, cur.tags);
    showNoteSaved();
    if(document.getElementById('note-slider-container')) renderNoteSlider();
    renderNotesHistory();
  }, 800);
}

function showNoteSaved() {
  const el = document.getElementById('notes-saved');
  if(!el) return;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 1800);
}

function toggleNoteMood(e, l) {
  const note = loadNote(noteViewDate);
  const idx = note.moods.findIndex(m=>m.l===l);
  if(idx >= 0) note.moods.splice(idx, 1);
  else note.moods.push({e, l});
  saveNote(noteViewDate, note.text, note.moods, note.tags);
  const mr = document.getElementById('mood-row');
  if(mr) mr.innerHTML = MOODS.map(m =>
    `<button class="mood-tag ${note.moods.find(x=>x.l===m.l)?'sel':''}" onclick="toggleNoteMood('${m.e}','${m.l}')">${m.e} ${m.l}</button>`
  ).join('');
  showNoteSaved();
  if(document.getElementById('note-slider-container')) renderNoteSlider();
}

function clearNote() {
  const isToday = noteViewDate === TODAY_KEY;
  const label = isToday ? "today's note" : "this day's note";
  if(!confirm('Clear ' + label + '?')) return;
  saveNote(noteViewDate, '', [], []);
  renderNoteCard();
  if(document.getElementById('note-slider-container')) renderNoteSlider();
}

function toggleNoteTag(label) {
  const note = loadNote(noteViewDate);
  const tags = note.tags || [];
  const idx = tags.indexOf(label);
  if(idx >= 0) tags.splice(idx, 1);
  else tags.push(label);
  saveNote(noteViewDate, note.text, note.moods, tags);
  // Re-render tags row only
  const tr = document.getElementById('note-tags-row');
  if(tr) tr.innerHTML = NOTE_TAGS.map(t =>
    `<button class="note-tag-btn ${tags.includes(t.l)?'sel':''}" style="${tags.includes(t.l)?`border-color:${t.c};background:${t.bg};color:${t.col}`:''}" onclick="toggleNoteTag('${t.l}')">${t.l}</button>`
  ).join('');
  showNoteSaved();
  renderNotesHistory();
}

function copyNote() {
  const note = loadNote(noteViewDate);
  const text = note.text || '';
  const tags = (note.tags||[]).length ? '[' + note.tags.join(', ') + ']\n' : '';
  const moods = (note.moods||[]).length ? note.moods.map(m=>m.e+' '+m.l).join(' · ') + '\n' : '';
  const d = new Date(noteViewDate + 'T00:00:00');
  const dateStr = d.toLocaleDateString('en-US', {weekday:'long', year:'numeric', month:'long', day:'numeric'});
  const full = `${dateStr}\n${moods}${tags}\n${text}`;
  if(navigator.clipboard) {
    navigator.clipboard.writeText(full).then(() => {
      const btn = document.querySelector('.copy-btn');
      if(btn) { btn.textContent = '✓ Copied'; setTimeout(() => { btn.innerHTML = '⎘ Copy'; }, 1800); }
    });
  }
}

// ── Focus Mode ──
function openNotesFocus() {
  const ovl = document.getElementById('notes-focus-overlay');
  const fta = document.getElementById('notes-focus-ta');
  const note = loadNote(noteViewDate);
  if(!ovl || !fta) return;
  fta.value = note.text || '';
  ovl.classList.add('open');
  setTimeout(() => fta.focus(), 350);
  _updateFocusWC(fta.value);
}

function closeNotesFocus() {
  const ovl = document.getElementById('notes-focus-overlay');
  if(ovl) ovl.classList.remove('open');
  // Sync back to main textarea
  const fta = document.getElementById('notes-focus-ta');
  const ta = document.getElementById('notes-ta');
  if(fta && ta) {
    ta.value = fta.value;
    onNoteInput();
  }
}

function _updateFocusWC(text) {
  const wc = (text||'').trim().split(/\s+/).filter(Boolean).length;
  const rt = getReadingTime(text);
  const wcEl = document.getElementById('notes-focus-wc');
  const rtEl = document.getElementById('notes-focus-rt');
  if(wcEl) wcEl.textContent = wc + ' word' + (wc!==1?'s':'');
  if(rtEl) rtEl.textContent = rt;
}

let _focusDebounce = null;
function onFocusNoteInput() {
  const fta = document.getElementById('notes-focus-ta');
  if(!fta) return;
  _updateFocusWC(fta.value);
  clearTimeout(_focusDebounce);
  _focusDebounce = setTimeout(() => {
    const cur = loadNote(noteViewDate);
    saveNote(noteViewDate, fta.value, cur.moods, cur.tags);
    const sv = document.getElementById('notes-focus-save');
    if(sv) { sv.classList.add('show'); setTimeout(() => sv.classList.remove('show'), 1800); }
    // Sync main textarea
    const ta = document.getElementById('notes-ta');
    if(ta) { ta.value = fta.value; autoResizeTA(ta); }
    const wcEl = document.getElementById('notes-wc');
    if(wcEl) {
      const cc = fta.value.length, wc2 = fta.value.trim().split(/\s+/).filter(Boolean).length;
      const rt2 = getReadingTime(fta.value);
      const cls = cc >= NOTE_MAX ? 'limit' : cc >= NOTE_WARN ? 'warn' : '';
      wcEl.className = 'notes-wc ' + cls;
      wcEl.textContent = `${wc2} word${wc2!==1?'s':''} · ${cc}/${NOTE_MAX}${rt2?' · '+rt2:''}`;
    }
    if(document.getElementById('note-slider-container')) renderNoteSlider();
    renderNotesHistory();
  }, 600);
}

// ── Search ──
function openNotesSearch() {
  const ovl = document.getElementById('notes-search-ovl');
  const inp = document.getElementById('notes-search-input');
  if(!ovl) return;
  ovl.classList.add('open');
  setTimeout(() => { if(inp) inp.focus(); }, 300);
}

function closeNotesSearch() {
  const ovl = document.getElementById('notes-search-ovl');
  if(ovl) ovl.classList.remove('open');
  const inp = document.getElementById('notes-search-input');
  if(inp) inp.value = '';
  const res = document.getElementById('notes-search-results');
  if(res) res.innerHTML = '<div class="notes-search-empty">Start typing to search your notes</div>';
}

function onNotesSearch(query) {
  const res = document.getElementById('notes-search-results');
  if(!res) return;
  const q = (query||'').trim().toLowerCase();
  if(!q) {
    res.innerHTML = '<div class="notes-search-empty">Start typing to search your notes</div>';
    return;
  }
  const matches = Object.keys(daily).filter(k => {
    const n = daily[k];
    return (n?.noteText||'').toLowerCase().includes(q) ||
           (n?.noteTags||[]).some(t=>t.toLowerCase().includes(q)) ||
           (n?.noteMoods||[]).some(m=>(m.l||'').toLowerCase().includes(q));
  }).sort().reverse();

  if(!matches.length) {
    res.innerHTML = '<div class="notes-search-empty">No notes found for "' + query + '"</div>';
    return;
  }

  res.innerHTML = matches.map(k => {
    const n = daily[k];
    const text = n?.noteText || '';
    const moods = n?.noteMoods || [];
    const tags = n?.noteTags || [];
    const d = new Date(k + 'T00:00:00');
    const dateLabel = k === TODAY_KEY ? 'Today' :
      d.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'});
    // Highlight snippet
    const idx = text.toLowerCase().indexOf(q);
    let snippet = '';
    if(idx >= 0) {
      const start = Math.max(0, idx - 40);
      const end = Math.min(text.length, idx + q.length + 80);
      const raw = (start > 0 ? '…' : '') + text.slice(start, end) + (end < text.length ? '…' : '');
      snippet = raw.replace(new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gi'), m => `<mark>${m}</mark>`);
    } else {
      snippet = text.slice(0, 120) + (text.length > 120 ? '…' : '');
    }
    const moodIcons = moods.map(m=>`<span class="notes-search-mood">${m.e}</span>`).join('');
    const tagPills = tags.map(t=>`<span style="font-size:0.4375rem;padding:1px 6px;border-radius:99px;border:1px solid rgba(var(--purple-rgb),.3);background:rgba(var(--purple-rgb),.08);color:var(--purple)">${t}</span>`).join('');
    return `<div class="notes-search-result" onclick="closeNotesSearch();switchDate('${k}')">
      <div class="notes-search-date">${dateLabel}</div>
      ${tagPills ? `<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:4px">${tagPills}</div>` : ''}
      ${snippet ? `<div class="notes-search-snippet">${snippet}</div>` : ''}
      ${moodIcons ? `<div class="notes-search-moods">${moodIcons}</div>` : ''}
    </div>`;
  }).join('');
}

// ── History Timeline ──
function renderNotesHistory() {
  const wrap = document.getElementById('notes-history-wrap');
  if(!wrap) return;

  const dates = Object.keys(daily).filter(k => {
    if(k === noteViewDate) return false; // skip current note
    const n = daily[k];
    return (n?.noteText||'').trim() || (n?.noteMoods||[]).length;
  }).sort().reverse().slice(0, 20);

  if(!dates.length) { wrap.innerHTML = ''; return; }

  wrap.innerHTML = `<div style="padding:0 16px 24px">
    <div class="notes-history-title">Past Notes</div>
    ${dates.map((k, i) => {
      const n = daily[k];
      const text = n?.noteText || '';
      const moods = n?.noteMoods || [];
      const tags = n?.noteTags || [];
      const d = new Date(k + 'T00:00:00');
      const yesterday = (() => { const y = new Date(); y.setDate(y.getDate()-1); return dateKey(y); })();
      const dateLabel = k === TODAY_KEY ? 'Today' : k === yesterday ? 'Yesterday' :
        d.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
      const snippet = text.slice(0, 100) + (text.length > 100 ? '…' : '');
      const tagPills = tags.map(t=>`<span class="notes-history-tag">${t}</span>`).join('');
      const moodIcons = moods.slice(0,4).map(m=>`<span class="notes-history-mood">${m.e}</span>`).join('');
      const isLast = i === dates.length - 1;
      return `<div class="notes-history-item" onclick="switchDate('${k}')">
        <div class="notes-history-spine">
          <div class="notes-history-dot"></div>
          ${!isLast ? '<div class="notes-history-line"></div>' : ''}
        </div>
        <div class="notes-history-card">
          <div class="notes-history-date">${dateLabel}</div>
          ${tagPills ? `<div class="notes-history-tags">${tagPills}</div>` : ''}
          ${snippet ? `<div class="notes-history-snippet">${snippet}</div>` : ''}
          ${moodIcons ? `<div class="notes-history-moods">${moodIcons}</div>` : ''}
        </div>
      </div>`;
    }).join('')}
  </div>`;
}

function insertFmt(before, after) {
  const ta = document.getElementById('notes-ta');
  if(!ta) return;
  const s = ta.selectionStart, e = ta.selectionEnd;
  const sel = ta.value.substring(s, e) || 'text';
  ta.value = ta.value.substring(0,s) + before + sel + after + ta.value.substring(e);
  ta.selectionStart = s + before.length;
  ta.selectionEnd   = s + before.length + sel.length;
  ta.focus();
  onNoteInput();
}

// Called when switching date strip - updates notes card for that day
function switchNoteDate(key) {
  noteViewDate = key;
  renderNoteCard();
}

// Render note preview in stats/progress view
function renderNotePreview() {
  // Keep for backward compat — the progress tab now uses renderNoteSlider
  renderNoteSlider();
}

// ==============================================
// SLIDING NOTE VIEWER (Progress Tab)
// ==============================================
let _noteSliderIdx = 0; // 0 = most recent note
let _noteSliderDates = [];
let _noteSliderTouchX = null;

function _buildNoteDates() {
  // Gather all dates with notes, newest first
  const dates = Object.keys(daily).filter(k => {
    const d = daily[k];
    return (d.noteText && d.noteText.trim()) || (d.noteMoods && d.noteMoods.length);
  }).sort().reverse();
  // Also check TODAY_KEY live state
  const todayNote = loadNote(TODAY_KEY);
  if((todayNote.text && todayNote.text.trim()) || todayNote.moods.length) {
    if(!dates.includes(TODAY_KEY)) dates.unshift(TODAY_KEY);
    else { dates.splice(dates.indexOf(TODAY_KEY), 1); dates.unshift(TODAY_KEY); }
  }
  return dates;
}

function renderNoteSlider() {
  const container = document.getElementById('note-slider-container');
  if(!container) return;

  _noteSliderDates = _buildNoteDates();

  if(!_noteSliderDates.length) {
    container.innerHTML = `<div class="note-slide-card"><div class="note-slide-empty">No notes written yet. Add a note from the Today tab.</div></div>`;
    return;
  }

  // Clamp index
  _noteSliderIdx = Math.max(0, Math.min(_noteSliderIdx, _noteSliderDates.length - 1));

  const total = _noteSliderDates.length;
  container.innerHTML = `
    <div class="note-slider-wrap" id="note-slider-wrap">
      <div class="note-slider-hdr">
        <div class="note-slider-title">📝 Notes</div>
        <div class="note-slider-nav">
          <button class="note-slider-btn" id="note-prev-btn" onclick="noteSlide(-1)" ${_noteSliderIdx >= total-1 ? 'disabled' : ''}>‹</button>
          <span class="note-slider-pos" id="note-slider-pos">${total - _noteSliderIdx} / ${total}</span>
          <button class="note-slider-btn" id="note-next-btn" onclick="noteSlide(1)" ${_noteSliderIdx <= 0 ? 'disabled' : ''}>›</button>
        </div>
      </div>
      <div id="note-slide-card-wrap"></div>
    </div>`;

  _renderNoteSlideCard();
  _initNoteSliderSwipe();
}

function _renderNoteSlideCard(direction) {
  const wrap = document.getElementById('note-slide-card-wrap');
  if(!wrap) return;
  const key = _noteSliderDates[_noteSliderIdx];
  if(!key) { wrap.innerHTML = ''; return; }

  const note = key === TODAY_KEY ? loadNote(TODAY_KEY) : { text: daily[key]?.noteText || '', moods: daily[key]?.noteMoods || [] };
  const d = new Date(key+'T00:00:00');
  const isToday = key === TODAY_KEY;
  const dateLabel = isToday ? '✦ Today' : d.toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'});
  const preview = (note.text||'').trim().slice(0, 260) + ((note.text||'').trim().length > 260 ? '…' : '');

  const card = document.createElement('div');
  card.className = 'note-slide-card';
  if(direction === 'prev') card.classList.add('sliding-in');
  else if(direction === 'next') { card.style.transform = 'translateX(-18px)'; card.style.opacity = '0'; }
  card.innerHTML = `
    <div class="note-slide-date">${dateLabel}</div>
    ${preview ? `<div class="note-slide-text">${renderNoteMarkdown(preview)}</div>` : ''}
    ${note.moods && note.moods.length ? `<div class="note-slide-moods">${note.moods.map(m=>`<span class="note-slide-badge">${m.e} ${m.l||''}</span>`).join('')}</div>` : ''}`;

  wrap.innerHTML = '';
  wrap.appendChild(card);

  // Animate in
  requestAnimationFrame(() => {
    card.style.transition = 'opacity .2s, transform .2s cubic-bezier(.22,1,.36,1)';
    card.style.opacity = '1';
    card.style.transform = 'translateX(0)';
  });

  // Update nav buttons
  const total = _noteSliderDates.length;
  const posEl = document.getElementById('note-slider-pos');
  const prevBtn = document.getElementById('note-prev-btn');
  const nextBtn = document.getElementById('note-next-btn');
  if(posEl) posEl.textContent = (total - _noteSliderIdx) + ' / ' + total;
  if(prevBtn) prevBtn.disabled = _noteSliderIdx >= total - 1;
  if(nextBtn) nextBtn.disabled = _noteSliderIdx <= 0;
}

function noteSlide(dir) {
  // dir = -1 = older (prev), +1 = newer (next)
  const newIdx = _noteSliderIdx + (-dir); // -1 dir means go to older = higher index
  if(newIdx < 0 || newIdx >= _noteSliderDates.length) return;
  _noteSliderIdx = newIdx;
  _renderNoteSlideCard(dir === -1 ? 'prev' : 'next');
}

function _initNoteSliderSwipe() {
  const wrap = document.getElementById('note-slider-wrap');
  if(!wrap || wrap.dataset.swipe) return;
  wrap.dataset.swipe = '1';
  let startX = null;
  wrap.addEventListener('touchstart', e => { startX = e.touches[0].clientX; }, {passive:true});
  wrap.addEventListener('touchend', e => {
    if(startX === null) return;
    const dx = e.changedTouches[0].clientX - startX;
    startX = null;
    if(Math.abs(dx) < 40) return;
    noteSlide(dx > 0 ? -1 : 1); // swipe right = older, swipe left = newer
  }, {passive:true});
}

// ==============================================
// DUA LIBRARY
// ==============================================
const DUA_CATS = {
  Masnun: [
    { title:'After Waking Up', ar:'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ', trans:'All praise is for Allah who gave us life after causing us to die, and to Him is the resurrection.' },
    { title:'Before Sleeping', ar:'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا', trans:'In Your name, O Allah, I die and I live.' },
    { title:'Entering the Bathroom', ar:'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ', trans:'O Allah, I seek refuge in You from male and female devils.' },
    { title:'Leaving the Bathroom', ar:'غُفْرَانَكَ', trans:'I seek Your forgiveness.' },
    { title:'Before Eating', ar:'بِسْمِ اللَّهِ', trans:'In the name of Allah.' },
    { title:'After Eating', ar:'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مِنَ الْمُسْلِمِينَ', trans:'All praise is for Allah who fed us, gave us drink, and made us Muslims.' },
    { title:'Leaving Home', ar:'بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ', trans:'In the name of Allah, I place my trust in Allah. There is no power and no strength except with Allah.' },
    { title:'Entering Home', ar:'اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ الْمَوْلَجِ وَخَيْرَ الْمَخْرَجِ', trans:'O Allah, I ask You for the best entrance and the best exit.' },
    { title:'Entering the Mosque', ar:'اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ', trans:'O Allah, open for me the doors of Your mercy.' },
    { title:'Leaving the Mosque', ar:'اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ', trans:'O Allah, I ask You from Your bounty.' }
  ],
  Morning: [
    { title:'Morning Dua', ar:'اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ', trans:'O Allah, by You we enter the morning, by You we enter the evening, by You we live and die, and to You is the resurrection.' },
    { title:'Dua for Provision', ar:'اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا وَرِزْقًا طَيِّبًا وَعَمَلًا مُتَقَبَّلًا', trans:'O Allah, I ask You for beneficial knowledge, good provision, and accepted deeds.' },
    { title:'Protection in Morning', ar:'رَضِيتُ بِاللَّهِ رَبًّا وَبِالْإِسْلَامِ دِينًا وَبِمُحَمَّدٍ نَبِيًّا', trans:'I am pleased with Allah as Lord, Islam as religion, and Muhammad ﷺ as Prophet.' }
  ],
  Evening: [
    { title:'Evening Dua', ar:'اللَّهُمَّ بِكَ أَمْسَيْنَا وَبِكَ أَصْبَحْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ الْمَصِيرُ', trans:'O Allah, by You we enter the evening and by You we enter the morning; by You we live and die, and to You is the return.' },
    { title:'Dua for Protection', ar:'بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ', trans:'In the name of Allah, with Whose name nothing on earth or in the sky can cause harm.' },
    { title:'Seeking Safety', ar:'أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ', trans:'I seek refuge in the perfect words of Allah from the evil of what He created.' }
  ],
  Sleep: [
    { title:'Before Sleep', ar:'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا', trans:'In Your name, O Allah, I die and I live.' },
    { title:'Ayat al-Kursi', ar:'اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ', trans:'Allah — there is no deity except Him, the Ever-Living, the Sustainer of existence.' },
    { title:'Turning in Bed', ar:'بِاسْمِكَ رَبِّ وَضَعْتُ جَنْبِي وَبِكَ أَرْفَعُهُ', trans:'In Your name, my Lord, I lay down my side and by You I raise it.' }
  ],
  Travel: [
    { title:'Leaving Home', ar:'بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ', trans:'In the name of Allah, I place my trust in Allah.' },
    { title:'Entering Vehicle', ar:'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ', trans:'Glory be to Him who has subjected this to us, and we could not have done it ourselves.' },
    { title:'Travel Takbir', ar:'اللَّهُ أَكْبَرُ، اللَّهُ أَكْبَرُ، اللَّهُ أَكْبَرُ', trans:'Allah is the Greatest, Allah is the Greatest, Allah is the Greatest.' }
  ],
  Eating: [
    { title:'Before Eating', ar:'بِسْمِ اللَّهِ', trans:'In the name of Allah.' },
    { title:'If Forgot at Start', ar:'بِسْمِ اللَّهِ أَوَّلَهُ وَآخِرَهُ', trans:'In the name of Allah, at its beginning and its end.' },
    { title:'After Eating', ar:'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا', trans:'All praise is due to Allah who fed us and gave us drink.' }
  ],
  Hardship: [
    { title:'In Difficulty', ar:'اللَّهُمَّ لَا سَهْلَ إِلَّا مَا جَعَلْتَهُ سَهْلًا', trans:'O Allah, there is no ease except what You make easy.' },
    { title:'Dua of Yunus', ar:'لَا إِلَٰهَ إِلَّا أَنتَ سُبْحَانَكَ إِنِّي كُنتُ مِنَ الظَّالِمِينَ', trans:'There is no deity except You; exalted are You. Indeed, I have been of the wrongdoers.' },
    { title:'Hasbunallah', ar:'حَسْبُنَا اللَّهُ وَنِعْمَ الْوَكِيلُ', trans:'Allah is sufficient for us, and He is the best disposer of affairs.' }
  ],
};

let activeDuaCat = 'Masnun';

function renderDuaTabs() {
  document.getElementById('dua-cat-tabs').innerHTML = Object.keys(DUA_CATS).map(cat => `
    <button class="dua-tab ${cat===activeDuaCat?'active':''}" onclick="setDuaCat('${cat}')">${cat}</button>`).join('');
}
function renderDuaList() {
  const duas = DUA_CATS[activeDuaCat];
  document.getElementById('dua-list').innerHTML = duas.map(d => `
    <div class="dua-item glass">
      <div class="dua-title">${d.title}</div>
      <div class="dua-arabic">${d.ar}</div>
      <div class="dua-trans">${d.trans}</div>
    </div>`).join('');
}
function setDuaCat(cat) {
  activeDuaCat = cat;
  renderDuaTabs(); renderDuaList();
}

// ==============================================
// QIBLA FINDER
// ==============================================
let qiblaAngle = null;

function renderQiblaCard(angle, locText) {
  const el = document.getElementById('qibla-card');
  if (angle === null) {
    el.innerHTML = `
      <div class="qibla-inner">
        <div style="flex:1">
          <div style="font-family:'Playfair Display',serif;font-size:18px;font-weight:300;color:var(--t2);margin-bottom:8px">Find Qibla Direction</div>
          <div style="font-size:11px;color:var(--t3);line-height:1.6">Tap below to use your device location to calculate the direction of the Kaaba in Mecca.</div>
          <button class="qibla-btn" onclick="findQibla()" style="margin-top:12px">🧭 Find Qibla</button>
        </div>
        <div style="font-size:52px;opacity:.25">🕋</div>
      </div>`;
    return;
  }
  el.innerHTML = `
    <div class="qibla-inner">
      <div class="qibla-compass">
        <div class="qibla-ring">
          <div class="qibla-needle-wrap" id="qibla-needle" style="transform:rotate(${angle}deg)">
            <div class="qibla-needle"></div>
          </div>
          <div class="qibla-dot"></div>
        </div>
      </div>
      <div class="qibla-info">
        <div class="qibla-deg">${Math.round(angle)}<span>°</span></div>
        <div class="qibla-lbl">from North</div>
        <div class="qibla-loc">${locText||'Based on your location'}</div>
        <button class="qibla-btn" onclick="findQibla()">↻ Recalculate</button>
      </div>
    </div>`;
}

function findQibla() {
  const el = document.getElementById('qibla-card');
  el.innerHTML = `<div style="text-align:center;padding:18px;color:var(--t3);font-size:12px">📍 Getting your location…</div>`;
  if (!navigator.geolocation) {
    el.innerHTML = `<div style="text-align:center;padding:18px;color:var(--rose);font-size:12px">Geolocation not available on this device.</div>`;
    return;
  }
  navigator.geolocation.getCurrentPosition(pos => {
    const lat = pos.coords.latitude, lng = pos.coords.longitude;
    // Kaaba coordinates
    const kLat = 21.4225, kLng = 39.8262;
    const dLng = (kLng - lng) * Math.PI / 180;
    const lat1 = lat * Math.PI / 180, lat2 = kLat * Math.PI / 180;
    const x = Math.sin(dLng) * Math.cos(lat2);
    const y = Math.cos(lat1)*Math.sin(lat2) - Math.sin(lat1)*Math.cos(lat2)*Math.cos(dLng);
    let brg = Math.atan2(x, y) * 180 / Math.PI;
    brg = (brg + 360) % 360;
    qiblaAngle = brg;
    const locText = `${lat.toFixed(2)}°, ${lng.toFixed(2)}°`;
    try { localStorage.setItem('mrd3_qibla', JSON.stringify({ angle: brg, loc: locText })); } catch {}
    renderQiblaCard(brg, locText);
  }, () => {
    // Try to load cached
    try {
      const r = localStorage.getItem('mrd3_qibla');
      if (r) { const p = JSON.parse(r); renderQiblaCard(p.angle, p.loc + ' (cached)'); return; }
    } catch {}
    el.innerHTML = `<div style="text-align:center;padding:18px">
      <div style="color:var(--rose);font-size:12px;margin-bottom:10px">Location access denied.</div>
      <button class="qibla-btn" onclick="findQibla()">Try again</button>
    </div>`;
  });
}

function initQibla() {
  try {
    const r = localStorage.getItem('mrd3_qibla');
    if (r) { const p = JSON.parse(r); renderQiblaCard(p.angle, p.loc + ' (cached)'); return; }
  } catch {}
  renderQiblaCard(null, null);
}

// ==============================================
// SCROLL REVEAL
// ==============================================
function initScrollReveal() {
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if(e.isIntersecting) {
        e.target.classList.add('visible');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -20px 0px' });

  document.querySelectorAll(
    '.clock-wrap,.prayer-strip,.kpi,.dhikr-wrap,.fast-wrap,.quran-wrap,.qvs-wrap,.ayah-wrap,.sunnah-wrap,.dua-wrap,.qibla-wrap'
  ).forEach(el => {
    el.classList.add('scroll-reveal');
    io.observe(el);
  });
}

// Smooth scroll to list area when switching date
function smoothScrollToList() {
  const strip = document.getElementById('date-strip');
  const view  = document.getElementById('view-today');
  if(strip && view) setTimeout(() => {
    view.scrollTo({ top: strip.offsetTop - 60, behavior: 'smooth' });
  }, 60);
}

// ==============================================


// -- DOM element cache (avoids repeated getElementById) --
const _domCache = {};
function $id(id) {
  if(!_domCache[id]) _domCache[id] = document.getElementById(id);
  return _domCache[id];
}
// Invalidate cache on view switches (elements may be re-created)
function _clearDomCache() { Object.keys(_domCache).forEach(k => delete _domCache[k]); }

// -- Performance: debounce helpers --------------------
let _kpiTimer = null;
function renderKPIDebounced() {
  if(_kpiTimer) clearTimeout(_kpiTimer);
  _kpiTimer = setTimeout(renderKPI, 32); // max 1 frame at 30fps
}
let _statsTimer = null;
function renderStatsDebounced() {
  if(_statsTimer) clearTimeout(_statsTimer);
  _statsTimer = setTimeout(renderStats, 32);
}
let _listTimer = null;
function renderListDebounced() {
  if(_listTimer) clearTimeout(_listTimer);
  _listTimer = setTimeout(renderList, 16);
}

// INIT
// ==============================================

renderPrayers();
renderKPI();
renderAyah();
renderDhikrTabs();
renderDhikrCard();
renderFasting();
renderQuran();
initQVS();
renderSunnah();
renderNoteCard();
renderDuaTabs();
renderDuaList();
initQibla();
renderDateStrip();
renderViewingBanner();
renderList();
// Always open at the very top of home page
requestAnimationFrame(() => {
  const v = document.getElementById('view-today');
  if(v) v.scrollTop = 0;
});
// Check account / show onboarding
obInit();
// Check milestones on first load (e.g. welcome message)
setTimeout(checkMilestones, 1800);
// Apply expand/collapse state
applyExpandState();

// Init date picker
(function() {
  const dp = document.getElementById('date-picker');
  if(dp) {
    dp.value = TODAY_KEY;
    dp.min = '1900-01-01';
    dp.max = '2200-12-31';
  }
})();

// Init scroll reveal after a brief paint delay
requestAnimationFrame(() => requestAnimationFrame(initScrollReveal));

// ==============================================
// DATA & SETTINGS
// ==============================================

const ALL_STORAGE_KEYS = [
  { key:'mrd4_daily',        label:'Daily Data',        desc:'Activities, prayers, fasting, dhikr, Quran, sunnah, notes', icon:'📅' },
  { key:'mrd3_prayers',      label:'Prayer Times',      desc:'Configured prayer schedule',                                icon:'🕌' },
  { key:'mrd3_pdone',        label:'Prayer Check-ins',  desc:'Which prayers were completed today',                       icon:'✅' },
  { key:'mrd3_dhikr',        label:'Dhikr Counts',      desc:'Today\'s dhikr progress',                                 icon:'📿' },
  { key:'mrd3_fasting',      label:'Fasting Log',       desc:'Past fasting days record',                                 icon:'🤍' },
  { key:'mrd3_quran',        label:'Quran Progress',    desc:'Pages read and daily goal',                                icon:'📖' },
  { key:'mrd3_sunnah',       label:'Sunnah Check-ins',  desc:'Today\'s sunnah habits',                                  icon:'🌙' },
  { key:'mrd3_custom_dhikr', label:'Custom Dhikrs',     desc:'Your personally added dhikr entries',                     icon:'✨' },
  { key:'mrd3_custom_sunnah',label:'Custom Sunnah',     desc:'Your personally added sunnah habits',                     icon:'🌱' },
  { key:'mrd3_ayah',         label:'Ayah Favourites',   desc:'Saved favourite ayahs',                                   icon:'⭐' },
  { key:'mrd3_qibla',        label:'Qibla Cache',       desc:'Cached qibla direction for your location',                icon:'🧭' },
  { key:'mrd3_dayacts',      label:'Activity Log',      desc:'Backup activity data per date',                           icon:'📋' },
  { key:'mrd_settings',      label:'App Settings',      desc:'All your preferences and customisations',                 icon:'⚙️' },
  { key:'pq_custom_types',   label:'Custom Salah Types', desc:'Your custom salah quality labels',                        icon:'🏷️' },
];

// -- Default settings ----------------------------
const SETTINGS_DEFAULTS = {
  accentColor:      'gold',
  fontSize:         100,
  animations:       true,
  orbs:             true,
  prayerMethod:     2,
  asrMethod:        1,
  notifications:    false,
  reminderOffset:   5,
  dhikrResetDaily:  true,
  showDone:         true,
  weekStart:        0,
  hijriOffset:      0,
  showScore:        true,
  clockFormat:      12,
  showHijri:        true,
  quranGoal:        2,
  // Display extras
  compactMode:      false,
  showSeconds:      false,
  kpiLabels:        true,
  theme:            'dark',
  cardRadius:       'round',
  fontTheme:        'luxe-classic',
  // Habits
  sunnahResetDaily: true,
  dhikrHaptic:      true,
  activityGoal:     5,
  fastingReminder:  false,
  // Privacy
  pinEnabled:       false,
  hideBg:           false,
  // Language
  prayerNameStyle:  'english',
  showTranslit:     true,
  duaLang:          'both',
  // Language
  language:         'en',
  // Daily Routine
  wakeTime:         '05:30',
  sleepTime:        '23:00',
  niyyahEnabled:    false,
  niyyahText:       '',
  focusMode:        false,
  jumuahBanner:     true,
  ishraqNudge:      true,
  // Home Screen sections
  showDhikr:        true,
  showFasting:      true,
  showQuran:        true,
  showSunnah:       true,
  showWater:        true,
  showKpi:          true,
  showStreak:       true,
  showMood:         true,
  showNafsCoach:    true,
  showAyah:         true,
  showLevelWidget:  true,
  showQuickNav:     true,
  // Score weights (0-5, relative)
  scoreWeightPrayer:    5,
  scoreWeightActs:      4,
  scoreWeightSunnah:    3,
  scoreWeightDhikr:     3,
  scoreWeightQuran:     3,
  scoreWeightFasting:   2,
};

const ACCENT_COLORS = [
  { name:'gold',   color:'#c9a96e', vars:{'--gold':'#c9a96e','--gold2':'#e2c488','--gold-g':'rgba(var(--accent-rgb),.22)','--accent-rgb':'201,169,110','--accent-soft':'rgba(var(--accent-rgb),.10)','--accent-soft-2':'rgba(var(--accent-rgb),.16)','--accent-soft-3':'rgba(var(--accent-rgb),.24)','--accent-contrast':'#0d0c09','--accent-main':'#c9a96e','--accent-2':'#d7ba84','--accent-3':'#e2c488','--accent-4':'#ead1a0','--accent-5':'#f0dcba','--accent-6':'#f6e8d6'} },
  { name:'teal',   color:'#5bbfb5', vars:{'--gold':'#5bbfb5','--gold2':'#8ed9d2','--gold-g':'rgba(var(--accent-rgb),.22)','--accent-rgb':'91,191,181','--accent-soft':'rgba(var(--accent-rgb),.10)','--accent-soft-2':'rgba(var(--accent-rgb),.16)','--accent-soft-3':'rgba(var(--accent-rgb),.24)','--accent-contrast':'#071311','--accent-main':'#5bbfb5','--accent-2':'#72cbc2','--accent-3':'#8ed9d2','--accent-4':'#a8e4df','--accent-5':'#c7efec','--accent-6':'#e1f7f5'}  },
  { name:'rose',   color:'#e07b8a', vars:{'--gold':'#e07b8a','--gold2':'#f0a6b1','--gold-g':'rgba(var(--accent-rgb),.22)','--accent-rgb':'224,123,138','--accent-soft':'rgba(var(--accent-rgb),.10)','--accent-soft-2':'rgba(var(--accent-rgb),.16)','--accent-soft-3':'rgba(var(--accent-rgb),.24)','--accent-contrast':'#170c10','--accent-main':'#e07b8a','--accent-2':'#e7909c','--accent-3':'#f0a6b1','--accent-4':'#f4bcc5','--accent-5':'#f8d3d9','--accent-6':'#fcebed'} },
  { name:'green',  color:'#6dbf8a', vars:{'--gold':'#6dbf8a','--gold2':'#97d7ac','--gold-g':'rgba(var(--accent-rgb),.22)','--accent-rgb':'109,191,138','--accent-soft':'rgba(var(--accent-rgb),.10)','--accent-soft-2':'rgba(var(--accent-rgb),.16)','--accent-soft-3':'rgba(var(--accent-rgb),.24)','--accent-contrast':'#09140d','--accent-main':'#6dbf8a','--accent-2':'#84ca9b','--accent-3':'#97d7ac','--accent-4':'#b1e3c1','--accent-5':'#cfefda','--accent-6':'#e8f8ee'} },
  { name:'purple', color:'#ce93d8', vars:{'--gold':'#ce93d8','--gold2':'#e2b8e9','--gold-g':'rgba(var(--accent-rgb),.22)','--accent-rgb':'206,147,216','--accent-soft':'rgba(var(--accent-rgb),.10)','--accent-soft-2':'rgba(var(--accent-rgb),.16)','--accent-soft-3':'rgba(var(--accent-rgb),.24)','--accent-contrast':'#120b15','--accent-main':'#ce93d8','--accent-2':'#d9a7e1','--accent-3':'#e2b8e9','--accent-4':'#ebccef','--accent-5':'#f2ddf5','--accent-6':'#f8eef9'} },
];

let appSettings     = null; // declared early to prevent TDZ; assigned after loadSettings is defined
let autoSaveEnabled = true;

function loadSettings() {
  try {
    const r = localStorage.getItem('mrd_settings');
    if(r) return { ...SETTINGS_DEFAULTS, ...JSON.parse(r) };
  } catch{}
  return { ...SETTINGS_DEFAULTS };
}
function saveSettings() {
  try { localStorage.setItem('mrd_settings', JSON.stringify(appSettings)); } catch{}
  // ☁️ Supabase debounced push
  clearTimeout(saveSettings._supaTimer);
  saveSettings._supaTimer = setTimeout(() => {
    supaPushSettings();
    // Also update profile so settings are synced to user_profiles
    const acc = loadAccount();
    if (acc) supaPushProfile(acc);
  }, 4000);
}

appSettings = loadSettings(); // now safe to call
_lang = appSettings.language || 'en';


function _hexToRgb(hex){
  const raw = String(hex || '').trim().replace('#','');
  const full = raw.length === 3 ? raw.split('').map(ch=>ch+ch).join('') : raw;
  const n = parseInt(full, 16);
  if (!Number.isFinite(n) || full.length !== 6) return {r:201,g:169,b:110};
  return { r:(n>>16)&255, g:(n>>8)&255, b:n&255 };
}
function _rgbToHex(r,g,b){
  const toHex = v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2,'0');
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}
function _mixRgb(base, target, amount){
  return {
    r: base.r + (target.r - base.r) * amount,
    g: base.g + (target.g - base.g) * amount,
    b: base.b + (target.b - base.b) * amount,
  };
}
function _setThemeFamilyVars(ac){
  const root = document.documentElement;
  const base = _hexToRgb(ac?.color || '#c9a96e');
  const lightTarget = { r: 255, g: 255, b: 255 };
  const darkTarget  = { r: 8, g: 9, b: 12 };
  const theme = appSettings?.theme === 'light' ? 'light' : 'dark';
  const mk = (mixAmt, darkAmt=0) => {
    const mixed = _mixRgb(base, lightTarget, mixAmt);
    return darkAmt ? _mixRgb(mixed, darkTarget, darkAmt) : mixed;
  };
  const teal   = theme === 'light' ? mk(.18,.18) : mk(.10,0);
  const green  = theme === 'light' ? mk(.28,.12) : mk(.18,0);
  const rose   = theme === 'light' ? mk(.08,.10) : mk(.26,0);
  const purple = theme === 'light' ? mk(.34,.06) : mk(.34,0);
  const amber  = theme === 'light' ? mk(.12,.02) : mk(.12,0);
  const family = {
    '--teal-rgb': `${Math.round(teal.r)},${Math.round(teal.g)},${Math.round(teal.b)}`,
    '--teal': _rgbToHex(teal.r, teal.g, teal.b),
    '--teal-g': 'rgba(var(--teal-rgb),.18)',
    '--green-rgb': `${Math.round(green.r)},${Math.round(green.g)},${Math.round(green.b)}`,
    '--green': _rgbToHex(green.r, green.g, green.b),
    '--green-g': 'rgba(var(--green-rgb),.18)',
    '--rose-rgb': `${Math.round(rose.r)},${Math.round(rose.g)},${Math.round(rose.b)}`,
    '--rose': _rgbToHex(rose.r, rose.g, rose.b),
    '--rose-g': 'rgba(var(--rose-rgb),.18)',
    '--purple-rgb': `${Math.round(purple.r)},${Math.round(purple.g)},${Math.round(purple.b)}`,
    '--purple': _rgbToHex(purple.r, purple.g, purple.b),
    '--amber-rgb': `${Math.round(amber.r)},${Math.round(amber.g)},${Math.round(amber.b)}`,
    '--amber': _rgbToHex(amber.r, amber.g, amber.b),
  };
  Object.entries(family).forEach(([k,v]) => root.style.setProperty(k,v));
}

// -- Apply settings to DOM ----------------------
function applySettings() {
  // Collect all toggle/select values if settings view is active
  const animEl  = document.getElementById('anim-toggle');
  const orbsEl  = document.getElementById('orbs-toggle');
  const dhikrEl = document.getElementById('dhikr-reset-toggle');
  const doneEl  = document.getElementById('show-done-toggle');
  const scoreEl = document.getElementById('show-score-toggle');
  const hijriEl = document.getElementById('show-hijri-toggle');
  const methEl  = document.getElementById('prayer-method-sel');

  if(animEl  !== null) appSettings.animations     = animEl.checked;
  if(orbsEl  !== null) appSettings.orbs           = orbsEl.checked;
  if(dhikrEl !== null) appSettings.dhikrResetDaily= dhikrEl.checked;
  if(doneEl  !== null) appSettings.showDone       = doneEl.checked;
  if(scoreEl !== null) appSettings.showScore      = scoreEl.checked;
  if(hijriEl !== null) appSettings.showHijri      = hijriEl.checked;
  if(methEl  !== null) appSettings.prayerMethod   = parseInt(methEl.value);

  saveSettings();
  _applySettingsToDom();
  applyLanguage();
  // Apply new feature settings
  if(typeof applyHomeSections === 'function') applyHomeSections();
  if(typeof renderNiyyahBanner === 'function') renderNiyyahBanner();
  if(typeof applyFocusMode === 'function') applyFocusMode();
}

var _lastSettingsJSON = '';
function _applySettingsToDom() {
  // Skip if settings haven't actually changed — prevents DOM thrash (and sky blink) on sync
  const currentJSON = JSON.stringify(appSettings);
  if (currentJSON === _lastSettingsJSON) return;
  _lastSettingsJSON = currentJSON;

  const cfg = appSettings;
  const root = document.documentElement;

  // Accent color
  const ac = ACCENT_COLORS.find(a=>a.name===cfg.accentColor) || ACCENT_COLORS[0];
  Object.entries(ac.vars).forEach(([k,v]) => root.style.setProperty(k,v));
  _setThemeFamilyVars(ac);
  document.body.dataset.accent = ac.name;
  const fontThemes = ['luxe-classic','editorial-gold','royal-script','soft-readable','clean-luxury','modern-air','timeless-book','slim-premium','quiet-refined','minimal-sharp'];
  document.body.classList.remove(...fontThemes.map(v => 'font-theme-' + v));
  document.body.classList.add('font-theme-' + (cfg.fontTheme || 'luxe-classic'));
  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (metaTheme) metaTheme.setAttribute('content', cfg.theme === 'light' ? '#f0ede8' : ac.color);

  // Font size
  root.style.fontSize = cfg.fontSize + '%';

  // Animations
  const styleId = 'no-anim-style';
  let existingStyle = document.getElementById(styleId);
  if(!cfg.animations) {
    if(!existingStyle) {
      const st = document.createElement('style');
      st.id = styleId;
      // Exempt sky banner elements — killing their animation causes visible blink
      st.textContent = '*:not(.sky-cloud):not(.sky-body):not(.sky-body svg):not(#sky-stars span),*:not(.sky-cloud):not(.sky-body):not(.sky-body svg):not(#sky-stars span)::before,*:not(.sky-cloud):not(.sky-body):not(.sky-body svg):not(#sky-stars span)::after{animation-duration:.01ms!important;transition-duration:.01ms!important}';
      document.head.appendChild(st);
    }
  } else {
    if(existingStyle) existingStyle.remove();
  }

  // Orbs
  const orbEls = document.querySelectorAll('.orb,.grain');
  orbEls.forEach(el => el.style.display = cfg.orbs ? '' : 'none');

  // Hijri badge
  const hBadge = document.getElementById('hdr-hijri-en');
  if(hBadge) hBadge.style.display = cfg.showHijri ? '' : 'none';

  // Score ring visibility
  const bigWrap = document.querySelector('.big-wrap');
  if(bigWrap) bigWrap.style.display = cfg.showScore ? '' : 'none';

  // Show/hide done activities
  document.querySelectorAll('.itm.done').forEach(el => {
    el.style.display = cfg.showDone ? '' : 'none';
  });

  // Quran goal sync
  if(cfg.quranGoal && quranData.goal !== cfg.quranGoal) {
    quranData.goal = cfg.quranGoal;
    renderQuran();
    renderKPI();
  }

  // Compact mode
  document.body.classList.toggle('compact-mode', !!cfg.compactMode);

  // Theme
  document.body.classList.toggle('theme-light', cfg.theme === 'light');

  // Card radius
  const radVal = cfg.cardRadius === 'sharp' ? '10px' : cfg.cardRadius === 'pill' ? '32px' : '20px';
  document.documentElement.style.setProperty('--card-radius', radVal);

  // KPI labels
  document.querySelectorAll('.kpi-lbl').forEach(el => {
    el.style.display = cfg.kpiLabels === false ? 'none' : '';
  });

  // Prayer names style
  const PRAYER_NAMES_AR = {Fajr:'الفجر', Dhuhr:'الظهر', Asr:'العصر', Maghrib:'المغرب', Isha:'العشاء'};
  document.querySelectorAll('.prayer-name[data-prayer]').forEach(el => {
    const key = el.dataset.prayer;
    el.textContent = cfg.prayerNameStyle === 'arabic' ? (PRAYER_NAMES_AR[key] || key) : key;
  });

  // Transliteration visibility on dhikr cards
  document.querySelectorAll('.dhikr-tr').forEach(el => {
    el.style.display = cfg.showTranslit ? '' : 'none';
  });

  // Dua translation visibility
  document.querySelectorAll('.dua-trans').forEach(el => {
    el.style.display = cfg.duaLang === 'arabic' ? 'none' : '';
  });

  // Hide-on-background
  if(cfg.hideBg) {
    if(!window._hideBgListenerAdded) {
      document.addEventListener('visibilitychange', _handleVisibilityBlur);
      window._hideBgListenerAdded = true;
    }
  } else {
    document.removeEventListener('visibilitychange', _handleVisibilityBlur);
    window._hideBgListenerAdded = false;
    document.body.style.filter = '';
  }
}

// -- Render settings view controls -------------
function renderSettingsView() {
  const cfg = appSettings;

  // Populate toggles
  const ids = {
    'anim-toggle':          cfg.animations,
    'orbs-toggle':          cfg.orbs,
    'dhikr-reset-toggle':   cfg.dhikrResetDaily,
    'show-done-toggle':     cfg.showDone,
    'show-score-toggle':    cfg.showScore,
    'show-hijri-toggle':    cfg.showHijri,
    'notif-toggle':         cfg.notifications,
    'autosave-toggle':      true,
    // new
    'compact-toggle':       cfg.compactMode,
    'show-seconds-toggle':  cfg.showSeconds,
    'kpi-labels-toggle':    cfg.kpiLabels,
    'sunnah-reset-toggle':  cfg.sunnahResetDaily,
    'dhikr-haptic-toggle':  cfg.dhikrHaptic,
    'fasting-reminder-toggle': cfg.fastingReminder,
    'pin-toggle':           cfg.pinEnabled,
    'hide-bg-toggle':       cfg.hideBg,
    'translit-toggle':      cfg.showTranslit,
    'show-quick-nav-toggle': cfg.showQuickNav,
  };
  Object.entries(ids).forEach(([id, val]) => {
    const el = document.getElementById(id);
    if(el) el.checked = val;
  });

  // Show/hide PIN change row
  const pinRow = document.getElementById('pin-change-row');
  if(pinRow) pinRow.style.display = cfg.pinEnabled ? '' : 'none';

  // PIN sub label
  const pinSub = document.getElementById('pin-sub');
  if(pinSub) pinSub.textContent = cfg.pinEnabled ? 'PIN is active — tap Change to update' : 'Require a PIN to open the app';

  // Prayer method select
  const methEl = document.getElementById('prayer-method-sel');
  if(methEl) methEl.value = cfg.prayerMethod;

  // Font size
  const fsEl  = document.getElementById('fontsize-val');
  const fsSub = document.getElementById('fontsize-sub');
  if(fsEl)  fsEl.textContent  = cfg.fontSize + '%';
  if(fsSub) fsSub.textContent = cfg.fontSize <= 85 ? 'Small' : cfg.fontSize <= 100 ? 'Medium' : cfg.fontSize <= 115 ? 'Large' : 'Extra Large';

  // Font theme
  const ftEl = document.getElementById('font-theme-sel');
  const ftSub = document.getElementById('fonttheme-sub');
  const fontThemeLabels = {
    'luxe-classic': 'Balanced luxury serif + clean UI',
    'editorial-gold': 'Editorial contrast with premium sharpness',
    'royal-script': 'Tall elegant serif with polished modern UI',
    'soft-readable': 'Soft readable serif for a calm feel',
    'clean-luxury': 'Classic luxury serif with tidy modern body text',
    'modern-air': 'Stylish modern serif with airy UI',
    'timeless-book': 'Bookish classic with smooth contemporary balance',
    'slim-premium': 'Slim premium display with clean supporting text',
    'quiet-refined': 'Refined reading feel with elegant light UI',
    'minimal-sharp': 'Sharp minimal serif with crisp modern UI'
  };
  if(ftEl) ftEl.value = cfg.fontTheme || 'luxe-classic';
  if(ftSub) ftSub.textContent = fontThemeLabels[cfg.fontTheme || 'luxe-classic'] || 'Balanced premium serif';

  // Reminder offset
  const roEl = document.getElementById('reminder-offset-val');
  if(roEl) roEl.textContent = cfg.reminderOffset + ' min';

  // Hijri offset
  const hoEl = document.getElementById('hijri-offset-val');
  if(hoEl) hoEl.textContent = (cfg.hijriOffset >= 0 ? '+' : '') + cfg.hijriOffset;

  // Quran goal
  const qgEl = document.getElementById('quran-goal-val');
  if(qgEl) qgEl.textContent = cfg.quranGoal + ' pg';

  // Asr method pill
  _activatePill('asr-toggle', cfg.asrMethod === 2 ? 1 : 0);

  // Clock format pill
  _activatePill('clock-format-toggle', cfg.clockFormat === 24 ? 1 : 0);

  // Week start pill
  const wsMap = [0,1,6];
  _activatePill('week-start-toggle', wsMap.indexOf(cfg.weekStart));

  // Accent swatches
  const swatchEl = document.getElementById('accent-swatches');
  if(swatchEl) {
    swatchEl.innerHTML = ACCENT_COLORS.map(ac => `
      <div class="accent-sw ${ac.name===cfg.accentColor?'active':''}"
           style="background:${ac.color};border-color:${ac.name===cfg.accentColor?'rgba(255,255,255,.5)':'transparent'}"
           onclick="setAccentColor('${ac.name}')" title="${ac.name}"></div>`
    ).join('');
  }

  // Theme pill
  _activatePill('theme-toggle', cfg.theme === 'light' ? 1 : 0);

  // Card radius pill
  const radMap = ['sharp','round','pill'];
  _activatePill('radius-toggle', radMap.indexOf(cfg.cardRadius));

  // Prayer name style pill
  _activatePill('prayer-name-toggle', cfg.prayerNameStyle === 'arabic' ? 1 : 0);

  // Dua lang pill
  _activatePill('dua-lang-toggle', cfg.duaLang === 'both' ? 1 : 0);

  // App language pill
  _activatePill('lang-toggle', cfg.language === 'bn' ? 1 : 0);
  renderAllScardTitles();

  // Backup section user info

  // Activity goal
  const agEl = document.getElementById('activity-goal-val');
  if(agEl) agEl.textContent = cfg.activityGoal;

  // Prayer name sub
  const pnSub = document.getElementById('prayer-name-sub');
  if(pnSub) pnSub.textContent = cfg.prayerNameStyle === 'arabic'
    ? 'Showing: الفجر · الظهر · العصر · المغرب · العشاء'
    : 'Showing: Fajr · Dhuhr · Asr · Maghrib · Isha';

  // Notification sub
  const notifSub = document.getElementById('notif-sub');
  if(notifSub) {
    const perm = 'Notification' in window ? Notification.permission : 'unavailable';
    notifSub.textContent = perm === 'granted' ? 'Active — you\'ll receive prayer reminders'
      : perm === 'denied' ? 'Blocked — enable in browser settings'
      : 'Get browser reminders at prayer times';
  }

  // Storage stats
  const bytes   = getStorageBytes();
  const maxBytes= 5*1024*1024;
  const pct     = Math.min(bytes/maxBytes*100,100);
  const daysT   = getDaysTracked();

  const barEl   = document.getElementById('storage-bar');
  const badgeEl = document.getElementById('storage-badge');
  const lblEl   = document.getElementById('storage-size-lbl');
  const daysEl  = document.getElementById('days-tracked-badge');
  const daysSub = document.getElementById('days-tracked-sub');
  const lastEl  = document.getElementById('last-saved-sub');
  const saveSub = document.getElementById('autosave-sub');
  const dotEl   = document.getElementById('save-dot');

  if(barEl)   { barEl.style.width=pct+'%'; barEl.style.background=pct>80?'var(--rose)':pct>50?'var(--gold)':'var(--teal)'; }
  if(badgeEl)  badgeEl.textContent = formatBytes(bytes);
  if(lblEl)    lblEl.textContent   = `${formatBytes(bytes)} of ~5 MB used (${pct.toFixed(1)}%)`;
  if(daysEl)   daysEl.textContent  = daysT;
  if(daysSub)  daysSub.textContent = `${daysT} day${daysT!==1?'s':''} with recorded data`;
  if(lastEl)   lastEl.textContent  = getLastSaved();
  if(saveSub)  saveSub.textContent = autoSaveEnabled ? 'All changes save instantly to your device' : 'Auto-save is paused';
  if(dotEl)    dotEl.className     = 'save-dot'+(autoSaveEnabled?'':' off');

  // What's stored list
  const listEl = document.getElementById('stored-keys-list');
  if(listEl) {
    listEl.innerHTML = ALL_STORAGE_KEYS.map(item => {
      const raw  = localStorage.getItem(item.key);
      const size = raw ? formatBytes(raw.length*2) : null;
      return `<div style="display:flex;align-items:center;gap:10px;padding:4px 0">
        <span style="font-size:16px;width:24px;text-align:center;flex-shrink:0">${item.icon}</span>
        <div style="flex:1;min-width:0">
          <div style="font-size:13px;font-weight:500">${item.label}</div>
          <div style="font-size:11px;color:var(--t2);margin-top:1px">${item.desc}</div>
        </div>
        <div style="flex-shrink:0">
          ${size ? `<span style="font-size:10px;padding:2px 8px;border-radius:99px;background:rgba(var(--accent-rgb),.1);color:var(--teal)">${size}</span>`
                 : `<span style="font-size:10px;color:var(--t3)">empty</span>`}
        </div>
      </div>`;
    }).join('');
  }

  // ── New settings sync ──────────────────────────
  _setChk('focus-mode-toggle',      cfg.focusMode);
  _setChk('jumuah-banner-toggle',   cfg.jumuahBanner !== false);
  _setChk('ishraq-nudge-toggle',    cfg.ishraqNudge  !== false);
  _setChk('niyyah-toggle',          cfg.niyyahEnabled);
  _setChk('show-dhikr-toggle',      cfg.showDhikr    !== false);
  _setChk('show-fasting-toggle',    cfg.showFasting  !== false);
  _setChk('show-quran-toggle',      cfg.showQuran    !== false);
  _setChk('show-sunnah-toggle',     cfg.showSunnah   !== false);
  _setChk('show-water-toggle',      cfg.showWater    !== false);
  _setChk('show-kpi-toggle',        cfg.showKpi      !== false);
  _setChk('show-streak-toggle',     cfg.showStreak   !== false);
  _setChk('show-mood-toggle',       cfg.showMood     !== false);
  _setChk('show-nafs-coach-toggle', cfg.showNafsCoach!== false);
  _setChk('show-ayah-toggle',       cfg.showAyah     !== false);
  _setChk('show-level-widget-toggle', cfg.showLevelWidget !== false);
  const wakeEl  = document.getElementById('wake-time-inp');
  const sleepEl = document.getElementById('sleep-time-inp');
  const niyEl   = document.getElementById('niyyah-text');
  const niyChar = document.getElementById('niyyah-chars');
  if(wakeEl)  wakeEl.value  = cfg.wakeTime  || '05:30';
  if(sleepEl) sleepEl.value = cfg.sleepTime || '23:00';
  if(niyEl)   niyEl.value   = cfg.niyyahText || '';
  if(niyChar) niyChar.textContent = (cfg.niyyahText||'').length + ' / 120';
  updateBackupInfo();

  // ☁️ Cloud Sync card (collapsible body)
  const supaCard = document.getElementById('supa-auth-card');
  if (supaCard) {
    supaCard.innerHTML = _supaUser ? _supaLoggedInHTML() : _supaAuthFormHTML();
  }

  // ☁️ Top mini card
  _renderCloudTopCard();
}

function _renderCloudTopCard() {
  const inner  = document.getElementById('settings-cloud-inner');
  const avatar = document.getElementById('sct-avatar');
  const title  = document.getElementById('sct-title');
  const sub    = document.getElementById('sct-sub');
  const action = document.getElementById('sct-action');
  if (!inner) return;

  if (_supaUser) {
    const email = _supaUser.email || '';
    const initials = email.slice(0, 2).toUpperCase();
    inner.style.borderColor  = 'rgba(var(--green-rgb),.25)';
    inner.style.background   = 'rgba(var(--green-rgb),.06)';
    if (avatar) {
      avatar.style.background = 'rgba(var(--green-rgb),.18)';
      avatar.innerHTML = `<span style="font-size:0.75rem;font-weight:700;color:var(--green)">${initials}</span>`;
    }
    if (title) title.textContent = email;
    if (sub)   sub.innerHTML  = '<span style="color:var(--green)">✓ Synced to cloud</span>';
    if (action) action.innerHTML = `<button onclick="event.stopPropagation();supaSignOut().then(()=>{_renderCloudTopCard();renderSettingsView();showSettingsToast('Signed out')})" style="font-size:0.6875rem;padding:5px 12px;border-radius:99px;background:rgba(var(--rose-rgb),.1);border:1px solid rgba(var(--rose-rgb),.25);color:var(--rose);font-family:'Manrope',sans-serif;cursor:pointer;-webkit-tap-highlight-color:transparent">Sign Out</button>`;
  } else {
    inner.style.borderColor  = 'rgba(var(--teal-rgb),.18)';
    inner.style.background   = 'rgba(var(--teal-rgb),.06)';
    if (avatar) { avatar.style.background = 'rgba(var(--teal-rgb),.15)'; avatar.innerHTML = '☁️'; }
    if (title)  title.textContent = 'Cloud Sync';
    if (sub)    sub.textContent   = 'Sign in to backup & sync your data';
    if (action) action.innerHTML  = '<span style="font-size:0.6875rem;padding:5px 12px;border-radius:99px;background:rgba(var(--teal-rgb),.15);border:1px solid rgba(var(--teal-rgb),.3);color:var(--teal);font-weight:500">Sign In ›</span>';
  }
}

function _activatePill(wrapperId, activeIndex) {
  const wrap = document.getElementById(wrapperId);
  if(!wrap) return;
  wrap.querySelectorAll('.spt').forEach((btn,i) => {
    btn.classList.toggle('active', i === activeIndex);
  });
}

function _setChk(id, val) {
  const el = document.getElementById(id);
  if(el) el.checked = !!val;
}

// ══════════════════════════════════════════════
// DAILY ROUTINE SETTINGS
// ══════════════════════════════════════════════
function saveRoutineTime(key, val) {
  appSettings[key] = val;
  saveSettings();
  showSettingsToast(key === 'wakeTime' ? '🌄 Wake time saved' : '🌙 Bedtime saved');
}

function toggleNiyyah(on) {
  appSettings.niyyahEnabled = on;
  saveSettings();
  renderNiyyahBanner();
  showSettingsToast(on ? '🤲 Daily Niyyah enabled' : 'Niyyah banner hidden');
}

function saveNiyyahText(val) {
  appSettings.niyyahText = val.slice(0, 120);
  saveSettings();
  const el = document.getElementById('niyyah-chars');
  if(el) el.textContent = appSettings.niyyahText.length + ' / 120';
  renderNiyyahBanner();
}

function renderNiyyahBanner() {
  let el = document.getElementById('niyyah-banner');
  if(!appSettings.niyyahEnabled || !appSettings.niyyahText) {
    if(el) el.style.display = 'none';
    return;
  }
  if(!el) {
    // Create banner below header
    el = document.createElement('div');
    el.id = 'niyyah-banner';
    const clockWrap = document.querySelector('.clock-wrap');
    if(clockWrap) clockWrap.parentNode.insertBefore(el, clockWrap);
  }
  el.style.display = '';
  el.style.cssText += 'margin:0 14px 8px;padding:10px 14px;border-radius:14px;background:rgba(var(--accent-rgb),.07);border:1px solid rgba(var(--accent-rgb),.18);display:flex;align-items:center;gap:9px';
  el.innerHTML = `<span style="font-size:1rem;flex-shrink:0">🤲</span><div><div style="font-size:0.5rem;letter-spacing:.14em;text-transform:uppercase;color:var(--t3);margin-bottom:2px">Today's Intention</div><div style="font-size:0.8125rem;color:var(--gold);font-family:'Playfair Display',serif;font-style:italic;line-height:1.4">${escHtml(appSettings.niyyahText)}</div></div>`;
}

function toggleFocusMode(on) {
  appSettings.focusMode = on;
  saveSettings();
  applyFocusMode();
  showSettingsToast(on ? '🎯 Focus Mode on — prayer times highlighted at prayer windows' : 'Focus Mode off');
}

function applyFocusMode() {
  const strip = document.getElementById('prayer-strip-fixed');
  if(!strip) return;
  if(appSettings.focusMode) {
    const activePrayer = typeof getActivePrayer === 'function' ? getActivePrayer() : null;
    const nowMins = new Date().getHours() * 60 + new Date().getMinutes();
    const inWindow = activePrayer && prayerTimes[activePrayer] && (() => {
      const pm = typeof minsSinceMidnight === 'function' ? minsSinceMidnight(prayerTimes[activePrayer]) : -1;
      return pm >= 0 && (nowMins - pm) < 30;
    })();
    strip.style.transition = 'box-shadow .4s';
    strip.style.boxShadow = inWindow ? '0 0 0 2px rgba(var(--accent-rgb),.4), 0 0 24px rgba(var(--accent-rgb),.12)' : '';
  } else {
    strip.style.boxShadow = '';
  }
}

function toggleJumuahBanner(on) {
  appSettings.jumuahBanner = on;
  saveSettings();
  showSettingsToast(on ? '🕌 Jumu\'ah banner enabled' : 'Jumu\'ah banner disabled');
  if(typeof renderFridayBanner === 'function') renderFridayBanner();
}

function toggleIshraqNudge(on) {
  appSettings.ishraqNudge = on;
  saveSettings();
  showSettingsToast(on ? '☀️ Ishraq nudge enabled' : 'Ishraq nudge disabled');
  const el = document.getElementById('ishraq-nudge');
  if(el) el.style.display = on ? '' : 'none';
}

// ══════════════════════════════════════════════
// HOME SCREEN SECTION VISIBILITY
// ══════════════════════════════════════════════

// Maps settingKey -> CSS body class to add when hidden
const SECTION_CLASS_MAP = {
  showDhikr:   'hide-dhikr',
  showFasting: 'hide-fasting',
  showQuran:   'hide-quran',
  showSunnah:  'hide-sunnah',
  showWater:   'hide-water',
  showKpi:     'hide-kpi',
  showStreak:  'hide-streak',
  showMood:    'hide-mood',
  showNafsCoach: 'hide-nafs-coach',
  showAyah:    'hide-ayah',
  showLevelWidget: 'hide-level-widget',
  showQuickNav: 'hide-quick-nav',
};

function toggleExploreMore() {
  const grid = document.getElementById('explore-more-grid');
  const lbl  = document.getElementById('explore-toggle-label');
  const arr  = document.getElementById('explore-toggle-arrow');
  const open = grid.style.maxHeight && grid.style.maxHeight !== '0px';
  if (open) {
    grid.style.maxHeight = '0px';
    grid.style.opacity   = '0';
    grid.style.pointerEvents = 'none';
    lbl.textContent = 'Show more';
    arr.style.transform = 'rotate(0deg)';
  } else {
    grid.style.maxHeight = '1200px';
    grid.style.opacity   = '1';
    grid.style.pointerEvents = 'auto';
    lbl.textContent = 'Show less';
    arr.style.transform = 'rotate(180deg)';
  }
}

function _syncExploreBadges() {
  // Sync badge visibility from original feat badges to explore page badges
  const pairs = [
    ['feat-quran-badge',    'feat-quran-badge2'],
    ['feat-tasbih-badge',   'feat-tasbih-badge2'],
    ['feat-calendar-badge', 'feat-calendar-badge2'],
    ['feat-challenge-badge','feat-challenge-badge2'],
    ['feat-achieve-badge',  'feat-achieve-badge2'],
    ['feat-quiz-badge',     'feat-quiz-badge2'],
  ];
  pairs.forEach(([src, dst]) => {
    const s = document.getElementById(src);
    const d = document.getElementById(dst);
    if(s && d) {
      d.style.display = s.style.display;
      d.textContent   = s.textContent;
      d.className     = s.className;
    }
  });
}


function toggleSection(sectionId, on, settingKey) {
  appSettings[settingKey] = on;
  saveSettings();
  const cls = SECTION_CLASS_MAP[settingKey];
  if(cls) {
    document.body.classList.toggle(cls, !on);
  }
  showSettingsToast(settingKey === 'showQuickNav' ? (on ? '✓ Quick pill shown' : 'Quick pill hidden') : (on ? '✓ Section visible' : 'Section hidden'));
}

function applyHomeSections() {
  Object.entries(SECTION_CLASS_MAP).forEach(([key, cls]) => {
    const hidden = appSettings[key] === false;
    document.body.classList.toggle(cls, hidden);
  });
}

// Init new features on startup
// initNewFeatures defined later (merged definition handles all startup tasks)


// -- Individual setting actions -----------------
function setAccentColor(name) {
  appSettings.accentColor = name;
  applySettings();
  renderSettingsView();
}

function stepFontSize(dir) {
  const steps = [85,100,115,130];
  const cur = steps.indexOf(appSettings.fontSize);
  const next = Math.max(0, Math.min(steps.length-1, cur + dir));
  appSettings.fontSize = steps[next];
  applySettings();
  renderSettingsView();
}

function setFontTheme(val) {
  appSettings.fontTheme = val || 'luxe-classic'
  applySettings();
  renderSettingsView();
  const labels = {
    'luxe-classic': 'Luxe Classic applied',
    'editorial-gold': 'Editorial Gold applied',
    'royal-script': 'Royal Script applied',
    'soft-readable': 'Soft Readable applied',
    'clean-luxury': 'Clean Luxury applied',
    'modern-air': 'Modern Air applied',
    'timeless-book': 'Timeless Book applied',
    'slim-premium': 'Slim Premium applied',
    'quiet-refined': 'Quiet Refined applied',
    'minimal-sharp': 'Minimal Sharp applied'
  };
  showSettingsToast(labels[appSettings.fontTheme] || 'Font updated');
}

function setAsrMethod(val, btn) {
  appSettings.asrMethod = val;
  btn.closest('.st-pill-toggle').querySelectorAll('.spt').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  saveSettings();
  showSettingsToast('Asr method updated — re-fetch prayer times to apply');
}

function setClockFormat(val, btn) {
  appSettings.clockFormat = val;
  btn.closest('.st-pill-toggle').querySelectorAll('.spt').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  saveSettings();
}

function setWeekStart(val, btn) {
  appSettings.weekStart = val;
  btn.closest('.st-pill-toggle').querySelectorAll('.spt').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  saveSettings();
  showSettingsToast('Week start updated');
}

function stepReminderOffset(dir) {
  appSettings.reminderOffset = Math.max(0, Math.min(30, appSettings.reminderOffset + dir));
  saveSettings();
  const el = document.getElementById('reminder-offset-val');
  if(el) el.textContent = appSettings.reminderOffset + ' min';
  showSettingsToast('Reminder: ' + appSettings.reminderOffset + ' min before prayer');
}

function stepHijriOffset(dir) {
  appSettings.hijriOffset = Math.max(-3, Math.min(3, appSettings.hijriOffset + dir));
  saveSettings();
  const el = document.getElementById('hijri-offset-val');
  if(el) el.textContent = (appSettings.hijriOffset>=0?'+':'') + appSettings.hijriOffset;
  // Re-render hijri badge
  const badge = document.getElementById('hdr-hijri-en');
  if(badge) badge.innerHTML = '🌙 ' + toHijriArabic(new Date());
  showSettingsToast('Hijri offset: ' + (appSettings.hijriOffset>=0?'+':'') + appSettings.hijriOffset + ' day(s)');
}

function stepQuranGoal(dir) {
  appSettings.quranGoal = Math.max(1, Math.min(30, (appSettings.quranGoal||2) + dir));
  saveSettings();
  quranData.goal = appSettings.quranGoal;
  const el = document.getElementById('quran-goal-val');
  if(el) el.textContent = appSettings.quranGoal + ' pg';
  persistQuran();
  renderQuran();
  renderKPI();
}

async function toggleNotifications(on) {
  if(!('Notification' in window)) {
    showSettingsToast('Notifications not supported in this browser');
    const el = document.getElementById('notif-toggle');
    if(el) el.checked = false;
    return;
  }
  if(on) {
    const perm = await Notification.requestPermission();
    appSettings.notifications = perm === 'granted';
    if(perm !== 'granted') {
      showSettingsToast('Permission denied — enable in browser settings');
      const el = document.getElementById('notif-toggle');
      if(el) el.checked = false;
    } else {
      showSettingsToast('✓ Prayer reminders enabled');
    }
  } else {
    appSettings.notifications = false;
    showSettingsToast('Prayer reminders disabled');
  }
  saveSettings();
  renderSettingsView();
}

// ==============================================
// NEW SETTING ACTIONS
// ==============================================

// -- Display Extras -----------------------------
function toggleCompactMode(on) {
  appSettings.compactMode = on;
  applySettings(); saveSettings();
  showSettingsToast(on ? 'Compact mode on' : 'Compact mode off');
}
function toggleShowSeconds(on) {
  appSettings.showSeconds = on;
  saveSettings();
  showSettingsToast(on ? 'Seconds shown in clock' : 'Seconds hidden');
}
function toggleKpiLabels(on) {
  appSettings.kpiLabels = on;
  applySettings(); saveSettings();
  showSettingsToast(on ? 'KPI labels visible' : 'KPI labels hidden');
}
function setTheme(val, btn) {
  appSettings.theme = val;
  btn.closest('.st-pill-toggle').querySelectorAll('.spt').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  applySettings(); saveSettings();
  showSettingsToast(val === 'light' ? '☀️ Light theme applied' : '🌙 Dark theme applied');
}
function setCardRadius(val, btn) {
  appSettings.cardRadius = val;
  btn.closest('.st-pill-toggle').querySelectorAll('.spt').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  applySettings(); saveSettings();
}

// -- Habits ------------------------------------
function toggleSunnahReset(on) {
  appSettings.sunnahResetDaily = on;
  saveSettings();
  showSettingsToast(on ? 'Sunnah resets daily at midnight' : 'Sunnah does not auto-reset');
}
function toggleDhikrHaptic(on) {
  appSettings.dhikrHaptic = on;
  saveSettings();
  if(on && navigator.vibrate) navigator.vibrate(30);
  showSettingsToast(on ? '📳 Haptic feedback on' : 'Haptic feedback off');
}
function stepActivityGoal(dir) {
  appSettings.activityGoal = Math.max(1, Math.min(20, (appSettings.activityGoal||5) + dir));
  saveSettings();
  const el = document.getElementById('activity-goal-val');
  if(el) el.textContent = appSettings.activityGoal;
  showSettingsToast('Activity goal: ' + appSettings.activityGoal + ' per day');
}
function toggleFastingReminder(on) {
  appSettings.fastingReminder = on;
  saveSettings();
  showSettingsToast(on ? '🤍 Fasting reminder enabled' : 'Fasting reminder off');
}

// -- Privacy -----------------------------------
function togglePinLock(on) {
  if(on) {
    openSetPinModal();
  } else {
    appSettings.pinEnabled = false;
    try { localStorage.removeItem('mrd_pin'); } catch{}
    saveSettings(); renderSettingsView();
    showSettingsToast('PIN lock disabled');
  }
}
function openSetPinModal() {
  const pin = prompt('Set a 4-digit PIN:');
  if(pin === null) {
    const el = document.getElementById('pin-toggle'); if(el) el.checked = false; return;
  }
  if(!/^\d{4}$/.test(pin)) {
    showSettingsToast('PIN must be exactly 4 digits');
    const el = document.getElementById('pin-toggle'); if(el) el.checked = false; return;
  }
  const confirm2 = prompt('Confirm your PIN:');
  if(confirm2 !== pin) {
    showSettingsToast('PINs did not match — try again');
    const el = document.getElementById('pin-toggle'); if(el) el.checked = false; return;
  }
  try { localStorage.setItem('mrd_pin', btoa(pin)); } catch{}
  appSettings.pinEnabled = true;
  saveSettings(); renderSettingsView();
  showSettingsToast('✓ PIN set — app locked on next open');
}
function openChangePinModal() {
  let stored = '';
  try { stored = atob(localStorage.getItem('mrd_pin')||''); } catch{}
  const cur = prompt('Enter your current PIN:');
  if(cur === null) return;
  if(cur !== stored) { showSettingsToast('Incorrect PIN'); return; }
  openSetPinModal();
}
function checkPinLock() {
  if(!appSettings.pinEnabled) return;
  let stored = '';
  try { stored = atob(localStorage.getItem('mrd_pin')||''); } catch{}
  if(!stored) return;
  const overlay = document.createElement('div');
  overlay.id = 'pin-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;z-index:99999;background:var(--bg);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:20px;font-family:"Outfit",sans-serif';
  overlay.innerHTML = `
    <div style="font-size:32px">🔒</div>
    <div style="font-size:20px;font-family:\'Cormorant Garamond\',serif;color:var(--text)">Enter PIN</div>
    <input id="pin-input" type="password" inputmode="numeric" maxlength="4" placeholder="••••"
      style="width:120px;text-align:center;font-size:28px;letter-spacing:12px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.15);border-radius:14px;padding:12px 16px;color:var(--text);font-family:\'Outfit\',sans-serif;outline:none"
      oninput="if(this.value.length===4)_checkPin(this.value,'${stored}')">
    <div id="pin-err" style="font-size:12px;color:var(--rose);min-height:16px"></div>`;
  document.body.appendChild(overlay);
  setTimeout(()=>{ const i=document.getElementById('pin-input'); if(i) i.focus(); }, 100);
}
function _checkPin(entered, stored) {
  if(entered === stored) {
    const ov = document.getElementById('pin-overlay');
    if(ov) { ov.style.opacity='0'; ov.style.transition='opacity .3s'; setTimeout(()=>ov.remove(),300); }
  } else {
    const err = document.getElementById('pin-err');
    if(err) err.textContent = 'Incorrect PIN';
    const inp = document.getElementById('pin-input');
    if(inp) { inp.value=''; inp.focus(); }
  }
}
function toggleHideBg(on) {
  appSettings.hideBg = on;
  applySettings(); saveSettings();
  showSettingsToast(on ? '🫣 Content blurred when minimised' : 'Background hide off');
}
function _handleVisibilityBlur() {
  document.body.style.filter = document.hidden ? 'blur(20px)' : '';
}

// ── Sky animation pause/resume on visibility change ──
// Prevents cloud/star blink when returning to the app
(function _skyVisibilityGuard() {
  function _setSkyAnimState(state) {
    document.querySelectorAll('.sky-cloud, #sky-stars span').forEach(el => {
      el.style.animationPlayState = state;
    });
  }
  document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
      _setSkyAnimState('paused');
    } else {
      // Resume after a microtask so the browser finishes compositing first
      requestAnimationFrame(function() {
        requestAnimationFrame(function() {
          _setSkyAnimState('running');
        });
      });
    }
  });
})();

// -- Language & Names --------------------------
function setPrayerNameStyle(val, btn) {
  appSettings.prayerNameStyle = val;
  btn.closest('.st-pill-toggle').querySelectorAll('.spt').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  applySettings(); saveSettings(); renderSettingsView();
}
function toggleTranslit(on) {
  appSettings.showTranslit = on;
  applySettings(); saveSettings();
  showSettingsToast(on ? 'Transliteration shown' : 'Transliteration hidden');
}
function setDuaLang(val, btn) {
  appSettings.duaLang = val;
  btn.closest('.st-pill-toggle').querySelectorAll('.spt').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  applySettings(); saveSettings();
  showSettingsToast(val === 'arabic' ? 'Arabic only' : 'Arabic + translation');
}

// -- Storage helpers ----------------------------
function getStorageBytes() {
  let total = 0;
  try { for(let k in localStorage) { if(localStorage.hasOwnProperty(k)) total += (localStorage.getItem(k)||'').length*2; } } catch{}
  return total;
}
function formatBytes(b) {
  if(b < 1024) return b + ' B';
  if(b < 1024*1024) return (b/1024).toFixed(1) + ' KB';
  return (b/(1024*1024)).toFixed(2) + ' MB';
}
function getDaysTracked() {
  return Object.keys(daily).filter(k => {
    const d = daily[k];
    return d && ((d.acts&&d.acts.length)||d.fasting||(d.prayers&&Object.values(d.prayers).some(Boolean))||(d.noteText&&d.noteText.trim()));
  }).length;
}
function getLastSaved() {
  try {
    const ts = localStorage.getItem('mrd_last_save');
    if(ts) {
      const diff = Date.now() - new Date(ts).getTime();
      if(diff < 60000) return 'Just now';
      if(diff < 3600000) return Math.floor(diff/60000) + ' min ago';
      return new Date(ts).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
    }
  } catch{}
  return 'This session';
}
function stampLastSave() {
  try { localStorage.setItem('mrd_last_save', new Date().toISOString()); } catch{}
  const dot = document.getElementById('save-dot');
  if(dot) { dot.style.boxShadow='0 0 8px var(--teal-g)'; setTimeout(()=>dot.style.boxShadow='',800); }
}

function toggleAutoSave(on) {
  autoSaveEnabled = on;
  renderSettingsView();
  if(on) { persist(); stampLastSave(); }
}

// -- Export / Import ----------------------------
// ==============================================
// SMART BACKUP SYSTEM (username-aware)
// ==============================================




// -- Danger zone --------------------------------

// ══════════════════════════════════════════════
// SMART BACKUP SYSTEM
// ══════════════════════════════════════════════

function buildBackupObject() {
  const acc  = loadAccount();
  const name = (acc && acc.name) ? acc.name.toLowerCase().replace(/[^a-z0-9]/g,'_').slice(0,20) : 'backup';
  const backup = { exportedAt: new Date().toISOString(), version: 'mrd4', name: acc?.name || '', data: {} };
  ALL_STORAGE_KEYS.forEach(function(item) {
    const v = localStorage.getItem(item.key);
    if(v) { try { backup.data[item.key] = JSON.parse(v); } catch(e) { backup.data[item.key] = v; } }
  });
  // Also include health tracker data
  const health = localStorage.getItem('mrd_health');
  if(health) { try { backup.data['mrd_health'] = JSON.parse(health); } catch(e) {} }
  return { backup, name };
}

function getBackupFilename(name) {
  return 'meridian_' + name + '_' + dateKey(now) + '.json';
}

async function copyBackupToClipboard() {
  try {
    const { backup } = buildBackupObject();
    const json = JSON.stringify(backup, null, 2);
    const ok = await _copyToClipboard(json);
    showSettingsToast(ok ? '✓ Backup copied to clipboard' : '✗ Could not copy — try Restore from Text');
  } catch(e) {
    showSettingsToast('Copy failed: ' + e.message);
  }
}

async function _copyToClipboard(text) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    try { await navigator.clipboard.writeText(text); return true; } catch(e) {}
  }
  try {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;width:1px;height:1px';
    document.body.appendChild(ta);
    ta.focus(); ta.select();
    const ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch(e) { return false; }
}

function openPasteRestore() {
  document.getElementById('paste-restore-area').value = '';
  document.getElementById('paste-restore-info').textContent = '';
  document.getElementById('paste-restore-ovl').classList.add('open');
  setTimeout(() => document.getElementById('paste-restore-area').focus(), 350);
}

function closePasteRestoreOvl(e) {
  if(e.target === document.getElementById('paste-restore-ovl') || e.target.classList.contains('ovl-bg'))
    document.getElementById('paste-restore-ovl').classList.remove('open');
}

document.addEventListener('DOMContentLoaded', function() {
  const ta = document.getElementById('paste-restore-area');
  if(ta) ta.addEventListener('input', function() {
    const info = document.getElementById('paste-restore-info');
    if(!info) return;
    try {
      const b = JSON.parse(ta.value.trim());
      if(!b || !b.data) { info.textContent = '⚠ Not a valid backup'; info.style.color='var(--rose)'; return; }
      const days = b.data['mrd4_daily'] ? Object.keys(b.data['mrd4_daily']).length : '?';
      const date = b.exportedAt ? new Date(b.exportedAt).toLocaleString() : 'unknown date';
      const who  = b.name ? ' · ' + b.name : '';
      info.textContent = '✓ Valid — ' + days + ' days' + who + ' · ' + date;
      info.style.color = 'var(--green)';
    } catch(e) {
      if(ta.value.trim().length > 10) { info.textContent = '⚠ Not valid JSON'; info.style.color='var(--rose)'; }
      else { info.textContent = ''; }
    }
  });
});

function executePasteRestore() {
  const ta = document.getElementById('paste-restore-area');
  try {
    const backup = JSON.parse(ta.value.trim());
    if(!backup || !backup.data) throw new Error('Invalid');
    const date = backup.exportedAt ? new Date(backup.exportedAt).toLocaleDateString() : 'unknown date';
    const days = backup.data['mrd4_daily'] ? Object.keys(backup.data['mrd4_daily']).length : '?';
    const who  = backup.name ? ' (' + backup.name + ')' : '';
    if(!confirm('Restore backup from ' + date + who + '?\n' + days + ' days of data.\n\nThis will overwrite your current data.')) return;
    Object.entries(backup.data).forEach(function([k, v]) {
      try { localStorage.setItem(k, JSON.stringify(v)); } catch(e) {}
    });
    showSettingsToast('Restored — reloading...');
    setTimeout(function() { location.reload(); }, 1200);
  } catch(e) {
    showSettingsToast('Invalid backup — check the text and try again');
  }
}


function importData(evt) {
  const file = evt.target.files && evt.target.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const backup = JSON.parse(e.target.result);
      if(!backup || !backup.data) throw new Error('Invalid');
      const date = backup.exportedAt ? new Date(backup.exportedAt).toLocaleDateString() : 'unknown date';
      const days = backup.data['mrd4_daily'] ? Object.keys(backup.data['mrd4_daily']).length : '?';
      const who  = backup.name ? ' (' + backup.name + ')' : '';
      if(!confirm('Restore backup from ' + date + who + '?\n' + days + ' days of data.\n\nThis will overwrite your current data.')) return;
      Object.entries(backup.data).forEach(function([k, v]) {
        try { localStorage.setItem(k, JSON.stringify(v)); } catch(e) {}
      });
      showSettingsToast('Restored — reloading...');
      setTimeout(function() { location.reload(); }, 1200);
    } catch(e) { showSettingsToast('Invalid backup file'); }
  };
  reader.readAsText(file);
  evt.target.value = '';
}

// Update backup info in settings view
function updateBackupInfo() {
  const bytes = getStorageBytes ? getStorageBytes() : 0;
  const daysT = getDaysTracked ? getDaysTracked() : 0;
  const lbl = document.getElementById('backup-size-lbl');
  const badge = document.getElementById('backup-days-badge');
  if(lbl)   lbl.textContent   = (bytes > 0 ? formatBytes(bytes) : '—') + ' stored · auto-saved';
  if(badge) badge.textContent = daysT + (daysT === 1 ? ' day' : ' days');
}

function clearTodayData() {
  if(!confirm(`Clear today's data (${TODAY_KEY})?\n\nToday's activities, prayers, fasting, dhikr, Quran, sunnah and note will be reset.`)) return;

  // 1. Reset all in-memory state for today
  viewingDate  = TODAY_KEY;
  noteViewDate = TODAY_KEY;

  // 2. Wipe today from unified store
  delete daily[TODAY_KEY];
  delete dayActs[TODAY_KEY];

  // 3. Reset all live state variables to clean defaults
  prayerDone  = {Fajr:false, Dhuhr:false, Asr:false, Maghrib:false, Isha:false};
  dhikrCounts = getDhikrList().map(()=>0);
  sunnahDone  = getSunnahList().map(()=>false);
  fastingData[TODAY_KEY] = false;
  quranData   = {pages:0, goal:appSettings.quranGoal||604};

  // 4. Persist clean state to localStorage
  try{localStorage.setItem('mrd4_daily', JSON.stringify(daily));}catch{}
  try{localStorage.setItem('mrd3_dayacts', JSON.stringify(dayActs));}catch{}
  try{localStorage.setItem('mrd3_fasting', JSON.stringify(fastingData));}catch{}
  try{localStorage.setItem('mrd3_quran', JSON.stringify(quranData));}catch{}
  try{localStorage.removeItem('mrd3_pdone');}catch{}
  try{localStorage.removeItem('mrd3_dhikr');}catch{}
  try{localStorage.removeItem('mrd3_sunnah');}catch{}

  // 5. Re-render every widget safely
  try{renderPrayers();}catch(e){}
  try{renderKPI();}catch(e){}
  try{renderDhikrTabs();}catch(e){}
  try{renderDhikrCard();}catch(e){}
  try{renderFasting();}catch(e){}
  try{renderQuran();}catch(e){}
  try{renderSunnah();}catch(e){}
  try{renderNoteCard();}catch(e){}
  try{renderList();}catch(e){}
  try{renderDateStrip();}catch(e){}
  try{renderViewingBanner();}catch(e){}
  try{renderStats();}catch(e){}
  try{renderSettingsView();}catch(e){}

  showSettingsToast('✓ Today cleared — fresh start!');
}

function clearAllData() {
  // Hidden safety function - removed from UI but kept in case needed via export/import recovery
  // Reloads the page after clearing so the app fully re-initialises from scratch
  if(!confirm('⚠️ Reset ALL Toukir\'s Flow data?\n\nThis cannot be undone.')) return;
  if(!confirm('Last chance: everything will be permanently erased.')) return;
  ALL_STORAGE_KEYS.forEach(item=>{try{localStorage.removeItem(item.key);}catch{}});
  try{localStorage.removeItem('mrd_last_save');}catch{}
  // Reload immediately so the app boots fresh from empty storage
  location.reload();
}

// -- Toast --------------------------------------
function showSettingsToast(msg) {
  let t = document.getElementById('settings-toast');
  if(!t) {
    t = document.createElement('div'); t.id='settings-toast';
    t.style.cssText=`position:fixed;bottom:calc(100px + env(safe-area-inset-bottom));left:50%;transform:translateX(-50%) translateY(12px);background:rgba(8,9,12,.92);border:1px solid var(--bd-hi);backdrop-filter:blur(20px);color:var(--text);font-family:'Manrope',sans-serif;font-size:13px;padding:10px 20px;border-radius:99px;z-index:9999;opacity:0;transition:all .28s cubic-bezier(.34,1.56,.64,1);white-space:nowrap;pointer-events:none;box-shadow:0 8px 32px rgba(0,0,0,.4)`;
    document.body.appendChild(t);
  }
  t.textContent=msg;
  requestAnimationFrame(()=>{ t.style.opacity='1'; t.style.transform='translateX(-50%) translateY(0)'; });
  clearTimeout(t._timer);
  t._timer=setTimeout(()=>{ t.style.opacity='0'; t.style.transform='translateX(-50%) translateY(8px)'; },2400);
}
function showToast(msg){ showSettingsToast(msg); }

// ==============================================
// EXPAND / COLLAPSE SECTIONS
// ==============================================
// EXPAND_KEY and EXPAND_DEFAULTS hoisted to top of script

function loadExpandState() {
  try { return Object.assign({}, EXPAND_DEFAULTS, JSON.parse(localStorage.getItem(EXPAND_KEY)||'{}')); }
  catch { return {...EXPAND_DEFAULTS}; }
}
function saveExpandState(state) {
  try { localStorage.setItem(EXPAND_KEY, JSON.stringify(state)); } catch {}
}

function toggleExpand(id) {
  const sec = document.getElementById(id);
  if(!sec) return;
  const isOpen = sec.classList.toggle('open');
  const state  = loadExpandState();
  state[id]    = isOpen;
  saveExpandState(state);
  if(id === 'exp-qibla' && isOpen) setTimeout(initQibla, 100);
  if(id === 'exp-asma'  && isOpen) setTimeout(renderAsmaGrid, 0);
}

function applyExpandState() {
  const state = loadExpandState();
  Object.entries(state).forEach(([id, open]) => {
    const sec = document.getElementById(id);
    if(!sec) return;
    sec.classList.toggle('open', !!open);
    if(id === 'exp-asma' && open) renderAsmaGrid();
    if(id === 'exp-qibla' && open) setTimeout(initQibla, 100);
  });
}

// ==============================================
// ACCOUNT / ONBOARDING
// ==============================================
// ACCOUNT_KEY and OB_EMOJIS hoisted to top

function loadAccount() {
  try { return JSON.parse(localStorage.getItem(ACCOUNT_KEY) || 'null'); } catch { return null; }
}
function saveAccount(acc) {
  localStorage.setItem(ACCOUNT_KEY, JSON.stringify(acc));
}

// ── Update all app title occurrences with the user's name ─────────
function fitAppTitle(){
  const el = document.getElementById('hdr-app-title');
  if(!el) return;

  const titleWrap = el.parentElement;
  const headerRow = titleWrap && titleWrap.parentElement;
  const sideWrap = headerRow && headerRow.lastElementChild;

  const titleText = (el.textContent || '').trim();
  const isLong = titleText.length > 14;

  if(headerRow && sideWrap){
    if(isLong){
      headerRow.style.display = 'block';
      sideWrap.style.marginTop = '10px';
      sideWrap.style.alignItems = 'flex-start';
    } else {
      headerRow.style.display = 'flex';
      sideWrap.style.marginTop = '';
      sideWrap.style.alignItems = 'flex-end';
    }
  }

  el.style.whiteSpace = 'nowrap';
  el.style.maxWidth = '100%';
  el.style.overflow = 'visible';
  el.style.textOverflow = 'clip';

  let size = Math.min(window.innerWidth * 0.14, 52); // px
  const minSize = 20; // px
  el.style.fontSize = size + 'px';

  const available = Math.max(120, Math.floor((titleWrap ? titleWrap.clientWidth : el.parentElement.clientWidth || el.clientWidth) - 2));

  while(el.scrollWidth > available && size > minSize){
    size -= 1;
    el.style.fontSize = size + 'px';
  }
}
function updateAppTitle(name) {
  const display = name && name.trim() ? name.trim() + "'s Flow" : "Toukir's Flow";
  const firstName = name && name.trim() ? name.trim().split(/\s+/)[0] : '';
  // Main home header
  const titleEl = document.getElementById('hdr-app-title');
  if(titleEl) titleEl.textContent = firstName ? `Assalamu Alaikum, ${firstName}` : 'Assalamu Alaikum';
  const badgeEl = document.getElementById('hdr-name-badge');
  const badgeTxt = document.getElementById('hdr-name-badge-text');
  if(badgeEl && badgeTxt){
    badgeTxt.textContent = '';
    badgeEl.classList.remove('show');
    badgeEl.style.display = 'none';
  }
  fitAppTitle();
  // Settings header eye label
  const settingsEye = document.getElementById('settings-hdr-eye');
  if(settingsEye) settingsEye.textContent = display;
  // PWA share-sheet label
  const srLabel = document.querySelector('.sr-label');
  // (intentionally skip sr-label — it's a generic settings row label)
}
window.addEventListener('resize', fitAppTitle);

// obSelectedEmoji and obCurrentStep hoisted to top

// ── Onboarding state ────────────────────────────────────────────
let _obGoals = { quran: 2, acts: 5, fastReminder: false, lang: 'en' };
let _obLat = null, _obLng = null, _obMethodVal = 2;

function obInit() {
  const acc = loadAccount();
  if(!acc) {
    const s = document.getElementById('onboarding-screen');
    if(s) { s.style.display = 'flex'; }
    obRenderEmojiRow();
    obGoStep(0);
  } else {
    updateProfileBtn(acc);
    updateAppTitle(acc.name);
  }
}

function obRenderEmojiRow() {
  const row = document.getElementById('ob-emoji-row');
  if(!row) return;
  row.innerHTML = OB_EMOJIS.map(e =>
    `<button class="ob-emoji-btn${e===obSelectedEmoji?' sel':''}" onclick="obPickEmoji('${e}')">${e}</button>`
  ).join('');
}

function obPickEmoji(e) {
  obSelectedEmoji = e;
  obRenderEmojiRow();
}

function obValidateStep0() {
  const name = (document.getElementById('ob-name-input')?.value || '').trim();
  const btn  = document.getElementById('ob-btn-0');
  if(btn) btn.disabled = name.length < 2;
}

function obGoStep(n) {
  const steps = document.querySelectorAll('.ob-step');
  const dots  = document.querySelectorAll('.ob-dot');
  steps.forEach((s,i) => s.classList.toggle('active', i === n));
  dots.forEach((d,i) => d.classList.toggle('active', i === n));
  obCurrentStep = n;
}

function obNext(step) {
  if(step === 1) {
    // Name step — validate and go to location
    const name = (document.getElementById('ob-name-input')?.value || '').trim();
    if(name.length < 2) return;
    obGoStep(2);
  } else if(step === 2) {
    // Save location if entered, go to goals
    const latEl = document.getElementById('ob-lat');
    const lngEl = document.getElementById('ob-lng');
    const methEl = document.getElementById('ob-method');
    if(latEl?.value && lngEl?.value) {
      _obLat = parseFloat(latEl.value);
      _obLng = parseFloat(lngEl.value);
    }
    if(methEl) _obMethodVal = parseInt(methEl.value) || 2;
    obGoStep(3);
  } else if(step === 3) {
    // Goals done — build confirm preview then go to step 4
    _obBuildConfirmPreview();
    obGoStep(4);
  }
}

function _obBuildConfirmPreview() {
  const name    = (document.getElementById('ob-name-input')?.value || '').trim();
  const initial = name.charAt(0).toUpperCase();
  const preview = document.getElementById('ob-preview-row');
  if(preview) {
    preview.innerHTML = `
      <div class="ob-profile-avatar">${obSelectedEmoji || initial}</div>
      <div class="ob-profile-info">
        <div class="ob-profile-name">${name}</div>
        <div class="ob-profile-joined">Joined ${new Date().toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'})}</div>
      </div>`;
  }
  // Build summary
  const summary = document.getElementById('ob-summary');
  if(summary) {
    const locStr = (_obLat && _obLng)
      ? `${_obLat.toFixed(2)}°, ${_obLng.toFixed(2)}° set`
      : 'Manual setup (Settings → Prayer)';
    const methodNames = {1:'Karachi',2:'ISNA',3:'MWL',4:'Umm Al-Qura',5:'Egyptian'};
    const cloudRow = _supaUser
      ? { icon:'☁️', label: `Cloud: ${_supaUser.email}` }
      : { icon:'☁️', label: 'Cloud: Local only' };
    summary.innerHTML = [
      { icon:'📍', label: 'Location: ' + locStr },
      { icon:'🕌', label: 'Method: ' + (methodNames[_obMethodVal] || 'ISNA') },
      { icon:'📖', label: `Quran goal: ${_obGoals.quran} page${_obGoals.quran!==1?'s':''}/day` },
      { icon:'✅', label: `Activity goal: ${_obGoals.acts} per day` },
      { icon:'🌐', label: `Language: ${_obGoals.lang === 'bn' ? 'বাংলা' : 'English'}` },
      cloudRow,
    ].map(r => `
      <div class="ob-sum-row">
        <span>${r.icon}</span>
        <span>${r.label}</span>
        <span class="ob-sum-check">✓</span>
      </div>`).join('');
  }
}

// ── Location detection ───────────────────────────────────────────
function obDetectLocation() {
  const btn = document.getElementById('ob-loc-btn');
  const txt = document.getElementById('ob-loc-btn-text');
  const ico = document.getElementById('ob-loc-btn-icon');
  const res = document.getElementById('ob-loc-result');
  if(!navigator.geolocation) { res.textContent = '⚠ Geolocation not supported on this device'; res.style.color='var(--rose)'; return; }
  if(btn) btn.classList.add('loading');
  if(txt) txt.textContent = 'Detecting…';
  if(ico) ico.textContent = '⏳';
  navigator.geolocation.getCurrentPosition(
    pos => {
      _obLat = parseFloat(pos.coords.latitude.toFixed(4));
      _obLng = parseFloat(pos.coords.longitude.toFixed(4));
      const latEl = document.getElementById('ob-lat');
      const lngEl = document.getElementById('ob-lng');
      if(latEl) latEl.value = _obLat;
      if(lngEl) lngEl.value = _obLng;
      if(btn) { btn.classList.remove('loading'); btn.classList.add('success'); }
      if(txt) txt.textContent = 'Location detected ✓';
      if(ico) ico.textContent = '✅';
      if(res) { res.textContent = `📍 ${_obLat}°, ${_obLng}°`; res.style.color = 'var(--green)'; }
    },
    err => {
      if(btn) btn.classList.remove('loading');
      if(txt) txt.textContent = 'Use My Location';
      if(ico) ico.textContent = '📍';
      if(res) { res.textContent = '⚠ Permission denied — enter manually below'; res.style.color = 'var(--rose)'; }
    },
    { timeout: 8000, maximumAge: 60000 }
  );
}

function obClearLocResult() {
  _obLat = null; _obLng = null;
  const btn = document.getElementById('ob-loc-btn');
  const txt = document.getElementById('ob-loc-btn-text');
  const ico = document.getElementById('ob-loc-btn-icon');
  if(btn) { btn.classList.remove('success','loading'); }
  if(txt) txt.textContent = 'Use My Location';
  if(ico) ico.textContent = '📍';
}

// ── Goal steppers ────────────────────────────────────────────────
const _OB_QURAN_STEPS = [1,2,3,4,5,10,20,30,100,200,604];
let _obQuranIdx = 1; // default: 2 pages
function obAdjGoal(key, dir) {
  if(key === 'quran') {
    _obQuranIdx = Math.max(0, Math.min(_OB_QURAN_STEPS.length-1, _obQuranIdx + dir));
    _obGoals.quran = _OB_QURAN_STEPS[_obQuranIdx];
    const el = document.getElementById('ob-goal-quran');
    if(el) el.textContent = _obGoals.quran === 604 ? '604 (Full)' : _obGoals.quran;
  } else if(key === 'acts') {
    _obGoals.acts = Math.max(1, Math.min(20, _obGoals.acts + dir));
    const el = document.getElementById('ob-goal-acts');
    if(el) el.textContent = _obGoals.acts;
  }
}

function obToggleFastReminder() {
  _obGoals.fastReminder = !_obGoals.fastReminder;
  const tw = document.getElementById('ob-fast-toggle');
  if(tw) tw.classList.toggle('on', _obGoals.fastReminder);
}

function obSetLang(lang, btn) {
  _obGoals.lang = lang;
  document.querySelectorAll('.ob-lang-pill').forEach(b => b.classList.remove('active'));
  if(btn) btn.classList.add('active');
}

// ── Cloud auth in onboarding ────────────────────────────────────
let _obAuthMode = 'signin'; // 'signin' | 'signup'

function obAuthTab(mode) {
  _obAuthMode = mode;
  const si = document.getElementById('ob-tab-signin');
  const su = document.getElementById('ob-tab-signup');
  const btn = document.getElementById('ob-cloud-btn');
  const pass = document.getElementById('ob-cloud-pass');
  const activeStyle = 'rgba(var(--accent-rgb),.2)';
  const inactiveStyle = 'transparent';
  const activeColor = 'var(--gold)';
  const inactiveColor = 'var(--t3)';
  if (si) { si.style.background = mode === 'signin' ? activeStyle : inactiveStyle; si.style.color = mode === 'signin' ? activeColor : inactiveColor; }
  if (su) { su.style.background = mode === 'signup' ? activeStyle : inactiveStyle; su.style.color = mode === 'signup' ? activeColor : inactiveColor; }
  if (btn) btn.textContent = mode === 'signin' ? 'Sign In & Sync ☁️' : 'Create Account & Sync ☁️';
  if (pass) pass.setAttribute('autocomplete', mode === 'signin' ? 'current-password' : 'new-password');
  const errEl = document.getElementById('ob-cloud-err');
  if (errEl) errEl.textContent = '';
}

async function obCloudAuth() {
  const email = (document.getElementById('ob-cloud-email')?.value || '').trim();
  const pass  = document.getElementById('ob-cloud-pass')?.value || '';
  const errEl = document.getElementById('ob-cloud-err');
  const btn   = document.getElementById('ob-cloud-btn');
  if (!email || !pass) { if(errEl) errEl.textContent = 'Email ও password দিন'; return; }
  if (!_supa) { if(errEl) errEl.textContent = '⚠ Cloud unavailable — skip করুন'; return; }
  if (btn) { btn.textContent = '⏳ Please wait…'; btn.style.opacity = '.7'; btn.disabled = true; }
  if (errEl) errEl.textContent = '';
  try {
    if (_obAuthMode === 'signup') {
      const { error } = await _supa.auth.signUp({ email, password: pass });
      if (error) throw error;
      // After signup, sign in immediately so session is active
      const { error: siErr } = await _supa.auth.signInWithPassword({ email, password: pass });
      if (siErr) throw siErr;
      await supaGetSession();
      if (btn) { btn.textContent = '✓ Account Created!'; btn.style.opacity = '1'; btn.style.background = 'linear-gradient(135deg,rgba(var(--green-rgb),.8),rgba(var(--green-rgb),.5))'; btn.style.color = '#08090c'; }
      if (errEl) { errEl.style.color = 'var(--green)'; errEl.textContent = `✓ Account created for ${email}`; }
      // New signup — go to name/profile step next
      setTimeout(() => { obGoStep(1); }, 900);
    } else {
      // Sign In — try to restore existing profile from cloud
      const { error } = await _supa.auth.signInWithPassword({ email, password: pass });
      if (error) throw error;
      await supaGetSession();
      if (btn) { btn.textContent = '⏳ Restoring…'; }
      // Pull profile from Supabase
      const restoredAcc = await supaPullProfile();
      if (restoredAcc && restoredAcc.name) {
        // Existing account found — restore and skip onboarding
        _supaInitSyncDone = true;
        updateProfileBtn(restoredAcc);
        updateAppTitle(restoredAcc.name);
        if (btn) { btn.textContent = '✓ Welcome back!'; btn.style.opacity = '1'; btn.style.background = 'linear-gradient(135deg,rgba(var(--green-rgb),.8),rgba(var(--green-rgb),.5))'; btn.style.color = '#08090c'; }
        if (errEl) { errEl.style.color = 'var(--green)'; errEl.textContent = `✓ Signed in as ${email}`; }
        // Dismiss onboarding after short delay
        setTimeout(() => {
          const s = document.getElementById('onboarding-screen');
          if (s) {
            s.style.transition = 'opacity .5s, transform .5s';
            s.style.opacity    = '0';
            s.style.transform  = 'scale(.97)';
            setTimeout(() => { s.style.display='none'; s.style.transition=s.style.opacity=s.style.transform=''; }, 500);
          }
          supaFullSync();
        }, 800);
      } else {
        // No profile in cloud yet — continue onboarding normally from name step
        if (btn) { btn.textContent = '✓ Synced!'; btn.style.opacity = '1'; btn.style.background = 'linear-gradient(135deg,rgba(var(--green-rgb),.8),rgba(var(--green-rgb),.5))'; btn.style.color = '#08090c'; }
        if (errEl) { errEl.style.color = 'var(--green)'; errEl.textContent = `✓ Logged in as ${email}`; }
        setTimeout(() => { obGoStep(1); }, 900);
      }
    }
  } catch(e) {
    if (btn) { btn.textContent = _obAuthMode === 'signin' ? 'Sign In & Sync ☁️' : 'Create Account & Sync ☁️'; btn.style.opacity = '1'; btn.disabled = false; }
    const msg = e.message || 'Something went wrong';
    if (errEl) { errEl.style.color = 'var(--rose)'; errEl.textContent = msg.includes('Invalid') ? '⚠ Wrong email or password' : msg.includes('already') ? '⚠ Account exists — try Sign In' : '⚠ ' + msg; }
  }
}

// ── Finish ───────────────────────────────────────────────────────
function obFinish() {
  const name = (document.getElementById('ob-name-input')?.value || '').trim();
  const acc  = {
    name,
    avatar:  obSelectedEmoji,
    joined:  new Date().toISOString(),
    initial: name.charAt(0).toUpperCase()
  };
  saveAccount(acc);
  updateProfileBtn(acc);
  updateAppTitle(acc.name);

  // Apply prayer location
  if(_obLat && _obLng) {
    try {
      const existing = JSON.parse(localStorage.getItem('mrd3_prayers') || '{}');
      existing.lat    = _obLat;
      existing.lng    = _obLng;
      existing.method = _obMethodVal;
      localStorage.setItem('mrd3_prayers', JSON.stringify(existing));
    } catch(e) {}
  }

  // Apply goals & preferences into settings
  appSettings.quranGoal       = _obGoals.quran;
  appSettings.activityGoal    = _obGoals.acts;
  appSettings.fastingReminder = _obGoals.fastReminder;
  appSettings.language        = _obGoals.lang;
  appSettings.prayerMethod    = _obMethodVal;
  saveSettings();
  _lang = _obGoals.lang;

  // Re-calc prayer times with new location
  try { if(typeof renderPrayers === 'function') renderPrayers(); } catch(e) {}
  try { if(typeof applyLanguage === 'function') applyLanguage(); } catch(e) {}

  // If user signed in during onboarding, push profile + all data to cloud
  if (_supaUser) {
    _supaInitSyncDone = true; // prevent double-sync from auth listener
    try { supaPushProfile(acc); } catch(e) {} // save profile info to Supabase
    try { supaFullSync(); } catch(e) {}
  }

  // Dismiss onboarding
  const s = document.getElementById('onboarding-screen');
  if(s) {
    s.style.transition = 'opacity .5s, transform .5s';
    s.style.opacity    = '0';
    s.style.transform  = 'scale(.97)';
    setTimeout(() => { s.style.display='none'; s.style.transition=s.style.opacity=s.style.transform=''; }, 500);
  }

  // Personalised welcome
  const hs = document.getElementById('hdr-s');
  if(hs) hs.textContent = t('Plan your day with focus and barakah.');

  // Recalculate quran goal
  quranData.goal = _obGoals.quran;
  try { renderQuran(); renderKPI(); } catch(e) {}
}

function updateProfileBtn(acc) {
  const btn = document.getElementById('hdr-profile-btn');
  if(!btn || !acc) return;
  if(acc.photo) {
    btn.innerHTML = `<img src="${acc.photo}" alt="${acc.name}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;display:block">`;
    btn.style.padding = '0';
    btn.style.background = 'transparent';
  } else {
    btn.innerHTML = '';
    btn.textContent = acc.avatar || acc.initial || '?';
    btn.style.padding = '';
    btn.style.background = '';
  }
  btn.title = acc.name;
}

function openProfileModal() {
  const acc = loadAccount();
  if(!acc) { obInit(); return; }

  // ── Identity ──────────────────────────────────────────────
  const avatarEl = document.getElementById('pm-avatar');
  if(avatarEl) {
    if(acc.photo) {
      avatarEl.innerHTML = `<img src="${acc.photo}" alt="${acc.name}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;display:block">`;
    } else {
      avatarEl.innerHTML = '';
      avatarEl.textContent = acc.avatar || acc.initial || '?';
    }
  }
  document.getElementById('pm-name').textContent   = acc.name;
  const joined = acc.joined ? new Date(acc.joined).toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'}) : '';
  document.getElementById('pm-joined').textContent = joined ? `Joined ${joined}` : '';

  // ── Aggregate stats ───────────────────────────────────────
  const allKeys   = Object.keys(daily);
  const days      = allKeys.length;
  const prayers   = allKeys.reduce((t,k) => t + (daily[k].prayers ? Object.values(daily[k].prayers).filter(Boolean).length : 0), 0);
  const acts      = allKeys.reduce((t,k) => t + (daily[k].acts ? daily[k].acts.filter(a=>a.done).length : 0), 0);
  const fastDays  = allKeys.filter(k => daily[k].fasting).length;
  const quranTotal= allKeys.reduce((t,k) => t + (daily[k].quranPages || 0), 0);

  // ── Streak ────────────────────────────────────────────────
  const streak = calcAllFivePrayerStreak();

  // ── Today score + breakdown ───────────────────────────────
  const score     = calcDayScore(TODAY_KEY);
  const breakdown = calcDayBreakdown(TODAY_KEY);
  const CATS = [
    { key:'prayer',  label:'Salah',    col:'#d4a853', icon:'🕌' },
    { key:'acts',    label:'Acts',     col:'var(--teal)', icon:'✅' },
    { key:'sunnah',  label:'Sunnah',   col:'var(--purple)', icon:'🌙' },
    { key:'dhikr',   label:'Dhikr',    col:'var(--green)', icon:'📿' },
    { key:'quran',   label:'Quran',    col:'var(--rose)', icon:'📖' },
    { key:'fasting', label:'Fast',     col:'var(--accent-6)', icon:'💧' },
  ];
  const scoreColor = score >= 80 ? 'var(--teal)' : score >= 50 ? 'var(--gold)' : 'var(--rose)';

  document.getElementById('pm-score-num').textContent = score + '%';
  document.getElementById('pm-score-num').style.color = scoreColor;

  // Stacked bar
  let barHtml = ''; let leftPct = 0;
  CATS.forEach(c => {
    const pct = (breakdown[c.key] || 0);
    if(pct <= 0) return;
    const w = pct / 100 * score / 100 * 100; // proportional share
    barHtml += `<div style="position:absolute;top:0;left:${leftPct}%;width:${Math.min(pct,100-leftPct)}%;height:100%;background:${c.col};border-radius:99px"></div>`;
    leftPct += pct;
  });
  document.getElementById('pm-score-bar').style.position = 'relative';
  document.getElementById('pm-score-bar').innerHTML = barHtml;

  // Category pills
  document.getElementById('pm-score-cats').innerHTML = CATS.map(c => {
    const pct = Math.round(breakdown[c.key] || 0);
    if(pct === 0) return '';
    return `<div style="display:flex;align-items:center;gap:3px;padding:3px 8px;border-radius:99px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.09)">
      <span style="font-size:0.5625rem">${c.icon}</span>
      <span style="font-size:0.4375rem;color:${c.col};font-weight:700;letter-spacing:.04em">${pct}%</span>
    </div>`;
  }).join('');

  // ── Level badge ───────────────────────────────────────────
  const LEVELS = [
    { min:0,   label:'Beginner',   icon:'🌱', col:'#9ca3af', bg:'rgba(156,163,175,.12)', bd:'rgba(156,163,175,.25)' },
    { min:7,   label:'Consistent', icon:'📿', col:'#d4a853', bg:'rgba(var(--accent-rgb),.12)',  bd:'rgba(var(--accent-rgb),.3)'   },
    { min:30,  label:'Devoted',    icon:'🕌', col:'var(--teal)', bg:'rgba(var(--teal-rgb),.12)',  bd:'rgba(var(--teal-rgb),.3)'   },
    { min:90,  label:'Steadfast',  icon:'⭐', col:'var(--purple)', bg:'rgba(var(--purple-rgb),.12)', bd:'rgba(var(--purple-rgb),.3)'  },
    { min:180, label:'Scholar',    icon:'📖', col:'var(--accent-3)', bg:'rgba(232,196,122,.12)', bd:'rgba(232,196,122,.3)'  },
    { min:365, label:'Guardian',   icon:'🌟', col:'var(--amber)', bg:'rgba(var(--amber-rgb),.14)',  bd:'rgba(var(--amber-rgb),.35)'  },
  ];
  const lvl = [...LEVELS].reverse().find(l => days >= l.min) || LEVELS[0];
  const badge = document.getElementById('pm-level-badge');
  if(badge) {
    badge.style.cssText += `;background:${lvl.bg};border:1px solid ${lvl.bd};color:${lvl.col}`;
    badge.innerHTML = `<span>${lvl.icon}</span><span style="font-size:0.5rem">${lvl.label}</span>`;
  }

  // ── Streak ring color ─────────────────────────────────────
  const ring = document.getElementById('pm-streak-ring');
  if(ring) {
    ring.style.borderColor = streak >= 7 ? 'rgba(var(--amber-rgb),.7)' : streak >= 3 ? 'rgba(var(--accent-rgb),.5)' : streak >= 1 ? 'rgba(var(--teal-rgb),.4)' : 'transparent';
    ring.style.boxShadow   = streak >= 3 ? `0 0 12px rgba(var(--amber-rgb),.25)` : '';
  }

  // ── 4-stat grid ───────────────────────────────────────────
  document.getElementById('pm-stats').innerHTML = [
    { val: days,    lbl: 'Days',     icon: '📅', col: 'var(--teal)' },
    { val: prayers, lbl: 'Prayers',  icon: '🕌', col: 'var(--gold)' },
    { val: acts,    lbl: 'Acts',     icon: '✅', col: 'var(--green)' },
    { val: fastDays,lbl: 'Fasts',    icon: '💧', col: 'var(--teal)' },
  ].map(s => `
    <div class="pm-stat">
      <div style="font-size:0.875rem;margin-bottom:3px">${s.icon}</div>
      <div class="pm-stat-val" style="color:${s.col};font-size:1.25rem">${s.val}</div>
      <div class="pm-stat-lbl">${s.lbl}</div>
    </div>`).join('');

  // ── Streak + Quran insight cards ──────────────────────────
  const streakIcon  = streak >= 7 ? '🔥' : streak >= 3 ? '✨' : streak >= 1 ? '⚡' : '—';
  const streakColor = streak >= 7 ? 'var(--amber)' : streak >= 3 ? 'var(--gold)' : streak >= 1 ? 'var(--teal)' : 'var(--t3)';
  document.getElementById('pm-insights').innerHTML = `
    <div class="pm-insight-card" style="border-color:${streak>0?'rgba(var(--accent-rgb),.2)':'rgba(255,255,255,.08)'}">
      <div class="pm-insight-val" style="color:${streakColor}">${streakIcon} ${streak}<span style="font-size:0.625rem;margin-left:2px;opacity:.7">d</span></div>
      <div class="pm-insight-lbl">Prayer Streak</div>
    </div>
    <div class="pm-insight-card" style="border-color:rgba(var(--rose-rgb),.2)">
      <div class="pm-insight-val" style="color:var(--rose)">${quranTotal}<span style="font-size:0.625rem;margin-left:2px;opacity:.7">pg</span></div>
      <div class="pm-insight-lbl">Quran Read</div>
    </div>
    <div class="pm-insight-card" style="border-color:rgba(var(--teal-rgb),.2)">
      <div class="pm-insight-val" style="color:var(--teal)">${days > 0 ? Math.round(prayers/days*10)/10 : 0}<span style="font-size:0.625rem;margin-left:2px;opacity:.7">avg</span></div>
      <div class="pm-insight-lbl">Prayers/Day</div>
    </div>`;

  document.getElementById('profile-modal').classList.add('open');
}

function closeProfileModal() {
  document.getElementById('profile-modal').classList.remove('open');
}

function pmOpenEdit() {
  const acc = loadAccount() || {};

  // Pre-fill name
  const nameInp = document.getElementById('pm-edit-name');
  if(nameInp) nameInp.value = acc.name || '';

  // Photo preview
  _pmTempPhoto = acc.photo || null;
  _pmRefreshPhotoPreview(acc);

  // Render emoji picker
  const row = document.getElementById('pm-edit-emoji-row');
  if(row) {
    let currentEmoji = acc.avatar || '🌙';
    row.innerHTML = OB_EMOJIS.map(e =>
      `<button onclick="pmPickEmoji('${e}',this)"
        style="width:38px;height:38px;border-radius:10px;border:1.5px solid ${e===currentEmoji?'rgba(var(--accent-rgb),.6)':'rgba(255,255,255,.1)'};background:${e===currentEmoji?'rgba(var(--accent-rgb),.15)':'transparent'};font-size:1.125rem;cursor:pointer;display:flex;align-items:center;justify-content:center;-webkit-tap-highlight-color:transparent;transition:all .15s;transform:${e===currentEmoji?'scale(1.1)':'scale(1)'}"
        data-emoji="${e}">${e}</button>`
    ).join('');
  }

  // Show panel, scroll into view
  const panel = document.getElementById('pm-edit-panel');
  if(panel) {
    panel.style.display = 'block';
    setTimeout(() => panel.scrollIntoView({ behavior:'smooth', block:'nearest' }), 60);
  }
  setTimeout(() => { const inp = document.getElementById('pm-edit-name'); if(inp) inp.focus(); }, 80);
}

// Temp photo state during editing
let _pmTempPhoto = null;

function _pmRefreshPhotoPreview(acc) {
  const preview = document.getElementById('pm-photo-preview');
  const removeBtn = document.getElementById('pm-photo-remove');
  if(!preview) return;
  const src = _pmTempPhoto;
  if(src) {
    preview.innerHTML = `<img src="${src}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;display:block">`;
    if(removeBtn) removeBtn.style.display = 'block';
  } else {
    preview.innerHTML = '';
    preview.textContent = acc?.avatar || acc?.initial || '?';
    if(removeBtn) removeBtn.style.display = 'none';
  }
}

function pmHandlePhoto(input) {
  const file = input.files && input.files[0];
  if(!file) return;
  if(file.size > 3 * 1024 * 1024) {
    showToast('⚠ Photo too large — max 3 MB');
    input.value = '';
    return;
  }
  const reader = new FileReader();
  reader.onload = e => {
    // Resize to max 200×200 to keep localStorage small
    const img = new Image();
    img.onload = () => {
      const MAX = 200;
      const scale = Math.min(MAX / img.width, MAX / img.height, 1);
      const w = Math.round(img.width  * scale);
      const h = Math.round(img.height * scale);
      const canvas = document.createElement('canvas');
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d');
      // Circular clip
      ctx.beginPath();
      ctx.arc(w/2, h/2, Math.min(w,h)/2, 0, Math.PI*2);
      ctx.clip();
      ctx.drawImage(img, 0, 0, w, h);
      _pmTempPhoto = canvas.toDataURL('image/jpeg', 0.82);
      _pmRefreshPhotoPreview(loadAccount() || {});
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
  input.value = ''; // reset so same file can be re-selected
}

function pmRemovePhoto() {
  _pmTempPhoto = null;
  _pmRefreshPhotoPreview(loadAccount() || {});
}

function pmPickEmoji(e, btn) {
  // Highlight selected
  document.querySelectorAll('#pm-edit-emoji-row button').forEach(b => {
    const sel = b.dataset.emoji === e;
    b.style.borderColor  = sel ? 'rgba(var(--accent-rgb),.6)' : 'rgba(255,255,255,.1)';
    b.style.background   = sel ? 'rgba(var(--accent-rgb),.15)' : 'transparent';
    b.style.transform    = sel ? 'scale(1.1)' : 'scale(1)';
  });
}

function pmCancelEdit() {
  const panel = document.getElementById('pm-edit-panel');
  if(panel) panel.style.display = 'none';
}

function pmSaveEdit() {
  const nameInp = document.getElementById('pm-edit-name');
  const name = (nameInp?.value || '').trim();
  if(name.length < 2) {
    nameInp?.focus();
    nameInp && (nameInp.style.borderColor = 'rgba(var(--rose-rgb),.6)');
    setTimeout(() => { if(nameInp) nameInp.style.borderColor = 'rgba(var(--accent-rgb),.25)'; }, 1200);
    return;
  }

  // Get selected emoji (if no photo)
  const selBtn = document.querySelector('#pm-edit-emoji-row button[style*="scale(1.1)"]');
  const emoji  = selBtn?.dataset?.emoji || (loadAccount()?.avatar) || '🌙';

  const acc = loadAccount() || {};
  acc.name    = name;
  acc.initial = name.charAt(0).toUpperCase();
  acc.avatar  = emoji;
  // Photo: _pmTempPhoto = null means "remove", undefined means "untouched" — here null means remove
  if(_pmTempPhoto !== undefined) acc.photo = _pmTempPhoto || null;
  if(!acc.photo) delete acc.photo; // don't store null

  try {
    saveAccount(acc);
  } catch(e) {
    // localStorage full (large photo) — try without photo
    const accNoPhoto = {...acc}; delete accNoPhoto.photo;
    saveAccount(accNoPhoto);
    showToast('⚠ Photo too large for storage — saved without photo');
    _pmTempPhoto = null;
  }

  updateProfileBtn(acc);
  updateAppTitle(acc.name);

  // Update visible avatar in modal
  const avatarEl = document.getElementById('pm-avatar');
  if(avatarEl) {
    if(acc.photo) {
      avatarEl.innerHTML = `<img src="${acc.photo}" style="width:100%;height:100%;object-fit:cover;border-radius:50%;display:block">`;
    } else {
      avatarEl.innerHTML = '';
      avatarEl.textContent = emoji;
    }
  }
  document.getElementById('pm-name').textContent = name;

  pmCancelEdit();
  showToast('✓ Profile updated');

  // ☁️ Push updated profile to Supabase
  if (_supaUser) {
    clearTimeout(pmSaveEdit._supaTimer);
    pmSaveEdit._supaTimer = setTimeout(() => { supaPushProfile(loadAccount()); }, 2000);
  }
}

// Keep obEditProfile as alias (used nowhere else but safe)
function obEditProfile() { pmOpenEdit(); }

function obLogout() {
  closeProfileModal();
  if(!confirm('This will clear your account and ALL app data. Are you sure?')) return;
  localStorage.removeItem(ACCOUNT_KEY);
  location.reload();
}



// ==============================================
// HOME VIEW ENHANCEMENTS
// ==============================================

// -- Today Score Pill (Activities section header) --
function updateScorePill() {
  const el = document.getElementById('today-score-pill');
  const score = calcDayScore(TODAY_KEY);
  if(el) {
    el.textContent = score + '%';
    if(score >= 80) { el.style.background='rgba(var(--accent-rgb),.15)'; el.style.borderColor='rgba(var(--accent-rgb),.3)'; el.style.color='var(--teal)'; }
    else if(score >= 50) { el.style.background='rgba(var(--accent-rgb),.12)'; el.style.borderColor='rgba(var(--accent-rgb),.25)'; el.style.color='var(--gold)'; }
    else { el.style.background='rgba(var(--accent-rgb),.1)'; el.style.borderColor='rgba(var(--accent-rgb),.2)'; el.style.color='var(--rose)'; }
  }
  // Update hero score card
  const arc    = document.getElementById('hero-arc');
  const bigNum = document.getElementById('hero-score-big');
  const numEl  = document.getElementById('hero-score-num');
  const subEl  = document.getElementById('hero-score-sub');
  const barsEl = document.getElementById('hero-mini-bars');
  if(arc) {
    const offset = 175.9 * (1 - score / 100);
    arc.style.strokeDashoffset = offset;
  }
  if(bigNum) bigNum.textContent = score + '%';
  if(numEl)  numEl.textContent  = score;
  if(subEl) {
    const msgs = ['Keep going! 💪','Good progress 🌟','Excellent! ✨','Mashallah! 🌙','Perfect day! 🏆'];
    subEl.textContent = score < 20 ? msgs[0] : score < 40 ? msgs[1] : score < 70 ? msgs[2] : score < 90 ? msgs[3] : msgs[4];
  }
  const prayerPct = Object.values(prayerDone).filter(Boolean).length/5*100;
  const actsPct = (()=>{ const a=todayActs(); return a.length?a.filter(x=>x.done).length/a.length*100:0; })();
  const dhikrPct = Math.min(dhikrCounts.reduce((s,c,i)=>s+Math.min(c/(getDhikrList()[i]?.target||33),1),0)/Math.max(getDhikrList().length,1)*100,100);
  const scoreTop = document.getElementById('hero-top-score');
  const prayerTop = document.getElementById('hero-top-prayer');
  const dhikrTop = document.getElementById('hero-top-dhikr');
  const focusEl = document.getElementById('hero-feature-focus');
  const goalsEl = document.getElementById('hero-feature-goals');
  if(scoreTop) scoreTop.textContent = score + '%';
  if(prayerTop) prayerTop.textContent = Object.values(prayerDone).filter(Boolean).length + '/5';
  if(dhikrTop) dhikrTop.textContent = Math.round(dhikrPct) + '%';
  if(focusEl) {
    const weakest = [
      {label:'Prayer focus', pct: prayerPct},
      {label:'Activity focus', pct: actsPct},
      {label:'Dhikr focus', pct: dhikrPct}
    ].sort((a,b)=>a.pct-b.pct)[0];
    focusEl.textContent = weakest.pct >= 85 ? 'Strong momentum' : weakest.label;
  }
  if(goalsEl) {
    try {
      const g = JSON.parse(localStorage.getItem('mf_goals_v1') || '{}');
      const hasGoals = !!(g && Object.keys(g).length);
      goalsEl.textContent = hasGoals ? 'Active goals' : 'Personal plan';
    } catch(e) {
      goalsEl.textContent = 'Personal plan';
    }
  }
  if(barsEl) {
    const cats = [
      { label:'Prayer', pct: Object.values(prayerDone).filter(Boolean).length/5*100, color:'#c9a96e' },
      { label:'Acts',   pct: (()=>{ const a=todayActs(); return a.length?a.filter(x=>x.done).length/a.length*100:0; })(), color:'#5bbfb5' },
      { label:'Dhikr',  pct: Math.min(dhikrCounts.reduce((s,c,i)=>s+Math.min(c/(getDhikrList()[i]?.target||33),1),0)/Math.max(getDhikrList().length,1)*100,100), color:'#ce93d8' },
    ];
    barsEl.innerHTML = cats.map(c=>`
      <div style="display:flex;align-items:center;gap:10px">
        <div style="font-size:0.375rem;color:rgba(var(--accent-rgb),.45);width:36px;letter-spacing:.14em;text-transform:uppercase;font-weight:700;flex-shrink:0">${c.label}</div>
        <div style="flex:1;height:2px;border-radius:99px;background:rgba(255,255,255,.06);overflow:visible;position:relative">
          <div style="height:100%;width:${c.pct.toFixed(0)}%;background:linear-gradient(90deg,${c.color}aa,${c.color});border-radius:99px;transition:width 1s cubic-bezier(.22,1,.36,1);position:relative">
            <div style="position:absolute;right:-3px;top:-3px;width:7px;height:7px;border-radius:50%;background:${c.color};box-shadow:0 0 8px ${c.color},0 0 16px ${c.color}66;transition:opacity .5s"></div>
          </div>
        </div>
        <div style="font-size:0.5625rem;color:${c.pct>0?c.color:'var(--t3)'};width:26px;text-align:right;font-family:'Playfair Display',serif;font-weight:400;transition:color .5s;flex-shrink:0">${c.pct.toFixed(0)}<span style="font-size:0.375rem;opacity:.6">%</span></div>
      </div>`).join('');
  }
}

// -- Prayer Streak Badge --
function calcAllFivePrayerStreak() {
  // Count consecutive days (going back from today) where all 5 prayers were done
  let streak = 0;
  for(let i = 0; i < 365; i++) {
    const d = new Date(now); d.setDate(d.getDate() - i);
    const k = dateKey(d);
    const prayers = k === TODAY_KEY ? prayerDone : (daily[k]?.prayers || {});
    const allFive = Object.values(prayers).filter(Boolean).length === 5;
    if(allFive) streak++;
    else break;
  }
  return streak;
}

function updatePrayerStreakBadge() {
  const el = document.getElementById('prayer-streak-badge');
  if(!el) return;
  const streak = calcAllFivePrayerStreak();
  if(streak >= 1) {
    el.textContent = '🔥 ' + streak + (streak === 1 ? ' day' : ' days');
    el.style.display = '';
  } else {
    el.style.display = 'none';
  }
}

// -- Dhikr Total Counter --
function updateDhikrTotal() {
  const el = document.getElementById('dhikr-total-lbl');
  if(!el) return;
  const list = getDhikrList();
  const total = dhikrCounts.reduce((s, c) => s + (c || 0), 0);
  const doneCount = list.filter((d, i) => (dhikrCounts[i]||0) >= d.target).length;
  if(total === 0) { el.textContent = ''; return; }
  el.textContent = doneCount > 0
    ? `· ${total.toLocaleString()} · ${doneCount}/${list.length} done`
    : `· ${total.toLocaleString()}`;
  el.style.color = doneCount === list.length ? 'var(--green)' : 'var(--t3)';
}

// -- Missed Prayer Dot --
// Called inside renderPrayers() - adds amber pulse dot on prayer cards that are past-due & not done
function getMissedPrayers() {
  const nowMins = new Date().getHours() * 60 + new Date().getMinutes();
  // Give 30-min grace window
  return PRAYERS.filter(p => {
    if(prayerDone[p]) return false;
    const t = minsSinceMidnight(prayerTimes[p]);
    return t > 0 && (nowMins - t) > 30; // past by 30+ min
  });
}

// -- Quick-Nav scroll helper --
function qnavTo(id) {
  const el   = document.getElementById(id);
  const view = document.getElementById('view-today');
  if(!el || !view) return;
  // Calculate offset relative to the scrolling view container
  const viewRect = view.getBoundingClientRect();
  const elRect   = el.getBoundingClientRect();
  const offset   = view.scrollTop + (elRect.top - viewRect.top) - 72;
  view.scrollTo({ top: Math.max(0, offset), behavior: 'smooth' });
}

function scrollToTop() {
  const view = document.getElementById('view-today');
  if(view) view.scrollTo({ top: 0, behavior: 'smooth' });
}

// -- Show/hide quick-nav on scroll --
function initQuickNav() {
  const view = document.getElementById('view-today');
  const nav  = document.getElementById('quick-nav');
  if(!view || !nav) return;
  let ticking = false;
  view.addEventListener('scroll', () => {
    if(!ticking) {
      requestAnimationFrame(() => {
        // Only show on today view, when scrolled past the clock
        const onTodayView = document.getElementById('view-today').classList.contains('active');
        const shouldShow  = onTodayView && view.scrollTop > 220;
        if(shouldShow && nav.style.display === 'none') {
          nav.style.display = '';
          nav.style.opacity = '0';
          nav.style.transform = 'translateY(10px)';
          requestAnimationFrame(() => {
            nav.style.transition = 'opacity .22s, transform .22s cubic-bezier(.34,1.56,.64,1)';
            nav.style.opacity = '1';
            nav.style.transform = 'translateY(0)';
          });
        } else if(!shouldShow && nav.style.display !== 'none') {
          nav.style.transition = 'opacity .18s, transform .18s';
          nav.style.opacity = '0';
          nav.style.transform = 'translateY(8px)';
          setTimeout(() => { nav.style.display = 'none'; }, 180);
        }
        ticking = false;
      });
      ticking = true;
    }
  }, { passive: true });
}

// -- Master refresh: call after any state change --
function refreshHomeExtras() {
  updateScorePill();
  updatePrayerStreakBadge();
  updateDhikrTotal();
}


// ==============================================
// MOOD CHECK-IN
// ==============================================
const MOODS_CI = [
  { e:'😌', label:'Calm',       color:'#5bbfb5', bg:'rgba(var(--accent-rgb),.12)'  },
  { e:'💪', label:'Motivated',  color:'var(--green)', bg:'rgba(var(--accent-rgb),.12)' },
  { e:'😔', label:'Struggling', color:'#e07b8a', bg:'rgba(var(--accent-rgb),.12)' },
  { e:'🤲', label:'Grateful',   color:'#c9a96e', bg:'rgba(var(--accent-rgb),.12)' },
];

function loadMoodCI() {
  try {
    const r = localStorage.getItem('mrd_mood_ci');
    if(r) { const p = JSON.parse(r); if(p.date === TODAY_KEY) return p.mood; }
  } catch{}
  return null;
}
function saveMoodCI(mood) {
  try { localStorage.setItem('mrd_mood_ci', JSON.stringify({ date: TODAY_KEY, mood })); } catch{}
}


function _clamp(v,min,max){ return Math.max(min, Math.min(max, v)); }
function _ncoachDateKeyOffset(key, offset){
  const d = new Date(String(key || TODAY_KEY) + 'T00:00:00');
  if(isNaN(d)) return TODAY_KEY;
  d.setDate(d.getDate() + offset);
  return dateKey(d);
}
function _ncoachRecentKeys(baseKey = viewingDate || TODAY_KEY, days = 7){
  return Array.from({length:days}, (_,i)=>_ncoachDateKeyOffset(baseKey, -(days-1-i)));
}
function _ncoachMetricPack(key = viewingDate || TODAY_KEY){
  const snap = typeof getDateSnapshot === 'function' ? (getDateSnapshot(key) || {}) : {};
  const settings = (typeof appSettings === 'object' && appSettings) ? appSettings : {};
  const prayers = (snap && typeof snap.prayers === 'object' && snap.prayers) ? snap.prayers : {};
  const prayerDoneCount = ['Fajr','Dhuhr','Asr','Maghrib','Isha'].filter(p => !!prayers[p]).length;
  const qGoal = Math.max(1, Number(snap?.quranGoal ?? settings?.quranGoal ?? 2) || 2);
  const qPages = Math.max(0, Number(snap?.quranPages || 0));
  const dhikrTotal = Array.isArray(snap?.dhikr) ? snap.dhikr.reduce((a,b)=>a + (+b || 0), 0) : 0;
  const sunnahDoneCount = Array.isArray(snap?.sunnah) ? snap.sunnah.filter(Boolean).length : 0;
  const sunnahLen = Math.max(1, Number(snap?.sunnahLen || (Array.isArray(snap?.sunnah) ? snap.sunnah.length : 1) || 1));
  const actsAll = Array.isArray(snap?.acts) ? snap.acts.filter(a => !a?.hidden) : [];
  const actsTotal = actsAll.length;
  const fallbackActivityGoal = Math.max(1, Number(settings?.activityGoal || settings?.actsGoal || 5) || 5);
  const actsTarget = Math.max(1, actsTotal || fallbackActivityGoal);
  const actsDone = actsAll.filter(a => a?.done).length;
  const fast = !!snap?.fasting;
  const metrics = {
    prayer: { label:'Prayer', value: prayerDoneCount / 5, done: prayerDoneCount, target:5 },
    quran: { label:'Quran', value: _clamp(qPages / qGoal, 0, 1), done: qPages, target:qGoal },
    dhikr: { label:'Dhikr', value: _clamp(dhikrTotal / 100, 0, 1), done: dhikrTotal, target:100 },
    sunnah:{ label:'Sunnah', value: _clamp(sunnahDoneCount / sunnahLen, 0, 1), done:sunnahDoneCount, target:sunnahLen },
    acts:  { label:'Activities', value: _clamp(actsDone / actsTarget, 0, 1), done:actsDone, target:actsTarget },
    fasting:{ label:'Fasting', value: fast ? 1 : 0, done: fast ? 1 : 0, target:1 }
  };
  const weighted = (metrics.prayer.value * 0.34 + metrics.quran.value * 0.18 + metrics.dhikr.value * 0.14 + metrics.sunnah.value * 0.14 + metrics.acts.value * 0.16 + metrics.fasting.value * 0.04);
  const score = Math.round(weighted * 100);
  const weakestKey = ['prayer','quran','dhikr','sunnah','acts'].sort((a,b)=>metrics[a].value - metrics[b].value)[0];
  return { key, score, metrics, weakestKey, weakestLabel: metrics[weakestKey].label };
}

function getNafsCoachData(key = viewingDate || TODAY_KEY){
  const base = _ncoachMetricPack(key);
  const metrics = base.metrics;
  const score = base.score;
  const weakestKey = base.weakestKey;
  const history = _ncoachRecentKeys(key, 7).map(k => { const pack = _ncoachMetricPack(k); return { key:k, score:pack.score, weakestKey:pack.weakestKey, weakestLabel:pack.weakestLabel, metrics:pack.metrics }; });
  const validHistory = history.filter(h => Object.values(h.metrics).some(m => m.done > 0));
  const historyUsed = validHistory.length ? validHistory : history;
  const avgScore = Math.round(historyUsed.reduce((s,h)=>s + h.score, 0) / Math.max(1, historyUsed.length));
  const firstScore = historyUsed[0]?.score ?? score;
  const trendDelta = score - firstScore;
  const trendDirection = trendDelta >= 8 ? 'up' : trendDelta <= -8 ? 'down' : 'flat';
  const trendLabel = trendDirection === 'up' ? `Up ${trendDelta}` : trendDirection === 'down' ? `Down ${Math.abs(trendDelta)}` : 'Stable';
  const trendNote = trendDirection === 'up' ? `You are ${Math.abs(trendDelta)} point${Math.abs(trendDelta)===1?'':'s'} above your 7-day opening.` : trendDirection === 'down' ? `You are ${Math.abs(trendDelta)} point${Math.abs(trendDelta)===1?'':'s'} below your 7-day opening.` : 'Your last 7 days are mostly steady.';
  let recurringWeakest = weakestKey;
  try { const freq = {}; historyUsed.forEach(h => { freq[h.weakestKey] = (freq[h.weakestKey] || 0) + 1; }); recurringWeakest = Object.entries(freq).sort((a,b)=>b[1]-a[1])[0]?.[0] || weakestKey; } catch {}
  let weakStreak = 0;
  for(let i = history.length - 1; i >= 0; i--){ if((history[i].metrics[weakestKey]?.value || 0) < 0.45) weakStreak++; else break; }
  let recoveryStreak = 0;
  for(let i = history.length - 1; i >= 0; i--){ const prayerSafe = (history[i].metrics.prayer?.value || 0) >= 0.6; const scoreSafe = history[i].score >= 45; if(prayerSafe && scoreSafe) recoveryStreak++; else break; }
  const nextMilestone = recoveryStreak < 3 ? 3 : recoveryStreak < 7 ? 7 : recoveryStreak < 14 ? 14 : 21;
  const prayerSlip = history.slice(-3).every(h => (h.metrics.prayer?.value || 0) < 0.8);
  const quranDrop = history.slice(-3).every(h => (h.metrics.quran?.value || 0) < 0.4);
  const overPressure = score < 45 && (metrics.acts.value > 0.75) && ((metrics.prayer.value < 0.6) || (metrics.quran.value < 0.35));
  let alertTone = 'good';
  let alertLabel = 'Protected';
  let warningTitle = 'Your recent pattern is protected.';
  let warningBody = 'Keep the same calm rhythm. Do not add pressure unless quality can hold.';
  if(weakStreak >= 3 || prayerSlip || quranDrop || trendDirection === 'down'){
    alertTone = 'warn';
    alertLabel = weakStreak >= 3 ? `${metrics[weakestKey].label} slipping` : trendDirection === 'down' ? 'Momentum falling' : 'Needs recovery';
    warningTitle = weakStreak >= 3 ? `${metrics[weakestKey].label} has been weak for ${weakStreak} day${weakStreak===1?'':'s'} in a row.` : trendDirection === 'down' ? 'Your 7-day reading is drifting downward.' : 'One key area needs quick recovery before it becomes a habit.';
    warningBody = prayerSlip ? 'Prayer consistency has stayed soft across recent days. Let the next salah become your reset point.' : quranDrop ? 'Quran has stayed below your normal rhythm for several days. Even one short reading block matters now.' : overPressure ? 'You are completing tasks, but core worship quality is falling behind. Simplify before adding more.' : 'Recover the weakest area first. Once it stabilizes, the rest of the day becomes easier to protect.';
  }
  let mode = 'Steady';
  let focusTitle = 'Stay steady and protect your good momentum.';
  let focusNote  = 'You are doing something right already. Keep the next step simple and sincere.';
  if (score < 25) { mode = 'Reset'; focusTitle = 'Start with one easy win before the day slips away.'; focusNote = 'Do not chase everything at once. One sincere action can restart your rhythm.'; }
  else if (score < 50) { mode = 'Recovery'; focusTitle = 'Recover the weakest area first, then add one small Sunnah.'; focusNote = 'Today is about recovery, not perfection.'; }
  else if (score < 80) { mode = 'Consistency'; focusTitle = 'Protect consistency and clean up the one area that is lagging.'; focusNote = 'A balanced day is better than a dramatic burst.'; }
  else { mode = 'Growth'; focusTitle = 'You have momentum today — deepen quality, not just quantity.'; focusNote = 'Use your energy for khushu, reflection, and one extra voluntary act.'; }
  const prayerDoneCount = metrics.prayer.done; const qPages = metrics.quran.done; const qGoal = metrics.quran.target; const dhikrTotal = metrics.dhikr.done; const sunnahDoneCount = metrics.sunnah.done; const sunnahLen = metrics.sunnah.target; const actsDone = metrics.acts.done; const actsTarget = metrics.acts.target;
  const adviceMap = {
    prayer: [prayerDoneCount < 5 ? `Complete the next prayer on time and avoid letting ${5 - prayerDoneCount} prayer(s) stay behind.` : 'All fard prayers are done — now protect khushu and jamaah where possible.', weakStreak >= 2 ? 'Your prayer rhythm has been soft for several days, so make the next salah your recovery anchor.' : 'Keep wudu easy and ready so the next salah feels lighter.', 'Let prayer become the anchor, not the last task.'],
    quran: [qPages < qGoal ? `Read at least ${Math.max(1, qGoal - qPages)} more page${(qGoal - qPages) > 1 ? 's' : ''} to touch your Quran goal.` : 'You reached your Quran target — read one page slowly with reflection.', recurringWeakest === 'quran' ? 'Quran has been the repeating weak area lately, so protect one fixed reading window today.' : 'Choose a short, realistic session instead of waiting for a perfect long one.', 'Read with meaning in mind, not only page count.'],
    dhikr: [dhikrTotal < 100 ? `Add ${Math.max(10, 100 - dhikrTotal > 33 ? 33 : 10)} easy dhikr in a calm sitting.` : 'Your dhikr is healthy today — slow down and focus on presence.', 'Use natural gaps: after salah, walking, or before sleep.', 'Keep the tongue soft and the heart awake.'],
    sunnah: [sunnahDoneCount < sunnahLen ? 'Pick only one neglected Sunnah and complete it before the day ends.' : 'Your Sunnah flow is strong today — protect it quietly and consistently.', recurringWeakest === 'sunnah' ? 'Sunnah habits are slipping most often, so anchor one to an existing daily action.' : 'Small Sunnahs build identity faster than occasional big efforts.', 'Attach Sunnah habits to actions you already do daily.'],
    acts: [actsDone < actsTarget ? `Complete ${Math.max(1, actsTarget - actsDone)} more tracked act${(actsTarget - actsDone) > 1 ? 's' : ''} to close your daily plan.` : 'Your activity target is already met — focus on sincerity and quality now.', overPressure ? 'You are doing many actions, but the coach wants you to simplify and protect the core.' : 'Choose one meaningful action instead of adding clutter.', 'A shorter honest list beats a crowded unfinished list.']
  };
  const coachChallenge = weakestKey === 'prayer' ? 'Win the next salah on time and protect the one after it.' : weakestKey === 'quran' ? 'Open Quran once today, even for a very short focused reading.' : weakestKey === 'dhikr' ? 'Complete one calm dhikr sitting before sleep.' : weakestKey === 'sunnah' ? 'Revive one neglected Sunnah and repeat it tomorrow.' : 'Finish one meaningful act with full sincerity, then stop adding noise.';
  return { key, score, avgScore, mode, weakestKey, weakestLabel: metrics[weakestKey].label, recurringWeakest, recurringWeakestLabel: metrics[recurringWeakest]?.label || metrics[weakestKey].label, focusTitle, focusNote, actions: adviceMap[weakestKey], metrics, history, trendDelta, trendDirection, trendLabel, trendNote, weakStreak, recoveryStreak, nextMilestone, alertTone, alertLabel, warningTitle, warningBody, coachChallenge, summary: score < 25 ? 'A soft restart is enough for today.' : score < 50 ? 'You are behind in one key area.' : score < 80 ? 'Your day is stable but can become cleaner.' : 'Strong day — refine your quality.' };
}

function renderNafsCoach(key = viewingDate || TODAY_KEY){
  const root = document.getElementById('nafs-coach-home');
  if(!root) return;
  const d = getNafsCoachData(key);
  const score = document.getElementById('ncoach-score'); const mode = document.getElementById('ncoach-mode'); const weak = document.getElementById('ncoach-weak'); const focus = document.getElementById('ncoach-focus'); const note = document.getElementById('ncoach-focus-note'); const sub = document.getElementById('ncoach-sub'); const list = document.getElementById('ncoach-list'); const trend = document.getElementById('ncoach-trend'); const alert = document.getElementById('ncoach-alert'); const trendNote = document.getElementById('ncoach-trend-note'); const streak = document.getElementById('ncoach-streak');
  if(score) score.textContent = d.score + '%';
  if(mode) mode.textContent = 'Mode · ' + d.mode;
  if(weak) weak.textContent = 'Focus · ' + d.weakestLabel;
  if(trend) trend.textContent = 'Trend · ' + d.trendLabel;
  if(alert) alert.textContent = 'Alert · ' + d.alertLabel;
  if(focus) focus.textContent = d.focusTitle;
  if(note) note.textContent = d.focusNote;
  if(sub) sub.textContent = d.summary;
  if(trendNote) trendNote.textContent = d.trendNote;
  if(streak) streak.textContent = `${d.recoveryStreak} day${d.recoveryStreak===1?'':'s'} · next ${d.nextMilestone}`;
  if(list) list.innerHTML = d.actions.slice(0,3).map(a => `<li><span class="ncoach-dot">✓</span><span>${a}</span></li>`).join('');
}


function refreshNafsCoachUI(key = viewingDate || TODAY_KEY){
  try { renderNafsCoach(key); } catch(err) { console.warn('Nafs Coach home render failed', err); }
  try { renderNafsCoachPage(key); } catch(err) { console.warn('Nafs Coach page render failed', err); }
}

window.refreshNafsCoachUI = refreshNafsCoachUI;

(function initNafsCoachBoot(){
  const run = () => {
    const key = (typeof viewingDate !== 'undefined' && viewingDate) ? viewingDate : (typeof TODAY_KEY !== 'undefined' ? TODAY_KEY : undefined);
    refreshNafsCoachUI(key);
  };
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run, { once:true });
  else run();
  window.addEventListener('load', () => setTimeout(run, 120));
  document.addEventListener('visibilitychange', () => { if(!document.hidden) setTimeout(run, 40); });
  window.addEventListener('focus', () => setTimeout(run, 40));
})();

function renderNafsCoachPage(key = viewingDate || TODAY_KEY){
  const el = document.getElementById('nafs-coach-page-body');
  if(!el) return;
  const d = getNafsCoachData(key);
  const metricOrder = ['prayer','quran','dhikr','sunnah','acts'];
  const metricHtml = metricOrder.map(k => { const m = d.metrics[k]; return `<div class="ncoach-metric"><div style="flex:1;min-width:0"><div style="font-size:.74rem;color:var(--text);font-weight:700">${m.label}</div><div class="ncoach-bar"><span style="width:${Math.round(m.value*100)}%"></span></div></div><div style="font-size:.68rem;color:var(--t2);flex-shrink:0">${m.done} / ${m.target}</div></div>`; }).join('');
  const historyBars = d.history.map(h => `<div style="display:flex;align-items:flex-end;gap:4px;flex:1;min-width:0"><div style="flex:1;height:${Math.max(12, h.score)}px;border-radius:10px 10px 4px 4px;background:linear-gradient(180deg,rgba(var(--accent-rgb),.9),rgba(var(--accent-rgb),.28));position:relative"></div></div>`).join('');
  const historyLabels = d.history.map(h => `<div style="flex:1;text-align:center;font-size:.5rem;color:var(--t3)">${String(h.key).slice(5)}</div>`).join('');
  el.innerHTML = `<div class="ncoach-page-grid"><div class="ncoach-page-card" style="background:linear-gradient(155deg,rgba(var(--accent-rgb),.12),rgba(255,255,255,.03));border-color:rgba(var(--accent-rgb),.18)"><div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap"><div><div class="ncoach-page-title">Daily reading</div><div style="font-family:'Playfair Display',serif;font-size:2.4rem;line-height:.95;color:var(--gold)">${d.score}%</div><div style="font-size:.76rem;color:var(--text);font-weight:700;margin-top:8px">${d.mode} mode</div><div style="font-size:.68rem;color:var(--t2);line-height:1.55;margin-top:6px">${d.summary}</div></div><div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end"><div class="ncoach-alert ${d.alertTone}">${d.alertLabel}</div><div class="ncoach-alert">7-day avg · ${d.avgScore}%</div><div class="ncoach-alert">Weakest · ${d.weakestLabel}</div></div></div></div><div class="ncoach-page-card"><div class="ncoach-page-title">Coach warning</div><div style="font-size:1rem;color:var(--text);font-weight:700;line-height:1.35">${d.warningTitle}</div><div style="font-size:.72rem;color:var(--t2);line-height:1.65;margin-top:8px">${d.warningBody}</div><div class="ncoach-mini-row" style="margin-top:12px"><div class="ncoach-mini"><div class="ncoach-mini-k">Recurring weak area</div><div class="ncoach-mini-v">${d.recurringWeakestLabel}</div></div><div class="ncoach-mini"><div class="ncoach-mini-k">Weak streak</div><div class="ncoach-mini-v">${d.weakStreak} day${d.weakStreak===1?'':'s'}</div></div></div></div><div class="ncoach-page-card"><div class="ncoach-page-title">Coach plan</div><div style="font-size:1rem;color:var(--text);font-weight:700;line-height:1.35">${d.focusTitle}</div><div style="font-size:.72rem;color:var(--t2);line-height:1.65;margin-top:8px">${d.focusNote}</div><ul class="ncoach-list" style="margin-top:12px">${d.actions.map(a => `<li><span class="ncoach-dot">→</span><span>${a}</span></li>`).join('')}</ul></div><div class="ncoach-page-card"><div class="ncoach-page-title">7 day pattern</div><div style="display:flex;align-items:flex-end;gap:4px;height:110px;margin-top:8px">${historyBars}</div><div style="display:flex;gap:4px;margin-top:8px">${historyLabels}</div><div style="font-size:.72rem;color:var(--t2);line-height:1.6;margin-top:10px">${d.trendNote}</div></div><div class="ncoach-page-card"><div class="ncoach-page-title">Area breakdown</div>${metricHtml}</div><div class="ncoach-page-card"><div class="ncoach-page-title">Recovery system</div><div style="display:flex;gap:10px;flex-wrap:wrap"><div class="ncoach-mini" style="flex:1"><div class="ncoach-mini-k">Recovery streak</div><div class="ncoach-mini-v">${d.recoveryStreak} day${d.recoveryStreak===1?'':'s'}</div></div><div class="ncoach-mini" style="flex:1"><div class="ncoach-mini-k">Next milestone</div><div class="ncoach-mini-v">${d.nextMilestone} days</div></div></div><div style="font-size:.72rem;color:var(--t2);line-height:1.65;margin-top:12px">A recovery day is counted when prayer protection stays decent and your daily reading does not collapse. This helps the coach reward stability, not random spikes.</div><div class="ncoach-mini" style="margin-top:12px"><div class="ncoach-mini-k">Today's recovery challenge</div><div class="ncoach-mini-v">${d.coachChallenge}</div></div></div><div class="ncoach-page-card"><div class="ncoach-page-title">Guidance logic</div><div style="display:flex;flex-direction:column;gap:10px"><div style="font-size:.72rem;color:var(--text);line-height:1.6"><strong style="color:var(--gold);font-weight:700">Reset:</strong> when your day is very light, the coach reduces pressure and asks for one easy win.</div><div style="font-size:.72rem;color:var(--text);line-height:1.6"><strong style="color:var(--gold);font-weight:700">Recovery:</strong> when one key area is weak, the coach tells you where to recover first.</div><div style="font-size:.72rem;color:var(--text);line-height:1.6"><strong style="color:var(--gold);font-weight:700">Consistency:</strong> when you are doing okay, the coach protects balance and prevents drift.</div><div style="font-size:.72rem;color:var(--text);line-height:1.6"><strong style="color:var(--gold);font-weight:700">Growth:</strong> when your day is strong, the coach pushes quality over quantity.</div></div></div></div>`;
}

function renderMoodCheckin() {
  const el = document.getElementById('mood-checkin-card');
  if(!el) return;
  const sel = loadMoodCI();
  el.innerHTML = `
    <span class="mood-ci-label">How are you feeling?</span>
    <div style="display:flex;gap:6px;flex:1;justify-content:flex-end">
    ${MOODS_CI.map(m => `
      <button class="mood-ci-btn ${sel===m.label?'sel':''}"
        style="--mood-color:${m.color};--mood-bg:${m.bg}"
        onclick="pickMoodCI('${m.label}')">
        <span class="mood-ci-emoji">${m.e}</span>
        <span class="mood-ci-word">${m.label}</span>
      </button>`).join('')}
    </div>`;
  // Update summary badge in expand header
  const badge = document.getElementById('mood-summary-badge');
  if(badge) {
    const found = MOODS_CI.find(m => m.label === sel);
    if(found) {
      badge.textContent = found.e + ' ' + found.label;
      badge.style.display = '';
      badge.style.background = found.bg;
      badge.style.color = found.color;
      badge.style.borderColor = (found.color||'').includes('rgb') ? found.color.replace(')', ',.3)').replace('rgb','rgba') : found.color+'99';
    } else {
      badge.style.display = 'none';
    }
  }
}

function pickMoodCI(label) {
  const prev = loadMoodCI();
  // Toggle off if tapping same one
  const next = prev === label ? null : label;
  saveMoodCI(next);
  // Also save into daily note moods for consistency
  if(!daily[TODAY_KEY]) daily[TODAY_KEY] = {};
  daily[TODAY_KEY].energyMood = next;
  try { localStorage.setItem('mrd4_daily', JSON.stringify(daily)); } catch{}
  // ☁️ Supabase push for mood/energy
  clearTimeout(pickMoodCI._supaTimer);
  pickMoodCI._supaTimer = setTimeout(() => { supaPushDay(TODAY_KEY); }, 2000);
  renderMoodCheckin();
  updateScorePill();
}

// ==============================================
// HEADER HIJRI DATE + OCCASION BANNER
// ==============================================
function renderFridayBanner() { renderIslamicDayBadge(); } // alias

function renderIslamicDayBadge() {
  // -- English Hijri date in header --
  const viewDate = (typeof viewingDate !== 'undefined' && viewingDate)
    ? new Date(viewingDate + 'T12:00:00') : new Date();
  // Use Maghrib-aware Hijri — Islamic day begins at sunset
  const isViewingToday = !viewingDate || viewingDate === TODAY_KEY;
  const h = isViewingToday ? getHijriForDisplay(viewDate) : toHijriObj(viewDate);
  const dow  = viewDate.getDay();
  const hDay = h.day, hMon = h.month;
  const enEl = document.getElementById('hdr-hijri-en');
  if(enEl) enEl.textContent = `${hDay} ${HIJRI_MONTHS_EN[hMon-1]} ${h.year} AH`;

  // -- Occasion lookup --
  const el = document.getElementById('islamic-day-badge');
  if(!el) return;

  let occ = null;
  if(hMon===10 && hDay===1)
    occ={ sym:'🎉', name:'Eid al-Fitr',            sub:'Mubarak!',                 cls:'gold'   };
  else if(hMon===12 && hDay===10)
    occ={ sym:'🎉', name:'Eid al-Adha',             sub:'Mubarak!',                 cls:'gold'   };
  else if(hMon===12 && hDay===9)
    occ={ sym:'🤲', name:'Day of Arafah',           sub:'Fast & make dua',          cls:'green'  };
  else if(hMon===1  && hDay===10)
    occ={ sym:'✨', name:'Ashura',                  sub:'10 Muharram',              cls:'purple' };
  else if(hMon===9  && hDay===27)
    occ={ sym:'💫', name:'Laylat al-Qadr',          sub:'Seek this blessed night',  cls:'purple' };
  else if(hMon===7  && hDay===27)
    occ={ sym:'⭐', name:"Israʼ & Miʼraj", sub:'27 Rajab',                cls:'gold'   };
  else if(hMon===8  && hDay===15)
    occ={ sym:'🌟', name:"Laylat al-Baraʼah",  sub:"15 Shaʼban",          cls:'purple' };
  else if(hMon===12 && hDay>=11 && hDay<=13)
    occ={ sym:'🕋', name:'Days of Tashreeq',        sub:'Remember Allah abundantly',cls:'teal'   };
  else if(hMon===9)
    occ={ sym:'🌙', name:'Ramadan Mubarak',
          sub: hDay>=21 && hDay%2===1 ? 'Seek Laylat al-Qadr tonight' : `Day ${hDay} of Ramadan`,
          cls:'gold' };
  else if(hMon===12 && hDay<=10)
    occ={ sym:'🕋', name:'Dhul Hijjah',             sub:'Best 10 days of the year', cls:'gold'   };
  else if(hMon===1)
    occ={ sym:'🌙', name:'Muharram',                sub:'Sacred month of Allah',    cls:'teal'   };
  else if(hMon===7)
    occ={ sym:'🌿', name:'Rajab',                   sub:'Sacred month',             cls:'green'  };
  else if(hMon===8)
    occ={ sym:'🌸', name:"Shaʼban",            sub:'Month of the Prophet ★',cls:'teal' };
  else if(hMon===11)
    occ={ sym:'🌙', name:"Dhul Qaʼdah",        sub:'Sacred month',             cls:'teal'   };
  else if(dow===5)
    occ={ sym:'🕌', name:"Jumuʼah Mubarak",    sub:'Don’t forget Surah al-Kahf', cls:'gold' };
  else if(dow===1 || dow===4)
    occ={ sym:'🤍', name:`${dow===1?'Monday':'Thursday'} — Sunnah Fast`, sub:'Fast today for extra reward', cls:'teal' };

  if(!occ) { el.style.display='none'; return; }

  el.style.display = '';
  el.innerHTML = `
    <div class="occ-banner ${occ.cls}">
      <span class="occ-banner-text">
        <span class="occ-banner-name">${occ.name}</span>
        <span class="occ-banner-sub">${occ.sub}</span>
      </span>
      <span class="occ-banner-sym">${occ.sym}</span>
    </div>`;
}


// ==============================================
// ISHRAQ / DUHA TIME NUDGE
// ==============================================
function renderIshraqNudge() {
  const el = document.getElementById('ishraq-nudge');
  if(!el) return;

  const live    = new Date();
  const nowMins = live.getHours() * 60 + live.getMinutes();
  const fajrMins   = minsSinceMidnight(prayerTimes['Fajr'])   || 0;
  const dhuhrMins  = minsSinceMidnight(prayerTimes['Dhuhr'])  || 720;
  const ishraqStart = fajrMins + 20;   // ~20 min after Fajr sunrise
  const duhaEnd     = dhuhrMins - 10;  // ends ~10 min before Dhuhr

  const inWindow = nowMins >= ishraqStart && nowMins < duhaEnd;
  if(!inWindow) { el.style.display = 'none'; return; }

  const isEarly = nowMins < fajrMins + 90;
  el.style.display = '';
  el.innerHTML = `
    <div class="ishraq-nudge">
      <span class="ishraq-nudge-icon">${isEarly ? '🌄' : '☀️'}</span>
      <span>${isEarly
        ? '<strong>Ishraq time</strong> — 2 rakʿah after sunrise for the reward of a complete Hajj'
        : '<strong>Duha prayer</strong> — Pray before Dhuhr for abundant blessing today'
      }</span>
    </div>`;
}


// ==============================================
// HIJRI-AWARE SUNNAH TIP
// ==============================================
function renderSunnahHijriTip() {
  const el = document.getElementById('sunnah-hijri-tip');
  if(!el) return;
  const d    = (typeof viewingDate !== 'undefined' && viewingDate)
               ? new Date(viewingDate+'T12:00:00') : new Date();
  const h    = toHijriObj(d);
  const dow  = d.getDay();
  let tip = null;

  if(h.month===9)
    tip = { icon:'🌙', text:`Ramadan night ${h.day} — Increase your dhikr & Quran recitation` };
  else if(h.month===12 && h.day<=10)
    tip = { icon:'🕋', text:'Dhul Hijjah — Increase takbeer, tahmeed, tahleel & tasbeeh' };
  else if((h.day===13||h.day===14||h.day===15))
    tip = { icon:'🌕', text:`Ayyam al-Beed — White days (${h.day} ${HIJRI_MONTHS_EN[h.month-1]}). Recommended sunnah fast` };
  else if(h.month===1 && h.day===10)
    tip = { icon:'✨', text:'Ashura — Fast today; it expiates the sins of the past year (Ibn Majah)' };
  else if(h.month===7 && h.day===27)
    tip = { icon:'⭐', text:"Israʼ & Miʼraj — Night of the Prophet’s ascension. Increase salawat tonight" };
  else if(dow===5)
    tip = { icon:'🕌', text:"Jumuʼah — Read Surah al-Kahf, send salawat abundantly, make dua at the last hour" };
  else if(dow===1||dow===4)
    tip = { icon:'🤍', text:`${dow===1?'Monday':'Thursday'} — Sunnah fasting day. The Prophet ♖ fasted on these days` };

  if(!tip) { el.style.display='none'; return; }
  el.style.display='';
  el.innerHTML=`<div style="display:flex;align-items:flex-start;gap:8px;padding:8px 12px;border-radius:11px;background:rgba(var(--accent-rgb),.07);border:1px solid rgba(var(--accent-rgb),.15);font-size:11px;color:var(--t2);line-height:1.5">
    <span style="font-size:15px;flex-shrink:0;line-height:1.3">${tip.icon}</span>
    <span>${tip.text}</span>
  </div>`;
}


// ==============================================
// ==============================================

// ══════════════════════════════════════════════
// SURPRISE CELEBRATION SYSTEM
// ══════════════════════════════════════════════
const CEL_KEY = 'mrd_celebrated';

function _getCelebrated() {
  try { return JSON.parse(localStorage.getItem(CEL_KEY) || '{}'); } catch { return {}; }
}
function _markCelebrated(id) {
  const c = _getCelebrated(); c[id] = Date.now();
  try { localStorage.setItem(CEL_KEY, JSON.stringify(c)); } catch {}
}
function _hasCelebrated(id) {
  return !!_getCelebrated()[id];
}

// -- Milestone definitions ----------------------
function _getMilestones() {
  const acc      = loadAccount();
  const name     = acc ? acc.name.split(' ')[0] : null;
  const avatar   = acc ? acc.avatar : '🌙';
  const streak   = calcAllFivePrayerStreak();
  const daysT    = getDaysTracked();
  const totalDhikr = dhikrCounts.reduce((s,c) => s+c, 0);
  const allFiveToday = Object.values(prayerDone).filter(Boolean).length === 5;
  const allTakbir = Object.values(prayerQuality).filter(q=>q==='takbir').length === 5;
  const score    = calcDayScore(TODAY_KEY);
  const hObj     = toHijriObj(now);
  const isRamadan = hObj.month === 9;
  const ramadanFasts = isRamadan ? Object.keys(fastingData).filter(k => {
    const d = new Date(k+'T12:00:00');
    return fastingData[k] && toHijriObj(d).month === 9;
  }).length : 0;
  const totalFasts = Object.values(fastingData).filter(Boolean).length;
  const quranPages = quranData.pages;

  const milestones = [];

  // -- First time opening --
  if(!_hasCelebrated('welcome') && daysT >= 1) milestones.push({
    id:'welcome', priority:10,
    emoji:'🌙', badge:'Welcome', badgeColor:'rgba(var(--accent-rgb),.2)', badgeTextColor:'var(--gold)',
    title: name ? `Ahlan, ${name}!` : 'Ahlan wa Sahlan!',
    msg: 'Your journey of intentional living begins today. Every small act done with sincerity is recorded.',
    arabic: 'إِنَّمَا الْأَعْمَالُ بِالنِّيَّاتِ',
    hadith: '"Actions are judged by intentions." — Bukhari & Muslim',
    btnText: 'Bismillah, let\'s go! 🤲',
  });

  // -- First all-5-prayers day --
  if(!_hasCelebrated('all5_first') && allFiveToday) milestones.push({
    id:'all5_first', priority:9,
    emoji:'🕌', badge:'All 5 Prayers', badgeColor:'rgba(var(--accent-rgb),.15)', badgeTextColor:'var(--teal)',
    title: name ? `Mashallah, ${name}!` : 'Mashallah!',
    msg: 'You completed all five prayers today. The pillars of your day are standing strong.',
    arabic: 'إِنَّ الصَّلَاةَ كَانَتْ عَلَى الْمُؤْمِنِينَ كِتَابًا مَّوْقُوتًا',
    hadith: '"Indeed, prayer has been decreed upon the believers a decree of specified times." — Quran 4:103',
    btnText: 'Alhamdulillah ✨',
  });

  // -- 3-day prayer streak --
  if(!_hasCelebrated('streak_3') && streak >= 3) milestones.push({
    id:'streak_3', priority:7,
    emoji:'🔥', badge:'3-Day Streak', badgeColor:'rgba(255,183,77,.15)', badgeTextColor:'var(--amber)',
    title: name ? `3 days strong, ${name}!` : '3 Days Strong!',
    msg: 'Three consecutive days of all five prayers. Consistency is the key that opens the door of tawfiq.',
    arabic: 'أَحَبُّ الْأَعْمَالِ إِلَى اللَّهِ أَدْوَمُهَا وَإِنْ قَلَّ',
    hadith: '"The most beloved deeds to Allah are those done consistently, even if small." — Bukhari',
    btnText: 'Keep going! 💪',
  });

  // -- 7-day prayer streak --
  if(!_hasCelebrated('streak_7') && streak >= 7) milestones.push({
    id:'streak_7', priority:8,
    emoji:'⭐', badge:'7-Day Streak', badgeColor:'rgba(var(--accent-rgb),.2)', badgeTextColor:'var(--gold)',
    title: name ? `One full week, ${name}!` : 'One Full Week!',
    msg: 'Seven days, all five prayers — every single day. This is what nurturing the soul looks like.',
    arabic: 'قَدْ أَفْلَحَ الْمُؤْمِنُونَ ۝ الَّذِينَ هُمْ فِي صَلَاتِهِمْ خَاشِعُونَ',
    hadith: '"Successful are the believers — those who are humbly submissive in their prayers." — Quran 23:1-2',
    btnText: 'Subhanallah 🌟',
  });

  // -- 30-day streak --
  if(!_hasCelebrated('streak_30') && streak >= 30) milestones.push({
    id:'streak_30', priority:9,
    emoji:'🏆', badge:'30-Day Streak', badgeColor:'rgba(var(--accent-rgb),.15)', badgeTextColor:'var(--green)',
    title: name ? `30 days, ${name}!` : 'Thirty Days!',
    msg: 'A full month of all five prayers without missing a single day. You have built something beautiful.',
    arabic: 'وَأَقِيمُوا الصَّلَاةَ وَآتُوا الزَّكَاةَ',
    hadith: '"Establish prayer and give zakah." — Quran 2:43',
    btnText: 'Alhamdulillah 🤲',
  });

  // -- All 5 with Takbir-ul-Ula --
  if(!_hasCelebrated('takbir5') && allTakbir && allFiveToday) milestones.push({
    id:'takbir5', priority:8,
    emoji:'✨', badge:'Takbir-ul-Ula', badgeColor:'rgba(var(--accent-rgb),.18)', badgeTextColor:'var(--gold)',
    title: name ? `Magnificent, ${name}!` : 'Magnificent!',
    msg: 'All five prayers with Takbir-ul-Ula today. Catching the opening takbir is a treasure many miss.',
    arabic: 'مَنْ صَلَّى لِلَّهِ أَرْبَعِينَ يَوْمًا فِي جَمَاعَةٍ',
    hadith: '"Whoever prays for Allah forty days in congregation catching the first takbir, two freedoms are written for him." — Tirmidhi',
    btnText: 'Allahu Akbar! 🌙',
  });

  // -- First 7 days tracked --
  if(!_hasCelebrated('days_7') && daysT >= 7) milestones.push({
    id:'days_7', priority:6,
    emoji:'📅', badge:'One Week Tracked', badgeColor:'rgba(var(--accent-rgb),.15)', badgeTextColor:'var(--teal)',
    title: name ? `One week in, ${name}!` : 'One Week In!',
    msg: 'Seven days of intentional tracking. You are building habits that will last a lifetime inshallah.',
    arabic: 'إِنَّ مَعَ الْعُسْرِ يُسْرًا',
    hadith: '"Indeed, with hardship comes ease." — Quran 94:6',
    btnText: 'Let\'s keep building 🌱',
  });

  // -- 30 days tracked --
  if(!_hasCelebrated('days_30') && daysT >= 30) milestones.push({
    id:'days_30', priority:8,
    emoji:'🗓️', badge:'30 Days Tracked', badgeColor:'rgba(var(--accent-rgb),.15)', badgeTextColor:'var(--green)',
    title: name ? `A whole month, ${name}!` : 'A Whole Month!',
    msg: 'Thirty days of showing up for yourself and your deen. May Allah bless your consistency.',
    arabic: 'فَاسْتَقِمْ كَمَا أُمِرْتَ',
    hadith: '"So be steadfast as you are commanded." — Quran 11:112',
    btnText: 'Barakallahu feek 🤲',
  });

  // -- Perfect score day (100%) --
  if(!_hasCelebrated('perfect_score') && score >= 100) milestones.push({
    id:'perfect_score', priority:9,
    emoji:'💎', badge:'Perfect Day', badgeColor:'rgba(var(--accent-rgb),.15)', badgeTextColor:'#ce93d8',
    title: name ? `Perfect day, ${name}!` : 'A Perfect Day!',
    msg: 'A 100% score — prayers, dhikr, quran, sunnah, activities — all complete. Truly a blessed day.',
    arabic: 'هَذَا مِن فَضْلِ رَبِّي',
    hadith: '"This is from the grace of my Lord." — Quran 27:40',
    btnText: 'Alhamdulillah 💎',
  });

  // -- First Ramadan fast --
  if(!_hasCelebrated('ramadan_first') && isRamadan && ramadanFasts >= 1) milestones.push({
    id:'ramadan_first', priority:9,
    emoji:'🌙', badge:'Ramadan', badgeColor:'rgba(var(--accent-rgb),.2)', badgeTextColor:'var(--gold)',
    title: name ? `Ramadan Mubarak, ${name}!` : 'Ramadan Mubarak!',
    msg: 'Your first recorded Ramadan fast this year. May every suhoor and iftar be filled with barakah.',
    arabic: 'شَهْرُ رَمَضَانَ الَّذِي أُنزِلَ فِيهِ الْقُرْآنُ',
    hadith: '"The month of Ramadan in which the Quran was revealed as guidance for mankind." — Quran 2:185',
    btnText: 'Ramadan Kareem 🌙',
  });

  // -- 10 Ramadan fasts --
  if(!_hasCelebrated('ramadan_10') && isRamadan && ramadanFasts >= 10) milestones.push({
    id:'ramadan_10', priority:8,
    emoji:'⭐', badge:'10 Ramadan Fasts', badgeColor:'rgba(var(--accent-rgb),.2)', badgeTextColor:'var(--gold)',
    title: name ? `Ten fasts, ${name}!` : 'Ten Fasts!',
    msg: 'Ten days of Ramadan complete. The first ten days are days of mercy — you are in the heart of them.',
    arabic: 'كُلُّ عَمَلِ ابْنِ آدَمَ لَهُ إِلَّا الصِّيَامَ فَإِنَّهُ لِي',
    hadith: '"Every deed of the son of Adam is for him except fasting — it is for Me." — Hadith Qudsi, Bukhari',
    btnText: 'Allahu Akbar 🌙',
  });

  // -- 50 total dhikr today --
  if(!_hasCelebrated('dhikr_50') && totalDhikr >= 50) milestones.push({
    id:'dhikr_50', priority:5,
    emoji:'📿', badge:'50 Dhikr', badgeColor:'rgba(var(--accent-rgb),.15)', badgeTextColor:'#ce93d8',
    title: name ? `Your tongue is busy, ${name}!` : 'Your Tongue is Busy!',
    msg: 'Fifty remembrances today. The tongue in dhikr is the tongue that finds peace.',
    arabic: 'أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ',
    hadith: '"Verily, in the remembrance of Allah do hearts find rest." — Quran 13:28',
    btnText: 'Subhanallah 📿',
  });

  // -- First Quran pages logged --
  if(!_hasCelebrated('quran_first') && quranPages >= 1) milestones.push({
    id:'quran_first', priority:6,
    emoji:'📖', badge:'Quran Started', badgeColor:'rgba(var(--accent-rgb),.15)', badgeTextColor:'var(--gold)',
    title: name ? `You opened the Book, ${name}!` : 'You Opened the Book!',
    msg: 'The first pages of Quran logged. Every letter carries ten rewards — imagine the treasure you just earned.',
    arabic: 'اقْرَأْ بِاسْمِ رَبِّكَ الَّذِي خَلَقَ',
    hadith: '"Read in the name of your Lord who created." — Quran 96:1',
    btnText: 'Keep reading 📖',
  });

  // Sort by priority descending, return highest unshown
  milestones.sort((a,b) => b.priority - a.priority);
  return milestones;
}

// -- Confetti engine ---------------------------
function _launchConfetti(colors) {
  const canvas = document.getElementById('confetti-canvas');
  if(!canvas) return;
  canvas.width  = window.innerWidth;
  canvas.height = window.innerHeight;
  const ctx = canvas.getContext('2d');
  const cols = colors || ['#c9a96e','#5bbfb5','#e07b8a','var(--green)','#ffb74d','#ce93d8'];
  const pieces = Array.from({length:90}, () => ({
    x: Math.random() * canvas.width,
    y: -10 - Math.random() * 100,
    r: 3 + Math.random() * 5,
    d: 2 + Math.random() * 4,
    color: cols[Math.floor(Math.random()*cols.length)],
    tilt: Math.random() * 10 - 5,
    tiltAngle: 0,
    tiltSpeed: 0.1 + Math.random() * 0.2,
    shape: Math.random() > 0.5 ? 'rect' : 'circle',
  }));
  let frame = 0;
  const maxFrames = 160;
  function draw() {
    ctx.clearRect(0,0,canvas.width,canvas.height);
    pieces.forEach(p => {
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.tiltAngle);
      ctx.globalAlpha = Math.max(0, 1 - frame/maxFrames);
      ctx.fillStyle = p.color;
      if(p.shape === 'rect') {
        ctx.fillRect(-p.r/2, -p.r/2, p.r, p.r*2.5);
      } else {
        ctx.beginPath(); ctx.arc(0,0,p.r,0,Math.PI*2); ctx.fill();
      }
      ctx.restore();
      p.y += p.d * (0.8 + frame/maxFrames);
      p.x += Math.sin(frame*0.05 + p.tilt) * 1.5;
      p.tiltAngle += p.tiltSpeed;
    });
    frame++;
    if(frame < maxFrames) requestAnimationFrame(draw);
    else ctx.clearRect(0,0,canvas.width,canvas.height);
  }
  draw();
}

// -- Show celebration --------------------------
function showCelebration(milestone) {
  // Celebration popup disabled
  if (milestone && milestone.id) _markCelebrated(milestone.id);
}

function closeCelebration() {
  const ovl = document.getElementById('celebration-ovl');
  ovl.classList.remove('show');
}

// -- Check and trigger milestone ---------------
function checkMilestones() {
  const _isToday = (typeof viewingDate === 'undefined' || !viewingDate || viewingDate === TODAY_KEY);
  if(!_isToday) return;
  const milestones = _getMilestones();
  const uncelebrated = milestones.filter(m => !_hasCelebrated(m.id));
  if(uncelebrated.length === 0) return;
  const top = uncelebrated[0];
  setTimeout(() => showCelebration(top), 900);
}


// ══════════════════════════════════════════════
// 99 NAMES OF ALLAH (Asma ul Husna)
// ══════════════════════════════════════════════




function loadSCardState() {
  try { return JSON.parse(localStorage.getItem(SCARD_KEY) || '{}'); } catch { return {}; }
}
function saveSCardState(state) {
  try { localStorage.setItem(SCARD_KEY, JSON.stringify(state)); } catch {}
}

function toggleSCard(id) {
  const el = document.getElementById(id);
  if(!el) return;
  const isOpen = el.classList.toggle('open');
  const state = loadSCardState();
  state[id] = isOpen;
  saveSCardState(state);
  // Refresh dynamic content when opening specific scards
}

function applySCardState() {
  const state = loadSCardState();
  SCARD_IDS.forEach(id => {
    const el = document.getElementById(id);
    if(!el) return;
    // Default all closed; restore saved state
    el.classList.toggle('open', !!state[id]);
  });
}

// -- Apply saved settings on startup -----------
_applySettingsToDom();
applySCardState();
checkPinLock();
if(appSettings.language && appSettings.language !== 'en') applyLanguage();
// Home view extras (must run after appSettings is assigned above)
renderMoodCheckin();
renderFridayBanner();
renderIshraqNudge();
renderSunnahHijriTip();
refreshHomeExtras();
initQuickNav();
// initNewFeatures() is defined in the second <script> block and called from there.
renderHealthTracker();
renderStreakRow();
renderDailyChallenge();
renderAchievements();
updateAchieveBadge();
renderRamadanMode();
setInterval(updateRamadanCountdown, 1000);
setTimeout(checkAchievements, 2000);
setInterval(renderIshraqNudge, 5 * 60 * 1000);
setInterval(applyFocusMode, 60 * 1000);


// ══════════════════════════════════════════════
// HEALTH TRACKER  (Water + Sleep + Steps)
// ══════════════════════════════════════════════

function loadHealth(key) {
  try {
    const r = localStorage.getItem('mrd_health');
    const d = r ? JSON.parse(r) : {};
    // Migrate old water data
    if (!d[key] && localStorage.getItem('mrd_water')) {
      try {
        const w = JSON.parse(localStorage.getItem('mrd_water'));
        if (w[key]) return { water: w[key], sleep: 0, steps: 0 };
      } catch {}
    }
    return d[key] || { water: 0, sleep: 0, steps: 0 };
  } catch { return { water: 0, sleep: 0, steps: 0 }; }
}
function saveHealth(key, data) {
  try {
    const r = localStorage.getItem('mrd_health');
    const d = r ? JSON.parse(r) : {};
    d[key] = data;
    localStorage.setItem('mrd_health', JSON.stringify(d));
  } catch {}
  // ☁️ Push health to Supabase settings (debounced)
  clearTimeout(saveHealth._supaTimer);
  saveHealth._supaTimer = setTimeout(() => { supaPushSettings(); }, 3000);
}
// Backward-compat aliases used by persist() and renderStreakRow()
function loadWater(key) { return loadHealth(key).water || 0; }
function saveWater(key, count) {
  const h = loadHealth(key); h.water = count; saveHealth(key, h);
}

function setWater(val) {
  const key = (typeof viewingDate !== 'undefined') ? viewingDate : TODAY_KEY;
  const h = loadHealth(key);
  h.water = Math.max(0, Math.min(12, val));
  saveHealth(key, h);
  renderHealthTracker(); renderStreakRow();
}
function setSleep(val) {
  const key = (typeof viewingDate !== 'undefined') ? viewingDate : TODAY_KEY;
  const h = loadHealth(key);
  h.sleep = Math.max(0, Math.min(14, Math.round(val * 2) / 2));
  saveHealth(key, h);
  renderHealthTracker();
}
function setSteps(val) {
  const key = (typeof viewingDate !== 'undefined') ? viewingDate : TODAY_KEY;
  const h = loadHealth(key);
  h.steps = Math.max(0, val);
  saveHealth(key, h);
  renderHealthTracker();
}

function _renderHealthTrackerWithData(h, readonly) {
  const el = document.getElementById('health-tracker');
  if (!el) return;
  const waterGoal = 8, sleepGoal = 8, stepsGoal = 10000;
  const wPct  = Math.min(h.water / waterGoal * 100, 100);
  const sPct  = Math.min((h.sleep || 0) / sleepGoal * 100, 100);
  const stPct = Math.min((h.steps || 0) / stepsGoal * 100, 100);
  const wDone  = h.water >= waterGoal;
  const sDone  = (h.sleep || 0) >= sleepGoal;
  const stDone = (h.steps || 0) >= stepsGoal;

  const card = (emoji, val, unit, pct, done, color, colorBase, minus, plus) => {
    const cb = colorBase || 'rgba(255,255,255,.15)';
    const borderDone = cb.replace(/\)$/, ', .35)');
    const borderBtn  = cb.replace(/\)$/, ', .4)');
    const bgBtn      = cb.replace(/\)$/, ', .12)');
    const bgGlow     = cb.replace(/\)$/, ', .22)');
    const btnStyle = readonly
      ? `opacity:.45;pointer-events:none;cursor:default`
      : `-webkit-tap-highlight-color:transparent;touch-action:manipulation`;
    return `
    <div style="border-radius:22px;padding:16px 10px 12px;text-align:center;background:rgba(255,255,255,.04);border:1px solid ${done?borderDone:'rgba(255,255,255,.07)'};transition:border-color .3s;position:relative;overflow:hidden">
      <div style="position:absolute;top:-20px;right:-20px;width:70px;height:70px;background:radial-gradient(circle,${bgGlow} 0%,transparent 70%);pointer-events:none;opacity:${done?'.4':'.2'}"></div>
      <div style="font-size:1.25rem;margin-bottom:6px">${emoji}</div>
      <div style="font-family:'Playfair Display',serif;font-size:2rem;font-weight:300;color:${done?color:'var(--text)'};line-height:1;margin-bottom:2px;transition:color .3s">${val}</div>
      <div style="font-size:0.4rem;letter-spacing:.12em;text-transform:uppercase;color:var(--t3);margin-bottom:8px">${unit}</div>
      <div style="height:3px;border-radius:99px;background:rgba(255,255,255,.07);overflow:hidden;margin-bottom:10px">
        <div style="height:100%;width:${pct}%;background:${color};border-radius:99px;transition:width .5s cubic-bezier(.22,1,.36,1);box-shadow:${done?'0 0 8px '+bgGlow:'none'}"></div>
      </div>
      <div style="display:flex;justify-content:center;gap:6px">
        <button onclick="${minus}" style="width:32px;height:32px;border-radius:50%;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.05);color:var(--t2);font-size:0.875rem;cursor:pointer;display:flex;align-items:center;justify-content:center;font-family:'Manrope',sans-serif;${btnStyle}">−</button>
        <button onclick="${plus}" style="width:32px;height:32px;border-radius:50%;border:1px solid ${borderBtn};background:${bgBtn};color:${color};font-size:0.875rem;cursor:pointer;display:flex;align-items:center;justify-content:center;font-family:'Manrope',sans-serif;${btnStyle}">+</button>
      </div>
    </div>`; };

  el.innerHTML = `
  <div style="padding:0 14px 14px">
    <div class="sec-lbl" style="padding:0 0 10px">Health Tracker${readonly?' <span style="font-size:0.5rem;color:var(--t3);letter-spacing:.06em;font-style:normal">(past date)</span>':''}</div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
      ${card('💧', h.water, `${h.water}/${waterGoal} glasses`, wPct, wDone, 'var(--teal)', 'rgba(var(--teal-rgb),.22)',
        `setWater(${Math.max(0,h.water-1)})`, `setWater(${h.water+1})`)}
      ${card('🌙', h.sleep > 0 ? h.sleep+'h' : '—', `goal ${sleepGoal}hrs`, sPct, sDone, '#c084fc', 'rgba(192,132,252,.22)',
        `setSleep(${Math.max(0,(h.sleep||0)-.5)})`, `setSleep(${(h.sleep||0)+.5})`)}
      ${card('🚶', h.steps >= 1000 ? (h.steps/1000).toFixed(1)+'k' : (h.steps||'—'), `goal 10k steps`, stPct, stDone, 'var(--green)', 'rgba(var(--green-rgb),.22)',
        `setSteps(${Math.max(0,(h.steps||0)-1000)})`, `setSteps(${(h.steps||0)+1000})`)}
    </div>
  </div>`;
}

function renderHealthTracker() {
  if(typeof viewingDate !== 'undefined' && viewingDate !== TODAY_KEY) {
    const h = loadHealth(viewingDate);
    _renderHealthTrackerWithData(h, false); // past dates are editable
    return;
  }
  _renderHealthTrackerWithData(loadHealth(TODAY_KEY), false);
}

function renderHealthTrackerForSnap(s) {
  _renderHealthTrackerWithData(s.health || { water:0, sleep:0, steps:0 }, false);
}

// alias so persist() still works
function renderWaterTracker() { renderHealthTracker(); }

// ══════════════════════════════════════════════
// SALAT ALARM SYSTEM
// ══════════════════════════════════════════════

const ALARM_KEY = 'mrd_salat_alarms';
const PRAYER_ALARM_DEFAULTS = ['Fajr','Dhuhr','Asr','Maghrib','Isha'].map(p => ({
  id: 'prayer_' + p.toLowerCase(),
  prayer: p,
  type: 'prayer',
  enabled: false,
  offset: 0,         // minutes before (-) or after (+) prayer time
  manualTime: '',    // '' = use prayer time, otherwise HH:MM override
  sound: true
}));

function loadAlarms() {
  try {
    const r = localStorage.getItem(ALARM_KEY);
    if (r) {
      const d = JSON.parse(r);
      // Ensure all 5 prayer alarms exist
      ['Fajr','Dhuhr','Asr','Maghrib','Isha'].forEach(p => {
        if (!d.prayer) d.prayer = {};
        if (!d.prayer[p]) d.prayer[p] = { enabled: false, offset: 0, manualTime: '' };
      });
      return d;
    }
  } catch {}
  const def = { prayer: {}, custom: [] };
  ['Fajr','Dhuhr','Asr','Maghrib','Isha'].forEach(p => {
    def.prayer[p] = { enabled: false, offset: 0, manualTime: '' };
  });
  return def;
}

function saveAlarms() {
  try { localStorage.setItem(ALARM_KEY, JSON.stringify(_alarmData)); } catch {}
  updateAlarmChip();
  scheduleAlarms();
}

let _alarmData = loadAlarms();

function updateAlarmChip() {
  const activeCount = Object.values(_alarmData.prayer).filter(a => a.enabled).length
    + (_alarmData.custom || []).filter(a => a.enabled).length;
  const chip = document.getElementById('salat-alarm-chip');
  const lbl = document.getElementById('alarm-chip-label');
  if (lbl) lbl.textContent = activeCount > 0 ? `${activeCount} Active` : 'Alarms';
  if (chip) {
    chip.style.background = activeCount > 0 ? 'rgba(var(--accent-rgb),.22)' : 'rgba(var(--accent-rgb),.12)';
    chip.style.borderColor = activeCount > 0 ? 'rgba(var(--accent-rgb),.55)' : 'rgba(var(--accent-rgb),.28)';
  }
}

function openSalatAlarmPanel() {
  renderPrayerAlarmList();
  renderCustomAlarmList();
  updateNotifNote();
  document.getElementById('salat-alarm-ovl').classList.add('open');
}

function closeSalatAlarmOvl(e) {
  if (e.target === document.getElementById('salat-alarm-ovl') || e.target.classList.contains('ovl-bg'))
    document.getElementById('salat-alarm-ovl').classList.remove('open');
}

function renderPrayerAlarmList() {
  const el = document.getElementById('prayer-alarm-list');
  if (!el) return;
  el.innerHTML = ['Fajr','Dhuhr','Asr','Maghrib','Isha'].map(p => {
    const a = _alarmData.prayer[p] || { enabled: false, offset: 0, manualTime: '' };
    const pTime = prayerTimes[p] || '--:--';
    const displayTime = a.manualTime ? a.manualTime : (pTime !== '--:--' ? offsetTime(pTime, a.offset) : '--:--');
    const offsetLabel = a.offset === 0 ? 'At prayer time' : (a.offset > 0 ? `+${a.offset} min after` : `${Math.abs(a.offset)} min before`);
    return `
    <div style="background:${a.enabled ? 'rgba(var(--accent-rgb),.08)' : 'rgba(255,255,255,.03)'};border:1px solid ${a.enabled ? 'rgba(var(--accent-rgb),.28)' : 'var(--bd)'};border-radius:14px;padding:12px 14px;transition:all .2s">
      <div style="display:flex;align-items:center;gap:10px">
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:baseline;gap:7px">
            <span style="font-size:0.875rem;font-weight:600;color:${a.enabled ? 'var(--gold)' : 'var(--text)'}">${p}</span>
            <span style="font-family:'Playfair Display',serif;font-size:1.25rem;color:${a.enabled ? 'var(--gold)' : 'var(--t2)'};line-height:1">${displayTime !== '--:--' ? fmtTime(displayTime) : '--:--'}</span>
          </div>
          <div style="font-size:0.5625rem;color:var(--t3);margin-top:2px;letter-spacing:.04em">${a.manualTime ? '⏱ Manual time' : offsetLabel}</div>
        </div>
        <label class="sw-wrap" style="flex-shrink:0"><input type="checkbox" ${a.enabled ? 'checked' : ''} onchange="togglePrayerAlarm('${p}',this.checked)"><div class="sw-slider"></div></label>
      </div>
      ${a.enabled ? `
      <div style="margin-top:10px;display:flex;flex-wrap:wrap;gap:8px;align-items:center">
        <div style="display:flex;flex-direction:column;gap:3px;flex:1;min-width:100px">
          <label style="font-size:0.5rem;letter-spacing:.12em;text-transform:uppercase;color:var(--t3)">Manual Override Time</label>
          <input type="time" value="${a.manualTime || ''}" onchange="setPrayerAlarmManualTime('${p}',this.value)"
            style="padding:7px 10px;border-radius:10px;border:1px solid var(--bd);background:rgba(255,255,255,.06);color:var(--text);font-family:'Manrope',sans-serif;font-size:0.8125rem;outline:none;width:100%;color-scheme:dark"
            placeholder="Leave empty to use prayer time">
          ${a.manualTime ? `<button onclick="clearPrayerAlarmManualTime('${p}')" style="font-size:0.5rem;color:var(--rose);background:none;border:none;cursor:pointer;letter-spacing:.06em;text-align:left;padding:2px 0">✕ Clear (use prayer time)</button>` : ''}
        </div>
        <div style="display:flex;flex-direction:column;gap:3px;min-width:90px">
          <label style="font-size:0.5rem;letter-spacing:.12em;text-transform:uppercase;color:var(--t3)">Offset</label>
          <div style="display:flex;align-items:center;gap:4px">
            <button onclick="stepPrayerAlarmOffset('${p}',-5)" style="width:26px;height:26px;border-radius:50%;border:1px solid var(--bd);background:rgba(255,255,255,.05);color:var(--t2);font-size:0.875rem;cursor:pointer;display:flex;align-items:center;justify-content:center">−</button>
            <span style="font-size:0.6875rem;color:var(--gold);min-width:48px;text-align:center" id="offset-lbl-${p}">${offsetLabel}</span>
            <button onclick="stepPrayerAlarmOffset('${p}',5)" style="width:26px;height:26px;border-radius:50%;border:1px solid var(--bd);background:rgba(255,255,255,.05);color:var(--t2);font-size:0.875rem;cursor:pointer;display:flex;align-items:center;justify-content:center">＋</button>
          </div>
        </div>
      </div>` : ''}
    </div>`;
  }).join('');
}

function renderCustomAlarmList() {
  const el = document.getElementById('custom-alarm-list');
  if (!el) return;
  const list = _alarmData.custom || [];
  if (!list.length) {
    el.innerHTML = `<div style="font-size:0.6875rem;color:var(--t3);font-style:italic;text-align:center;padding:8px 0">No custom alarms yet. Tap ＋ Add to create one.</div>`;
    return;
  }
  el.innerHTML = list.map((a, i) => `
    <div style="background:${a.enabled ? 'rgba(var(--accent-rgb),.07)' : 'rgba(255,255,255,.03)'};border:1px solid ${a.enabled ? 'rgba(var(--accent-rgb),.28)' : 'var(--bd)'};border-radius:14px;padding:12px 14px;transition:all .2s">
      <div style="display:flex;align-items:center;gap:10px">
        <div style="flex:1;min-width:0">
          <div style="display:flex;align-items:baseline;gap:7px">
            <span style="font-size:0.875rem;font-weight:500;color:${a.enabled ? 'var(--teal)' : 'var(--text)'}">${escHtml(a.label)}</span>
            <span style="font-family:'Playfair Display',serif;font-size:1.25rem;color:${a.enabled ? 'var(--teal)' : 'var(--t2)'};line-height:1">${a.time ? fmtTime(a.time) : '--:--'}</span>
          </div>
          <div style="font-size:0.5625rem;color:var(--t3);margin-top:2px;letter-spacing:.04em">${capitalise(a.repeat || 'daily')}</div>
        </div>
        <label class="sw-wrap" style="flex-shrink:0"><input type="checkbox" ${a.enabled ? 'checked' : ''} onchange="toggleCustomAlarm(${i},this.checked)"><div class="sw-slider"></div></label>
        <button onclick="deleteCustomAlarm(${i})" style="width:28px;height:28px;border-radius:50%;background:rgba(var(--accent-rgb),.12);border:1px solid rgba(var(--accent-rgb),.2);color:var(--rose);font-size:0.75rem;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;-webkit-tap-highlight-color:transparent">✕</button>
      </div>
    </div>`).join('');
}

function togglePrayerAlarm(p, on) {
  if (!_alarmData.prayer[p]) _alarmData.prayer[p] = { enabled: false, offset: 0, manualTime: '' };
  _alarmData.prayer[p].enabled = on;
  saveAlarms();
  renderPrayerAlarmList();
}

function setPrayerAlarmManualTime(p, val) {
  if (!_alarmData.prayer[p]) _alarmData.prayer[p] = { enabled: true, offset: 0, manualTime: '' };
  _alarmData.prayer[p].manualTime = val || '';
  saveAlarms();
  renderPrayerAlarmList();
}

function clearPrayerAlarmManualTime(p) {
  if (_alarmData.prayer[p]) _alarmData.prayer[p].manualTime = '';
  saveAlarms();
  renderPrayerAlarmList();
}

function stepPrayerAlarmOffset(p, step) {
  if (!_alarmData.prayer[p]) _alarmData.prayer[p] = { enabled: true, offset: 0, manualTime: '' };
  _alarmData.prayer[p].offset = Math.max(-30, Math.min(30, (_alarmData.prayer[p].offset || 0) + step));
  saveAlarms();
  renderPrayerAlarmList();
}

function toggleCustomAlarm(i, on) {
  if (_alarmData.custom[i]) _alarmData.custom[i].enabled = on;
  saveAlarms();
  renderCustomAlarmList();
}

function deleteCustomAlarm(i) {
  _alarmData.custom.splice(i, 1);
  saveAlarms();
  renderCustomAlarmList();
}

function openAddCustomAlarm() {
  document.getElementById('add-custom-alarm-form').style.display = 'block';
  document.getElementById('cal-label').value = '';
  document.getElementById('cal-time').value = '';
  document.getElementById('cal-repeat').value = 'daily';
  setTimeout(() => document.getElementById('cal-label').focus(), 100);
}

function closeAddCustomAlarm() {
  document.getElementById('add-custom-alarm-form').style.display = 'none';
}

function saveCustomAlarm() {
  const label = document.getElementById('cal-label').value.trim();
  const time  = document.getElementById('cal-time').value;
  const repeat = document.getElementById('cal-repeat').value;
  if (!label) {
    const inp = document.getElementById('cal-label');
    inp.style.borderColor = 'var(--rose)'; inp.style.boxShadow = '0 0 0 2px rgba(var(--accent-rgb),.2)';
    setTimeout(() => { inp.style.borderColor = ''; inp.style.boxShadow = ''; }, 1200);
    inp.focus(); return;
  }
  if (!time) {
    const inp = document.getElementById('cal-time');
    inp.style.borderColor = 'var(--rose)';
    setTimeout(() => inp.style.borderColor = '', 1200);
    return;
  }
  if (!_alarmData.custom) _alarmData.custom = [];
  _alarmData.custom.push({ label, time, repeat, enabled: true });
  saveAlarms();
  closeAddCustomAlarm();
  renderCustomAlarmList();
}

function offsetTime(timeStr, offsetMins) {
  if (!timeStr || timeStr === '--:--') return timeStr;
  const [h, m] = timeStr.split(':').map(Number);
  let total = h * 60 + m + offsetMins;
  total = ((total % 1440) + 1440) % 1440;
  return `${String(Math.floor(total/60)).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`;
}

function capitalise(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
function escHtml(s) { return s ? s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') : ''; }

function updateNotifNote() {
  const el = document.getElementById('alarm-notif-note');
  if (!el) return;
  if (!('Notification' in window)) {
    el.textContent = 'Browser notifications are not supported on this device.'; return;
  }
  const perm = Notification.permission;
  if (perm === 'granted') {
    el.textContent = '✓ Browser notifications enabled — alarms will fire as notifications.';
    el.style.color = 'var(--green)';
  } else if (perm === 'denied') {
    el.textContent = '⚠ Notifications blocked. Enable them in browser settings to use alarms.';
    el.style.color = 'var(--rose)';
  } else {
    el.innerHTML = `<button onclick="requestAlarmPermission()" style="background:rgba(var(--accent-rgb),.12);border:1px solid rgba(var(--accent-rgb),.3);color:var(--gold);border-radius:10px;padding:8px 16px;font-family:'Manrope',sans-serif;font-size:0.75rem;cursor:pointer;letter-spacing:.06em">Enable Notifications for Alarms</button>`;
  }
}

async function requestAlarmPermission() {
  const perm = await Notification.requestPermission();
  updateNotifNote();
  if (perm === 'granted') scheduleAlarms();
}

let _alarmTimers = [];
function scheduleAlarms() {
  _alarmTimers.forEach(t => clearTimeout(t));
  _alarmTimers = [];
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  const now2 = new Date();
  const todayMins = now2.getHours() * 60 + now2.getMinutes();

  // Schedule prayer alarms
  ['Fajr','Dhuhr','Asr','Maghrib','Isha'].forEach(p => {
    const a = _alarmData.prayer[p];
    if (!a || !a.enabled) return;
    const baseTime = a.manualTime || prayerTimes[p];
    if (!baseTime) return;
    const scheduled = offsetTime(baseTime, a.offset);
    const [sh, sm] = scheduled.split(':').map(Number);
    let diffMs = (sh * 60 + sm - todayMins) * 60000 - now2.getSeconds() * 1000;
    if (diffMs < 0) diffMs += 86400000;
    const tid = setTimeout(() => {
      const _title = `🕌 ${p} Prayer`;
      const _body = `It's time for ${p} — ${fmtTime(scheduled)}`;
      addNotifHistoryItem({ id:`prayer_${p}_${dateKey(new Date())}_${scheduled}`, title:_title, body:_body, type:'prayer', createdAt:new Date().toISOString() });
      new Notification(_title, { body: _body, icon: '' });
    }, diffMs);
    _alarmTimers.push(tid);
  });

  // Schedule custom alarms
  (_alarmData.custom || []).forEach((a, i) => {
    if (!a.enabled || !a.time) return;
    const [ah, am] = a.time.split(':').map(Number);
    let diffMs = (ah * 60 + am - todayMins) * 60000 - now2.getSeconds() * 1000;
    const today = now2.getDay();
    const isWeekday = today >= 1 && today <= 5;
    const isWeekend = today === 0 || today === 6;
    if (a.repeat === 'weekdays' && !isWeekday) return;
    if (a.repeat === 'weekends' && !isWeekend) return;
    if (diffMs < 0) {
      if (a.repeat === 'once') return;
      diffMs += 86400000;
    }
    const tid = setTimeout(() => {
      const _title = `⏰ ${a.label}`;
      const _body = fmtTime(a.time);
      addNotifHistoryItem({ id:`alarm_${(a.label||'alarm').replace(/[^a-z0-9]+/gi,'_')}_${dateKey(new Date())}_${a.time}`, title:_title, body:_body, type:'alarm', createdAt:new Date().toISOString() });
      new Notification(_title, { body: _body, icon: '' });
    }, diffMs);
    _alarmTimers.push(tid);
  });
}

// Init
updateAlarmChip();
scheduleAlarms();
setTimeout(updateFeatBadges, 1500);

// ══════════════════════════════════════════════
// PWA — Inline Manifest + Inline Service Worker
// Works on ANY domain including Netlify
// ══════════════════════════════════════════════

// 1) Inject manifest as blob URL (no external manifest.json needed)
(function(){
  const m = {
    name:"Toukir's Flow — Muslim Daily Tracker",
    short_name:"Toukir's Flow",
    description:"Islamic daily companion: prayers, dhikr, Quran, fasting and more.",
    start_url:"./",
    scope:"./",
    display:"standalone",
    orientation:"portrait-primary",
    background_color:"#08090c",
    theme_color:"#08090c",
    icons:[
      {src:"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCADAAMADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD5iA5qRVoRamRa+wSOkREqZFpUWpkSrSGNVKlRKeiVMiVQyNUqRU9qkVKkVKaQyIJTwlTBKeI/anyhYrhPal2H0qyIz6U4Qt2BNOyAqbKVUTDb9wOPlwOpz39utWzCw/hP5Uwxn0NFkBUKUxkq4Y/amNH7UcoWKTJUbJV1kqNkqbAUWSomSrzJULpSEUmWoXWrrpUc0ToQHRlJAIyMZB6GpaEUWFRsPzq061CwqGhEyLUyLSKtWTC8UhjdcMOo61aQxI1qdFoRfap0SqGIiVOi0saVPGnPFUkOwxUqaGF5GCopZj0AFbOjaDPd4klzHEe5HJ+lddp2mW1ogWGIA927n8amVRLYLnJWPhy8nwZcQr78n8q27TwzZx4Mu+U+5wP0rrLPS7ifBVNq+rcCta20GMf6xmc+g4FYSreYrnHw6VZRAbLWMf8AAasraRj7sSj8K7u10FWA8qyLe+0mr8fh26I4s8f8BArF1kTc82Nqh6xqfwqvNplpIPntoz/wEV6m/h27xzaZ/AVSudAKg+bYke+zH8qSrRC55TdeHLCXJVGjP+yf8axb/wAM3EYLW7rKPQ8GvW7rQoTnZvjP5isq80i4hyVUSL/s/wCFbRreY7njtzaTQOUljZG9CKqvHXqd7YQ3CFJ4gw9x0rldY8OPEDLaZdP7vcf410RqJ7jucg6Y7VE6VoSxFSQwwaryJVNDKLpUEik9ST9avOlV5FqRFF1qF1q5ItQOtS0ImRasRrimRrViNaoaHxrViNaZGtWY1/WqQx0UZYgAZJrr/D2gKgW4u1y3VUPb60nhXRwqreXC8nlFPb3rs9MsXupQqjCD7x9KxqVOiE2RWVnJO4jiTP8AIV0ulaKiMvyebKenH8hWtoWjGQiGBAFHLMf5mu103TYLNMRrl+7kcn/CuCpXtoiWzC07w5I4D3LeWP7o5Nb1ppdnbgbIVJ/vNya29L0u7v3220JYA/M54Vfqa6nT/CdrGA17K07d1X5V/wATXBUxCW7IcrHEBAOOPpUyWk7j5LeVvpGTXplrYWVqALe1ijx3CjP51ZrmeJ7IjnPLGsrleXtZ1+sZ/wAKgaPBwRg+hr1qori1trgYngikH+0oNCxL6oOc8gutPtZwRLChPrjBrD1Hw4CC1q/P91v8a9iv/C+nzgm332z9tpyv5GuX1fQ73T8tLGJIv+eicj8fSuiniE9mUpHjWr6KC7JPEY5B3xg//XrltR0+W2b5hlT0YdK9xvrKG6jKTICOx7j6Vx2vaK1vuBXzIG4zj9DXfSr9GXc8Y17RI7xTLEAk/wCjfX/GuIurd4ZGjkUqynBB7V7LrGmtbMXQFoz+nsa5HxJpK3kRliUCdRx/tD0rvp1S0zzyRarutaM8ZRirAgjtVSRa3YyjItV5FxV6QVWkWpJZMgqxGOlRRjkVZjFNFIljWt7wvpn2y68yRf3UfJ9z6VjW8Zd1UDJJr0fRLMWdlHCB82MsfU1M5WQM09PtWnmWKMdf0rvfD+k+YyW8K4A5ZiP1NY/huy2Qq5X95J0Ht2r0zRLBbO1VSB5jcuff0rza9S2iIbLFjaRW0IiiXCjr6k+tdX4b8Otdhbq8DJbnlU6F/wDAUnhLRheyfa7lc28Z4U/xt/gK7fIVewAryK1Z7IylIbDFFDEsUSKiKMBVGAKfXm3iL47fCfQb+Sw1DxpYG5jba6W6vcbT6ExqRn8aueHfjL8L9fmWHTfG2kmV/uxzym3Y+wEgXNYeyqWvyu3oRZne0UyKWOWNZInV0YZVlOQR7Gm3VzbWsDT3M8UMS43O7BVGTgZJ9yKzES4ooyPUVU1nU9P0bSrnVNVvIbOytYzJPPM21EUdSTRuBbpCAQQRkHgivKdE8eeOfH4N78P/AA9Yad4fyRDrPiDzB9rA43Q20eGK+jMy59Kmbxj408IeK9D0nx7Bol7pmu3YsLPU9JjlhMNyQSkcsUjNw2CAytwRyK09lK9uo7HUeIvDSsrXOnJtbq0I6H/d9D7VxdxAsiNHImQeCpFeu1y3jHRg6NqNqnzrzMoHUf3vr61rRrNOzKjLoeKeJNI+zORt3wydM/yNef6vZG2mIwSh5U17nqFrHc27wyDhh+R9a828Raa3723dcOp+U+9evQq9GapnjXi/TNrfbYl4J+cDsfWuTlWvVdQt1kjkglX5WBBFebanbNbXckLjlTivTpyurFpmVItVnWr0i1WkXmrYMfEKsxiq6tjtVqAhhkU7NDN7wla+fqSuwysY3fj2r03w3pdxql8kECbgOXYnAUe5rjPBEAWzkmI5dsD6D/8AXXqfgeb7PayFeCzcn1rkrTavYlnYaDoM1vcieYxOkYyNhzz2rrLK3Ms0cbHYrMAWP8I9az9FY/YUY9X+b/Cur8NWJuUluGHAOxfr1P8ASvIqz6szbNu91KLTbeG00+NJAqDBJ+UD+pNea/EK91Lxv4p0r4bTXsunaVd2z6hrVxaMY5ZbZXEaW4b+ESOTuI/hUjvXo/8AZo9K4Xx3o2t6L4r07xvoOjz62kVm+napp1uyi4e3ZxIksIYgM6ODlMjcGOORXLT5F6kqxf8AEmgfCz4aeBrnU5vBGl/2TYKpnWDTop5FQsF3tv8AmYDIJ5Jx61z3xC+FfwM1LwXP4w1HSLPS9LFqLv8AtDTWNvmNgCpCr8rE5GAVJJIFcz8TNS8UfE/Rn8D+DvBfiKwj1F0TUdX1uxNnDbRBgzABjl2JA6duBnORiftILKyfDr4D6PM/lTtbJcvn5mjUiKMt+Ukh/wB0ela06crr3nfrr0BJ9zJ+Fvwd8fajoH/CU/Dzxzq3hTSryQvpdpfzP5s1v2klEXyLuPIXaeMHPNemeFvhB8RdQ1mxuvif8S59c02xuI7lNLtAUhnkRgyGU4XcoYA4wc46iug8TfGTwP4I1tPA9hZ6nq1/p1rmW00qBZBaQxR7m3MzKMrGu4qMnHucVv3HxU8IR+ONB8HRXU91qmuWwurYQRbkjjKF1MhzlNygkDH1xxUVK1aWtt/LW3qJuTPP/D+j/GP4hSXniS6+IE/gmw+2Tw6fpVppqSOkcUrR5mL4JJKk989eAQK858Uz/ETx98RJPhzqksXjnRvCVyl3rA0xE09r88Yife2wsrZG0FQcP3AI90m+MXha40Xxze6XLPK/hBHW7aSErFJKA4VUbPzZdCvavDfgH8RdH+GvgP8AtvXdN1bVdR8S6uJtUvbWNWjtTIW8lJGYjdIwEkuxckK+TjIzdPns5cuq0St3/HYavue72vxNsLS1S3m8CeOtPaJQi2w8OyyBQBgKrRbo8DoMNisKXTvFXxQ8c+H9V1bw/d+GfCXh28Go28F+VF7qN0oIjZo1J8qNck4Y7j6enNfEXXtNvPij4g8VeHte1+91n4f6Q7SaHFGy2U0pDDcWU/MBv+dcZOwYPBrpPAPxEl8c/BW7Nvr9nc+MzpM0s1vohVriF2LLEyxlvlb7nU4BPJFZcjjHmiv+Bf8ArcVransdBAIIIBBrx/4S+O9Qj1aw+GF7bap4i17RbGIeItYEsZhtpmXO1mZg0hB+XIBPGeecewVzTg4OzJasedeJtO/s/UnjQYhk+eP2Hp+H+FcP4wsg0a3SDkfK39K9g8bWgn0nzwPngbdn/ZPB/p+VedanAJ7SWLGdynH1rvw1S6TNIs8T8RW3l3ZcDiTn8e9efeNrTbJHcqPvfK34dK9Y8TQBrUtjmNs/0rgfFEHnaVLxyg3D8K9qlLZmqPOZRVWQdauT4HBIFU3bJ9BXZy3KHItWbcYYe9QR1btwMj60XuB6H4XTZpEGOMgn8zXoPhmPFkhHVmJrhPD4xplsP9gV6F4aA+zW47Z/rXBWZLPTbKMJBHGP4VA/SvR/CcCx6FbnHL5c/if8MV55FXp2hqF0ezA/54r/ACrw8S9EYz2JLya3s7Sa7upY4YII2klkc4VFUZJJ7AAE14f4W8W/ED4xapeXvgzUo/CHgq0naCLUms1nvb916lFk+VF6c4OM45OQOh/a2v7vT/gB4mltNwaWOKB2XqEeVFf8wSPxrR8Bx3Pg/wCCHhmLw54duNcki023Y2ltPFE7l0Du4MhCnLMSec896zglGnz9W7ErRXG+FtS8SaF8Rk8C+JNbXxDFe6XJqOn6hJbJBcIYpESSKUR4Rh+8RlYAH7wOeDXhnhK+l8aftQ+NPHlvELmz8KWNy1kMZVmijaGID6kStXa+ONV8ReDvDnib4u+N0tdN8SXmn/2N4f0mGcSiwR2LDc44eQt+8YjgCPFYPwOe4+E3gPw7pqaL/aXjXx/dmaC0nm8lIoEX5XmfDEBUO8gAklyO1dFNcsJSW70/V/gUtrnHfDDS9D8QfBJw0ov/AIheKdelFk8NyyXULsNkkzlTuEKxPK7hvlYMAeoqtpN9o/hD4n/EbxFoNuqXnh2zk0rQLRpWkmeVUMcl05YliqJE7sx4AYLx8or6G8Vv4D+CfhG+8Z2/hPSbPV7rbCIdPhCPd3D8iFGIyFLZJ4AwCcZ4rgh4wsPBlt461/x14N8LPrclnZpcx6XaFHubm7R2NhKzlt7BVR3YYBDZIPGbjWc+ZpNp/wCa09Og+a54re6tHpP7PWm+EdHJvdZ8W6mLzV5kO7yxvxBbuR/y0fYHK9QMk/eFejfCzw9pGkeM9f8AC/jySXULn4eW7alo1goEVrOgTzHuWQDMkuSnzMTwRxxivR/g/puj3fh2+07xr4Q8HaRD4b1KC6iFnB5UFncvBHMQzOTmaPeqs+eeB2rhvjlrmka/4+0fxt8JJbjxJ4l0fdDqUenWElxaXFphtySyqNh4LLgEkh/VRVOr7RuCVt3f8tfTQd76GV8AnOr+CdakkuWn1Txdez6j4kuIXy9npcTMXUkHKvMxkRAedrMw4WrP7PGrS3uqax40t5bG11rxJqDSzkKpi0jR7dg8rsOihsLEmeu0NyFNdj8FfFd1r/h66/4Vd4G8BaFpokY3lnc6u4uA3QmWKOEkcdCSRjj2rY8HzaDYWXiLwC/gLR/D99dWfnXUemyeZa31vLuiLh9qOMfMu1gMZ4yM1E225q2/5f1b7hPqeX+F9R1y8/ai1ceEdRn8MW3jKwF/BdXtgk7tCqbllETMAm8o5XdyFYZAJ4+ovA0HiK18N29v4r1Sy1TVY2kEl3aQ+Ukq7zsbb0Vtu3IHGc4r53+HWl+GbL4q6/pFmuualrekWMMMupaldCcRxEKFgj6EYGByM8EfX1iya9tJN9rNJCe+08H8OlPEUuayT6IJRueiaisclnNBIyjzEZfmOOory6Xp/OrklvNPIXmZ5GJ5ZjkmqLgrkVFKlydQirHm/iiDa93EB/exXlniieRbdrWH7zqdzeg9K941tLJ3lE9vGxOcnGD09a8g8VabBFcs9uxaJ+gbqvtXrUJ9zRHjsyYJ9ahYVfu1xKwA71SkGK9TmNB0dW4O31qnFVuE+lZCR6R4dfdpVuf9nFeg+G5MWcJ/un+teZeD5Q+lqvdGI/rXoPheXNuyE/dbP51xVVuSz1+AhlVuxGa9L8OSCTQ7RvSML+XH9K8p0WbztOgfPO3B+o4rtfC+uJaWQtZoZGVXJDLg4B9vzrxsRBtaGUldGx420DTPFPhPU/DusAmxv7doJiDgqD0YHsQcEe4rzHwTffEvwH4ft/CMvhOLxrbaagg0/U9N1SCF5YRwizRSkFGUYBKlhx+fVanNd6pcmSYt5efkjz8qj/H3qSy01iwbbgjoR1FZxhyxtJkpWWp5r4k8J6lrmtxfEf47ahpei+HNDPmWOgQTGaKNiRhpnx+8ckAbVB3YA6ZBk8Uta/Gq20jxt8KdUa38R+ErsyWo1C0khiuEkHKEsOVbbwRkfeBxnIt/GDSz4u+LPw18Fa0Wm0V2vdTuoW+7dNAi7EYdx8xz7Ma9I+I3h/StZ8JNpmoatfaNpNuPOuhp9x9mZ4Y1JMZZeVToSFxnbjpmm58vK+v4JbbdbhfY+aPGvinx549+N3hjQNV+H7S3/hJvt17olpqMTJPL8rCQyN8qrzFwcnBI71F41vNS1r44eF/CkPhKCHUdLMmr3WjQ3JuI5dUmPmKZ5sfMqqIS7ngKGVf4RVz9lH4cp4th8QeNxrvijQ4Jr5rSxbT9QMcssAwxWSRlLOBlBnI5U/gz4VanN4Y+KHxX07RbK91HxnPdNZaLbXDSTP5atITNNM2fkUCNiWOW+UDORXXLli3GK+Ffi9+vn/wS9OgvifUfAtp41i8L/wDCNz/EPWdLWaTUbjUNR+zaa16BJcXTCPBWSZtrgBgQNioOFOPX9B+MfhObx74Y8AeFNHFwup2QuZWtGSOLTgYjKqMijBbaOQCNuR34rwr4JDRPE3whv/h5bWEeqeMte1p5L5ri1LnTohtDXkjEYRkTft53GR8etTxy/wBj/HD4j23hnTktNY0/S/7J0C0igKpaxCMeZcnAwAqIWBPLvKAM5NROlGTcXe6X9MXKnodF4+1jwF4t0fxz450f4fO994VvVtnv7W+eza/Bk2vJvhIbAAJ5BJBXmui03xJ8PPD2nSwfDazk8V+JdQRSLOxllvJpJMfL9puHJ2IuTncwxzgc1w37OKR6/wDDTSPC1hCxsI9VbV/EU7odsjxuDbWmTwxYojtjOFXB5bFfQvhvxfFqbaj9g8pxZX8tlc/uwoMseN3I6j5hz9aKicPcWy8xvTQ574NfDa78K6NeX2v3Ed74l1u4N7q1wnKiQ5xGh/urk89yT2xXfrpQ/u1f0zULe9+QDy5QMlD3+h71f2iuKdWbfvbmbkzFGmoiliAAoya4GYhmLDuc16P4luBa6LcODhmXYv1PFea3DiNGc9FGa2w7bu2VE4bxPdEXN0QeF3fpXmuqTF43LHgAmuz8ST/6NPITy5x+Zrz7XpvK024fvsI/PivZox0NUeb3ZzKx96pSd6tznk1Uk716BYiZFWoTVUVPEaqUbAdb4Kuds0luT94bh+FeieHZ/LvAhPDjH49q8g0m5NteRzL/AAnmvSrCcFY5o264ZTXJViJntXhi6RojbDjaMqP511eiSIl9GspAjc7ST2z0P515V4e1Iq0N0h6feH8xXolrMksSyIcqwyDXlVoGbPRotNVf4RVLxhrGn+EfC1/4gv45ZILOPd5US5klckKkajuzMVUe5FT+E9VW+tRbzMPtEQxz/GvY/wCNUvir4evfE3gu507S5YYtRint7yzM2fLaaCZJkV8c7WKBSewOe1eZrzWkZddTzfxT8MPG3juxtPEfifXUs9Zs386w0OxlaC1t42wJbeS5T98zug2NIpAB6KR14P8AaU8FeA/DnhLStF8N+D4R418R3EdvZRm6lnni5HmNuLnPJCZOR8xPavYbv4keKVtPstp8I/Fsmt42+RI1utor/wDXz5hUp7gZx2FUvhp8NdXHjSf4lfEa7ttQ8Vzx+VaW1vk2ulQ8/u4s9WwSC3u3XJJ3p1ZQfNJ6LZL+thptbmV4c/Z28P6V4csLez8ReKtH1aK3QXN5pWryRLJNj53EZyoBbPGBxiotS8FfGPwjFNqHh34r2GqwIuZI/EenJuYDoDOg3H8cV7nWB8Ryo8AeIGZXYDTbg4S3EzcRt0jPDH2PWslXnJ66376i5mzxW3+KHxc8Nx/a9X+EGn6tBdDzWvPD13kTf7RUB2z9cVk6l+0bam4Mmo/DjxTZ3ZAVkW3UE46AkgE4969Z8BQ+b4H0CRQ2DptuRuhER/1Y/hHC/T8e9b6wSH+N/wDvo11KVKL1jr8y9EfPkfj34meNIf7P+Hvw/m8OW8pIbVtUGxIAerKu0Dd34DHPavUvhz4St/BvhK10K3nkunQvLc3Un37idzukkP1P6AV2gtSTk5Y+pqRbT2onXTVkrIHJGZEskciyRkqynIPpWxZarOHC3SqyH+JRgikW0z2qvqskWn2hlcAueEX1P+FYSanoToyh45vxNcR2UTZSL53x3Y9P0/nXB+JbrydPZQfmk+UfTvWxPIWZndsknJJrhPE+orPcOwb91GML9PWuuhTtZFxVjkfFFxkpCD/tH+lee+NLkJZrADy7ZP0FdVqVwZ53lPc8e1eb+Jrz7VqD7TlE+Va9ejHU1Riymqsh4qeU1WlNdLGx4NSIeKhU09DiulDLkLdK7PwjqStELSVwGB/d5PX2rho2x9KmS7SPULAKvmTGcGNR1BwcGuapDoJo9t0C++zzeW5/dufyPrXo3hnUxERbTN8jH5Sf4TXi+j36XcAcfK44dD1U11+hanwsErc9FY/yrzqtO5DR7RZ3MttOk8DlJEOQRXoGg6xBqcIHEdwo+ePP6j1FeLaDrQ2rBdPwOFc/yNdPbzvHIssTlHByrKcEV5dajczcbnquB6ClrldH8VKQItRGD/z1QcfiP8K6aCeGeISwypIh7qciuGUHHczasOclVJxmvFv2hPinbeENMuNE0+2n1TXrqFkMSQu0VqjqQWcgY3YPC9e5wOvFftG/tECwurrwh4CvFN1GTFfarGQRE3Ro4T0LDoX7dBzyPna28a+JnYK/inXiM9P7Sm/+Kr1cHls5pVJrTsaQh1Z9ifs9fEXTPGPhy00W5hksNbsLdYnt5ImQTIgwHQkc8AZHUfSvWhbr6V8H+G/E+qTSIJ/EOtvyDzqc3/xVfW/wh8bx67pcVlfXPmXsagCRz80g9Se596jGYOdO847BODWqO8ECjtThEPSpHdEQu7KqjqScAVgav4otoA0dkBcS/wB7+Af4150VKT0M1dmjql5a6bbGa4brwqD7zH0FcFq2oTX9yZ5jjsqjoo9BUV9eT3k7T3Epkc9z29h6Vz2uaylsrQwMGl6E9l/+vXbRo29TSMbEXiXVBFG1rE3zsPnI7D0rzjxFf5zbo3++f6Vb13VPLDKrbpm6n0964/Ur1IInnmfCgZJJr06VOxokZnifUBa2bKrfvZBhfb1NcDO+SSa3NenudQsLbVBC5tPmi81RlA24kLnHXHPPXtXOStXfTVkWiKVqrStUsjVVlbrVMRYB7U8c1XVqlVq2Uhk6mq9xAJXOXYcjBHb3FSBqqXkhSY4YjjPWm5JjOo0DVLq3ENzJL5kjKPMJ43/WvQNK1CK7hEsL/Udwa8p0w7LOIB3YFd2WOevOPpWrYajJZTo8Um1mOAP73fFcs4J7EntGk6wUxHOxI7N6fWuz0fXJLdVUt5sJ7Z6fQ14xo+tQXihWYRzf3Sev0rorHUprcjY/y9welcc6VyWj2y01O0niMizqoUZYOcbR71xX7QnjC/8ACPw0u5dKu5bW+1GVbGKWJirIGBLsCO+xSAe2a8w+Jvj7T7Hw5eaQGkOp3cG1I0GQgJ+8x7Dg8dTVb4qau/j34TWep6dO9yunzrPPCSC8XyFHyB6Zz9Mms6eGtOLltcSR4XEdvA4HarEcrKeM1VVgD94fnUmQR94fnXuXNDc0rVHt5AdxFeqfD/xxNp15DPFMVZGBHNeHKxU/e/Wr9jqLwMCHxj3rKpTUkDPvnTvEg8S6dFfpcvKjAAoWyEbHIxUdxf20MQledNjDKkHO4e3rXz94M8af8IV8OludYnlim1KVpbW3VcyuoUBSAeg75PYj1rR8DeKre98KWwZ2a4t08uRMjPXg/SvFeFs3bYz5T03V9feQGO3zGndu5/wri9W1lVykLbm/vdhWVqGqT3GVLbE/uiuf1TVbe0U+Y2X7KDya2hSsNIt6heJEjzTyYA5JJrzzxjqUupWs8aSNFEFOAO49/rU2sajcXjB5MrGc7F7VgaqfMsZlLuvyE5U4PArshC2pWxJo+tanY6dc6IlwkljdjEsbxc5UkqwOeCCo/WoJWrn9Glllv08yaQgKWxu6n/JrakarVkAyVqrSNT5GqB2pNiLCtT1aqivzUiyVdx3LYbiqN+/78j2FWFes67dvPbcwJ45AxRcdzesn/wBGix02ihrlV1O3SZJRAmWeRBkgkEDjuKq6e7fZk3MDxxgYwKrancSpdoiMAGUdVzjmk2I3dQupbewlmhfbIgBBxnuK6TS/EM8KhZCJk9c8/nXHas5OlzqTk7Rn8xWfouqx2ds0MyuQGyu0dM9alpPcC/4rguda8Wzy2kW7z3WNNzBeRGpOSTwMd6PD9xrfhmLUL62eSzlaExq3BBZZkVgR0OM/rVQaxCL0TCOUqJGftnBQL/SoL3VBPbyQqJAHZzyePmdW/wDZarpYDZHxF8XgADUYTj1soT/7LTv+Fj+MP+gjB/4Aw/8AxNJZXel2OiWk13pVlcMyAZaAFmPuaUeJPDo+94Wsz/2zA/rU6dgD/hY/jD/oIwf+AMP/AMTSH4jeLyMf2jBj/ryh/wDiacfEfh0j5fC1mP8AtmP8aZqF5pd9od1LaaVZW7quMrCAynjoaLLsAviifWfEllpGoXDPdzralZGAA5adkUADjrgcUeFU1HQfFMK3qmJI5BHMA4b7yMR0PI4rIttXMNpDbt5pEYQYB4+WUv8A1qWXWopLwzeVLgyI2OM/KGH9afTlA9C1TxLIykQYiXuzHn/AVy1neTXVjFPcSGSRwSx9eTWDrGqre2whijdBuy27HOOlaGlMRpkCg87P6mkopDLlldwXmmyvK8kN3FL8kDJ8rxnuG9QcZHvVPUH/ANDn5/5Zt/Ks7TbiV710dwQgI4XGean1JnNpJtYDg5yM5HpQnZCMfR/lv1Of4T/KtiR6xrIMLldhCnnkjNayqX5JwP50K8tELcjYljheTTTDIw/hH41ZVVUHaMZpN2K0VJdSlEz1enq+O9VEapVasOYktLJVO7bM7fh/KpgTVaUM0jE8H0p3C5qWL/6LHz2qrqThrtCDnaBn25p9mx8oAjAHQ561Heczg+gFFwNLUHD6fKQcgr/Ws+7s0htYpVclm+8D06Z4q3dtm1kGe1RXciPaxoHBIIyAfancBuj2cM+95wWVTgLnFN1a0it508rIRxnBOcVY0p1jjkDMBlu59qbqzLI8W1gcA9DTuA+8Qy6Xp0K9Sdo/KtO1s7W2QBIlZu7sMk1nE/udPH91xWlvoTGJd2drcoVaJVbs6jBFZlqhi0rUIm6hsGtTfWaT+4vx/eei4FCwt1uLtY3JCck468Vd1WwtorfzYFKFSARnOag0wiO7DMQPlPJq5qUqPaModScjgHPei4Gfp9oly7h2KhR29a07FtlnEp/hBH61X0+PyQxY4LAcVYU/Lx09q0jTbHYzbBXS8dmVl3A4yPerc6GWF1zgEYzT1b5qSRjg0/ZLqPlKkNmiSBg7ZHtVvgAAdqi3HNDMe9Wko7Boh5emk5qPdnvSM3pQI//Z",sizes:"192x192",type:"image/jpeg",purpose:"any maskable"},
      {src:"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCAIAAgADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD45ooxmnYxX3R1oBxSgUAU8DpVDAKadRTgPT8aAALT1WlC8U/b9AKoBAOwp68e/wBaTHpTlGOgpgFOC7valA6cU8DtVJWHsIBTgMe1KB6U8DJphYaAafj0pwQ4pwX6UANC07bntTgOelPx60DIwKeBxTselOxmgBm2nbT3wPrTwKcB6qPxpgMxjuT9adtPpTto9KUL9BSAbt9qXA7U7H0pdvtTsMZilx7U7BpcU7CG4+lGKfj2pMH0oSuOw3FGKft9qNv0p8oWGY96Me4qTZ9KMY7D8KVgI8e4pMVLj2FN2n0osAzb7UEVqRy6UPDk0ElpKb8zKyTCUABdrZGNvqRxms7FAERFG32qTHNJj86BEe09iKaQPSpsUxlGO4/GiwEJWmkGpitIQRSsBDj0pCPbFTEetMxSAhIwelN2VNimlfWgCAikxUxU0wrQBCy5FNK+1TFQTzTNuOtAiFgQaaRUxX3ppXNAEJGeoppGDUpHrTSOOmaiwiEimkVMw4qMrSEQ0hFSEe3HpTSMGpaDYjIpMZp5AP1phBpbjGEYpKf1GKaRipYrDvpTgM0Ad6eox1qxhjApw59aKeopgCg9qeAKAop4HemAKM9afye1Az3pwHrTXcdhoGaeq0oGe1PA56VYAAAMflTh9KUDmnhCOT0oGNVc1IF9qUCngZ6UAIBg04D1pcY6CnhaAG49KUCnhSfenheKAGBT9acF9ad9cfhTgPQU0AmPwFGKcBTgPUCmNjQKUCnbfwFO207DGYNKBntUgXtShadgI9vtShcVIAB2/WjGKdgI8UpTHoak2k0bfcU7AMC4pduey/hTwBS49iKAIsY6hfwpSvsPwqTHsaMetAEOyjZUu2jb7UAQlT0pCvsPyqUqTRtpWAh2+1IVqcrTSKLAQ4I6CmkVMVI7ZppUntU2AiIppB9Km203bik0BEVFMK1Ng03r0oEQFaaRVgrTCvpSsIhK5phUVMV5pu3tSAgK00jBxVjHtUZFAEOPTpTCvFTFeKaRQIgI54phGKmK57U0j86VhEJHoKaV9KlxTSPSk0BCR6VGRzxU5GelMI9KhgQkYNNYZFSkZpmMHFIWxEQaQjIxUhHfvTDwaW4yQLTqO1OA9KYChfSngcdKAOKeB61QAB604DHJAoA9aeBzz+FOw0AHrTwDmhR37+tPA4qrAAHpTwM9KFFSKuB05pjBVp6jHWgD0pwFAAF9acFzSqvtUir7UAMC1Iq88/kKcFx7U4D0qgGge1OApwWnBc0DGBadt9qkCn1FLtquUYwCnBe1P289acF9qdgGgew/GgLUuygL7UwGAZ9KUDPapQue1PETGgCDYaXZzzmrsNjPMcRRPJn+6Cf5VoxeG9SlwRbbB6uQKhzSFcwtuKdt9APyrqI/Cd23LyxJ+Zq0nhFf+Wl0c/7Kf/Xpe1iFzjdh96PLbuK7hfClqPvTTH8AKkHhSxxgtOf+BD/Cp9tELnCbCO1IYzjpiu9/4RWw/wCmv/fQ/wAKY3hSzPAkmH4g/wBKft4hzHCFSOoNJj2rt28JQ/wXDj/eUGq0nhKUD93cxn/eXFCrRYXOQ2D0o24ro5vC+oJyqROP9l/8aoTaRewj95ayL77eKtTTC5k7fpSEZ7VaaFwelRmNhTuMg2U0rVjYfwphXFMCArx0ppUipitJtoYEBX2ppGR0qcrmmFanlEyIjimY9BUzD2FMZcGpEREUwripSM0m0/WgZBimkZ+tTMufp696RhjrjFKwiBh60wjPTrUzDjmmFTSAhI9qYR61My0wjFArEJRtpO04HGajIweK2ItV8nw3c6UbGyfzpkl+0NEDIu0MMBs5/irLYcUAQkHtTCM1MR3xTDUtAQkd6YwwKmI9qjYcVLQiGkIp7DnpTakVh4GalUYpqj161IBnpVDACnikA9KeAfSmgFA/KnAfnQBnGRzUgHYVYABx/WpAPakUVIo/AUFCqtOA7UBT0p+DQMAM9Kcq0oX8KkAOcmmIQLUgHFA604Lz60xiKOeaftP/ANalC4HAp4XmmlcBqqaeFx70oHsKeBV2GJtHtS4p4QgU5UyeBQAwL608KT06Vat7KWeQJHG0jnoFGa6Gx8KzPhrp1iH9wcn/AAFQ5pbibOYWBmrTtNBvrrBS3Kqf4n+UV2tno1naAGKAFh/G3JrSWDnpWLrdhNnJ2vhJBg3M+f8AZjGP1NbNroNhCQUtFY+r/Mf1rZESjnHNOC1k5yZJWS2VV2gbR6AVIsCVMFPeneXUjsQ+WnpThGOwH5VMIz2p3lE0AQbBjpRsHov5VY8k0vkfQ/hS0EVto9BSbR6CrRhPoPypDDTshorFc9h+VJ5Y71aMRxmmmJvQ0tBFQwr6VG1uMdfyq6yH0ppQ+lMdjJn0u1uMiaCN/qOfzrLuPC9lICYvMib2ORXU7aaV46U1KSDY4C68L3cWWiKTD/Z4P5GsS5spYX2yRsjejDFerGIMPSqs9lHNGUliV1PUMM1oqz6hc8paM57Uwriu7vPC9tLlrcmFvQ8r/jXPX2h3VpkyR5T++vIreNVSKuYZWmlRnvVl4Sp6VEVPerGV2XvTCtWMe1NK+lMCuRTcYqcrUbDjpUNWFYhNNx7ipSKaR60gICuD0ppHtUzCmFeeKW4iErzxTGXj2qbBPQUwj2pAQFcdKYQO9Tkd+1RkYoAgI/8A10w8dKnK8Y7VGw7Ac0CICOc5NNI7jgVKy/l6UwjFSIiIqMqamYUxhxzUgSgU5Rjp+NCj1pQBjpQAoHYVIq8ZoC5/rTwD/wDW7VYwUZPvUgXjikA/OpAuO1MYoGOlPAoANOA7UAKAc09VH40KvFSAelPYAAx9acB2FAFSBeOn4Uxgq8U8D25pQMfSpFX2ppDGhKkAo+gFSKMcVYDAOakVSex/GnpCzdRW7pegXF5iRgY4v75HX6CpcktwMiG0kkkVEQsx4AAyTXTad4WZtsl6dg/55r1/E9q6HT9Kt7JAIYgD3kP3jWmkYXsM+tc0qrexNyja6dBbR7IIURe+Byfxq6sSgc1KB6AYp6oayeoiIKB2/Onhc9qmSInsTWja6NdTYJTy19X4/Sk3YLmWIye1SrAWOAuT7V0sGhwIAZS0h9OgrRhtYoRiKJE/3RUOohHKw6Tdy/dgZR6twKux+H5TzJIi+wBNdII6kEZz0rN1X0AwY9BgGN0kh+gAqwmjWa9YifqxrZELdhTxbN6VPO+4GONMsx0tk/HJp4061H/LtFj/AHa2PsxPUUv2Ueg/Ol7QVzH/ALPtsf8AHtF/3yKadOtT/wAu0X/fNbX2X2FBtTnpmlzhcwW0qyPWAfUEioH0S0b7okU+xz/OuiNsaYbdh2p87GcvJ4fGfknH/AhVSXQ7tMlUVx6qa69oDn7tNMWO1UqrFc4SWzkiOJI2Q/7QxUDQ+xrvWiDDBAI9xmqM+k2kuT5Qjb1Tj9K0VVdR3scY0XtTCmO1dJcaDKuTCyv7Hg/4Vkz2kkLlZIyp9xVqSewrmeUB6gVA8Gf4avNEc1GUOetUM5rUPDdrcktGohk9VHBP0/wrlNQ0a5smPmx5Xs68qa9NZc8EVBNbJIpDKGU9QeauFWURpnkjwlT0qIrXd6n4YRwZLIKh7xt0P0PauTubKSGRo5IyrjqCMEV1RqKRSdzOK5qMpVhoyDyKjx+NWMrlcU0j24qwy+1Rlcen4VLQrkBXFMI7GpyPyqMj3qREDLTCtTkcEdqjZfbntSsBCQajI9KnYCo2UUgIGAqMrk4NWCDUZXtQLcgIHWmHI61MR7ZPpTGA6YoEQkZGCKjYcVNg9DTGBPY1mBKBzx0pw60gHOKeB3qkgLemXMFpq1tc3NqlzFHKrtE5IBAYHsRReTQ3OoTTwWyW8buzLEhJCgknGSTVcDtUirzVDQqgA81KBge9IBT8Y60DADtUij2pFXnpxUgGKYCgdhTwuaAuelPA6cU0MUDJp4HpQAfYfU08LVJXGKq08fSgDPXpUiqT0FUAijPGKtW9o80oRVLOegA61Y0/TZ7y4EUMeWP5D3Nd1pWiwWEeVAeUj5pCP0HoKynUUdBN2M3SPDaR7ZrxQz9RH2H19TXTRwgDpUqIFHv2qRRz61yuTluQNC9Keq57U9YyT0rSsdJnusHaUT+8w6/T1qW0hlCOElgACa2LPQppAHmPlL6YyTWzZ6dBaj92nzd3PWr6Rj0rGVXsIo22n29sB5cY3f3m5NXVjGasJbsx6VpWej3V1jyYSR/fPCj8axc+7Ay1hYnoanS1ZiMjmustfDMaAG5lLH+6n+Na9vYWtuP3MCKfXGT+dYSrJbCbONttCu5sFLd8erfKP1rTg8LSf8tZY09gC2K6oJzTgtZOs2TcwY/DVouPMklf9KtR6Hp6j/j2B/3iTWttHYUY9qlzYiium2SfdtYR6fKDUgs7cf8ALGIfRRVvFGKXMwKptIf+eMZ/4CKa1hanrbQn/gAq4RijGetLmaAzW0iwfrax/gMfyqrJ4esH6JIn0b/GtzaPQfhSbc+1PnaA5iXwxGQTFOfo6/4VnT+G7tPuokgH90/0rtyvFN2D0q1VaBOx5vPp0sJ2yRsh9GGKpvbEdq9QkhWRSrIGHoRmsy60GymzhDET3T/CtI1+47nnjRH0qCW3SRNjoHU9Q3NddeeHLmLLRbZU9uD+VYk1mysVKkEdQRW0Z32GtTlrnQ4nJa3Oxv7rcisO6sZrd8SoR6HsfpXdvCRziq8sCSIUdQynqDW8ancZwLR46CoSuDXU3uhggva8H+4f6GsKa3eN2RlII7Gt1K4yg0YIxWZqGlW97HsmTDD7rjqtbLJ69KjI/Kne2wHm2q6JPYyEsu5D0cdD/gaxHiIPOcV63PbpLEyOgZGGCCM5rjda8PNbbri2UtD1I7r/AIiuinVvoykzkSMdqYyirckJVjxUDLit07lFcr70wjHapyBUZGOtJoCAjuaY3TFSkY6VGenNIViEjHSmMPyqYjPao2GOlIRCRjrTGHOR1qYjjmo2BqQISKiIqcjvURA6Y49KBEZFMIqVh3qMj3qRDwKkUUij9aeB61QDguakVeOmfekUVIBQUKBT1GT0pAKkVfXpQmAqripFBzQBT16VQ2Ko7YJ+lPUGkUY6VKo9qaGAWpAtAXnGKkVcnAqgBFy2B1rX0vSpr6cJGuB1ZiOFFJpelS310scQ92YjgCu/sLCKzt1hhXAHU9yfU1jUqW0QmxunabDZ24jiTA/iY9WPvWkqAChVAwMVKqk4rlbuQIq5wasQwNI4VVLE9ABnNTWllJcyiONcnuT0FdRYabFaINq7n7sRz/8AWFTOdgKNhoiIBJcrlu0YPA+vrW2kYAGB7YqVIie1XbWyeaRURdzHoq81yyqXFcqpATjAxWtp+jXF22Y48L3dugrd07w5HGBJdgOe0Y6D6nvW+kSqoVVAA6ADGK551ktEJsyrLQLW3w0o86Qd26D8K1lRR0HT8KkC5pwXmueUmyRoXjpS7cVJt9aMZ7UgGhfanYHvU1va3F1II7aCSZvSNS1blp4N1q4AMkUdsD/z1bn8hms5VYx3YrpbnPbaNvtXdW3gGHA+1ahIx9IkC/qc1pw+C9CiHzQSTf8AXSQ/0xWTxUETzo8yx7Uhx6j869bj8OaHH93S7b8Uz/Op10nTF4XT7UD2iX/Cs3jF0Qc6PHRj1/M0uM9K9jOm6eRg2NsR7xL/AIVG+iaQ4w+m2h/7ZAUvra7BznkO09xmk2n0NeqSeFdAlHOnRp7oSv8AI1Qn8CaU4/cT3MJ/3gw/WrWKh1DnR5yVHuaMV11z4EvkObW9hmHYSAof6isW70HVrHJuLCQIP44xvH6VtGtCWzK5kzJwPSmlc1OVpm2tEMhZc9qp3VhbXa4niDHs3Qj8a0StMK+1O7QXschfeGpEBe1Pmjuh4b/A1z09o8bFSpBHUHtXpxX1FUL7TLa9Q+amG7OOo/xreNXox8x5rJHjgiqF5YQ3KYkTkdGHUV1up6JPaEsVDR9nX+vpWLLCVJ4rqhPqizh77TZbV8kbk7MBwf8A69Zrxmu/lhV0KsuQeoNc9qWjtFmWAZj6le6//WrojUuBzhUj0qF0BHIq68ZFQEY5rRgcZrvh8BXurOP5erxgdPcf4VyEsO1uBzXrrpkVyev6EDuu7WP3dB/MV0U6ltGNPocMRUbD2q3NFtPSoCPrXQncsrsPWo2WrDLxUZHtQBWYZprA+lSsD0ppqBEDLUZHtU5FREUrCISPao2WpyPao2GaQmQHjNREdu1WG6ZqEigRKP8A9VSKDQAM09R60DsOAp4FIBT1HegY4DBxUigCmqPzPQU8daaVxj156dqeBSKMcAVIKYxQM1IAaRBx+NSKM00AqitLT7GW7uEhiXLN+Q9zVa2gaSQBVJJ6CvQdE0lbG2ywHnOPnPp7VNWfKhMt6XpsVlarDGPdj3J9a0woAwKao2ipVUntXE3ckEXmtLT9PkupgqAAD7zHtSWFg91OEUYH8TegrrrW1jt4lijUBR+tROdhDbSzit4hHEuB396vJGegFOjjJ4xit/R9Fa7YSSgpD692+n+Nck6nViuVtM0ia9kwi4QfecjgV2Fjp0FjFtiX5j1c9TViCCOGJY4kCqvAAGKnC/lXJKbZAgXjpT1XHHf0pVXtingYFQ2AgHc04H2rW0jw7f6swaFBFB3mk6fh613eleF9M0oLIqefOP8AltKMkfQdBXNUxEYadSXJI4jTPC2q6iFfyfs0J/5aTcZ+i9TXW6f4K0q1Ae633kg/56cKP+Aj+ua6aiuOdecupm5NkcMENvEI4IkjQdFRQo/SpKKKyJCiiigAooooAKKKKACiiigAooooAzL7QtL1HJurSNmP8aja35iuW1HwJKgL6ZdCQf8APKbg/gw4/Ou8oq4VJR2Y02jxq6srqxnMN3byQv6OOv0Peq5X2r2a6tLa9tzBdQRyxnqrjNcbq/gkqGn0mQsOvkSHn/gLf0NddPFJ6SNFO+5xBWmFatTQSQztFLG0cinDIwwRUOK6lK5ZWeJXUgrkHgg1zmq+HgVaazXjqYv8P8K6kr2FMZauM2tgPLp7YqTkEGqjpXoWraJHdhpoRtm6n0f6+/vXG3Vo8TsjIVIOCD2NdkKl0UtjkNT0fO6a2XnqyD+YrnZIirdK9BdMcd6wdW0oMGuIE56so/mK6qdTox7HKsOcEZFQSICOlXZI8HPeoGGK2QzhvEGi+UWu7dB5Z+8o/hP+FcpLGVbkV63NCrxlWUEEcg1wWu6SbK4JQEwvkofT2ropVOjKTObZc1G68VNIuGqNq6EOxAw4yBk96jIwelTkGo2AFQMgxTGFSkVGaBEJFRt0qZhzUZB6mpEQnrUbDrj8qmYVGRQIlUU8DApoFSKKBigdqmUZ7cVGoyalHTvQMcOvSnKOc00Z7VKBVDHKPSpFHrTVGTUoGDQAoHNTxR73HHFRouSK3tD0w3l4qMD5a8ufb0ok7LUDa8N6SAq3sy8/8s1/rXVxoAtMgiCRgBQABgCrAGTiuOUuZkvUVQTV6ys5LmdY0HzHv6VDDEWcKoJJOMCuw0zThaW4B5lb7xHb2rOUrIkmsrKO3gWONfcn1NaMceSMfypIo88Vv6LpBu5d7giFTyfX2rklPqxN2JNF0Y3JE0y4iHb+9/8AWrrokVFCqAABgAdqIo1SMIqhQBgADGKmAFcUpOTJADjNPA4pRVvT9PutSvFtbSLe55z2UepPYVm5JasRBFDJNMsUSM8jHCqoySa7jQvBkcQW51cLJIORbjlV/wB49z7dPrWxoXh200eDcuJLlhh5iOfoPQVt1wVcQ5aR2MpTvsNRFRAqgBQMAAYApQM0tFcxAmKWiigApDS0UAAGKKKKACiiigBtLilooAKKKKAAnFIBmlooAKKKKACm06igDN1XQ7HV4Nl1F8wHyyrwy/j/AErzrWfD97o8uZQJLdj8syDg+xHY16vTJoY54WhmRXRhhlYZBFa06soehSlY8VYZqMjNdZ4i8LSafvvNPVpLXq0fVox/UfyrljyK9CE1NXRqncgKgjpWVq2kR30JdAFmA4b19jW0QaYV57fjWqlYZ5jd2jRSMjoVZTgg9qzpE56V6LrOkrfQmWJcTqOMfxD0rhrm3KOQVxjr7V2U53RSZyGsaaFJuIV+X+NR29/pXPyx47V6BIgIIIyD1HrXK6rYG3nyqny26E9vau2nO+hRhMtUNQsY7y0eCQcHv6Hsa1HUg5qFh+VabO4Hleo2T2tzJFIuHU1mMMHkV6J4i0oXVoZ4l/fR88dx6f1rgp4yrHsK66cuZFoqMPaoiOOlWGHqKjYc81oMrsPSoyPapiMGozUgQsuDUZGO1TEZqJgc0iSIjvUbD1qYio2HFICRR+dPFIo4pw5NAEijinjmkFSAVQxyj06VItMUU8c8c4oGPQd6kX0pFGBUka5amBZtoS7gBck8ACvRtG04WVgsZUeYeXPv6fhXOeGdOE119pkX5IsYz3b/ADzXbxrgCuerO+hMmPUADipo0JamovNaWm2ZurpYhnHViOwrFuwjV0PTxxdyL7IP5mujiTpUUESoiqowFGAKv28RkcAAk9ABXHUldiLul6e95dLEowOrN6Cu7treO3t1hiXCqOBVTSNOWxsghAMjcv8A4VpqPSuGpO7MwC1KFx2pAAB04q1Z2c9/eR2lsm+VzgD+p9qylJLVgP0zTbnVb9bW2TLHlnPRB6mvUtI0e10exEFsuSeXkPVz6n/Co9E0e30fTxBFhpGwZZMcuf8AD0FalebWrOo7LYxlK4UUUViSFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUVkeIPE/h7wppDap4l1vT9Jsl63F9cLCmfQFjyfYV4pr/AO2d8CdDlMUGu6jrRXgtpdhI6fg77VP1Bq4U5z+FXGk3sfQVFfM1j+3T8Ery4EUsXiezUnHmzacHUfXy3Y/pXtngn4leBviPpLaj4J8S2OsQpgSLA+JIiegeNgGT8QKc6NSGsotA4tHW0UUVmIQjNcH4o8LCAPqWmx/u/vSwqPu/7S+3tXe0hGRVQm4O6GnY8TI7imEZNdb4r8OixkbUrJMWzH94gH+rPr9D+lcqwPpXpU5qaujZO5AwGK5nxDpIkVryFeesij+ddSQO4qJ0DKQeQa6IyaegzyuaIoxGKzru2S5t3hfgHofQ+tdfrml/ZbktGP3T5K/1Fc3IuM12wldXLRwd3btFO0bjDA4NUWXBxXXa1ZebB9pRfmT7w9RXLyr1rsg7oEUpFBFcF4i00Wt8WjTEUnzL7eor0FhxWTrFgL3T3jH31G5T7+n41pCXKxnmDLhsdqiYVduoikhyOnWqjCu1dyyBh61Ew56VYYHHtULdaVhkJ6mmMKmYVG3PWkSV6awHpx3qQ8U0jtUiY6npTFqVegpjHqKkX6CmrT15pgPFSL96owOKmQYFBQ4cnFXLaIu4UDJPAFVkXLAV03hmx8/UhIy5WIbz9e3+falJ2QHW6TZCz0+OHHIGWPqe9agHOKjiXAFTqvNchJJEpPauv0Wz+z2gdlw8nJz2HYVgaVaC5vUQrlR8zfSuxjXgVhVl0JJ415wK6zw3pwZheSLkKcIPfua5/T7Vrm5jijHzOcZr0O1t0t7ZIYxhVGB7+9cNadlYlssKAPapAB+FIop6iuYkcoJYYGT2HrXpfhbQhpdgZp1/0uYZc/3B/dH9fesDwZoouLn+1bhMxRHEQP8AE/c/h/P6V6BXnYipd8qM5y6ATikzQRmlAxXMZhUN1d21jayXV3PFBBGpaSWVwiIB3JPAH1rgPjD8YfC/wa8BN4h8Qu09xMTFYabCwE15LjO1c9FHVnPCj1JAP59a74t+O/7UXi6WzsdN1HU7GKTK6RpgMen2Q7eY7EKW/wBqQk+gA4rrw+ElW95u0e7LjBvU+4fE37VvwK8L3MlrceN7fUbmM4aLSIZLzH/AkGz/AMerkG/bn+Cok2rB4qcf3xpgA/V814Pov7CfxRv7JJdY8Q+GtHZh/qA8t06+x2qF/Imr91+wN4/SMmy8eeG5m/uy208X6jdXYsPgVo6jZajDufQek/tl/AbVJAk/iO/0tj0+36bMg/NVYCvSvDXxa+GnjAonhrx14f1KV+kMN6nmf98Ehv0r8+vEP7Hnxz0BHltdAsNciTndpN8jMfokmxj+FeM+IvC3iXwtqH2PxV4d1PRrgHhNRtXhP4FgAfwNarLcNVX7qpqP2cXsz9ngfXilJxX5DeE/jN8VvAojXw1481u1gTlbWWc3MH08uXcuPoBXvHhH9u/xzpwjg8ZeFdI1yIcNcWTtZTH3x86E/gK56uUV4ax1JdGS2P0BJxRXzh4W/bZ+C2uBI9YudX8NzkfMNQs2kjB9pIt4/MCvTtM+OXwd1iATWPxN8Ksp7SajHE35OQf0rgnQqw+KLIcWj0Go5J4opY43kRXkJCKWALYGTgd+Oa8z8R/tE/BXwvZPPqXxH0GVlBIhsLkXkrewSLcc1856N8ddT+PH7a/gKz8JaddWHhvQri5u18/AlnUwOkksoBIQbSEVcn73PJwKp4apNOVrJAotn25RTR0GTzXH6v8AFj4Y6Bemz1r4geGLC5U4aC41OFXH1XdkVik3olcmx2VFc/oPjfwd4n/5FvxVournGcWF9HOfyUk1v5GKVmtwAnFfJXx+/bH03wddXXhP4ZLaavrkW6O51WU77SyYcFVA/wBdIO/OxT1JORXP/tdftKXWnXd18JvAV+YboL5et6nA2Gi3D/j1jYdGIPzsOQDtHJOMT9kn9mu08QW1p8VPH2nrLpwYSaLpU6fJcYPFzKp6oCPkXocbjxtz6NHDQp0/b19ui7msYJLmkYXw6/Z1+Kvx/wBTi+IPxb8TapY6VcYkhmvf3l5coenkRN8kEfoSBkYwpHNfWHhT9mT4J+EbWNbXwLp2pTqPmu9ZX7bK59T5mVH4ACvXQoHSlrnrYupU0vZdkQ5tnn+s/A74Qa/p7Wep/Dbwy8TDGYtPjgdfo8YVh+Br4o+N/wALda/Zg+JmjfED4Y63e2ul3czR27yvve2lA3G3lP8Ay1iZQSA3UBgeQDX6L18p/t66nY2/wA0XSZWU3l5rkTwL32xxSF2/Dco/4EK0wNWftVBu6ejRVOTvY91+Enj+0+J/we0PxvaxCA38H7+3Bz5MyEpImfQOpx7Yrt6+dP2Jba6g/ZPsZbhWVJ9SvZYcjqnmbcj23K1fRdc9eChUlFbJkSVnYKKKKyERyxJPC0UqhkYFWUjIIPavLfEGjPo+pFFBa1k5iY/+gn3FerAYrP1nTIdV0t7SUAE8o5H3G7GtKVRwlcqMrM8hZccZFRsM1auLeW2uZLeZdssbFWHoagIr1E76mxm6hZreWbRMBk8qfQ159e27RTujLhgcEV6cy8VyviTT+RdoOvyv9exroozs7DTOIkQEEFcg8EVx+p2htrt4wPl6r9K7eWPBPFYus2vnWZkUZaPn3x3/AMa7qbsyzjWGGqCRcqTVyVTuqsw7HkV1AcB4l0/yL9pEXEcvzD69x/WuaZSDzXpev2X2rSpNoy8fzL/X9K85uE2yGumlK6LRVYVC9WCMioWHFaDIWBx0IpjD5qlIqM8DNITIWFRmpnqIipEKvWpl6VGoqReRTQEgqQDFMXnFSCmND1FSimLyakXrTGTwoWYV6H4ctPI0lXK4aU7/AMO3+feuI062NxdxQqOXYLXptrEqRqqjCqMCsK0uhLZYQYqxGuT0qFRzXTeFfDcuu3g8xzDaI2HkHU+y+/8AKuaTUVdkvQt6HbCKy81hhpDkfStuNCCAR19a73T7HTdNgWKzto0CjG4jcx/E1ogQXA2SRJIDxhlBrglWu7iuYfhexwjXbjn7if1P9K6dR0wOakXT4YbcJbIEVf4B0/D9aIomfpwPU1yTld3IFAq7p9lLqGoQ2cI+eRsZ/ujufwFRLAoHJJNbmgTtplw15HAkhddnz9hnnBrGpdR0E/I9Es7WGxsYrWBcRxqFUVR1TXbXS1CODLMRlYlPP1J7Coxr1vLpUtwg2yoP9Ux5yen1FcZMss9w80zF3c5Zj3rgp0eZ+8Zxjfcvz+KdXlYmHyYV9Am79TTY/GV/ZI8+otA9vGpeSRhs2KBktkdgATWd5X0FecfH6/m0b9mnxhfWz7JXsfsqsOo86RYifyc12woQk1GxpyrY8D0fSdZ/bG/amv8AV9Qubmz8G6WAMocNBZ7j5UMfYSykF2btyf4VFffPhfwn4e8F+GLbw74X0m20zTLZcRW1um1R6knqzHuxySepr5m/ZM0UeF/2fdJ1i0QC51Wea/mP98bzGin2CRj8zX1bb3CXNpHcJ911DCs8e2pKC+FbEVNHYmpMiq739mjbHuoQ3oXFfBn7Wd14q+Fn7RGl+NfBPjLW9NGu2puSkN9I0STxMEcCMkoUZTGShGM7uOa58PQdefItGTGN3Y+/ODVPUdL07VrF7LVLG2vbVxh4LmJZUb6qwIrzz4BfE0/Fv4Iab4suYo4dR3PaahFEMItxGcMVHZWBVwO27HavTXYICxIA7k1lKLhJxe6FseAfEH9lL4D61p91q9zpS+ETGjSzX+l3ItIowOSzo2YgB34FfCGq/DnStc+MEHgb4M6/feOnuXKR3DWH2RBjq28sQY1HJkIUemcivQv2pf2hbz4l+L7vwf4bvmj8F6ZOUzE3GpzIfmlbH3owQQi9DjceSMfV/wCyt8GLb4Z/CW31jVLRV8U65ClzfSOuXt4j80duD2CggsO7E+gr2IVauEoqpOTu9kbJuCuz4a8Q/s5fHDwvK41D4c6xcxp/y30xVvUI9QYiT+YFcZL4I8bLceTN4K8RiTONr6VPn/0Cv2W2rnOOaNvufzqY5zUStKKYvbM/KPwb+zb8ZvGlzHHp/ge/0y2cjdeauhsoUHr8/wAzfRVNfeXwB/Z80P4K+H55zdrqviS/ULfals2KFByIYlPKxg8nPLHk9AB7VgUprlxWYVcQuV6LsiZVHLQ/PD9qr4/+K/EXxN1P4Y+EtRu7DQdMn+w3S2LFZdSuQcOrFfmKBjsCD7xBJzwBzvgz9jL4x+J9Mj1C9stK8MwyrvSPV5is5B9Yo1YqfZiD6ivbPhz8Er/w5/wUM8Q614k0aa40to7zXNE1BoS8DyyyrwXxgSxiWQYODwGHY19iAADiuieN+rxjTw9tld+ZTnypKJ+c+p/sOfGPSFF9ouq+Gb+5Q7lFpey20oP+yzIOf+BCqE3xe/al+AkP9geMX1Bbe6ikhs21+NbwKQMF4JwxLFMg4LMOmRX6Tk8V+Vf7T3xOPxM+P2p3dtceZomjltM04A5UojfvJf8Agbhjn+6qela4OtPF1OWqk0t9Bwbm7M5H4bWXhHxB8ZNKPxO186f4ekuWuNTvJw8huOrFGZQSPMY4Zz0BY5zX6yeFfEHhPXtBhl8H6xpWo6dGipGdMmSSONQMKoCE7QBgY4xivm34OfsnfD3U/wBnTRm+IXhxpvEOox/2hLdxzvBcWokwY4gykcKm3III3FqytY/YUj03U31T4a/E7VtFuAcot5GWZf8AttC0bfmDWWNrUcTO3Na2m2gpyjJn2LketGR6ivjEfCj9tjw2yw6L8WrTVoV4UzahvJHbieAn9TTJvh5+3LrZ+zX/AMRLSwjbgvDqUUOPxhg3flXJ9Wj/AM/ERy+Z9ReP/ih4K+GPhx9Z8aa5badEFJigY7p7hv7sUQ+ZyfYY9SK/PfxRrfjz9r/9oW3sdB0+S1063UxWkT/NFpdoW+aedhxvYgE46kKi5xmvZdB/YY1LWte/tr4sfEu61S4Y5lj07fJLJ7G4nycfRa+qfAXw48G/DPwwug+C9Dt9Ms8hpCmWknfH35JDlnb3J+mK1p1aWFu6b5pd+iGmo7FrwT4S0vwJ8P8ASPCGioVsNMtUtot33m2jlm/2mOWPuTXQUUV57d3dmYUUUUAFFFFAHD+N9IIVNWgXpiObH/jrf0/KuJI5zXtF1bRXdnJbTANHIpRh7GvIb+zksdRms5R88Tlc+o7H8Riu3DVLrlZrB9CkQaq3dutxavA4+Vhg/wCNXGAqNhkYNdidmWeY6hbNDcPGwwykg1lyqCCCMg9R612fiayxcC4UDDjB+o/+t/KuTkTBNd8JXRaOE1G2+z3kkeOAePes5hk4NdRr9uCiXCjnOxv6VzTrhq7Iu6uCKcy8HgGvONcs/s2ozRDoDkfQ9K9NkXK1x/iy0yI7kDsUb+Y/rW9KVmXE4j1+tRsOeO1TyDD1Ew7nrXUUQEfWozUrDIqI9TSERHp9KjNTEc1E4qWIeo4zkU8VCrYPNP3ntir5B2JwMmpQKrLKw6gH6VZjZXGVNFmMlTpn8KkUVGtTxDLUgOn8K23m6n5mOIk3fieB/Wu7iXCVzXhO326fJMRy74/If4muoQfLiuSo7yIZLDG0s6RqPmdgo/GvWPD3lWlqlvCMRwoF+pPU/WvMNNIXUY3OPlyRn6V6FpExWwDZ5Y5rmraoR1qXZPetfSSZbnd12jNcnFNkgZrrtCXbYeYc5du/oOK4amiIZtBuOtPVu2RUCmng+tc4ixEryzJEn3mIUV0q2gRFRV4UYFUPDNobjUXnI3LCvp/Ef/rZrqvs3HIrmq1LOxMnYxvs/sKDbHHStk23tSC2x/DWSmLmMb7P7V5d+0RoV1rH7MfjG1s4zJNFZC7CgckQypKf/HUavavs3qKbJZRS28kE8KSwyKUkjcZV1IwQR6EEg1cK3LJSQKSueB/sr61Z6/8Asx6LbwSK1xpEk2nXCg8qQ5dD9CjqR+Ne1mW6+yJbeYwiTOEHAPPf1r4h1e38b/sffHS51HSdOm1TwBrUmI4nYrHNHklYS+CI7iLJCk/eX1BOPofw/wDtR/AzXNJS5uPFy6HcYy9pq1vJFIh9MqGVvqpNdFek5P2kVdPUqWuqPUjbBh0r4U/bN8RWuofGDSfDNrIsjaLYH7TtOQss7B9v1CLGT/vV678Tf2yPBOi6PPY/DQt4h1iRSsd7JA0dnbH++d4DSkdlAAPc9q+afhZ8KfGvx9+JM9wZrtrSS5NxrPiCcFliLNubBPDzNzhB06nCiunB0vZN1quiRcFbVn2N+w3pt1Yfs0TXlyrKuo6xcXUCnvGAkW4exaNvyrY/a9+J8nw++Ak2maZctBrPiJm062ZDhooiuZ5B6YQ7QexcV6d4d0Ox8HeHbHQ9Btha6fYW6WtvD12xqMAe57k9ySe9fnt+154/l8ZftHXulJLusfDkQ0yJV+75v352+u8hf+2Yrkw9H6ziuZ7XuZxjzTucr+zx4AT4h/tG+G9BuLcSadbzf2jfLj5TBBh9p9mbYn/Aq/WUcV8XfsD+Dgmk+KvH08WGnlj0m1fH8KDzZcfVmjH/AAGvr7X/ABDonhfQrjW/EOq2el6dbrvlu7yURRoPcnuew6ntUZpV9pXcV00FVd5WNSivnPxJ+2v8EdDlji0y/wBV8Rsxw7aXZkJHz3aYoD/wHNet/Dj4l+Evir4LTxP4Pv2uLMyGGWOVDHNbyAAmORD91gCD3BBBBIrhnRqQXNKLSM3Frc7GiuO+IPxT8CfC3SLbUvHPiCHS4bp2jt1ZHkkmYDJCIgLHAIycYGR61N4D+I/g34meG213wTrcOqWSSmGRkVkeJwAdro4DKcEHkcg5FRyy5ea2gWe51dAOa4bx78Xfh18MTaL458U2ekSXYZreF1eWSULwWCIpbaCQM4xW54T8YeG/HHhiDxF4U1i11XS5yRHc2zZUkHBUg4KsD1BAIo5ZJXa0FY8//aX+ID/Dj9nDX9atJvK1O6jGm6ew6ieb5Aw91Xe//Aa/O74C+BF+I/7QHhvwtNEZLAz/AGu9z0+zQ/O4P+9hU/4HXu37enjX7f438OfD+2m/dabbtqd0qn/lrLlIwfcIrH/gdXv2J9I0Xwj4K8Z/GbxXeW+nadDt0yK9uW2pHEmJJjnqcs0SgDklcDJr2sOnh8HKot5G8fdhc+6EUIoAAA7AdqdXyLqv7fHga18SG00nwTr+o6Yr7TfNLFA7juyxNk49AxU/Svpbwj410Dxt4A0/xloF4JdJvoPtEU0g2FQMhg4P3WUghh2INeTUoVKaTnG1zJxa3Piz9r744/EDSvjJP8OvDOu3+g6Xp9tBLM9hKYZbuSVd+WkHzBACAFBAyGJz29X/AGL/AB7448XfCfX38bardapa6ZfLBZalfPukK+XvkjaQ/eCErySSN2CeK19cn/ZR+OvxJtNJ1XVPDviLxLEDBb+RdSwyzKuSY1kQqJgPmIXJ74715x+2dr8Pw2+Dvhf4WeB7ODQ9I1TznuLawTylaCHb+647O8gZu7bec5Nd0eWrCGGjC0n1L3SjY+s9D8Z+E/FElzH4a8S6PrD2rBbhbC8jnMJPQNsJx0PWt2vgP9iDwzeaf+0R4tngnWWx03SRZ3E0QxHJLJKhVffHlyY+me9ffWcd648TQVCo4J3InHldj5O/aK/av174WfFFfA/g/QNLu7i2ginvbrUw7KTINyxoqMv8OCWJ/iwBxX0F8LPG0fxG+EGgeN47I2X9q2izvbbtwifJV1B7jcpwe4xXyJ+15oGieP8A9ovwp4I8C6eLvx/dw+XqMkLfJFBwYfOA6FQXcseiYB6rXuvir4o/Dz9lr4QeG/CV69zqN3bWKW1jplmB59yIxhpm3HEaFsksT1OADg1vUpQdKmqa99lNLlVtz3eivmP4S/tj6H8TPibZeDLnwVqOjT6gzR2lylyt3GXCl9smFUpkKeeR0zjOa+nO1clSlOm+WasyGmtwooAxRUCCuG8dadsmg1ONfvfupD7/AMJ/LIruazdcsv7R0G5tcAuULJ/vDkVdOXLJMadmeRsKYw5xUpHGajbp79q9VM3MjWbX7Rpcqhcso3r+H/1s159cJtkNepSKCDnJHfNedarb+ReyxYxtYj/P4V10X0Kic7qNv51jLH6jI+tcTMuGPFegSdK4nU4vJ1CaMdA2QPrzXfSdtCjOYZHPWsTXbbz9InXGSo3D6j/62a3D3qrPGGUqwGCMGtU7MDye4XDniqp6VqalD5N3LFjlGK/gKzSOCK7U7o0IG64qJhmpm61BM5X5R1/lTSu7ARsQOp59KiLZ7UY9aWtFBAHel60ir25p4GTRcAC59KlQlGBH/wCumqKeBSvcC4vIz61YgGXFVYWG0J3rQtlzIAO/FZNWA9F0GDytFtlI5K7j+JzWyo7VUtECW8cY/hUL+Qq4vauKWruZlm2ykykHmu+tD5dvGmfuqBXEafH5l/DGe7iu3i61jV1A0rdyWr0Kxj8qxhjxjagH6VwWlxedfwRY+9IB+tehxj0rgrPoQyUH3qQdKjWpVBK4HWudsR6B4SsjF4dWYrhp3L/gOB/Ktzyafp9sLXS7e2Ax5car+lWNteTKbbbMWyr5PYAE/Sk8r2q3gf3aNoPbNLmFcqeUaPIz25q3tX0P41wHxQ+MvgL4RaGt94v1QpcTKTa6dbKJLq6x12J/dHdmIUetOPNJ2itRrU6bVNE0rW9Hn0rWtNtdRsbhdk1rdxCWOQehU8GvDdf/AGMvgnrV809npusaGWOTHpeoMsefZJA4H0HFeJeIv22/iT4l1tdK+GvgmxszM22BJoZNSvJPoiYUH2AbHrWtp/xN/bjtIRq938PpL60A3m3n0SNGI/3I5BIPyzXoRw1elrzcr9bFqMkeraH+xh8EtFu1ubrS9X1tl52anqDNGfqkYQH6GvcdI0PS9A0eDSdE0210+wgXbFa2kSxRxj2VQAK8a+B37T+i/FDWm8HeI9Ibw14viDD7DIzGK5KffEZYBldcEmNhnAJBODj35lHeuWvOrzctW9yW5dTm/GGuWfhHwDrPiq/Krb6XZS3r7u+xCwH4kAfjX496jqN1qeq3er6lIZLu7me6uHPUu7F2P5k1+iX7bnjEeH/2eYvDUMu258RXyWxUdTBF+9k/DKxr/wACr4M+H/hSXxx8VvD3hKFSTqeoQ2zkDO2MsDIfwQMfwr2cpXJSnWf9WNqWkXI/Sz9nnQLb4c/sm+G01RorLGntq+oTSnaIzLmZyx7bVIH/AAGvgv4+fGrXPjZ8Rz9lNwvh21mMWjaWoOXydqzMv8Ur8Y/ughR3z9b/ALa3jVvB37PNr4R0p/Il8RXIsMJxttIl3yKPY4jT6Ma+bP2O/AkPjP8AaOttUv4RLY+HYDqbqw4abOyEfgxL/wDAK58GlGM8ZU1fQmHWbL37NHgfwvpn7WOpeCfizpmmTaha2ktrbWOohZYWu90ZKgN8rN5bNt/EjnFdl+zT428JfCL4n/GGy1vXbbS/DNjc5txM+S7R3M0SLGn3ncpgYUEnaPSvYf2kf2e/ht4u0bVfibrGp3vhzVNMsWuLrULII63CRLlRJG3DOMBVYEHoOcDHgX7NXwN8CeKvhdrfxe+KVtdXWl6XPM0Nk02yGVIYw8ry4+Z/mJXG4A7TnNEq1OvTlVm3rZW8/Id4yV2eS/Hb4xal8ZvilLrskctro9ohttKsXIzFDnJZ8ceY5wzY6YUds19j/sMeF5tH/Z8vfEVwrK2u6nJNCD0MUSiFSPqyyfpXwLfTal45+Ik01lZomoa3qGLe0hQKqNLIFjiVRwFXKqAOgFfo98UvEll+zl+xzDpejTRx6jbWEeiaTg4L3LJtMv8AwH95Kfp71rmEeWlTw9NbhU2UUfE37T3jkePf2mvEF9bT+bp2muNIsyGyuyHIcj2MhkP5V9t/sg+Fp/C37KWiy3gaOfWJZtXZWGNqythP/IaIfxr87PAPhO78f/FHQfB1qzGXVb2O2eU8lEJzI5+iB2/Cv0q+PvjfTfhB+zNqLacUt7mS0GjaPbg4IkePYmPZEDOf933qcxjyxp4WAVNlFH5y/GLxk/j347+KvFhcyRXWoSLbf9cIz5cQH/AEB/GvdfhT4B1T46WXh/4bw3c9h8MvByJLq1xbnadV1KXMkgU9yC5VTzsQburrj5Zs7G7vr2303Trea6upnWGGGJS7yMeAoA5JNe3aB8YvHer+AtB+A3wj0qDw9FfH7LNPHchbzU7iTmRnnbasQcg8LzgBd3QHtxdKSpRhT6fh5lyWlkY37SMvw7g+Ok+j/DPStP0/RdHtI9OlexX91PcIWMj5ydxGQhfJyUPJ619JG51P4Of8EtvI1QyWmr6zbSQW8DjDRNfSsQuOxELMxHY5q18Ef2LbDwzq1p4o+KN3Z6xf2zLLb6NagtaQuOQ0rMB5xB6LgLkc7q4T9vHx2NQ8daB8O7ObMOlwHUrxQePOlG2MH3WMMf8AtpXC6kcROnhoO6WrfcjmUmoo8b/Zs8N3Xib9qfwZaWgZUsr4alKw6JFbgyH6ZIVf+BV9iftteDPDus/s+Hxbquo/YNQ8PTebYvjd9oMpVGt8f7WFYHsUz0zXCfsF+A/L0zxH8SbuL5p3GkWLkfwJh5mH1Yxr/wAANbvxJl/4aB/a/wBI+EVkxn8IeDZBqfiF0OUmuBjEJ9eojx6tL/drPF1nLF80doilK8vQ+cbDU/2hP2dvAlpfWBPhvRvE5S6iuDDbXDTN5QZQ24M8bBDnaQMc9819D/si/HT4j/ErxrrfhbxvfJrEFtp4vob826RSxN5ip5bFAAwbcSMjI2nnFeIfth/ElfGvx2bw1ps4bSPC6tYxhD8r3JIM7D6ELGP9w+tfRn7Hvga1+H/7PN14/wBeKWlxrwOoSzTfL5FjEG8vOegI3yH2Yela4txeF9pUiueQ525btanv+meBfCWi+L9W8VaVoFha63qxU32oRxDzrjAAAZuuPlHAwOM1+Xv7SPiLUfEX7Ufja7vpGb7HqD6dboTxHFB8iKB2GQzfVie9foV8BPitqvxh8Ia54putEi07Sk1ie00iRSwe5tkC4dwf4skgkcZ4xxXwh+1j4Ybwz+1h4lZUIg1XytViJHXzUAf/AMiI9YZUmsQ4y3sTS+Kx+gXwL8O+H9B/Z78Hw+HrO3it5tKt7ppEQbpZZIlaSRm6lmYnJP07V6RX58/DX9r3UvBHwI0HwFo3ge48Qa/p6SW6zSSsIRCHJi+WNWdiFIBGABgcmtDTP26/iDpniWOPxt4B0lLANme3tUntbpE7svmkhiB2IAPTIrGpl9dyk7fiS6crs+9qKq6bqFvquk2upWjFre5hSeJiMEq6hgcduCKtV55mFFFFAHkuu2f2LxDd2wGFEhZfoeR/Oso8npXXeOrcR6xb3IGBLFtJ9Sp/wIrlGGM16lGXNBM3i7ogYcVxfiiHbqO8dHQH8eldq/Ga5nxTDutYpQBwxU/ln+lddJ6opbnDyDk1yviCLbeJJ03Lzx3FdbMMMa57X4wbWN8dGI/Ou+D1LOXI5qvKMrVqQfNWbqd/Fp9mZX5Y8LGDyx/oK6Fq7IDg/E8awavOzYCthsn3H+NczJcqDiME+/TNamv3FxfXwuLhgWIwFHQD0FYjL7V6FOC5dTRDWnkJxhfyqJss24nk05hnrQRzitUrAR0h6U7pTT0pgPFPUYpgGfapK57gOVcnrUoHHQU0AVItO4rD0GCCK2NLj8y/gT1kUfrWSg5wAK3tAXdrNsOuHB/LmolsM9Ih+7VhByKrwfcFWUrjMzY0RN2qRH0BP6V2EQ4FcpoC/wDEwJ7hD/SusiFc1XcTOg8OR7tYhOfugt09BXcIOK4/wuoOose6xn9SK7FelcVbclkqjNXtLg+061aQYzvmUfhnmqK8Zrb8KxiTxZZg/wALF/yU1yVX7rJex6nRRQBivKMAoooPSgDy/wCO3xf0v4M/C2fxHcxpd6nO32bS7Bm2/aZyMjOOQij5mPoMdSK/OLw9o/xB/aM+On2aa/fUNc1JjNeX9wD5VpAvVyB92NAQFQdyAOSTXWfta/Eabx7+0TqWnRTltJ8OltLtEz8u9T+/k+pkBXPpGK+r/wBjb4XQeCvgXD4qvbYLrXifbeyOy/NHajPkR+wwTIfd/avapr6jh/a/blsbr93G/U9M+E/wX8FfCDwymneGrBXvnQC81a4UG5u27lm/hX0RcKPc816IVXrgU6ivGlKUnzSd2Yt31Z8O/tt6DD4K8d+DPi54bxY601y0c80Q2mSWALLDIcdWwHQnuMDtX2hoOpprXhjT9YjXYl7axXSj0DoHx+tfDv7dHif/AISj4i+E/hfouLm+tQZp44+SJ7orFDH9duWx6OK+zhcaf4D+F4n1KcLY6HpgM8nQCOCIbiPwQ/nXXWi/Y0776/cXJXirnwD+234zPiL9oqPw5by77Tw7YpblQ3AnmxLJ+IXyh+FX/wBhrwedc+O2oeLJ4ybbQLA7Hxx58+UX8Qiyn8RXzp4r8RXni/xzq/inUCftWq3kt7ID/CXYsF/AED8K/Rn9jbwIfB/7Ntnqt3Dsv/EUx1STcMMIiAkA/wC+FDf8DNevi/8AZsGqfV/0zafuwseJ/t/yzv438EW75+zpYXci+m4yxg/oBW7/AME/oLUaV4+udy/ajcWUZHcR7JCD9Cxb8q9e/ag+B958Y/h7ZP4fkt08R6PI81ms7bEuEcASQlv4ScKVJ4BUZ4JI+NPCPwf/AGoPC3iie38H+FvFmgX9wv2aa6tpltonTPRpt+wrnkEE46iuWjKnWwfseZJruRG0oWue/ftefEi98VappX7PfgL/AE7W9Vuov7TjibOzkNFbsR0ycSv/AHVQZ61sfHzSIPgz/wAE+F8CaLKWDi10eSccGZpJPMnf/ge2T8Gro/2df2a4vhZJP4w8YX0es+N75W8y5DNLHZq/Lqjt8zyN/HIevQcZz2P7Rvwx1D4s/Am+8MaLLCmrRTR39iJ22pJLGT8jN/DuVmXPYkZ4rkVWnGcKa+FPV9yOZJpdD4X/AGR/Dttr/wC1NpF1fBDbaNbXGruZCAA0ahUJPs0gb/gNan7UXxDvfi14rfX9HkL+CNBvToumzgnbd3TIZJpl9RtRQD/d2f3qzvB/7K/x31fxWdLl8P3nha1kBgvNTvLhUiWFuHUCNyZgQPuDg8ZIHNfT/wAXv2ZY7n9lLR/h/wDDa2jkv/D90L6BLh1jfUHKssxZ+gkffuGcD5QvAxj0q+IpRxManNfp6GrlHmueFfsPeHbO7+M+ueL9QeNIdA0ksksjBVieZtpck8ACNJOfeuO/ab+Ll58XfiJ/aGlCU+DNJnk03SpOiXM20NLNz3YbceibOhatP4ffsx/HzWtXutClsNS8G6JfBYdVur2cRxzRBs7fJRsz85wp+XPUgV7J+0R+zBq5+EngnRPhHo39oW/hw3K3Vn5iLc3TTeWWuMsQHctH8wyDgjAwMU5VqMcWqjknf8BXXPe55D+xj4Lj8UftIQ61dQCS08OWj6h8w485v3UQ+oLO3/AK8++L3hy/+E37TWvabpTtZy6bqg1HS5R/BGzCeFh9M7f+Amvs79jP4V+Kfh34J8TXvjLQLjRtS1O9iWOG52+YYIo+D8pOAXd/yrjv27fhhLe6Po/xV0uDc9gBpuqbR/yxZswyH2Vyyk/9NB6VEcYpYxpv3XoHP759P/DDxzY/En4S6J400/aqajbK8sSn/UzD5ZYz7q4YfgK/LH40+JZ/FH7QHjTxBdOz+ZqtwiA9oomMSL+CxivfP2KPi/H4c8ZTfC3XLoJp2syefpjyNgRXmPmj9hIoGP8AaUd2rmPjP+y/8UrH4z61deE/CN74g0LVLyW9tLmxKN5YlYu0UqlgVZSxGTwRg56gLCU44XEzjN200CK5JO59Bav46sf2bf2MfCnhvSdk/jDUdOjj06yRd7vdTfPJOV6lUeTj+821R1rV+Gvgm5/Z4/ZL8TeLdYxN4vnsbjW9VnlO9vtAjZo4i38Wwtz6sznvWH+z9+zNr+i+KLP4lfGO/k1TxHaRJFpenXFybsaeqjCM7kkF1HCqvyp15OMfQ/xE8KR+OfhV4g8HyTi3Gq2E1osx5EbMpCsR3AOD+FebVnGMuVO93dvuZtpOx+TXgTw1c/EL4vaD4XnnZpta1GOC4uGOWw7bpXPvtDn619uftH+LLzX7/Q/2YfhaEXVNW8qHUjB9zT7JQCI2x90bFDMOyKB/GK+Z9M/Zy/aK8P8AxDt00fwbqlpqlnOHt9Ws7iJIEYcCRJy2AMHuM4PI7V9tfAH4DxfCvTb3XvEWoDWvG2r/AD6lqjM0m0E7jFGzfMRnlnPLkDoAAPRzCtT5ozjK9lovMuo1oyfxr4y8E/sv/s96ZaRwmZLOBbDStOVgsl7MFyzMf4RnLu/bJ6kgH4c+O2n/ABa1/RdB+MPxRNvbnxDI1rpumohja0t1TzU+T+FW3MQGJY9WxkCvX/2w76PTf2svhtfeLYJp/CFtBDNJEqF1dVu91yAv8R2iLI7jFct+198cvBnxSHh3w74GvDqVjpkkl5cX/lPHG0joEVEDgE4XcScYyQPWpwFOUJwnFXcrtsIK1mbn7AurXEfxI8X6GAPIuNMhvM45V45dnB9xJ+gr7B+I/wAJ/BXxX8P2+keMtMF1Fb3CXEU0Z2TIVbJUSYyEcZVh3BPQ4I+Rf2Q/DOveFtF1bx1IjWjawiWtl5iDc8CMWaQAj7rMQB6hc9MV9Nf8JZ4iR8rqRI9DGpH8qnHUJyrucGE4tyuj1SCCK2t0t4I0jijUIiIMBQBgAD0xUleeWXj29jIGoWkcy93i+RvyPFdXZ+JNIvbF7qO8jjVBl1lO1k+o/wAK8udGcPiRk4tGxRXE6l49iVzHplr5uP8AlrNlQfoBz+eKwp/F3iCZsi9EQ7CKMDH5g1pDDVJa2GoNnTePYd2kWs+AdkpX81P+ArgGPard3rmr31obe8vHmiyGwyjqPoKoCQk/NXbRpSpxszSMWkI3WsXxDFv0hyOqkNW315rP1OB7jTJooxucrwK3g9UUjzW4HznoKxNZj3aZJ/skGuvuNB1QsStsCP8AfXP8657WrG6ttPnFzbSRDbwzLwfx6V3wepaOElwAT0Arh9Vle/v3m52D5UHoP/r9a7TUSRYTYPJXAP14rl2tgF4Fd1LTUZyGrwYiRsdyKwnXBrsNegxYBsdHH8jXJSr854rtpyuikVj9BUZGKnIqI9+K15hkZAzTSKkPNMYVHMA4dKkFRjpUqiskSSLUqVEOgqVOooKJl9a6Dw6udbgP1/ka59OldF4cH/E6t/8AgX8jSnsSz0GE/KBVpBzVWD7p+tWk5NcVhHQeHxm7kP8Asf1rqIq5jw//AMfUh/2RXURdBXPV3EdX4WGbmY+kY/nXWr938K5Pwr/x8Tf7g/nXWL0rhq7kMkHauk8GqG8Vxk/wxOf0x/WubHUV03gs48VL/wBcX/pXHXfuMmWx6QBiloorzDAKo6vfLpuhXupMMi1gknx67VLf0q9WV4kspNS8I6pp0P8ArLmzmgX6tGyj+dC3QI/HGwhufFnjW0tpHLXOs6giM/ffPKAT+bmv2Y02xttL0i202zjEdtaxJBEg/hRFCqPyAr8e/hps0/4y+DmvPkW21uxEu7ttuEB/UV+xw717OcPWC6WNqz2Rz2r+PfBfh/VzpWveLNE0u+8kXH2a+vo4JDGSQHAcjK5UjPsa8G+MH7Y/w/8ABuk3GneBL628V+IWUpGbVi9lbH+9LKOHx12IST3K9a9S+KvwN8AfGLT7aLxhpspu7QEWuo2b+VcQg8lQ2CCpPO1gRnng1wHhH9i74LeF9bj1O7s9U8RyxMGih1m4WSBSOhMSKqv9GyPavPoewXvVLt9iFy9Tx/8AZX+EfiPx38S3+PfxFE86Gd7vT2uhhr+6bj7Rt7Rp0TsTjHCDPoX7cHxDXw58ErfwTZThb/xLN5cgU8raRENIfozeWnuC1fTcslnpOmPLI0NraW8RZmbCRxRqOSewUAfgBX5Q/Hz4oSfFr43an4mhkY6TF/oelI38NshOGx2Lks5/3gO1duEUsXiOeS92P9IuF5yuY3wo8B3nxO+MWh+C7ZW8u9uA13Kv/LK3T5pn/wC+QQPdhX6wa1r/AIU+HPgZtU1zULTRdC06FY/MlO1IkUBURQOSeAAoBJ7CvnX9iz4PP4S+H1x8RtctTFrHiCNRZpIuGgsQdyn2Mhw/+6ErxD9tz4iajrXxy/4Qdbh10jw7bRubdW4kupU3tIw7kIyKPTLetXiH9dxPs4v3UOXvysfROg/tieF/GHjseHPA/wAOfHXiRRgyXNjZxfImceYUaQFV92K/nX0fGwkQNsK5GcEcivLP2efh7o/w++APh+x061iW7v7KG/1C5C/PcTyoHJY9wu4Ko7BRXqnTtXl1uTnaprRGMrX0K99e2um6fNf31xFb2sEbSzTzOESJFGWZieAAASTXxX46/bG8X+LPiFF4K+Amgx3bzzeRbajc2xnmvW7tFESFSPgnc+eBkhRU37b/AMY5oVt/g/oN2UM0a3etsjclDzFbn2ON7DuNg6E1p/sTfC2y0HwFf/F3XIoo7vUhJb2Es2ALezjP7yQE9N7qcn+7GPU12UsPGlR9vVV77I0UbLmZv/A743/Ey6+O9/8ABn4zadZRa/HbtcQXNtGkbBlRZDG4jJRgY23Ky46EHPb2j4tfFrwr8HvAMviXxNM7l28mzsICPOvJsZEaA/mWPCjk9gfmH4E3h+Kv7cnjn42A+V4c0mKWO3u5PlQhoxDFknp+5jeQ+gYetfP3x4+J+q/HH44SXWmLNcaZDL/Z2g2SfxIXADgf35Wwx9to7VosGq1a1rJJN+Qcl2eoy/tdftAeIJtT8W+GfD+lW/hvSGje9gjsDPDbo7bUWadmDZY8ZXb1zgCvuX4feLIPHfwu0HxhBbG3TVrGK78hjnyiy5K574ORn2r5J+Neh6d8Bv2EtK+FOniObxB4luoo7toxlrmYFZZ3HqAVjiX2K19WfDfQU8DfBXw34cu3SM6VpUFvcO7AKrrGN5JPAG7dWGL9m4KVONtdPNCla10dgMY4FZniLQNL8U+FtQ8Pa3apdadqFu9tcwuOHRhg/Q+h7HBryXx5+1d8GfAnm2z+JBr2ox8fYdDUXTA+jSAiNfxb8K+dtd/bT+KXjrWDoHwn8CrZTyHbGRC2p3p99igIn4hh71lSwlafvJWXd6CUJM+e/ix8NvEHwc+L134avJrgC3kF1pmpJlDcQ7sxyow6OCMNjoyn2r7T+Fn7Y/w/ufhDa3PxM1r+zvE1oBb3UEVrJK16QOJ41RTww6g4w2R0xXk8H7NH7Rnxl1GHXPit4oGmoinyRrE32maIN1CW8WEjzgZGR06V89eP/h74t+E/jttA8W6QsM8b+ZBI6GS1vo1PDxtwHQjqOCMkHBr23Chi4qlUlea7G7UZqzep9p67+3z8MrCbydE8L+JNUfsZRDahvoGct+lY0f7fEUrbk+DmtND/AHxfg/yhx+tbP7Ofxm+BHiLTrTQz4S8L+B/FAAQ2otIoobpsdYJmGTn+453Dtu619P6hqtlpNsPOOWI+WFAMn8OwryqipU5cjpO/mzFpJ2sfOvhH9uD4Ta5fpZeI7LV/C87HBlvI1ngT/eeIll+pUD3r6Kttc0q+8Px65Y31vdadLCJ4rq3kEkciHoVYcEH2ryD4heFPBvxN0+XT/EvhHSXV+FvBEFuoP9tJlwVI6+nHORXg/wCyXrerJp3jTwHFqb3/AIe0y9SWykzlNzSSKdvorhFkwOM5PeqeDjOLnBWt0Y3BPVHuPxH0PRPipZDTfFmkQ3unxP5lvC5KvA2Mb1dSGViOCQcdua8lX4K/AfwJdJrOtW1lCI23J/b2p74gR6I5Ab6EGvdBBjtXwP8AtR6lb6j+0pqkcbK66bbW9kx9HVN7j8DIR+FelhIuX7uLsjWK6H3JYXNjqWlW99pl1b3NlNGHgmt2Dxuh6FSOCMelTiP1rjfghotxo/7PXhCwukKyjTkmdD1XzCZAPycV6ALYntWM2k2iSh5fPOT9aURD06VoC2PHFOFs3Hyk1POguUBF7GlEXsa0Bak9qcLUkfdqXUFczZIisLHHSqpyRW3c2xWylbGMLWMR9KqMropDc4qtIcROfarBx2NV7g7beU9wpP6VaGZck/PWqd1Or2zo4VlIOVbofwqCa4wevFZ15dYtpOf4TW6Gch4l8NWlzbSTaYFhm6mAH5G78f3T+lecTW5QlGUgg4IPFelXd9wfmrktbjSSb7SvDHhvf0NdtNvZgjgfEMQGlMcdHU5rh5hlia9C8RrjRpM/3l/nXn8wG/mu+i9DRFRgM8VG3JqdsVCRzWtxkWKYe9SN0qMnBqWwFHSpAcUxTxTxUkkq1KnWohUqdRVMomWug8PNjWrbnqSP0Nc+Dz0FbOiPs1a1b/poKiWxNj0qH7lWU61VhPyirCdq47iR0Ph8/wCmOPVP611cXauP0NtupKPVSK66I9K56u5LVzq/Czf6bIvrH/UV16/drifDMmNWUZ6ow/r/AErtlPFcNXclkij9K6Lwg+3xbAP7yOv/AI7n+lc6prY8PS+T4osXP/PULn68f1rkrK8WS1oer0UUV5ZgFB5FFFAH5WftM/Dq++Gn7ROqLaQvb6ZqszatpU6ghQGfc6g+schIx6FT3r9GPg78Q9P+KHwe0fxdZTI008KxXsIPMFyoAljI7YbkeoIPem/Fj4S+Fvi94Ffw54lhZGRjLZ30AAms5cYDoT27FTww4PYj4mt/BP7SH7LXjO71Pwvp8uuaDK2Z5bK3e6s7tF+6ZoVPmQuAfvdum5hXqOccXSjBu049+prfnSXU/RagnFfEUH/BQBraxEOrfCxhfqMOItW2Ju+jxbh9Oa4bxP8AtA/tBfHWCTw54G8K6hpmmXAKSw6BbyySyoeCJLpgAq+uNnuawjl9Vv3rJd20L2b6nZ/tfftH2t7YXfwj8B36TrIfK13UbdsrgHm1jYdST/rCOMfJ3bHm37Lv7Pl18UvFEXizxRYuvgzT5ssJAQNTmU/6lfWMH77f8BHJOPQvhD+w/fT3lvrXxeuI7a1QhxoFhKGeX2mmXhV9VTJP94V9s2GnaX4e0KDTtNtbaw06zhEcUEKCOKCNRwABwqgV0VMVTw9P2GHd292U5KKtEuxRJDEscaqqKAqqowAB2A9K/NT9tXwpdaJ+05d61NC32LX7KG6hkA+VmjQQyLn1GxCf98V95N8a/hImurozfEnwqL4ts8n+04id3TGc4zntmqXxj+EPhr41fDw6BrLm2uIm8/T9ShUNJaSkY3D+8hHDL0YehAI5cHWeHqqc1oRB8ruzlf2XPixpHxD+Buk6X9ri/wCEg0K0jsdQtC2HxGoRJgOpR1A57Nkdq9d8TeINP8LeD9T8SarKI7LTrWS7nbOPkRSxA9zjA9zX5jeKfg38b/gR4tXXLSz1SJbVibfxD4fLyRFf9oqNyZHVJBj61N4v/an+KXjn4SX3w+8STaVc292Y1uL+G28m5dUcMUYKdmGKjPyj9a7JZaqs+ehJOLfzRfs7u6PPNQvfEXxb+M8t04aTW/E+qgIo52PM4VF+iKVH0Wv0h+I3wn8Xa38GdD+Enw/1/TPDnh1bdLDVr6VHe5NqiqojhRcKd+GLksOOOhNfnB8NvHR+G3xP0zxrFpNjqlzpxeS3tr2Ro4/MZCgcleTt3EgeuK+jfDv7Sv7Rfxf8e6T4Y8L2djoVrfXUcE99pekvMLaIsN8jSy71XCbjnA5xXXmNGo3HksoxLnF30O8/aIbw7+z3+yPZ/CzwMJLa48QSNaPOzfv5osBrmeRhjLONseegD4GABXi37GngGPxR8ej4q1CNP7L8LwfbWZ+E+0NlYQT0G3EkntsBrK/a58cN4w/aX1LToLhpdP8ADsS6RBuOcuvzTN9TIdpP+xWt4T1HXLP4DaP8C/hrD5/jXx/MdQ1uePI+xWTALHE7D7uYV3uf4Uc93FTGEqeEt9qe78v+GBK0fU9Ht9csPjr+1rqnxS1dmf4a/DeAy2z7Cy3UiEsm1f4mkkHmY6lUiH8VcbqPw2/ah/aN8SXGr65DqWieHrqdpba2165a0tbaIklES2UbnIXAyU5Iznmvr3wpofgT9m39n2O11DUYbPS9Nj+0ahqMq4e6uGxufaOSzNhVQZOAqjpXzD43/by8SXV5d2vw+8JWOn2hBSC+1dmmuD6P5SkID6KS1clCVWpJ+wjdLRN9P+CRG7+E9H+H37C/gDQ1iu/Her3vie6TBNrFmztAfTap3sPqwHtX0n4a8H+F/B2krpnhXQNN0a0UAeTY26wg47nAyx9zmvkj4ZftE/Gjw98Y/D3gv48aSILPxME+w3MtmlpNAZDtibCHaUL4VlYBlLA+x+oPil8QNN+GPwn1jxrqirIthAWhti4Q3Mx+WOIH1ZiBxnAye1cuJVdzUajvfbsTLmvZnZZ9q57xj4G8KfEDw3JoPjDQ7TVrBzu8q4TJRv7yMPmRv9pSDXzB8EP2vfFPxK+Num+CPEHhDSba31MSrDcadLKXgZI2k+cOSGXCEEjBGQa95+N/xTt/g/8AB6+8ZPZx3t0kkdtZ2cjlBPNI2ApYAkAAMxx2U1nPD1aVRQatInladj5o+JH7C1rbu978O/F4hjdvl0zXFLgeyzoM4/3lP1ridL+G37X3gtF0zw9q1zLZpwkcesW9zBj/AGVnPyj2AFe3/A39pW6+NnjG98L6v4Vi0q/t7NryGeznaaF0VlVlYMAVb5xg8g+1eQftN/G/4meB/wBoF9A8J67LpFhpNpb3AhjjQrdvIm9jLuB3r0ULwMA9zmvYoTr83salm13No82zL7fCL9qX4gWp0vx146g0XSZeJ4luI2aRe4MdsoDfRnAr3z4a/CvQfhf4LTw94fWSTc/nXV5PjzbqXGN7Y4AAGAo4A/Env/D1y2t+ENJ1maBYZL6ygumjHRGkjVyv4FsVF4o1/wAOeC/DE/iDxTq9rpOmwjL3Fw2Ax/uqOrseyqCTXLUxc5+7b7iXK7scr488VaX8PPh1qnjDVyPIsYtyRZ5nlPEcQ9SzYH0ye1fn98MvBms/G348x2l+XmS7uX1PWroDhId+6Q/Vidij1Yeldf8AFX4l+L/2lvirp/g/wJo16+kwSn+zdN+68zdGurg9EAGcZOEXPJYmvsr4I/BbTPhB8Pxpkbx3mtXhWbU9QVcCWQDhEzyI0yQo7kljyeOtVfqtJ3+N/gi7qCOrTTo4o1ihhWKNFCoi9FUDAA9gOKlWzx/DW4LUZ6U77L6DivMdW5lzGILL/Z4p4svatv7LzyBSi156UnUDmMYWQz0p4s+22toWo9MU4WvH3aXtGHMczq9v5WiTtjHAH5kVyLDFd34pUQ+HiMAF5FUfz/pXCN2NdNGV4lRd0RGqd+wTTp36YQ1cNZ2tMI9HnPcgD9a6IblHH3M2GODWTqE5FnMc/wAJqzcyEsaxtXl26ZLz1GK7YLYuxztzc5z81ZV1JvjZT3FSzyEk81SkbIJrrQzmfE3y6OR6yKP5159P/rM13vit8adGPWT+Qrgp/v5rso7ForHpUTHipTUTVoMjJqJuhqRhwajboaTEhwqRelRDpT06CkImFSrUSVIvBzVFE461oWMhS4jcH7rA5/Gs8Y7irVucyYqXsI9XgIIz61ZU81m6ZJ52nwSZ+9Gp/StJetcTINbSX2alAc4Bbb+fFdnEffpXA2zlJVYfwkGu7hbcAw781jVA3tDl8rVrd84+cKfx4rv06da8ytZCkqsOoOa9JhcSQo46MA351w1iGWRU8EphnjmU4KMHH4HP9KgXrUi8gjFc8tUI9pjcSxK6nhgGH408jNZHhm5+1+GLSRjllTy2+q8fyxWvXjNWdjnegVl6jr2m6VxdzjzMcRJ8zn8O341leJvEbWWbCwYC5I+eT/nmD6f7X8q4ErI8zO5LOxyWJySfeumjh+fWWiLjC+rOwuPHjM5W007js0z/ANB/jUI8b6jnLWdq3+6WBrmkizjirEcJyMiur2FNdC+VHRxa/od/OH1XRIBJ/wA9WhSX9SM11tnLay2qtaPG0OPl8vG0fgK86jtc9BxWppzXFjcCS3bGeCnZh7iuerRX2SXFdDt554raB5pnSONFLO7ttVQBkknsAK/M39o/9ozW/ir4nu/DnhrULiz8FW0hiiggYodTIOPOlxyVJ+5H0xgkEnj6y/a38ez+Gf2VtSXTZTBea5PHo6kNhkSTLTY/7Zo4/wCBV4D+xL8IbLxN4ovviZ4gsUns9FmW20yKRco13gM0uDwfLUrj0Zs9VFdOChClTliaivbZeZUEormZy/w7/Yw+KPjLQ4tV1mXTfCVnMoaKDUY2kuXU9CYVxsHsxB9q+7fg74M134e/B7SvB3iLX49cutODwx3kcbIDDvJjTDEn5VIXr0ArvcDFeZfHm1+IGo/BXUNE+GcLtr+qSxWCTpKIjawyOBLLv/h2pu+YcjPHOK5q+LqYlqM3oRKbloyTxF8ffg14V1iXSde+Iug2l9EdssC3HmvG391ggO0+xr8+f2o/H+h/EH9oK6vvC9xZ3WiWNpDaWt1aIFS4OPMkkyAN3zOVyf7leqal+w9H4W+HGp+J/FXxRitjptlLe3EdlphaJQiFiA7yAtnGM4HXpXyVaQXF9eQWlvC8lxO6RRxjks7EKF+uSBXr5bh6EZOpTle33G1KMVqmfff7Evw30qP4IXnjDWdGtLq51jUHNtJc2yyFIIR5Y2lgcAuJDx14r6J8b+L/AA/8O/Ad9r2r39jp9taW8kkUc0iwiV1UlY0XjcxIAAAzzXxZpP7Hn7Q2lqtnpvxF0rSrXPIs9ZvUVc9fkRAPWs/4x/szJ8MvgXqfjzxp4+1LxP4iEtva2aZYQxPJKASWkZ3fCh8DKj2NcVWlTrVrupe76Ih2ctz5qt7fW/GfjSO2t4JL7WtavcLECN01xM+cZPHLN1PAr9Nf2ePgHpnwc8JPdXzxah4s1BF/tHUR8wQdRBETz5anGT1YjJ4AA+Kv2RfDya/+1n4fklj3xaXFcamwPYpGVT/x+RT+FffXxy+KFl8I/gvqniqZka+2fZtNgY8z3TgiMY9By5/2VNb5rVm5xw0PIdVu6ij4g/bB+Ltz46+L8vgrS7v/AIp7w3K0ASM/LcXgGJZD67OY19MOe9cpd/A3xTof7Mnh/wCNNvZzzvPfG5ntlQsLayGPImZQM7WdWLHoFdPc15x4Y0a68afEbSPD7TNJdazqMNq8xPJaaUBnPv8AMxr9jLHS7LS9EttJs4Eis7aFLaGED5VjVQqrj0wAK0xVb6lCFKn8ypPkSSPzg+OH7QXhj4reMvht4o03Tb6zk0Ii41OF1XKv58MhSJ84cYjbBOOozis79ov4kfEv4lJoviHxRosvhrwpdTTNoWjzMVkmCgbrlwQC5+dVDkBRkhMjcT6x8PtK8PfFn/gopquveHtD0238KeE1Z1+yWyRQ3EqAxJIQqgMzytI4J7RivNf20fFL+Iv2n7nSkl32+g2UOnoAcjzGHnSH65kUf8BqsNyOtCnGOyvr0uEWrpJHS/sJ+Em1b406x4vmiJg0TTvJjfsJ7hto/JEf/vqtL9u/x+mo+OdB+HVlNuj0qI6jfKp48+UbY1PuIwzf9tBXqP7LFrpXwo/YvvfiJ4iKwRXzXGt3D/xGBB5cSj1LCPgeslfBnjDxZqXjbx9rHi/Wm/0zU7qS7lXORGCeEHsqhVHstFCP1jGSqvaIRXNNs+w/2EPB7R6H4p8eTRfNczR6VbOR/BGPNlx9WeMf8BrH/bF0HTfGH7RXgjwb4cson8V6jarbXM24hTHJLtgVwP7uJmJ6hfwr6A+BcWh/C79kfw5/bM8dqItLOsag/wDc80Gd2b0wrAfgBXhv7Ppv/ib+0j4q/aE1ywY26zvaaPDKcCMlQgx/1zh2r/vSN6VyxnOVedddL2/Im75nInj8F/t1aFZJoGl+J9MurG3QQw3S3Vox2KMLhpIg/QDqCahsf2Qfix8Qddi1n41fEzzNv/LKCZ76dR3VC4WOL/gIP0r62/4SabIP2OL/AL7NTxeJ48gTWbAeqNn+dYvEV1rGKT8kieaSMD4d/CLwN8K9BbTPBujR2hlx9ovJT5lzdEd5JDyfYDCjsBXaiAeg/Gm2uqafeYWKYB/7j8H9av7R/dH5VwynJu8tyG31KYhFL5K9wD+FWtv0o2/Sp5hXKwhFPEI7Cp9nrS496OYLkHkjHSl8upsUYFK4jh/Hc2I7K1BGSWkP8h/M1xJ4NdD4wu/tHiiVAQVgAiH16n+dc8a9PDq0EbRWhGxrC8SS7NMCdCz/AKCt09O9cr4pmzJFCMcKWIHqa6qe5aOTnbLGsLXHK6dtz95wK2peprm/ED/6qLPPLH+Vd1Jaos52Y81Wc/KankOarynC10oDj/FsvywR5/vN/IVxUvLmuo8VS7tS2A52RgH8ea5ZjzXVS0iWiFh3qFqmbrULdK1GRmo26VJTG+7UkoRakHSolqQU0BMvBxUqnmoQeakXrRsUTryKsQnEnXiqyHiplOGpdQPRvDk/maNGufuMV/r/AFreU5Fcd4UueZoCewcfy/wrr42+SuSorMktRHJ5rtdLl83TYXzk7dp/DiuIjODXT6BPuheE9VO4fjWNRaEnTQnDA13+hT+do8WTkplD+HT9MV55Gehrt/DYaK3eOQ4Z/n2+n/164qq0JOjHTOMk0u5s9h9BTAc08ZrnskBpafe31spjtbyaIA7tqOQPriugsfFGqW/yXG26XHG8Yb8x1rlrVxHdoxxtJwa6FbT2rnqQg90RJIzJI5J7h55SWkdizMe5NPS3z1Fai2fP3asJZ4HTFLnS0E5GVHakH7oq3Fa8jp+FaUdn0+WrcdrjHy1nKoTzFGG0PHFXorXH8NWo7bAHFXIrcdxWEpiufIX7diXEfws8IbciE6zKH9M/Zzt/9mr1z9kTTrfT/wBkLwrLAih737ReSkfxO1xIM/kqj8K5z9s/TtCvv2ZryPUNY0+x1KzuodQ0+C5nWN7l0O1441JyxKO/Qdq8L+Ef7YejfCn9n/RvBE3hK/1jVrB50V/tMdvB5bSs6fMdzE/NggL2rtUJ18KowWzLs5Q0P0Jor4Sk/bE+O3iAFvCHwkthE33GXT72+P8A30u1f0rPl/aI/bA3GQ/Dy4iT28KXJA/M1zrAVetvvRPs2exftweNR4e/Z7j8L20u278SXi2xA6/Z4sSy/gSI1/4FXyf+yl4MPjP9qLQRNCZLLR92sXORkfuseWD9ZWj/ACNcv8Xfir47+KPim1n8erBBe6VE9mtpBbNbCElsvuQkkOSADn+6BW58Cfj0/wADtR1e5tPCWn63camsUcks940EkcabjsXCtwS2TkdhXs08LUoYRwj8TNlFxhZbn6rjpXzV+3Ha3E/7LJmgVjHbazaSzEDopLpk/wDAnWuU0b9vzwbM6r4i8A69p/q9lcQ3QH4Eoa7G7/aW/Zr+Kfg2+8KeJvEZtLDUoTb3FprFpNbZU46SAFVYHBBDcEAivFhh61Copyg9DFRlF3sfJf7KPxL8I/C741X+u+NLySzsLjSJbRLlIXm2SeZG4BVAT8wQjp1xXo3jKDxh+1ndeKPHdnaXuneBvCem3X9h2sgw97dqm7kDguduWxnaNiDksa67wd+x58D9d14ajpXxTvPE+khvMWxsbu2LMP7ryx/Nj1wFPuK+u9B8P6N4Z8O2mg6Dp9vp2m2kYit7S3TYkajsB+pJ5JJJrrxWMpqr7WknzefQqU1e63PyG+GniSy8H/GTwp4sv1d7HTNUt7uZYxuby1YbiB3IUkgd8V9m/Hb9rTw7qPgw+DPgzqM+u69rSi0+22UEgFssny7Y9wDNOwO0AD5ckk5AFavjz9hnwN4m8WXOteGfEt/4XS6kM0thHbJc26uTk+WCVZASSduSBnjA4rvPhB+y98PfhHqC63a/adc8QhSq6rqQUtAD18mNRtjyOC3LY4zinicXhqrVV3cl06BKcXqWP2afg6Pg/wDB2LT9Qjj/AOEg1Nheao6HIR9uEhB7rGvHuxc96/Oj44XN3cftH+P5bkH7R/bt4uCOm2RlT9Atfr9gYxXzf8Xf2QfAnxK8c3PjVNf1Lw7f3WHv/ssccsVwygDzNr/dcgAEg4OM4zknHA4xUq0p1Ooqc0pXZ5Drfi2x+OWneAv2fPhndTxeEtPsbSfxJqvlNGFjhRAYwCAThs/70hXGQpNfK/xH0y30j4teLNHsbQW1raardW8FuvSONZWCKM/7OK/R74e/DDwf8MPDb6N4UtpiJnElzfXTB7i7YDAZ2AAAAJwoAC5Pcknzr4l/su+EviH44n8Vx61qGh390Q14ttCk0dwwAG/a2NrkAAkHBxnGc57sJXp05NfZNItI8+8c/Em4+NjaH8EvhE8ktjdQwPq2qPE0cccMar8hBAPlpgFj/EwVBnkn6c8J+FNI8E+CNN8LaFEUsrCIRqW+9I3VpG/2mYlj7msD4cfCzwp8LdBk07w1ZyebOQ11fXDB57lh03tgYUdlAAH15rrtR1PTtH0a61bVr6CxsLSMzXFzO21IkHUk/wCc9BzWVWab5YbCbvojzL4o/FSXwD8Tvh3oSGJrbX9Rktr+NlyywnZGkinsRLID7gEV6sQQSD1HBr4OvfE958ev21fDtzp0MyaVBfwpZRuuGis7d/OeRh2ZtrMfTco7V944JJbnk5p1qfs1FPcJKwdBmtfTtfuLMrFckzw9OfvL9D3rJwBS4z2FcsoKSsyGrnodvcQ3Vus0DhkboRUtcNpWoyafdDOTC331H8x7128ciyxrIhBVhkEdxXBUpuDsZtWHUUUVAgqK4nS2tZLiQ4SNS7H2AzUtcz411AWugfZUOJLltn/ARyf6D8acY8zSGlc8+uZ3uLmS4kPzSMXP1JzVY/hUhbmo2Oewr14q2huRMcDrXC6/cedqszA5AO0H6V2d3MILSSZuiKT+PavObqQvKWJ5PWumkhopyHg+9chrkwk1BxnhQFrq53CRs56KMk1wt1IZZ3c/xMWrupIsqt3NVZ87MDvVhjntWdqFwILSWYnGxS3444/Wt0ugHn+uzedqtw+erkfgOKxmq3dOXkOTz71SbvXYlZWNCJ+hqJuKlaoXqgGVG3Snk80xjzjtUkjV6VIOPSm7B2p2MVTg4haxIvapl6ZqBelSr0xS3HuToealHTPeoFODUwoBm/4fuvI1SEk4VjsP48fzxXoUB45ryq1kZZBg8jkV6Vpl0LmxinB+8Ofr3/WuasuojWXrWto9x5Oopk8P8p/z9ax0qzCxDAjg1i1cTPRLAg3Klui84rp7C98q7RyeAefpXHaXc+bbJOOrDn6962IZjkc1xTjqSz0eM5AqVelZGi3f2rTlycvGdrf0/StZTXJJWZLJF+72rtdDkW/0lH48yP8AduPp0P5VxQ4NbnhrUVsNYVJm/cT4Ryex7N/n1rnqp8pEkdctqOOKmW16cVpCEdMD8ad5QxXA5mVyilsCegqdLcD0/GrIjA6c04L3AqXILkSxYGcV8w/Hv9qC88L+KP8AhV/wmsjrXjSWQW808UX2hbORukSRj/Wz85x91P4snIHqv7Q3xFn+F/wB1rxLYSKmqOq2OnlhkLcSnar/APARuf8A4DXmH7IHwXsvDXgCH4oa/A1z4o8Qxm4huLn55LW1c5GCf45Pvu3UhgPXO9FRjB1aiuui7spbXZxfgn9jfxF441QeM/j74t1K51K5+d9Nt7jzJ8f3Zbg5C/7kQwP71ZV34IH7Jn7RSeMpNBGsfDDVSLeS7ktxcy6TuORuYgkMjdG/5aISM7gK+66r3tjaajZS2V/aw3NtKhSWCdBIkinqrKeCPY0/rtRtqWz6BzvqQ6Rqmna3o1tq2kXkN5YXUSzW9zA++OVGGQykdRiuX+LPj21+GXwc17xncsrPY2xNtEx/1tw3yxJ+LlfwzW94a8L6B4P8PponhnSbXS9Njd5I7S1TZGhdizbV6DJJOBxXwf8Atq/GBPFHjuD4Y6HdCTTdBl83UWjbKzXpGBH7iNSR/vMf7tThKDr1lBbfoEI8zsfNnh7RfEHxE+Jdjodk73mua5fbDM/O6WRizyt7DLOfYGv1h0v4R/D6w8BaX4UuvCeialY6faR2kf22xilZgigbiWUnJOSfcmvmj9iH4NNZWM/xg1612zXcbWmio45WHOJbgf75GxT/AHQx6NX2gRXXmeJ56ihB6RKqzu7I8O8R/sjfAjxErMPBo0eZv+W2j3MlsR/wEEp/47Xj3iX9gLTD5k3g34g3lux+5b6xarMP+/kZU/8Ajpr7S60tclPGVqfwyZCnJdT8xvE37IXxz8JzveaZoltrixnIudCvR5v1CPsfP0zXM2/xb/aG+Fl+thdeKvF+jPEcCz1yN5E+gW4UjH0Nfq8QD1AP1rifHXiTwzaaTqmjasNNnvo9Kn1KCw1GNXS5WNWztV+HwwG4DkZHrXXHM5T0qwUi1Uvuj4k8Oft0/FPTVSPxDoXhzXI+8ixvZyN+KFl/8dr1TQv2+vBVxtXxL4F17TT0L2M0V2o98Eo36VuaL8FPgD8U/BnhyfUfDGn6d4l1PR4tSuv+EflNm0WVXe7RodiKXbAyvPOOhrzLxX+xPozX0zeCvHt7FECdserWizA/8DjKnH/ATW0Vgqzs4uLKtB9D220/bJ+CGpQr5HiSWxmP8OqWU0AX6kKR+ta6fHH4c6/B5cXxK8LOjf8ALMX8cefwYg18W6r+yH8X9NZm0+LRNYQdDa3wicj/AHZQv864vUvgR8Y9MYi8+G+vOo/iggFwv5xlq6IYDDfZmUqcT9B5PH3gONQx8beG8Hv/AGpB/wDF1lX/AMZvhLpkRN98R/DcZH8Md6szH6CPca/O2T4ZfEFZfLb4eeJQ/p/ZE2f/AECtbS/gj8X9VkCWHw38RAH+Ka1Nuo+pk2itfqNJbz/IrkXc+rvF/wC178NtIt5E8L2mqeJLsD5SkP2S3z7vJ8xH0Svlv4hfGL4hfF7VoLDUZWFm8wFpoemI3lGQ8L8oy0snoWz7AV6V4T/Y3+IOrPHN4r1XSvD1seWSN/tlxj2VMID9Wr6c+GnwK8A/C1RdaFp73erlNj6tfkSXGO4TAAjB9FAz3Joc8PQ+DVheMdjjP2bvghP8NtAm8S+JoFXxPqUQjMGQ32CDOfKyOsjHBfHAwF7GveAKlCc9KXyznpXBUqucuaRm3d3IttKFHv8AjUwjJHQ0oj9qzchEG2pYri5hx5U8qY6bWIqQR+opRFntUuz3AvWuvXsJCz4nX34b866O0voL2DzIWyO4PBX6iuP8o+lWLeSW1uFmhIDD16EehrnnST1RLidjXlnifUv7R1+Qo2Yof3UfvjqfxOa7HxBriWvhzzoGxNcZjjHdT3P4f4V5qxwMfzp4aGvMwguoxjxio2OKeahduOa70tTQw/EdyI7JYFIy5yfcD/6/8q4iVvmJrY1u8+06hIwb5R8q+mBWFI3U11wjZFoydZuPKsGUdX+Uf1rkZTknBH4Vs65cmS78sEYjGPxrDfr0FdlNWQyJzjPIrmvEtx5elmPPMjY/Ac/4V0MxwhrhPE935l+Yg2RENv4962pq8ijm5my5NVmORUrnJqF67SiNzxUTn5qkaojSYDDzmo35zT24qNvSkSS0v8NJSiutFCrwcVIvXFR1IOa55x5XYSJl/wDrVKp4qAVKh57VDGWI22sDXa+FbzMb2jt0+df61xCmtbSbs2t7FMD908+471E43RJ6dE2VzVmNuM1Qt5FZFZTlSMg1cU4rkJOm0C7wzWzN1+ZR/OumjkIGc1wFnO0M6SIeVOa7S1nSWBJUPysM1hUj1A6vQr8W1+oYgJINp9vQ12qHIry+F9pFd5od/wDbNPUMw8yP5Wz39DXHVj1IZsr0x3qQdKiVumNv41IDXOxHpfhTVxqWkiGZ83MACvnqw7N/St8LXkemajNpepx3cJzt4ZezL3Br1WxvIL+wju7dt0bjI/wPvXmV6fI/IxlGzLG0elLRRWJJ8p/t9QXkn7N+lSwBjDHrsXnBf9qCZV/8eIH419DfD26sb34UeGrvTGRrKTSrVoCnTZ5K4qr8T/AOl/E74Wav4K1ZzHDfw4SdRlreVSGjlX3VgDjuMjvXyH8P/jX4z/Zfvx8KPjL4YvrjQ7eRv7M1OyG4rEST+6LYWaLJJCgh0yQR2HXCPtqKhHdPbuWtY2R92YFFeBn9sf4Cf2YLpfFF80hGfsw0q4836Y2Y/WvEvif+3NqOqRPoPwk8O3NnPOfLTVdSRXn5/wCeNuu4bvQsT/u1MMHWm7KP3goM9g/ad/aHsvhV4Sl8OeHLqKXxpqERECAhv7Pjbj7RIPX+4p6nnoDXx7+zt8CdW+NnxBbUNYF0nhWxn83VL9mO+7cncYEfvI+cu38IJPUiu7+FX7J/xA+J/iL/AITH4sz6lo2m3Uv2mf7Y5OpaiT14bJiB/vN83ovQj758M+GNC8H+F7Tw74b0y307TLRPLgtoFwqjufUknkk8k8muyVeGEpulRd5Pd/5FOSirIvafYWml6Zb6fYW8VvaW8awwwRKFSNFGFVQOgAAAqzRRXlGQUUUUAFeOftKQ/D5Pghfaj49skm+zhk0uVEJmjvHUiPyyuCMkfNzjaDmvY68i/aTl8Cx/s/6oPH0Ly2jMq2McWfNN5g+TsI6EHJJPG3dnitaP8SPr0Kjujj/2dP8AhE4v2fbC78M2kceq3f7nWrnB8x54+xJ/hwylQOME9ya9N8s+g/KvNv2dx4ak+AWk/wDCORlGUldRViS/2zA8wnPY/KV7bcV6p5PtXdUSjOXqavcqiOlEXPAq15Z7LThET2qOcm5V2N/eYfiaPKyckCrggPpTxB7Uc7DmRTEXHSnLF7VcEP8As0oh9qlyFzFPyx6U4Q1cEIx0NPEP+zz7UuYOYpCLPQH8ad5RParghPpThAewpcwcxT8k+lKIeOlXhCfQ0ogpcwrlIQ+uaGjVVLMQABkk1fEI9K5nxNqYjB02Ajcf9cfT/Z/xpxbk7IauzD1S9N7fFwSIl4QH09fxqgeuaCQeKaTkYrsirKxoNNZGt3otdOYK2JJAVXH6mtR2CgsSAB3NcJreoG7vXZSdi/Ko9vX8a2pq7GZVw+WPNZd7cLb27yk8KP17VbkbAJrmtcu8uLZG4Xlj7+ldsI6lJWMS4lLyFmOSTmqjHmpZD1qvI2BXSUmUb64SC3kmY/Kg3GvNb+dpp2djkk5Ndb4nvQsC2qtyx3N9B0FcRK2XzmumjGyuUlYhJyahbrUjHnI/OojW4xjdKhPSpHPNMbgGkxMjb1qNqe1RmkInoPFFFdRQ6nr0zUY6Yp6GraT3AkVh0qVT0qAdalRsqDXPOHKOxYU96swvtcVUU8VMp9KyJO/8N3/nWXkM3zRdM/3f88V0iNla800i/a0vY5gflBww9RXodtMkkaupyrDIIrlqRs7ks0EbBrodCvME2rtgE5T+ormlParMEzJIHQ4YHINYyV0I9CjatjSdQazvFlB+XowHcVzOn3gurZZAQG6MPQ1pRPg1zSj0JPUYZUlhWRGBVhkGplPGD+Fcn4d1XawtJSNrfcJ7H0/GupDfnXFONmSTK1dD4Z146VdmC4ObSU/N/sH+8P61zdPU+tYVIKSsxNXPa0dZEDowZSMgg5BFOrz/AML+JfsRXT7+QfZicRyE/wCrPofb+Vd+rBhkdPWvNnBwdmYtWFrL13w7oXiXSn0zxDo9hqtk/wB62vrdZoz77WBGfetSio80I8hm/Zd+Ac90bh/hlpCuTkiNpY1/75VwP0rsfC3wx+H/AIJAbwn4O0TSJAMedaWiJIR/v43frXW0mfardSbVnJjuxaKKKgQUUUE4oAKKKpXV0UzHFjf3PpTSuBYkniiGZHVfqa8d/aQ8OaH4y+AuopqOpPp50x11C3uPLLqZVyioVHJD7yvHQkHtXpLRs7b3yWPUmvHPj/8AE/QPB3gG78MytbXmtatAYo7KQBxFETzM6noOPlz1bnoDXTh6cvaR5Ny4LUh/Zq8NWWi/A+G6t737VcalcvPdYGBDIuE8rnqVAGT3zXsAhryP9m7xtpXiL4aReGozBDqOk5VokAUzRk5EuO55wx9QD3r2sQn0rXEOUaklLe5U9ykITngYpwh7mrwg9acIeKw5yCkITnkUvk+1XRDTvKHbNLmApCD2pwhHpV0RjP3cU4IO2PypcwFIQ47U8Qn0q35dL5ftilzAVBD7U4Q+uPwq0E9sUoj9KXMBWEIPalEQ9D+FWdlZetazb6PZ73w87jEcWeWPqfb3oTvohFPX9Xj0iz2x4a6kH7teu0f3j/nk155JIzuXdizMcknkk1Ld3c95dPdXLl5HOSf6fSqpPNd9GnyrzNYxsKeBUbHA5pSao6hfJZWjSuQT0Vf7xroSuUZniDUvJgNqhw7D5vZfT8a4yeTJNWb26eeZpHYs7ck1myNxXXCFkWirfXKW1s8r44HA9T6VxdzM0krOxyxOTWlrF9585jRvkQ9u59axnbJ611wjZDGMcVSu5kijZ3YBVGSasSNhSc1ynibUNkP2RGwXGX+nYVqo3dikjmtVvGubuSYn7x4HoO1ZLGppHLOarsea7IqyKGMcCoWqQmonb9KYEZPJqNqcTUZNIkaaiY041Gx4x2pMRaBp1N6U4c11lgOD7d6eOtMNAGRz171SYE3bNKpw1NXkUtEldWGWFPNTqTVZDkVKp4rjJuW4nKvXaeGtSDx/Y5G5UbkPt3FcMp561W1i7uoNGeG0SVpZv3WYwcqCOentxUTjzKwj2uNsqMVOp/CuY8I6ldX/AIXtZr+No7pB5UofqSvAb8Rg/nXRowwDXK1Z2FY2NMv2tbkMT8h4YetdjDKroGU5BGQa89jbB61v6NqXlMLeVhsP3W9D6VjOF9RHYRSlWBFdroeqi7gEMzfvkHU/xCuAjk6AkVetbqSGZZI2KspyCK5ZwuiWj01T0p2f/wBVZOlarHfwYJAmUfMo/mPatIMa5JKxJMpwQK6vw54oaxKWWoMWtuiSdTH/AIj+VcmMeo/Ong4rGpBTVmJq57SjrJGHRgysMhlOQRTq8w0PxHdaQwhcGa1J+aI9V91Pb6dK9EsNRtNStBcWkodOhHdT6EdjXn1Kbg9TFqxbowKKKzEFFFFABQRmiigCOQlUJHXtVMQ7jk1Yup4ba1e4uJY4oYkLySSMFVFAySSeAAO5r5o8Z/tkfDbSdeu9D0nTNa162RTG+pabKkMbMeD5TMwY4/vjA9PWtqFKpVdqauVFN7Gz8dP2itE+GFtP4f0BoNT8VsuPKPzRWGejS46t6R9ehOB1+AvEPibV/EPiG71zWNQnvb+6kMk1xM2Wdv6AdABwBwK9tvPHn7L9/NJcXHwb8VSTSMXd21lizMepJM2ST61RPiz9lqT5f+FLeKvqNYP/AMdr6DBxWHjrTbfc3grdDzbwP8Q9X8FeJ7bWNMvJLe4hYMHU/oR3B7jvX6I/B740eHvipoSLHNFa63En7+xLY3Y6tH6r7dRXx2mufsuyMMfBfxb/AODk/wDx2tzRvGf7POg38V/ovwn8a2VzEQ0csGtsrKfUHzazxsPbq6ptMclzLY++9n0pQn+RXhPgL9p7wd4l1m30W/0rWtE3qEjvdTaN42boA7oSVJ/vEY9SK94QiRA6sCpGQQcgivCqQnTdpqxzyTW4mwelLs9qk2e9LtFZ3JItopcCpMD0pcUXAixSgZ7VJRSAZtOOlG33FPrktf8AF0VoGtdMKy3HQy9VT6ep/SqjFydkNK5o654gttGg28S3TDKQg/q3oP515te3txfXb3V1IZJG6k9vYDsPao55pJpnmmdpJGOWZjkk1ESc130aKh6msY2AkdSOaYfSnE1XmmSOMyOwVRySa6UUNuJ44IWkkYBVGSa4bV9Te9uS5JCjhR6Cp9Z1dryUxoxEY6D196wZJM1004WKSGyPnrWHq+oeVGYY2/eN1I7CreoXyWsJLMC54VfU1yNzO0kjO5yxOSa6oRuPcilfk1WZgOtPZqq3EpWNiOuOK3GtCrqF5Ha2zzOeFHT1PpXnOoXb3FzJK7ZZjk113jyJ7CeyhE8bRzW4mKKwJVs4OQOmcZH1rhJGy1dFKNtS9iNzxxULHjins3PSoW61uMaxqJmzxTmPvUdDAaTUTHAqQ/eqJjzx2qSSNj6VGx4pxIpjHmkBdHIxQp7U0Gl6HNdaKH0Dg/WgHIzRTAkB5p1RA5FPB55qwWhKp5xUqmq9PEhHSuedN30CxbU5qHULp7SzFyNojRwZCTyF9vfOKaJiOuKwPEOomeNLaOMiMNuMhPUjsKiUGtxNHpGhav8AZZklDBonA3Adx2Ir0CCdJEV0YMrDII715P4a0mefwks9ncJdG3UmSJRh1XrkDuBXUeH9aELrbTv+7Y/Kx/hP+FctSKeqJsdyrY/oKsRvznNUI5Qw61YDYrENzrNJ1Peot52+YcKx7+1bySdK8/jkIwQcV0ul6p5oEMzfvOgY/wAX/wBesJw6ok6q0u5beZZY3KuvQiu10rVYr+HbwswGSvr7ivO45PcVet7l4ZA6OVI6EHpXNOCkTY9LVqkVh071z+la7HdKIbhgk3QHoG/wNbQb3rmcGhFgNVqy1C6sLkXFpM0bj06H2I7iqIOOtP3d+lZOKejA9G0XxhaXoWC+C2054DH7jfQ9vxrplYMMjGK8UDduRWtpniLU9LwkUokgHWKX5l/D0rknhusTNw7Hq1Fc7pni/TL0Kk7G1lPaQ/Kfo3+NdAjq6BlIIPIIOQa5XFrRkNWHVl+IPEOj+FvDt1ruv6hb6fptohknuZ22qi/1J6ADkngZNN8SeI9G8JeFr7xH4h1CGw0yxiM1zczHCxqP5noABySQBya/MX49/tD638ZvFnkWpm0/wnZSk2Gmk4aQjjz5sdZCOg6IDgc5J7MDgZ4udo7dWVCDkzr/AI9/tK6v8Ubufw94ea40vwgjYELHbNqGDw02Oi+kfTu2TwPCBLk8mspbjOOakFxg9c19phsJToQ5YI6kklZGujrnqK0bYxkjIFc6lweuavQXPI5rdwGdhYtDxlFrqtNa3JGUH4155Z3uCOa6TT7/AAw+bisZRGj1bQzZrMjmJD+HWvpn4X+MRb6bDprztLaAYWNzkxf7p9Pb8q+QtJ1LDL8+K9K8MeImtJo5I5MYIyPavNxmFjVjqiZQTVj7ahljniEsTBlYZBHepK8y8CeMo7y0SN5NwPBGa9KikSWMOhBUjIIr5WtQlSlZnJKDiPooqjfavp2mrm8uY4z/AHM5Y/QDmsUr7E2L1UdR1ex0uDzbyZU44Qcs30Fcfqnja4lDRaXF5C9PNk5b8B0H61ys08s8zSzyvLI3VnOSfxrop4dy1kWodzd1nxTe6kGggzbWx42qfmf6n+grns56UhJxzTSa7Y04xVkaJWFJPemZ9qGPc1TvL2G0gMkzhfQd2+laqLYyaeeOGIySMFQdSa47WdZa7by4yVhHQev1/wAKg1TWJr2Q5O2MH5VHQf8A16x5JM55rphTsUohJITk1nXt5HbwmSRuOwHei7vI7eEySNgDt3NcnfXsl1OXZsAfdUdq6YxuUNvLx7mcyOfoPQVQd+9Ods8ZquzY6nFbpWGgdwAea5zXtXW2i+zo37x/vFTyo9vc1b1bU0srYtkGQ/cX1/8ArV5rfa5HcaqYhIXk3fPJngH0rSMb6sZ0ni+XT31SCSzinjmeBTc+Z90tjClPbaB+Ncwzcelem23gTU/HOgwXehXUEt5bw7RZSfK0oznCt0z6A/nXmdzFNbXD29xE8U0bFHjcYZWBwQR2IIrelJNWQ0QM3vURPPNKzEmoycZrUYjGo2PNKSKjPB4pEjWNRMacx5qMnFJgMJqNjSsfSo2JqRMvjrmng5HNNPTNAz611ljxx16U6m8HtSincBehzSikoBPfmqQEoPalAzTBT80xogu5NsO0Hlv5d6zJEWWMo65BrWnVGt2LKCQMg1EIYi9sPLxuB3e9Q3cGVdB1268NauhEpVAcq3t7+1dk1xDPL9rtSphnzIoXoPUfnXE6lbQtpFxL5Y8yOTCtnkDI4/Wuks4ILW2WKCNY1xnA7n1rmlFc1yLWO80DWtyraXL89Ecn9D/SupjcMB615RDMUYDPFdjoeuiQLbXTjd0Rz39j71z1KdtUB1qPirUchGKz45AQMmp1Yg1iI6nTdX3YiuGAPRX9frW9HMCOTXn6SgfWtjT9WaDEcpLR/qtYygI7OOYr3roNL8QPCFhuSXToG7j/ABrkLe4SWMOjBlPcGriSdMVhKKe4j0yC4iniEkLhlPcVPuPrXndlqU9pKHhkI9QehrqbDX7e4ASfEL+uflP+Fc0qbRNjeDZ+tAOfUVCrg4IINSKffismIlzjir9jquoaew+xXciDP+rzlT+B4rNB9a4v4t+LH8EfBPxF4hgkC3UNqYrUg/8ALeQiOM/gW3f8BoVJTko23C1z5p/an+Peq/EnxW3gnTrpU8NaNOVcQEhb66U4aVvVUOVQdOrdxj52ViDnoRTee7Fj3JOST60vOa+rw2HhQgoQVjZJRWhYR/eniQ1Ap4p46Y7+ldQ7llJOOtWY58d6zg2O+akWUD+IUmM2oboqw5rbsr45X5q5COYD+I1ftrvaRzWcogelabqeNvzc12uk6vgr+8rxuy1Haw+aun07V9pHz1zziK59G+D/ABbJp99E6ynbnkZr6R0LxireHPtcUX2gYHybsbT/AIV8K6VrmCp3+nevb/hz43EUi2dxKfLkG0gnrXk4zCxmtSZxTPb77xZrF6CqzC2Q/wAMAwfz61hO5dy7NuJ6knJNN3o4DIwZT0IpCcda8qNJQ0RhZdALH2ppNJnJpjEVdih5YetMLelVLzUbazTM8gB7KOSfwrmNR1+e4BSE+Uh9Dyfqf8K0jTbA2tS12C0DJERJKPyX61yN5qE1zKXlkLN/L6VVklJPU/nVZ5Rjg10xgkXYkeTuazr2+itYt0jAk9F9aq3+rpACkZDSfoK5q5uXmlLyPlj3raMe4yS9vpLmUvI30HYVQd8nrQzZNQs+B1rdKwwZgOW6Vl6lqUVjbNLIQT/CvdjS6jqMNnbmSRv91e7GuC1HUZry4aWRsnsOyj0FawjcozvFPiForaWaWbE8qlYQB39vTGa4TT7uOGUGSQD1JNdnd21texeVdQpKucgMOn0rkksbN9GtJjAN73YiZsnJXcRj8q35dLAz2L4afESw0LUIRJqMCDIHzSAVa+Mb6ZqnjOPxRostvJbalCpmMDqwE68NkDoSNp9+a8audOsFu9XC2ygQwq0YBPykg9PyrQ0iGKLR4GjjVWkQM5H8R9TURppS5kJF0nmomPNOZveoie3et2MRjUZOKUmoy1IQxjzUbU5iKiNSAhNRscinE4FRnrUkmkr8UbqiBpwNdRdiYN7UA4pgPrTw3GMU7jJAMjPegjFMDYp+8ehp3EhQafUW70BzTt2OpquZDFlP+jyf7ppin57Tj+E/ypl1GZIwVbG3kjPWs4sfWpbBss3wzot6AOkhP6iuhQnYuR2FcfPlrd1B5YYz71s6LYXWnxSpczBy7AhVJIWspi3NpWxU8UpQ9aphqlDe/FZtXEdpo3iDaFt7x/lHCyHt7H/GusjmDKCCCD0IryWOUqRzxXQaRr72eIpSXh9M8j6f4VhOn1Qmegq2KlSUgjmsu1vYriISQyBlPcVcVwcYrFoLmxZ38ts4aJz7qehro7LVYbkBSQj/AN09/pXEK+KsRz4PWsnBMnl1PQUl561YSYr3rjLPWpocLJ+8Uep5Fb9rqEFyv7qQE/3T1rKUGhHUWOs3VoQscpKf3G5FVvGvxTs/CWjabdSxAzXd/FAVJyPKBzKw9wvA92FZiyD1rxv4+6tcW9roVudKgmtjO0n22QnKuODCADwGXBJ9h0pQoxnJJhY+uIriKZA8Uiuh5DDkEV4D+17qb2/wa0nTkbAvdXTePURxO+PzK/lXXaHq+of2FZzzQGwuHgRpLZH3CFto+TPcCvKf2n7q81X4baJPKVZLTUzuYDGN8TAZ/FaWHpWrRuNRPlil7UlFfRo0ZIMg5/Knj2IFRKc81JnPPamCVg2jGS5ApQI/7/6UlMYU7jJlMXbrUqSBfumqgpwOKQGtDcsCPmH4Vr2d+ykDdXLJLtPWrsNxgdee9ZyiQz0DT9VKsvzV2+h+IzazI6yYIrxq3vSpHzVt2urMmPn5rmqU76CPt/4b+Iv+Eg8MTMzlmt5ghJ91B/xrrmdRnJCj1NeC/AvWri18B6jctHvFxebY2Y8YRAD9eW/Su21bXtSl0+doVM8ixs0duG2iRsHCk+54rw6lH94ybGj4W+IGn+IbHUp2dVNveyRRooyWi/gb8QDzUt94kmkylsPKX1zk14f8KNYubm41eD+y44YTJ5jyo3+rckgRf7oG7HpivSmkyMk1UqSiwaLEt08jlmYsT1JNVnk96ryzqilmYBR1JrGu9cjTctv8zY+8elaKI7GvcXUcMZeSRVFc7f6zJLlIMonc9z/hWZcXcszlpZCxqqz571tGFhkkkue9Vy5PNIze9QvLjPIrUBXkA71k6nq0NlESzBpD91B3/wDrVT1XXY7YNFAweXuey/4muOurx5pWd3LMeSTWkIX1ZoS6hqEt3OZJXyT+n0rOY7j1prPnknmo2bPeulKxIEk/QVy0Jz4dsSP+f4f+hmtTW7C41C2iS2nEZVslSSA35VxEivHM8Zb7jFeDxkd6AOsuR/puuf8AXuh/8dNWdNP/ABJLT08oVxG5s/ePPXnrXUaHaz29oZZZQUlVSiAk496QkapNRE5zmlY+h4qMkVQwJP41Ex45pxNRM1IBrH/61Rk0pJpjHjiobJEY1GacaYT3pAXqcDTcilHIxW5oPBNPBqIcfSlB/KqTAlzjrS55pm71pwPrQA/NO5HemUA4ouA6Uj7O5/2T/KsfdnrWpOf9FkIP8JrIOO5IpXER3MmyEdiWA/WuuzkkiuPniabaVcAg55HFdYr8VLbYiYN3zxUgNVweakDUD3LCnJHNLa3MdxCJoX3IcjP0OP6VWc5hfIYgqQQn3vw96o+GQBomFSVB5jYEn17f565pBsddp+qT2cweF9p7qeh+ors9N1y3vQFLCKX+4T1+hrzgNzxwaninZCDkjHespU0xHqyyg9+alD5rhtO8RTRAR3X71OzfxD/GuotL+C6jDwShh3HQj6iueUbbiNVHI7mrMc5UgqcH1HWs9JAe4pxkCDc33Ryamwiv4n+K9l4KgSO7Bv72Rd0dojbWx2Zm/hX9T2FfPfjLxtrPjfxH/a2qsiBF8uC2iJ8uFfRQe56k9T+QrJ1rU7jWfEN5ql05eWeUuc9h0AHsBgfhVIAiuylRjHXqUon0X8EviQtxp8fhfV7w+ZENts0xzhf7ufT0z0r0/wAc+HU8X/D/AFHQGISWdN0Dt0SZTuQ/TIx9Ca+KYJpra4Se3laORDlXU4INfQHwn+K+ravcv4f1uNbl4oDLFcA4YgEAg/nXNWoOMueBNjwO5trizvZbS7iaG4hcxyRMMFGBwQfxqKvqDxZ8NvB3jXXf7Yurq90y8dQszWwTExHRmDAjcBxnuMelZS/s++D3GU8R6uw9R5P/AMTXXDFRtqirnzoODUg44r6J/wCGePCp66/rP5Rf/E1IP2d/CuP+Q/rP5Rf/ABNV9agPmPnQHFOr6K/4Z58Kg/8AIe1n/wAhf/E04fs9eFP+g9rP/kL/AOJo+tQFzHzdjB6UtfSB/Z68KH/mO61+Plf/ABNNP7PHhXP/ACHdZ/KL/wCJo+twDmPnGno5U4FfRX/DPHhbH/Id1n8ov/iaP+GevCv/AEHtZ/KL/wCJo+twDmPn1JiDk9K09OS81LUrfT7GJprm4kEUUa9WYnAH+e1e3H9n3wmoJOvaz9T5X/xNbnhH4f8AhXwNq0uo2l3cXt26eWkt1tJhU9doUDk9z1xx61lPExtoI63RLbT/AAP8Prezu7uKC20+Dfc3Mh2ru6u+fdif0rxXxz8crrW0uNF8LRPaWMmY3v5MiaVe+wfwA9Ofmx6U/wDaA8S3EtvpXh+2kdbWUPdzc48wq21AfYcn649K8RjmZDxj8ayoYdSXPLcEj1XwD4lu9D1lLi2n2hhskQjKuvoRXv414XWlJeWygow+Yg52n0xXx3a6xcQONpArv/C3xCvLOVYpZd0LDDKx4Ip1qF9QPbbm+mnYmSQn27flVNpD61Ckyy26Sp911DD6EZphcCudIRIze9RPIAOTzUMk4Ck5xisHUPEMEIKWxErf3h90f41SV9hpXNe5vIoIjJNIEX1NcrquvyTBorclIu57t/hWRfajNdSl5ZC5PbsPp6VQeQt1NbxppblJExeSeURxjLHoBVRzg46Ee3SrNlOYdTgkUgYcZJGah1CUy6lcSM8blpGJaIYQ5Ocj2rSL1sMrs3FRsfWkY+9Rk+9WSO3fMOe9ed3Bzdyn/bb+Zr0AnvXnsn+uf3Yn9aTAbXZae3/Emtf+uYrjeh5rrdMbOj2/qEA/WpQFtjURoJyaaT2qgGswxURNKTk0wnPSoJEY1GTSsc9aYTikAE+lMY8f55pScfWo2PPXipAvAmn7sjiolOPWnBvSui5RICadn1pm7NAODgdKLj2JQfenZz1qIEinZHrT5guTKecUuSelRA0u4+9AwuSRaS8/wmsgnNad23+gyc9qyNx9aAHluK6ZD8oPfArlCTjnJrpozmJfoKIsSLAbjk08GoAccipA3vUJiKOr6stkn2eNRJM6+uAoPetjwlpNtc+GXNlfNJdLmRreQAZGOdp9eM+9ctqdjNLqVxMZUIEYk5GMLnGPrVnT11DRtRE1tcKGSRY8AnB3DP5VL8gZ0obIp6tyKrh2PzMACeoHSpEbkVQznNAuJz4uvFaZyoD4VmJH3xXbW17LDIHjkZHHdTiuB0eeC28VXj3EyRKfMG5zjnfXWQ3MNxF5kEqSpnAZTkVDQHZ2XiZ1CrdLuH99ev4ityPUre5tXMEof5Dx3HHpXm6yFelTLdOikqxU4PI47VDpLoJo8oFKOa3LDSbafwZe6hIP9JRi0bbuAF6gj3yfyFdD4J8L+HdQ0v7br0kztKxEUaOUVQDjJI5JJz7Ct3OyA4PFdn8MSR4tvSDg/wBmXH8hSXfg62tvidY6JDcmfT7thLG+4FvL53KSO42kZ9xW1pOk2+hfFjU7Kz3C3OmTSxq3VAyj5eeuDSc00B5ok83lr++l6D+M07zpv+e0v4OaiX/Vr9BS1egD/Pm/57zf99t/jQbi4H/LxN/38b/GmUcU0kFiTz7j/n4m/wC/jf40G4uT0uJv+/jf41HRRZAP+0XPe4m/7+H/ABpftFz/AM/E3/fxv8aj/KilZAS/abn/AJ+Jf+/jf40n2i47XEv/AH2f8ajop2QD/tFx/wA/E3/fZ/xpySztMn7+X7w/jPr9aip0ZxMn+8P50nYD0v40sW8Q6RntaP8A+h15p+FevePNOi1r4oeG9NuCRDLC3mYPJUMWI/EDH41y1z4Otp/i/J4ct5Ggsz/pBI5aOPYGKjPfnAz7VlTnyqwjihkCporp4TuA6CvR/Gngbw5p/h+S80WWSC6t13NE0xkEqjr16EdfT2rk59IsR8OI9Sjjb7Z5heSTdwULbdoHtwc1ftFJDPd9KulPhuwkZgB9miJJ7fIKpXviG1hysJ85x6cAfj/hXFwalcTaNZpLMzKkEagduFHaoHnJOBXMqWuoJGpf6zdXZxJLhOyLwK4LXZ5T41sQssiqfLyqsQD857Vvz3MNtCZrmZIowcbmOOa5XU7m3uvFtlLbzJKgMYJU5Gdx4rSw2dczUzdn3prHmoZi5gdYn2OVIV8ZwexxVjM59ahk1uOxiYKqv802e47AfWu51nwfc2PhWDxLa30d7ZSsFmwu14WPTI7qfWvKE0m6a82LNGH84xbueSBuzXZ+HfF2p23hy78P37fabe+ti0Y6bCG4PT1FZu6d0QV2Y++O1RsaHYVGTx1rUYFuCa4JsljXcyN8hPsa4bNSxXEwa6jTGJ0eAHsCP1Nczmui0xv+JTEM9M/zNINy4WGeDUTH1pScUwnnrQIQnHFMJ9KCwAzUZbJ4qNwAmmFvanojyH5RgdyelTi3jH3vnPvWkablsUo3KJPvzTGPvWqFVRwoH0FLgdhWn1d9x8hVyT04pd2aiDDsaXdipuIn3ADuacDleKhDDGacG9KYE2SO9KDnvUW6lzkZHSgCYHNPDDFQg04OR2H5UBciu54vs8kYkXdxx+NZWQBgGrd3bRxxPMrHr93tyao596AHbuMYrobe5hlRESVGYKMqDyOK5vJxWzY2cMQjudzFymcHoMigEzUDdOtPBqDPPpTgcVIFC/uoBdXCGdM/ZtmM87t2cfWkmvrVp2IuIsG5iYYPUAcms/Woo49QVo1wZF3tz1OcVVs40l1CCKXJVnAIBxQB3EcqSIHRgynkEd6kB5HPFVIESCBIo12oowBUwbkZoGcLef8AISuD281v5mtzwrdlZprJjw37xB7jgj+X5Vh3Zzfz/wDXRv506xuTZ6jDcj+BgTj07/pQI9DU+9OZvkP0rE/4SPTAf9bJ/wB+zQ3iPSyhHmS9P+eZpMZW0tj/AMIHd84yJf5Ctfw7Ky+GrUKTjDf+hGuVtNXgt/Dc2nMjmSTfhhjAzVvS/EVrY6TDayQzMyAglcYPJPr7012EbF5cuvj3SZUYqyIxBBxj71WhqlwPiNcXTMJHbTWjy4zxjFcxc67bza/aX6xTKkCkMpxk5z0/Oj+3YP8AhIZNQ8qby2tzCF4yD607DMRfugegr0PSfA3hu/0a0urjXL6CaaFZHXyl2qSMkA46V550AFekaTMw0KzGeBCn8qU2+gF6P4XeG5ceX4kuj/wGOrC/CLRW+7rl8fpHHWVqGuW2nRhrmQ5b7qKMs3/1ves4eObVT8tvdj8R/jUWk+pLZ1A+D+jj/mN3/wD36Sj/AIVBo/8A0G7/AP79pXNr8QUX7qXw/wCBj/GpB8RiOB/aGP8AeH+NFpgdB/wp/Rv+g3fn6RpSH4QaP/0Gr8/9s0/wrB/4WOx/i1D8GH+NMPxD3DBGoH/gY/xpJT7gdB/wqLRe+tah/wB+0qOT4VaBH9/X7tQP7wjFc+3juFvvQ3h+rA/1rRsNatdSiL20hLL95GGGX8KdpLqCKmu+B/D+laDeXltrl1cTwx70iKLhjkdSBXArxIv1H869C12Uv4cvRnI8o154PlYEg8GtI3a1Gem65rktz8S9DuliWNoYJAO/XdWa19NN8U57iSQlzbAZHHG1eKwrnX7efXbS+EEwSBGVlOMnPp+dMTW4F8TyaoYZfLaPywmRu6AZ9O1Ty2A6/V7hjol3k8mF/wCVc/K5/wCFY7Sf4Bn/AL+VHe+J7W6sJrdba4UyIVBbbgZH1rOOrwnwoNK8uTzNu3fxj72aLDOvsmxpttz/AMsk/wDQRUxaubg8TWkVnFEbeclECkjHOBj1qQeKbM9ba4/T/GmFyr4qvN00Nmp4UeY31PQflmsbTzjVrY5/5ar/ADpL24a8v5bls/O2QPQdh+VFiP8AiZ2+enmr/MU7Ad4WOetROyqhZmAAHJPFDN1qKVUliaORQyMMEHuKQzIjvrNbwP8AaY8C9aTOeNuzGfpmmWNzB9rswJkJFuyEZ5yWzisjUIo7fVJoYVIjU4UE57Cp9Gijl1H94Cdi7157gipIudMTTC3vSFuPQd6jY8+tUMhuLmCJWSSZEYg4DHrXJBTiuivrCGdnuGd1cJkgdDgVgdqhskbtOMZrZ064iSySJpUD5PGeetZFaFlZxTQrOzNkN90dKV7AabN6daYzAChjj60+OHI3SD6CnGLm7IaVyHbI5+UE++OKcltIWG4gD2NWgOKBXSqKW5aihMBVAAAApM0pzTD9Ca12KHg59aM4pmeKOaLgUKAxqPOepIp2Qe9cV7GJLn34pwPvUORSgkdKdyifJPenKxBABqAN61JvweaLgTg59KXODwQagD+ufypd5ouK4y9b/Qm+orM3fX8qvXzf6H/wIVQyaLjDdXQ2rf6FCP8AYFc5ures2zYw/wC6BRcVy2GxT1bioQxpwYetIRj64c30Y9I/6mqtkcalbn0kX+dWNXOdQU5z8g/rVW14voT6SL/OhMo7HOKcrEHsah3c+9OB5qgOQuv+P6f/AK6N/M1DgVPcj/TZj/tt/OrMWkX0tt5yRDBGQpPzH8KVxGfgUYFSEFTgggjsaSquDG4o49OamggkubhYYly7dK6CDw9arGDPLJI3+ydo/wAaLiRzNFb174f8uIy2bmTHJjfrj2NYn/AR+VMdiPFehaa2NGtOR/qV/lXAkZHQCu604/8AEote37pf5VMho5LXJJJtfuS5ztbYo9AKojPpVzVRnXLsjp5hqTS9Ll1CUkkxwr95/X2HvQBnBSSFAyT09TVpNL1GVcx2U5Hrtx/OuxtbG0skxbwKp7v1Y/jVrcadwOEk0zUYlzJZTqB1O3I/Sq2DkjuOor0TdjpVW8sLO9QieFS3Z14YfjU3A4XB9K0NFleHXrYocbm2MM9Qe1GpaZLp0/J3xMflk6fgfem6WP8Aic2v/XVarcDrNYOdBu/+uZrhsGu31cg6FdYP/LM1xODQgG4NJin8jtV3TtLm1CQ4ISNT8znn8B70xGfg+g/GjBrqR4dsAmC8xb+9u/pisnUdJksv3iMZIScbscg+/wDjUhaxmfhS4FOwaDn0FNjGmpbL/kJW/wD10X+dTWun3V4heGNQo/iY4BpsMUkGrRRSoUdZFyD9aTYmdcSKaTxTS2KaWFAzldTOdYuT/tmpdGJGonn/AJZn+lQX/wA2p3ByP9Yam0nK6kPdSKkSN4k5ppamsfem5oEMuW/0WX/cP8q5oEY6CuguW/0SXn+A/wAqxI7eaQZSJiPXFS1d6BYi4rV084s+OzHFU/sF3jPkn8xV21iligIkjYfNRyvsOxaiTc+484qwTxTIR+6B7nmnEdq7KUbRLirIUDigikBpC2OlXcdxeO5NISPWmluc0hYEVLYXFPWmHINBb2NISMUguZYbinAj1FQhz6CnZzXDzGROGI+lOzgZqDPpTs+vWncCXd33DPtTg1RdTjgUoJouBMDzTlbB96hU08Hii4Ed8f8ARR2O4VQ57mrl4f3C8/xVSzTGHcVuWbH7DEOPu1hAZrYs2P2OP6UAy7mnBu+QB71EGzzQwDIUYZBGDTQjL1J1kvdyOrAKBlTmoITtnjPowP61JdRJFclEGFAHXmo0UFwDyCRU3Hc6dZFfDIykeoORUitzVSGOKCPy4xhc55OamD9KsZgFQ+qlW6GbB/76rqQ9cuvGrr/12/rXRhsnv+dJEmBqyqurSYH3gGP1xVLPtWhqvOpscfwKKpiqA1dARd00mPmGFz7Vu7qxNE4Wf6j+ta2aLjJg3/665LUo1j1e4RBhd2cfUZ/rXUZrm9U/5C83HcfyFFxlIDFdpYN/xK7Yf9Ml/lXGiuvsmxpsAOM+Wv8AKhiRzGpgtrdyByfMNdbaQLa2UdumQEH5nufzrlLznXpf+u39a60t8xpjJN3vQGHv+VRbj6mjcPU0ASbh6mjdn1/lUe+jcfU0ANvYFu7KSBx94cH0PY1yumgjV7b/AK6D+ddaG5Ga5O041qE/9Nf60AdJqh/4ktyMnHlmuPya6vU2/wCJRcDvsNctSQDa6vSlWPR4AP4l3H3JrlhxXUaef+JVbj/YFDAubqhvFWWwmjbkFD/KnZqK4P8Ao0mf7jfypCZyXOOlHNOAOBRyR0NOwzp7NRFp8KDHCDtVDU1H9qWUnG4tg/gR/jV6JsW0eP7o/lVa6i824gcsQEbPHfpSjFvYaVy2W5pjSKilnYKo7mgkGkbaRgjIrX2LDkOZusNfTMCDlycj61JYOiXql3CjB5NbRAyeO9IIomYBokYe4FHsH3DkHE8ZyD9KaAXPFSeWgTaowB0AoyFAAyfpSjRb3BQGmNRGcjJxUVTO3yHoKg5reMUtEWl2HZ4p6E7TyOtRE4pyscEDpVNXGPJ7DpSds0ZxUZbPSlewhSeM0hYYxRnIxTe1IkMilzxTc5PNJuwaRIuaU9OKYWo3e9BRkA9hTgc1F1p4J7155lYkB7UvWmdetOGe/wClAyQHHXpTgajHuKeBQA7JxkUrOFUseAKQfWlwGGCARVAVriZZVULng55qAKSaszxIm0ouOveose1AXGBavQXUUcCxtuBHt71Tx6CrdvDE0SsyAn3Jp6gXwcjNOBqPr0FKDTAoXfzXjHPp/KoUAEi49aluAftL8U1VORx0pIDdznmlBIqIMfQ/hTg3sTVgZQP/ABMwTg/vc/rW5msItsvd5HAfJx9avDUof7sh/CpQFfUcm+J77RVXBNT3Myz3BkUEDAGDUXPpTuOxpaQSFmz6j+tam73rG0+4hgEglbbnGOM1d+32naY/98mhCLu6uf1AZ1OU4HUfyFaYv7Uf8tD/AN8msu7kEt48kZ3Keh/CjcZXwfSuntH/AOJfCP8ApmP5Vze0+ldDan/QIev3B0+lFxmHdnOsSnt5v9RXTluTyDXNXXOrSN/01roCfYmhCJd3+c03cfU/nTc0hOf4T+VMRJuOPejdUe7Hajd7UASBskYrmrbI1eLB/wCWv9a6LPPQVz8AP9pxn0k/rSY0bWoHOlzj/YNc3iuhvWJ06Ucj5awMEjpRcENAOa6Kzz/ZsHUfIK5/B9D+IrVtr63S0jjdyCoxjaaTYzRLD1FMmbNvIB/cP8qrHULT/noR/wABNMfULVonVXOSpHKmmIxAvA5qeG2aXk8KPzpIYTJKF7dzitJQqqFAwBWsIX1ZSVy2gCwoBjgdzTJT8y/WkEqhRwcims4Zl46Gt0WSFmPYCik5pCCasCIn5j9aAfnBppJzxQM7hQBLk0mRSc0Z9qVwGNIpUjNR5PrTnVQpOOajyewoAUk0qnbnofrTOc4xSgA55zU3Ex5bJpM0EDHQ00nFSITOO5P1oz6mm5PpmkyKVwH9+/50vAFM3igt71SQhxb6VGWNJnNNJApN2Q1sf//Z",sizes:"512x512",type:"image/jpeg",purpose:"any maskable"}
    ],
    categories:["lifestyle","productivity"]
  };
  try {
    const blob = new Blob([JSON.stringify(m)],{type:'application/manifest+json'});
    const el = document.getElementById('__pwa_manifest__');
    if(el) el.href = URL.createObjectURL(blob);
  } catch(e){}
})();

// 2) Inline Service Worker — no external sw.js needed
if('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    const swSrc = `
const CV = 'tf-v2';
self.addEventListener('install', e => { e.waitUntil(self.skipWaiting()); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CV).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch', e => {
  if(e.request.method!=='GET') return;
  e.respondWith(
    caches.open(CV).then(cache =>
      cache.match(e.request).then(cached => {
        const fresh = fetch(e.request).then(res => {
          if(res && res.status===200) cache.put(e.request, res.clone());
          return res;
        }).catch(()=>cached);
        return cached || fresh;
      })
    )
  );
});`;
    try {
      const blob = new Blob([swSrc],{type:'application/javascript'});
      const url  = URL.createObjectURL(blob);
      await navigator.serviceWorker.register(url, {scope:'./'});
      console.log('SW registered (inline)');
    } catch(e) {
      // fallback to external if blob SW blocked
      try { await navigator.serviceWorker.register('sw.js'); } catch(_){}
    }
  });
}

// PWA install prompt
let _pwaInstallPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  _pwaInstallPrompt = e;
  // Show install banner after 3 seconds if not standalone
  if(!window.matchMedia('(display-mode: standalone)').matches) {
    setTimeout(showPWABanner, 3000);
  }
});

function showPWABanner() {
  if(!_pwaInstallPrompt) return;
  if(localStorage.getItem('mrd_pwa_dismissed')) return;
  const banner = document.createElement('div');
  banner.id = 'pwa-banner';
  banner.style.cssText = 'position:fixed;bottom:calc(90px + env(safe-area-inset-bottom));left:14px;right:14px;z-index:9000;background:rgba(10,11,15,.97);border:1px solid rgba(var(--accent-rgb),.3);border-radius:18px;padding:14px 16px;display:flex;align-items:center;gap:12px;box-shadow:0 8px 32px rgba(0,0,0,.5);backdrop-filter:blur(16px);animation:slideUp .4s cubic-bezier(.22,1,.36,1)';
  banner.innerHTML = `
    <div style="width:40px;height:40px;border-radius:12px;background:rgba(var(--accent-rgb),.15);border:1px solid rgba(var(--accent-rgb),.3);display:flex;align-items:center;justify-content:center;font-size:1.375rem;flex-shrink:0">🌙</div>
    <div style="flex:1;min-width:0">
      <div style="font-size:0.8125rem;font-weight:600;color:var(--text);margin-bottom:1px">Install Toukir's Flow</div>
      <div style="font-size:0.625rem;color:var(--t3);letter-spacing:.04em">Add to home screen for the best experience</div>
    </div>
    <div style="display:flex;gap:6px;flex-shrink:0">
      <button onclick="installPWA()" style="padding:7px 14px;border-radius:10px;border:none;background:linear-gradient(135deg,var(--gold),var(--gold2));color:#0d0c09;font-family:'Manrope',sans-serif;font-size:0.6875rem;font-weight:600;cursor:pointer;-webkit-tap-highlight-color:transparent">Install</button>
      <button onclick="dismissPWABanner()" style="padding:7px 10px;border-radius:10px;border:1px solid var(--bd);background:rgba(255,255,255,.05);color:var(--t3);font-family:'Manrope',sans-serif;font-size:0.6875rem;cursor:pointer;-webkit-tap-highlight-color:transparent">✕</button>
    </div>`;
  document.body.appendChild(banner);
}

async function installPWA() {
  if(!_pwaInstallPrompt) return;
  _pwaInstallPrompt.prompt();
  const { outcome } = await _pwaInstallPrompt.userChoice;
  _pwaInstallPrompt = null;
  dismissPWABanner();
}

function dismissPWABanner() {
  const b = document.getElementById('pwa-banner');
  if(b) { b.style.opacity='0'; b.style.transform='translateY(20px)'; b.style.transition='all .3s'; setTimeout(()=>b.remove(),300); }
  localStorage.setItem('mrd_pwa_dismissed', '1');
}

// ══════════════════════════════════════════════
// 🎯 DAILY CHALLENGE
// ══════════════════════════════════════════════

function getDailyChallenge() {
  const seed = parseInt(dateKey(now).replace(/-/g,'')) % DAILY_CHALLENGES.length;
  return DAILY_CHALLENGES[seed];
}

function loadChallengeState() {
  try {
    const r = localStorage.getItem('mrd_challenge');
    if(r) { const d = JSON.parse(r); if(d.date === TODAY_KEY) return d; }
  } catch {}
  return { date: TODAY_KEY, done: false };
}
function saveChallengeState(done) {
  try { localStorage.setItem('mrd_challenge', JSON.stringify({ date: TODAY_KEY, done })); } catch {}
  // ☁️ Push challenge state to Supabase settings (debounced)
  clearTimeout(saveChallengeState._supaTimer);
  saveChallengeState._supaTimer = setTimeout(() => { supaPushSettings(); }, 3000);
}

function renderChallengeLevelCard() {
  const el = document.getElementById('challenge-level-card');
  if (!el) return;
  // XP functions defined later in script — guard against early call
  if (typeof getXP !== 'function' || typeof getLevelForXP !== 'function') {
    setTimeout(renderChallengeLevelCard, 300); return;
  }
  const xp     = getXP();
  const curLv  = getLevelForXP(xp);
  const nextLv = getNextLevelForXP(xp);
  const prevXP = curLv.xpNeeded;
  const rangeXP = nextLv ? (nextLv.xpNeeded - prevXP) : 1;
  const earnedInRange = nextLv ? (xp - prevXP) : rangeXP;
  const pct = Math.min(100, Math.round(earnedInRange / rangeXP * 100));

  // Build level dots (up to 8 levels)
  const dots = XP_LEVELS.map(lv => {
    const reached = xp >= lv.xpNeeded;
    const isCur   = lv.level === curLv.level;
    return `<div style="width:${isCur?'22px':'8px'};height:8px;border-radius:99px;transition:width .3s;background:${reached ? (isCur ? 'var(--gold)' : 'rgba(var(--accent-rgb),.45)') : 'rgba(255,255,255,.1)'}"></div>`;
  }).join('');

  el.innerHTML = `
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">
      <div style="width:44px;height:44px;border-radius:13px;background:linear-gradient(135deg,rgba(var(--accent-rgb),.18),rgba(var(--accent-rgb),.06));border:1px solid rgba(var(--accent-rgb),.3);display:flex;align-items:center;justify-content:center;font-size:1.4rem;flex-shrink:0">${curLv.icon}</div>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:baseline;gap:6px">
          <span style="font-size:0.5rem;letter-spacing:.18em;text-transform:uppercase;color:rgba(var(--accent-rgb),.55);font-weight:700">Level ${curLv.level}</span>
          <span style="font-family:'Playfair Display',serif;font-size:1.05rem;font-weight:600;color:var(--text)">${curLv.name}</span>
        </div>
        <div style="font-size:0.6875rem;color:var(--t3);line-height:1.4;margin-top:1px">${curLv.desc}</div>
      </div>
      <div style="text-align:right;flex-shrink:0">
        <div style="font-family:'Playfair Display',serif;font-size:1.1rem;color:var(--gold);font-weight:300">${xp.toLocaleString()}</div>
        <div style="font-size:0.5rem;color:var(--t3);letter-spacing:.1em">XP</div>
      </div>
    </div>
    <!-- Progress bar -->
    <div style="margin-bottom:8px">
      <div style="height:5px;border-radius:99px;background:rgba(255,255,255,.07);overflow:hidden">
        <div style="height:100%;width:${pct}%;border-radius:99px;background:linear-gradient(90deg,var(--gold),var(--accent-3));transition:width .6s cubic-bezier(.22,1,.36,1)"></div>
      </div>
      <div style="display:flex;justify-content:space-between;margin-top:5px">
        <div style="font-size:0.5rem;color:var(--t3);letter-spacing:.08em">${earnedInRange.toLocaleString()} / ${rangeXP.toLocaleString()} XP</div>
        ${nextLv
          ? `<div style="font-size:0.5rem;color:rgba(var(--accent-rgb),.6);letter-spacing:.06em">${(nextLv.xpNeeded - xp).toLocaleString()} XP to <em style="font-style:normal;color:var(--gold)">${nextLv.name}</em> ${nextLv.icon}</div>`
          : `<div style="font-size:0.5rem;color:var(--gold);letter-spacing:.06em">✦ Max Level</div>`}
      </div>
    </div>
    <!-- Level dots -->
    <div style="display:flex;gap:4px;align-items:center">${dots}</div>`;
}

function renderDailyChallenge() {
  renderChallengeLevelCard();
  const el = document.getElementById('challenge-card');
  if(!el) return;
  const ch    = getDailyChallenge();
  const state = loadChallengeState();
  const badge = document.getElementById('challenge-done-badge');
  if(badge) badge.style.display = state.done ? 'inline-flex' : 'none';

  el.innerHTML = `
    <div style="display:flex;align-items:flex-start;gap:14px">
      <div style="width:48px;height:48px;border-radius:14px;background:rgba(var(--accent-rgb),.12);border:1px solid rgba(var(--accent-rgb),.22);display:flex;align-items:center;justify-content:center;font-size:1.5rem;flex-shrink:0">${ch.icon}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:0.9375rem;font-weight:600;color:var(--text);margin-bottom:4px">${ch.title}</div>
        <div style="font-size:0.75rem;color:var(--t2);line-height:1.6;margin-bottom:12px">${ch.desc}</div>
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
          <button onclick="toggleChallengeDone()" style="padding:9px 18px;border-radius:12px;border:none;background:${state.done ? 'rgba(var(--accent-rgb),.15)' : 'linear-gradient(135deg,var(--gold),var(--gold2))'};color:${state.done ? 'var(--green)' : '#0d0c09'};font-family:'Manrope',sans-serif;font-size:0.75rem;font-weight:600;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:all .2s">
            ${state.done ? '✓ Completed!' : 'Mark Complete'}
          </button>
          <div style="font-size:0.5625rem;padding:4px 10px;border-radius:99px;background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.18);color:var(--gold);letter-spacing:.06em">🏅 ${ch.reward}</div>
        </div>
      </div>
    </div>`;
}

function toggleChallengeDone() {
  const state = loadChallengeState();
  saveChallengeState(!state.done);
  renderDailyChallenge();
  if(!state.done) {
    showCelebration('Challenge Complete! 🎯', `You completed today's challenge: "${getDailyChallenge().title}"`, '🎯');
    checkAchievements();
  }
}

// ══════════════════════════════════════════════
// 🏆 ACHIEVEMENTS SYSTEM
// ══════════════════════════════════════════════

function loadAchievements() {
  try { const r = localStorage.getItem('mrd_achievements'); if(r) return JSON.parse(r); } catch {}
  return {};
}
function saveAchievements(data) {
  try { localStorage.setItem('mrd_achievements', JSON.stringify(data)); } catch {}
  // ☁️ Push achievements to Supabase settings (debounced)
  clearTimeout(saveAchievements._supaTimer);
  saveAchievements._supaTimer = setTimeout(() => { supaPushSettings(); }, 3000);
}

function checkAchievements() {
  const unlocked = loadAchievements();
  let newUnlock = null;
  ACHIEVEMENTS.forEach(a => {
    if(!unlocked[a.id]) {
      try {
        if(a.check()) {
          unlocked[a.id] = new Date().toISOString();
          newUnlock = a;
        }
      } catch(e) {}
    }
  });
  if(newUnlock) {
    saveAchievements(unlocked);
    const _isToday = (typeof viewingDate === 'undefined' || !viewingDate || viewingDate === TODAY_KEY);
    if(_isToday) {
      setTimeout(() => {
        showCelebration('Achievement Unlocked! 🏆', `${newUnlock.icon} ${newUnlock.title} — ${newUnlock.desc}`, newUnlock.icon);
      }, 800);
    }
  }
  renderAchievements();
  updateAchieveBadge();
}

function renderAchievements() {
  const el = document.getElementById('achievements-grid');
  if(!el) return;
  const unlocked = loadAchievements();
  el.innerHTML = ACHIEVEMENTS.map(a => {
    const done = !!unlocked[a.id];
    const date = done ? new Date(unlocked[a.id]).toLocaleDateString() : '';
    return `
    <div style="border-radius:14px;padding:12px 8px;text-align:center;background:${done ? 'rgba(var(--accent-rgb),.08)' : 'rgba(255,255,255,.03)'};border:1px solid ${done ? 'rgba(var(--accent-rgb),.25)' : 'rgba(255,255,255,.06)'};transition:all .3s">
      <div style="font-size:1.5rem;margin-bottom:6px;${done ? '' : 'filter:grayscale(1);opacity:.35'}">${a.icon}</div>
      <div style="font-size:0.5625rem;font-weight:600;color:${done ? 'var(--gold)' : 'var(--t3)'};margin-bottom:2px;line-height:1.3">${a.title}</div>
      <div style="font-size:0.4375rem;color:var(--t3);line-height:1.4;margin-bottom:${date ? '4px' : '0'}">${a.desc}</div>
      ${date ? `<div style="font-size:0.4375rem;color:var(--teal);opacity:.8">${date}</div>` : ''}
    </div>`;
  }).join('');
}

function updateAchieveBadge() {
  const el = document.getElementById('achieve-count-badge');
  if(!el) return;
  const count = Object.keys(loadAchievements()).length;
  el.textContent = count + ' / ' + ACHIEVEMENTS.length + ' unlocked';
  el.style.background = count > 0 ? 'rgba(var(--accent-rgb),.1)' : 'rgba(255,255,255,.04)';
}

// ══════════════════════════════════════════════
// 🌙 RAMADAN MODE
// ══════════════════════════════════════════════
function renderRamadanMode() {
  const banner = document.getElementById('ramadan-banner');
  if(!banner) return;
  const h = toHijriObj(new Date());
  if(h.month !== 9) { banner.style.display = 'none'; return; }

  banner.style.display = 'block';
  const title = document.getElementById('ramadan-title');
  const sub   = document.getElementById('ramadan-sub');
  if(title) title.textContent = 'رَمَضَان مُبَارَك';
  if(sub)   sub.textContent   = `Day ${h.day} of Ramadan · ${30 - h.day} days remaining`;
  updateRamadanCountdown();
}

function updateRamadanCountdown() {
  const cd  = document.getElementById('ramadan-countdown');
  const lbl = document.getElementById('ramadan-next-lbl');
  if(!cd) return;

  const now2     = new Date();
  const nowMins  = now2.getHours() * 60 + now2.getMinutes();
  const maghrib  = prayerTimes.Maghrib ? (parseInt(prayerTimes.Maghrib.split(':')[0])*60 + parseInt(prayerTimes.Maghrib.split(':')[1])) : -1;
  const fajr     = prayerTimes.Fajr    ? (parseInt(prayerTimes.Fajr.split(':')[0])*60    + parseInt(prayerTimes.Fajr.split(':')[1]))    : -1;

  let targetMins, label;
  if(maghrib >= 0 && nowMins < maghrib) {
    targetMins = maghrib; label = 'until Iftar';
  } else if(fajr >= 0) {
    targetMins = fajr + 1440; label = 'until Suhoor ends';
  } else { cd.textContent = '--:--:--'; return; }

  let diff = (targetMins - nowMins) * 60 - now2.getSeconds();
  if(diff < 0) diff += 86400;
  const h2 = Math.floor(diff/3600), m = Math.floor((diff%3600)/60), s = diff%60;
  const pad = n => String(n).padStart(2,'0');
  cd.textContent = `${pad(h2)}:${pad(m)}:${pad(s)}`;
  if(lbl) lbl.textContent = label;
}

// ══════════════════════════════════════════════
// EXPAND DEFAULTS UPDATE
// ══════════════════════════════════════════════
// Add new sections to expand defaults tracking


// ══════════════════════════════════════════════
// 📖 QURAN TEXT READER (no audio)
// ══════════════════════════════════════════════

// Offline data — works without internet (most-read surahs)
const QP_OFFLINE = {"1":{"ar":["بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ","اَلْحَمْدُ لِلّٰهِ رَبِّ الْعٰلَمِيْنَ","الرَّحْمٰنِ الرَّحِيْمِ","مٰلِكِ يَوْمِ الدِّيْنِ","اِيَّاكَ نَعْبُدُ وَاِيَّاكَ نَسْتَعِيْنُ","اِهْدِنَا الصِّرَاطَ الْمُسْتَقِيْمَ","صِرَاطَ الَّذِيْنَ اَنْعَمْتَ عَلَيْهِمْ ۙ غَيْرِ الْمَغْضُوْبِ عَلَيْهِمْ وَلَا الضَّآلِّيْنَ"],"bn":["আল্লাহর নামে শুরু করছি, যিনি পরম করুণাময়, অতি দয়ালু।","সমস্ত প্রশংসা আল্লাহর জন্য, যিনি সকল সৃষ্টির প্রতিপালক।","যিনি পরম করুণাময়, অতি দয়ালু।","বিচার দিনের মালিক।","আমরা শুধু তোমারই ইবাদত করি এবং শুধু তোমার কাছেই সাহায্য চাই।","আমাদের সরল পথ দেখাও।","তাদের পথ, যাদের উপর তুমি নেয়ামত দিয়েছ; তাদের পথ নয়, যাদের উপর গজব নেমেছে এবং যারা পথভ্রষ্ট।"]},"36":{"ar":["يٰسٓ","وَالْقُرْاٰنِ الْحَكِيْمِ","اِنَّكَ لَمِنَ الْمُرْسَلِيْنَ","عَلٰى صِرَاطٍ مُّسْتَقِيْمٍ","تَنْزِيْلَ الْعَزِيْزِ الرَّحِيْمِ"],"bn":["ইয়া-সীন।","জ্ঞানময় কুরআনের শপথ।","নিশ্চয়ই তুমি রাসূলদের একজন।","সরল পথে আছ।","পরাক্রমশালী, পরম দয়ালুর নাজিলকৃত।"]},"55":{"ar":["اَلرَّحْمٰنُ","عَلَّمَ الْقُرْاٰنَ","خَلَقَ الْاِنْسَانَ","عَلَّمَهُ الْبَيَانَ","الشَّمْسُ وَالْقَمَرُ بِحُسْبَانٍ","وَّالنَّجْمُ وَالشَّجَرُ يَسْجُدٰنِ","وَالسَّمَآءَ رَفَعَهَا وَوَضَعَ الْمِيْزَانَ"],"bn":["পরম করুণাময়।","তিনিই কুরআন শিক্ষা দিয়েছেন।","তিনি মানুষ সৃষ্টি করেছেন।","তাকে বর্ণনা করতে শিখিয়েছেন।","সূর্য ও চাঁদ নির্দিষ্ট হিসাব মেনে চলে।","এবং তারা ও বৃক্ষরাজি সিজদা করে।","তিনি আকাশ উঁচু করেছেন এবং পাল্লা স্থাপন করেছেন।"]},"67":{"ar":["تَبٰرَكَ الَّذِيْ بِيَدِهِ الْمُلْكُ وَهُوَ عَلٰى كُلِّ شَيْءٍ قَدِيْرٌ","الَّذِيْ خَلَقَ الْمَوْتَ وَالْحَيٰوةَ لِيَبْلُوَكُمْ اَيُّكُمْ اَحْسَنُ عَمَلًا ۗ وَهُوَ الْعَزِيْزُ الْغَفُوْرُ","الَّذِيْ خَلَقَ سَبْعَ سَمٰوٰتٍ طِبَاقًا"],"bn":["কত মহান তিনি, যাঁর হাতে সমস্ত ক্ষমতা এবং তিনি সবকিছুর উপর সর্বশক্তিমান।","যিনি মৃত্যু ও জীবন সৃষ্টি করেছেন যাতে তিনি তোমাদের পরীক্ষা করেন কে আমলে উত্তম। তিনি পরাক্রমশালী, ক্ষমাশীল।","যিনি সাতটি আকাশ স্তরে স্তরে সৃষ্টি করেছেন।"]},"97":{"ar":["اِنَّآ اَنْزَلْنٰهُ فِيْ لَيْلَةِ الْقَدْرِ","وَمَآ اَدْرٰىكَ مَا لَيْلَةُ الْقَدْرِ","لَيْلَةُ الْقَدْرِ خَيْرٌ مِّنْ اَلْفِ شَهْرٍ","تَنَزَّلُ الْمَلٰٓئِكَةُ وَالرُّوْحُ فِيْهَا بِاِذْنِ رَبِّهِمْ مِّنْ كُلِّ اَمْرٍ","سَلٰمٌ ۚ هِيَ حَتّٰى مَطْلَعِ الْفَجْرِ"],"bn":["নিশ্চয়ই আমি এটি কদরের রাতে নাজিল করেছি।","কদরের রাত কী তা তুমি কি জানো?","কদরের রাত হাজার মাসের চেয়ে উত্তম।","সে রাতে ফেরেশতারা ও রূহ তাদের প্রভুর অনুমতিক্রমে প্রতিটি কাজে অবতীর্ণ হয়।","এটি ফজর উদয় পর্যন্ত শান্তিময়।"]},"103":{"ar":["وَالْعَصْرِ","اِنَّ الْاِنْسَانَ لَفِيْ خُسْرٍ","اِلَّا الَّذِيْنَ اٰمَنُوْا وَعَمِلُوا الصّٰلِحٰتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ"],"bn":["যুগের শপথ।","নিশ্চয়ই মানুষ ক্ষতিগ্রস্ত।","তবে তারা নয়, যারা ঈমান এনেছে, সৎকাজ করেছে এবং পরস্পরকে সত্যের ও ধৈর্যের উপদেশ দিয়েছে।"]},"108":{"ar":["اِنَّآ اَعْطَيْنٰكَ الْكَوْثَرَ","فَصَلِّ لِرَبِّكَ وَانْحَرْ","اِنَّ شَانِئَكَ هُوَ الْاَبْتَرُ"],"bn":["নিশ্চয়ই আমি তোমাকে কাউসার দিয়েছি।","অতএব তোমার প্রভুর উদ্দেশ্যে নামাজ পড়ো এবং কোরবানি করো।","তোমার শত্রুই তো নির্বংশ।"]},"109":{"ar":["قُلْ يٰٓاَيُّهَا الْكٰفِرُوْنَ","لَآ اَعْبُدُ مَا تَعْبُدُوْنَ","وَلَآ اَنْتُمْ عٰبِدُوْنَ مَآ اَعْبُدُ","وَلَآ اَنَا۠ عَابِدٌ مَّا عَبَدتُّمْ","وَلَآ اَنْتُمْ عٰبِدُوْنَ مَآ اَعْبُدُ","لَكُمْ دِيْنُكُمْ وَلِيَ دِيْنِ"],"bn":["বলো, হে কাফেরেরা।","আমি তার ইবাদত করি না যার ইবাদত তোমরা করো।","এবং তোমরা তার ইবাদতকারী নও যার ইবাদত আমি করি।","আমি ইবাদতকারী নই তোমাদের উপাস্যদের।","এবং তোমরা আমার উপাস্যের ইবাদতকারী নও।","তোমাদের দ্বীন তোমাদের জন্য, আমার দ্বীন আমার জন্য।"]},"110":{"ar":["اِذَا جَآءَ نَصْرُ اللّٰهِ وَالْفَتْحُ","وَرَاَيْتَ النَّاسَ يَدْخُلُوْنَ فِيْ دِيْنِ اللّٰهِ اَفْوَاجًا","فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُ ۗ اِنَّهٗ كَانَ تَوَّابًا"],"bn":["যখন আল্লাহর সাহায্য ও বিজয় আসবে।","এবং তুমি দেখবে মানুষ দলে দলে আল্লাহর দ্বীনে প্রবেশ করছে।","তখন তোমার প্রভুর প্রশংসায় তাসবিহ পাঠ করো এবং তাঁর কাছে ক্ষমা চাও। নিশ্চয়ই তিনি তওবা কবুলকারী।"]},"111":{"ar":["تَبَّتْ يَدَآ اَبِيْ لَهَبٍ وَّتَبَّ","مَآ اَغْنٰى عَنْهُ مَالُهٗ وَمَا كَسَبَ","سَيَصْلٰى نَارًا ذَاتَ لَهَبٍ","وَّامْرَاَتُهٗ ۚ حَمَّالَةَ الْحَطَبِ","فِيْ جِيْدِهَا حَبْلٌ مِّنْ مَّسَدٍ"],"bn":["আবু লাহাবের হাত ধ্বংস হোক এবং সে নিজেও ধ্বংস হোক।","তার সম্পদ ও উপার্জন তার কোনো কাজে আসেনি।","শীঘ্রই সে লেলিহান আগুনে প্রবেশ করবে।","এবং তার স্ত্রীও, যে কাঠ বহনকারী।","তার গলায় থাকবে খেজুর আঁশের রশি।"]},"112":{"ar":["قُلْ هُوَ اللّٰهُ اَحَدٌ","اَللّٰهُ الصَّمَدُ","لَمْ يَلِدْ وَلَمْ يُوْلَدْ","وَلَمْ يَكُنْ لَّهٗ كُفُوًا اَحَدٌ"],"bn":["বলো, তিনিই আল্লাহ, এক।","আল্লাহ অমুখাপেক্ষী।","তিনি কাউকে জন্ম দেননি এবং তাঁকেও কেউ জন্ম দেয়নি।","এবং তাঁর সমতুল্য কেউ নেই।"]},"113":{"ar":["قُلْ اَعُوْذُ بِرَبِّ الْفَلَقِ","مِنْ شَرِّ مَا خَلَقَ","وَمِنْ شَرِّ غَاسِقٍ اِذَا وَقَبَ","وَمِنْ شَرِّ النَّفّٰثٰتِ فِى الْعُقَدِ","وَمِنْ شَرِّ حَاسِدٍ اِذَا حَسَدَ"],"bn":["বলো, আমি আশ্রয় নিচ্ছি ঊষার প্রভুর কাছে।","তাঁর সৃষ্ট সবকিছুর অনিষ্ট থেকে।","অন্ধকার রাতের অনিষ্ট থেকে যখন তা ঘনিয়ে আসে।","গ্রন্থিতে ফুঁদাত্রীদের অনিষ্ট থেকে।","হিংসুকের অনিষ্ট থেকে যখন সে হিংসা করে।"]},"114":{"ar":["قُلْ اَعُوْذُ بِرَبِّ النَّاسِ","مَلِكِ النَّاسِ","اِلٰهِ النَّاسِ","مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ","الَّذِيْ يُوَسْوِسُ فِيْ صُدُوْرِ النَّاسِ","مِنَ الْجِنَّةِ وَالنَّاسِ"],"bn":["বলো, আমি আশ্রয় নিচ্ছি মানুষের প্রভুর কাছে।","মানুষের অধিপতির কাছে।","মানুষের মাবুদের কাছে।","কুমন্ত্রণাদাতার অনিষ্ট থেকে, যে পিছিয়ে যায়।","যে মানুষের বুকে কুমন্ত্রণা দেয়।","জ্বিন ও মানুষের মধ্য থেকে।"]}};

// ══════════════════════════════════════════════
// QURAN READER v2
// ══════════════════════════════════════════════

let _qrState = {
  surahNum: 0,
  showAr:   true,
  showBn:   true,
  fontSize: 'normal',   // normal | large | xlarge
  hifzMode: false,
  loaded:   false,
  loading:  false,
  activeAyah: -1,
  audioOn:  false,
  reciter:  'Alafasy_128kbps', // default reciter
  audioPlaying: false,
  audioAyah: -1,
};

// ── Audio ────────────────────────────────────────────────────
const QR_RECITERS = [
  { id: 'Alafasy_128kbps',               name: 'Mishary Alafasy' },
  { id: 'AbdurRahmaanAs-Sudais_192kbps', name: 'Abdurrahman As-Sudais' },
  { id: 'Husary_128kbps',                name: 'Mahmoud Khalil Husary' },
  { id: 'Minshawy_Murattal_128kbps',     name: 'Mohamed Siddiq Minshawi' },
  { id: 'Muhammad_Ayyoub_128kbps',       name: 'Muhammad Ayyoub' },
  { id: 'Hani_Rifai_192kbps',            name: 'Hani Rifai' },
  { id: 'Maher_AlMuaiqly_128kbps',       name: 'Maher Al-Muaiqly' },
  { id: 'Ghamadi_40kbps',                name: 'Saad Al-Ghamdi' },
  { id: 'Ibrahim_Akhdar_32kbps',         name: 'Ibrahim Al-Akhdar' },
  { id: 'Abdullah_Basfar_192kbps',       name: 'Abdullah Basfar' },
  { id: 'Sahl_Yasin_128kbps',            name: 'Sahl Yasin' },
  { id: 'Ahmed_ibn_Ali_al-Ajamy_128kbps_ketaballah', name: 'Ahmed Al-Ajamy' },
];
let _qrAudio = null;
let _qrAudioQueue = [];
let _qrAudioIdx   = -1;
let _qrAudioSpeed    = 1;
let _qrAudioRepeat   = false;   // repeat current ayah
let _qrAudioAutoplay = false;   // auto-play next surah
let _qrProgTimer     = null;

/* ── helpers ── */
function _qrFmt(s) {
  if (!isFinite(s) || s < 0) return '0:00';
  const m = Math.floor(s / 60), sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2,'0')}`;
}

function _qrStartProgTimer() {
  clearInterval(_qrProgTimer);
  _qrProgTimer = setInterval(() => {
    if (!_qrAudio || _qrAudio.paused) return;
    const dur = _qrAudio.duration, cur = _qrAudio.currentTime;
    const pct = dur > 0 ? (cur / dur * 100) : 0;
    const prog = document.getElementById('qr-ab-prog');
    const thumb = document.getElementById('qr-ab-thumb');
    const curEl = document.getElementById('qr-ab-cur');
    const durEl = document.getElementById('qr-ab-dur');
    if (prog)  prog.style.width  = pct + '%';
    if (thumb) thumb.style.left  = pct + '%';
    if (curEl) curEl.textContent = _qrFmt(cur);
    if (durEl) durEl.textContent = _qrFmt(dur);
  }, 250);
}

function qrAudioSeek(e, track) {
  if (!_qrAudio || !_qrAudio.duration) return;
  const rect = track.getBoundingClientRect();
  const pct  = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
  _qrAudio.currentTime = pct * _qrAudio.duration;
}

function qrAudioSetSpeed(v) {
  _qrAudioSpeed = parseFloat(v);
  if (_qrAudio) _qrAudio.playbackRate = _qrAudioSpeed;
}

function qrAudioToggleRepeat() {
  _qrAudioRepeat = !_qrAudioRepeat;
  const btn = document.getElementById('qr-ab-repeat');
  if (btn) {
    btn.textContent = _qrAudioRepeat ? '🔁 Ayah' : '🔁 Off';
    btn.style.color = _qrAudioRepeat ? 'var(--gold)' : 'var(--t3)';
    btn.style.borderColor = _qrAudioRepeat ? 'rgba(var(--accent-rgb),.4)' : 'rgba(255,255,255,.14)';
    btn.style.background  = _qrAudioRepeat ? 'rgba(var(--accent-rgb),.1)' : 'rgba(255,255,255,.05)';
  }
}

function qrAudioToggleAutoplay() {
  _qrAudioAutoplay = !_qrAudioAutoplay;
  const btn = document.getElementById('qr-ab-auto');
  if (btn) {
    btn.textContent = _qrAudioAutoplay ? '▶▶ On' : '▶▶ Auto';
    btn.style.color = _qrAudioAutoplay ? 'var(--teal)' : 'var(--t3)';
    btn.style.borderColor = _qrAudioAutoplay ? 'rgba(var(--teal-rgb),.4)' : 'rgba(255,255,255,.14)';
    btn.style.background  = _qrAudioAutoplay ? 'rgba(var(--teal-rgb),.1)' : 'rgba(255,255,255,.05)';
  }
}

function qrAudioRewind() {
  if (!_qrAudio) return;
  _qrAudio.currentTime = 0;
  if (_qrAudio.paused) { _qrAudio.play().catch(()=>{}); _qrState.audioPlaying = true; _qrUpdateAudioBar(); }
}

function _qrAudioUrl(reciter, surah, ayah) {
  // everyayah.com: /data/{reciter}/{surah 3-digits}{ayah 3-digits}.mp3
  const s = String(surah).padStart(3, '0');
  const a = String(ayah).padStart(3, '0');
  return `https://everyayah.com/data/${reciter}/${s}${a}.mp3`;
}

function qrToggleAudio() {
  _qrState.audioOn = !_qrState.audioOn;
  if (!_qrState.audioOn) { qrAudioStop(); }
  _qrUpdateToolbar();
  _qrUpdateAudioBar();
}

function qrAudioStop() {
  if (_qrAudio) { _qrAudio.pause(); _qrAudio.src = ''; }
  _qrState.audioPlaying = false;
  _qrState.audioAyah = -1;
  _qrAudioIdx = -1;
  _qrAudioQueue = [];
  clearInterval(_qrProgTimer);
  // reset progress bar
  const prog = document.getElementById('qr-ab-prog');
  const thumb = document.getElementById('qr-ab-thumb');
  const curEl = document.getElementById('qr-ab-cur');
  if (prog)  prog.style.width = '0%';
  if (thumb) thumb.style.left = '0%';
  if (curEl) curEl.textContent = '0:00';
  _qrHighlightAudioAyah(-1);
  _qrUpdateAudioBar();
  // Update persistent bar play button
  const playEl = document.getElementById('qpb-play-btn');
  if (playEl) playEl.textContent = '▶';
}

function qrAudioPlayAyah(ayahN) {
  const raw = document.getElementById('qr-ayahs')?.dataset?.ayahs;
  if (!raw) return;
  const ayahs = JSON.parse(raw);
  const surah = _qrState.surahNum;

  // For surahs other than 1 (Fatiha) and 9 (Tawbah),
  // prepend bismillah as ayah 0 (everyayah: {surah}000.mp3)
  const hasBismillah = (surah !== 1 && surah !== 9);
  _qrAudioQueue = hasBismillah ? [0, ...ayahs.map(a => a.n)] : ayahs.map(a => a.n);

  // Find clicked ayah in queue
  _qrAudioIdx = _qrAudioQueue.indexOf(ayahN);
  if (_qrAudioIdx < 0) _qrAudioIdx = hasBismillah ? 1 : 0; // start from ayah 1 if not found
  _qrState.audioOn = true;
  _qrUpdateToolbar();
  _qrPlayCurrent();
}

function _qrPlayCurrent() {
  if (_qrAudioIdx < 0 || _qrAudioIdx >= _qrAudioQueue.length) {
    _qrState.audioPlaying = false;
    _qrHighlightAudioAyah(-1);
    clearInterval(_qrProgTimer);
    _qrUpdateAudioBar();
    // Autoplay next surah if enabled
    if (_qrAudioAutoplay) { setTimeout(qrNextSurah, 600); }
    return;
  }
  const ayahN = _qrAudioQueue[_qrAudioIdx];
  const url   = _qrAudioUrl(_qrState.reciter, _qrState.surahNum, ayahN);
  _qrState.audioAyah    = ayahN;
  _qrState.audioPlaying = true;
  _qrHighlightAudioAyah(ayahN);
  _qrUpdateAudioBar();

  // Scroll to ayah
  const aEl = document.getElementById('qr-ayah-' + ayahN);
  if (aEl) aEl.scrollIntoView({ behavior: 'smooth', block: 'center' });

  if (_qrAudio) { _qrAudio.pause(); _qrAudio.onended = null; _qrAudio.onerror = null; }
  _qrAudio = new Audio();
  _qrAudio.crossOrigin = 'anonymous';
  _qrAudio.src = url;
  _qrAudio.playbackRate = _qrAudioSpeed;
  _qrAudio.onloadedmetadata = () => {
    const durEl = document.getElementById('qr-ab-dur');
    if (durEl) durEl.textContent = _qrFmt(_qrAudio.duration);
  };
  _qrAudio.onended = () => {
    if (_qrAudioRepeat) { _qrAudio.currentTime = 0; _qrAudio.play().catch(()=>{}); return; }
    _qrAudioIdx++;
    _qrPlayCurrent();
  };
  _qrAudio.onerror = (e) => {
    console.warn('Audio error for', url, e);
    _qrState.audioPlaying = false;
    clearInterval(_qrProgTimer);
    _qrUpdateAudioBar();
  };
  _qrAudio.play().catch(err => {
    console.warn('Audio play() failed:', err);
    _qrState.audioPlaying = false;
    clearInterval(_qrProgTimer);
    _qrUpdateAudioBar();
  });
  _qrStartProgTimer();
}

function qrAudioPause() {
  if (_qrAudio && !_qrAudio.paused) {
    _qrAudio.pause();
    _qrState.audioPlaying = false;
    clearInterval(_qrProgTimer);
  } else if (_qrAudio && _qrAudio.paused && _qrAudioIdx >= 0) {
    _qrAudio.playbackRate = _qrAudioSpeed;
    _qrAudio.play().catch(()=>{});
    _qrState.audioPlaying = true;
    _qrStartProgTimer();
  }
  _qrUpdateAudioBar();
  // Keep pill play button in sync
  const pillPlay = document.getElementById('qr-pill-play');
  if (pillPlay) pillPlay.textContent = _qrState.audioPlaying ? '⏸' : '▶';
}

function qrAudioNext() {
  _qrAudioIdx++;
  _qrPlayCurrent();
}

function qrAudioPrev() {
  _qrAudioIdx = Math.max(0, _qrAudioIdx - 1);
  _qrPlayCurrent();
}

function qrAudioSetReciter(id) {
  _qrState.reciter = id;
  const wasPlaying = _qrState.audioPlaying;
  if (wasPlaying) _qrPlayCurrent();
  _qrSave();
  _qrUpdateAudioBar();
}

// ══════════════════════════════════════════════
// PERSISTENT BOTTOM AUDIO BAR (QPB)
// ══════════════════════════════════════════════
let _qpbProgTimer = null;

function _qpbUpdate() {
  const bar  = document.getElementById('qr-persist-bar');
  const nav  = document.getElementById('main-nav');
  if (!bar) return;

  const active = _qrState.audioOn;

  // Update "Now Playing" pill on home screen
  const nowPlayingPill = document.getElementById('qvs-now-playing');
  if (nowPlayingPill) nowPlayingPill.style.display = (active && _qrState.audioPlaying) ? '' : 'none';

  if (!active) { _qpbHide(); return; }

  bar.classList.add('visible');

  // Player is now inline — no view padding changes needed

  const surah  = SURAHS.find(x => x.n === _qrState.surahNum);
  const ayahN  = _qrState.audioAyah;
  const snEl   = document.getElementById('qpb-surah-name');
  const ayEl   = document.getElementById('qpb-ayah-label');
  const playEl = document.getElementById('qpb-play-btn');
  if (snEl)   snEl.textContent   = surah ? surah.en : '—';
  if (ayEl)   ayEl.textContent   = ayahN > 0 ? `Ayah ${ayahN} · ${surah?.ar || ''}` : 'Ready to play';
  if (playEl) playEl.textContent = _qrState.audioPlaying ? '⏸' : '▶';

  // Start progress tracker for persistent bar
  clearInterval(_qpbProgTimer);
  _qpbProgTimer = setInterval(() => {
    if (!_qrAudio || _qrAudio.paused) return;
    const dur = _qrAudio.duration, cur = _qrAudio.currentTime;
    const pct = dur > 0 ? (cur / dur * 100) : 0;
    const fill  = document.getElementById('qpb-fill');
    const thumb = document.getElementById('qpb-thumb');
    const curEl = document.getElementById('qpb-cur');
    const durEl = document.getElementById('qpb-dur');
    if (fill)  fill.style.width  = pct + '%';
    if (thumb) thumb.style.left  = pct + '%';
    if (curEl) curEl.textContent = _qrFmt(cur);
    if (durEl) durEl.textContent = _qrFmt(dur);
    // Also keep play button in sync
    const playEl2 = document.getElementById('qpb-play-btn');
    if (playEl2) playEl2.textContent = _qrState.audioPlaying ? '⏸' : '▶';
  }, 250);
}

function _qpbHide() {
  const bar = document.getElementById('qr-persist-bar');
  if (bar) bar.classList.remove('visible');
  clearInterval(_qpbProgTimer);
  // No view padding to reset — player is inline
}

function qpbClose() {
  qrAudioStop();
  _qrState.audioOn = false;
  _qrUpdateToolbar();
  _qpbHide();
}

function qpbSeek(e, track) {
  if (!_qrAudio || !_qrAudio.duration) return;
  const rect = track.getBoundingClientRect();
  const pct  = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
  _qrAudio.currentTime = pct * _qrAudio.duration;
}

// Tap the persistent bar to open the reader
document.addEventListener('DOMContentLoaded', () => {
  const artEl = document.querySelector('.qpb-art');
  if (artEl) artEl.style.cursor = 'pointer';
  const info = document.querySelector('.qpb-info');
  if (info) {
    info.style.cursor = 'pointer';
    info.onclick = () => {
      if (_qrState.surahNum) openFeatPage('page-quran-reader');
      else openFeatPage('page-quran');
    };
  }
});

function _qrHighlightAudioAyah(n) {
  document.querySelectorAll('.qr-ayah').forEach(el => el.classList.remove('audio-active'));
  const bism = document.getElementById('qr-bismillah');
  if (bism) bism.style.color = (n === 0) ? 'var(--teal)' : 'var(--gold)';

  if (n > 0) {
    const el = document.getElementById('qr-ayah-' + n);
    if (el) el.classList.add('audio-active');
    // Navigate stage to playing ayah
    const idx = _qrAyahsData.findIndex(a => a.n === n);
    if (idx >= 0 && idx !== _qrCurIdx) {
      const dir = idx > _qrCurIdx ? 'next' : 'prev';
      _qrCurIdx = idx;
      _qrShowStageAyah(idx, dir);
      _qrUpdateDots();
      _qrUpdateReadProgress();
    }
  }
  // update pill play btn
  const playBtn = document.getElementById('qr-pill-play');
  if (playBtn) playBtn.textContent = _qrState.audioPlaying ? '⏸' : '▶';
  // update play buttons in full surah view
  document.querySelectorAll('.qr-play-btn').forEach(btn => {
    const bn = parseInt(btn.dataset.n);
    btn.textContent = (bn === n && _qrState.audioPlaying) ? '⏸' : '▶';
    btn.style.color = (bn === n) ? 'var(--gold)' : '';
    btn.style.borderColor = (bn === n) ? 'rgba(var(--accent-rgb),.5)' : '';
    btn.style.background  = (bn === n) ? 'rgba(var(--accent-rgb),.12)' : '';
  });
}

function _qrUpdateAudioBar() {
  // bar is now hidden compat element — don't show it
  // Populate reciter select if empty (compat + menu)
  const sel = document.getElementById('qr-reciter-select');
  if (sel && sel.options.length === 0) {
    QR_RECITERS.forEach(r => {
      const opt = document.createElement('option');
      opt.value = r.id; opt.textContent = r.name;
      sel.appendChild(opt);
    });
  }
  if (sel) sel.value = _qrState.reciter;
  // Also sync menu reciter select
  const ms = document.getElementById('qr-menu-reciter');
  if (ms && ms.options.length === 0 && sel && sel.options.length > 0) ms.innerHTML = sel.innerHTML;
  if (ms) ms.value = _qrState.reciter;
  // Update pill play button
  const playBtn = document.getElementById('qr-pill-play');
  if (playBtn) playBtn.textContent = _qrState.audioPlaying ? '⏸' : '▶';
  // Update persistent bottom bar
  _qpbUpdate();
}
let _qrHifzRevealed = new Set();

// Storage helpers
function _qrSave() {
  try {
    localStorage.setItem('mrd_qr2', JSON.stringify({
      s: _qrState.surahNum, ar: _qrState.showAr, bn: _qrState.showBn,
      fs: _qrState.fontSize, reciter: _qrState.reciter
    }));
  } catch(e) {}
}
function _qrLoad() {
  try {
    const d = JSON.parse(localStorage.getItem('mrd_qr2') || '{}');
    if(d.s)  _qrState.surahNum = d.s;
    if(d.ar !== undefined) _qrState.showAr = d.ar;
    if(d.bn !== undefined) _qrState.showBn = d.bn;
    if(d.fs) _qrState.fontSize = d.fs;
    if(d.reciter) _qrState.reciter = d.reciter;
  } catch(e) {}
}
_qrLoad();

// Surah reading progress  { surahNum: lastAyahN }
function _qrGetProgress() {
  try { return JSON.parse(localStorage.getItem('mrd_qr_prog') || '{}'); } catch { return {}; }
}
function _qrSetProgress(num, ayahN) {
  const p = _qrGetProgress(); p[num] = ayahN;
  try { localStorage.setItem('mrd_qr_prog', JSON.stringify(p)); } catch {}
}

// Ayah bookmarks  [ {surah, ayah, ar, bn} ]
function _qrGetBookmarks() {
  try { return JSON.parse(localStorage.getItem('mrd_qr_bm') || '[]'); } catch { return []; }
}
function _qrSaveBookmarks(bms) {
  try { localStorage.setItem('mrd_qr_bm', JSON.stringify(bms)); } catch {}
}
function _qrIsBookmarked(surah, ayah) {
  return _qrGetBookmarks().some(b => b.surah === surah && b.ayah === ayah);
}
function _qrToggleBookmark(surah, ayah, ar, bn) {
  let bms = _qrGetBookmarks();
  const idx = bms.findIndex(b => b.surah === surah && b.ayah === ayah);
  if(idx >= 0) bms.splice(idx, 1);
  else bms.unshift({ surah, ayah, ar, bn, ts: Date.now() });
  _qrSaveBookmarks(bms);
}

// Hifz tracking — which surahs user is memorising
function _qrGetHifzSurahs() {
  try { return JSON.parse(localStorage.getItem('mrd_qr_hifz') || '[]'); } catch { return []; }
}
function _qrSaveHifzSurahs(list) {
  try { localStorage.setItem('mrd_qr_hifz', JSON.stringify(list)); } catch {}
}
function _qrToggleHifzSurah(num) {
  let list = _qrGetHifzSurahs();
  const i = list.indexOf(num);
  if(i >= 0) list.splice(i,1); else list.push(num);
  _qrSaveHifzSurahs(list);
}

// ── Tab management ─────────────────────────────────────────
let _qrActiveTab = 'surah';
function qrSetTab(tab, btn) {
  _qrActiveTab = tab;
  document.querySelectorAll('.qr-tab-btn').forEach(b => b.classList.remove('active'));
  if(btn) btn.classList.add('active');
  document.getElementById('qp-list').style.display          = tab === 'surah'     ? '' : 'none';
  document.getElementById('qr-bookmarks-list').style.display = tab === 'bookmarks' ? '' : 'none';
  document.getElementById('qr-hifz-list').style.display      = tab === 'hifz'      ? '' : 'none';
  if(tab === 'bookmarks') _qrRenderBookmarksList();
  if(tab === 'hifz')      _qrRenderHifzList();
}

// ── Surah List ──────────────────────────────────────────────
function qpRenderSurahList() {
  const el = document.getElementById('qp-list');
  if(!el || el.dataset.built) return;
  el.dataset.built = '1';
  const prog = _qrGetProgress();
  const bms  = _qrGetBookmarks();
  const hifz = _qrGetHifzSurahs();
  el.innerHTML = SURAHS.map(s => {
    const hasOffline = !!QP_OFFLINE[String(s.n)];
    const readAyah   = prog[s.n] || 0;
    const hasProg    = readAyah > 0;
    const isBm       = bms.some(b => b.surah === s.n);
    const isHifz     = hifz.includes(s.n);
    const progPct    = hasProg ? Math.round(readAyah / s.v * 100) : 0;
    const readMins   = Math.max(1, Math.round(s.v * 4 / 60));
    // SVG ring for progress
    const r = 11, circ = 2 * Math.PI * r;
    const ringOff = (circ * (1 - progPct / 100)).toFixed(1);
    const ringHtml = hasProg
      ? `<div style="position:relative;width:30px;height:30px;flex-shrink:0">
          <svg width="30" height="30" viewBox="0 0 30 30">
            <circle cx="15" cy="15" r="${r}" fill="none" stroke="rgba(255,255,255,.07)" stroke-width="2.5"/>
            <circle cx="15" cy="15" r="${r}" fill="none" stroke="var(--teal)" stroke-width="2.5"
              stroke-linecap="round" stroke-dasharray="${circ.toFixed(1)}" stroke-dashoffset="${ringOff}"
              transform="rotate(-90 15 15)" style="transition:stroke-dashoffset .4s"/>
          </svg>
          <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:0.35rem;color:var(--teal);font-weight:700">${progPct}%</div>
        </div>`
      : `<div class="qr-surah-num" style="flex-shrink:0">${s.n}</div>`;
    return `<div class="qr-surah-row ${hasProg?'has-progress':''} ${isBm?'bookmarked-surah':''}" onclick="qrSelectSurah(${s.n})">
      ${ringHtml}
      <div style="flex:1;min-width:0">
        <div class="qr-surah-en">${s.en}${hasOffline ? ' <span class="qr-offline-badge">✓</span>' : ''}</div>
        <div class="qr-surah-meta">${s.v} ayahs · ~${readMins}min${hasProg ? ' · ' + readAyah + '/' + s.v : ''}${isHifz ? ' · 🧠' : ''}</div>
      </div>
      <div class="qr-surah-ar">${s.ar}</div>
      ${hasProg ? `<div class="qr-surah-prog" style="width:${progPct}%"></div>` : ''}
    </div>`;
  }).join('');
}


let _qrSearchMode = 'auto';
let _qrTypedSearchTimer = null;

function qrSetSearchMode(mode, btn){
  const chipsWrap = document.getElementById('qr-search-chip-auto')?.parentElement;
  _qrSearchMode = (chipsWrap && chipsWrap.style.display !== 'none') ? (mode || 'auto') : 'auto';
  ['auto','surah','ayah'].forEach(key => {
    const el = document.getElementById('qr-search-chip-' + key);
    if(!el) return;
    const active = key === _qrSearchMode;
    el.style.borderColor = active ? 'rgba(var(--accent-rgb),.22)' : 'rgba(255,255,255,.09)';
    el.style.background = active ? 'rgba(var(--accent-rgb),.09)' : 'rgba(255,255,255,.04)';
    el.style.color = active ? 'var(--gold)' : 'var(--t3)';
  });
  const input = document.getElementById('qp-search');
  if(input) qpFilter(input.value || '');
}

function qrClearSearch(){
  const input = document.getElementById('qp-search');
  if(input) input.value = '';
  qpFilter('');
}


let _qrQuickAccessMode = 'menu';

function qrOpenQuickAccess(mode){
  _qrQuickAccessMode = mode || 'menu';
  const wrap = document.getElementById('qr-quick-access');
  const sub = document.getElementById('qr-quick-access-sub');
  if(!wrap) return;
  if(sub){
    sub.textContent = mode === 'voice'
      ? 'Voice-related Quran tools'
      : 'Open Quran tools faster';
  }
  wrap.style.display = 'block';
  document.body.style.overflow = 'hidden';
  ['qr-qa-full-view','qr-qa-audio','qr-qa-continue','qr-qa-ayah-search'].forEach(id => {
    const el = document.getElementById(id);
    if(el) el.style.display = '';
  });
  if(mode === 'voice'){
    const ayahBtn = document.getElementById('qr-qa-ayah-search');
    if(ayahBtn) ayahBtn.style.display = 'none';
  }
}

function qrCloseQuickAccess(evt){
  if(evt && evt.target){
    const panel = document.getElementById('qr-quick-access-panel');
    if(panel && panel.contains(evt.target)) return;
  }
  const wrap = document.getElementById('qr-quick-access');
  if(!wrap) return;
  wrap.style.display = 'none';
  document.body.style.overflow = '';
}

function qrContinueLatest(){
  const prog = _qrGetProgress();
  const entries = Object.entries(prog || {}).filter(([,v]) => v > 0);
  if(!entries.length) return false;
  const last = entries.sort((a,b) => b[1] - a[1])[0];
  const num = parseInt(last[0], 10);
  const ayah = parseInt(last[1], 10) || 1;
  qrSelectSurah(num, ayah);
  return true;
}

function qrQuickAction(action){
  qrCloseQuickAccess();
  if(action === 'voice-surah'){
    qrVoiceSearch('surah');
    return;
  }
  if(action === 'voice-recite'){
    qrVoiceSearch('recite');
    return;
  }
  if(action === 'ayah-text'){
    qrSetSearchMode('ayah', document.getElementById('qr-search-chip-ayah'));
    const input = document.getElementById('qp-search');
    if(input){ input.focus(); }
    return;
  }
  if(action === 'continue'){
    if(!qrContinueLatest()){
      const st = document.getElementById('qr-voice-status');
      if(st){
        st.style.display = '';
        st.textContent = 'No recent Quran progress found yet. Open a surah first, then this shortcut will resume it.';
      }
    }
    return;
  }
  if(action === 'full-view'){
    openFeatPage('page-surah-view');
    return;
  }
  if(action === 'audio-player'){
    const bar = document.getElementById('qr-persist-bar');
    if(bar) bar.scrollIntoView({behavior:'smooth', block:'center'});
    return;
  }
}

document.addEventListener('keydown', (e) => {
  if(e.key === 'Escape') qrCloseQuickAccess();
});

function _qrTypedSearchEls(){
  return {
    list: document.getElementById('qp-list'),
    results: document.getElementById('qr-text-search-results'),
    hint: document.getElementById('qr-search-hint')
  };
}

function _qrShowTextSearchStatus(msg, kind){
  const {results} = _qrTypedSearchEls();
  if(!results) return;
  if(!msg){ results.style.display = 'none'; results.innerHTML = ''; return; }
  results.style.display = '';
  const border = kind === 'error' ? 'rgba(var(--rose-rgb),.22)' : kind === 'loading' ? 'rgba(var(--accent-rgb),.22)' : 'rgba(255,255,255,.07)';
  const bg = kind === 'error' ? 'rgba(var(--rose-rgb),.07)' : kind === 'loading' ? 'rgba(var(--accent-rgb),.06)' : 'rgba(255,255,255,.04)';
  const color = kind === 'error' ? 'var(--rose)' : kind === 'loading' ? 'var(--gold)' : 'var(--t2)';
  results.innerHTML = `<div style="padding:10px 12px;border-radius:12px;border:1px solid ${border};background:${bg};color:${color};font-size:.66rem;line-height:1.6">${_qrEscHtml(msg)}</div>`;
}

function _qrAyahSearchNorm(s){
  return _qrNorm(s)
    .replace(/[|/\\]+/g,' ')
    .replace(/\b(verse|ayah|ayat|আয়াত|আয়াত|সূরা|সুরা|surah|chapter|juz)\b/g,' ')
    .replace(/\s+/g,' ')
    .trim();
}

function _qrAyahSearchTokens(s){
  return _qrAyahSearchNorm(s).split(/\s+/).filter(Boolean);
}

function _qrLooksLikeAyahQuery(term){
  if(/[\u0600-\u06FF]/.test(term)) return true;
  const tokens = _qrAyahSearchTokens(term);
  if(tokens.length >= 3) return true;
  if(/\d+\s*[:.]\s*\d+/.test(term)) return true;
  return false;
}

function _qrParseAyahRef(term){
  const clean = _qrAyahSearchNorm(term);
  let m = clean.match(/^(\d{1,3})\s*[:.]\s*(\d{1,3})$/);
  if(m) return {surah: +m[1], ayah: +m[2]};
  m = clean.match(/^(?:surah\s*)?(\d{1,3})\s+(?:ayah\s*|ayat\s*|verse\s*|আয়াত\s*|আয়াত\s*)(\d{1,3})$/i);
  if(m) return {surah: +m[1], ayah: +m[2]};
  m = clean.match(/^(.*?)[,\s]+(?:ayah\s*|ayat\s*|verse\s*|আয়াত\s*|আয়াত\s*)(\d{1,3})$/i);
  if(m){
    const surahTerm = (m[1] || '').trim();
    const ayah = +m[2];
    const s = SURAHS.find(x => x.en.toLowerCase().includes(surahTerm.toLowerCase()) || x.ar.includes(surahTerm));
    if(s) return {surah: s.n, ayah};
  }
  return null;
}

function _qrScoreTypedAyahQuery(term, item){
  const raw = String(term || '').trim();
  if(!raw || !item) return null;
  const ref = _qrParseAyahRef(raw);
  if(ref){
    const exact = item.surah === ref.surah && item.ayah === ref.ayah;
    if(!exact) return { score: -1 };
    return { score: 9999, preview: item.ar, matchedWords: ['Direct reference'] };
  }
  const queryNorm = _qrAyahSearchNorm(raw);
  const qTokens = _qrAyahSearchTokens(raw);
  const qAr = _qrArabicCompact(raw);
  const qPh = _qrScriptAgnosticPhonemeKey(raw);
  const ar = item._arCompact || _qrArabicCompact(item.ar || '');
  const bn = _qrAyahSearchNorm(item.bn || '');
  const en = _qrAyahSearchNorm(item.en || '');
  const arTokens = item._arTokens || _qrTokenizeArabic(item.ar || '');
  const bnTokens = _qrAyahSearchTokens(item.bn || '');
  const enTokens = _qrAyahSearchTokens(item.en || '');
  const qSoundTokens = qTokens.map(_qrScriptAgnosticPhonemeKey).filter(Boolean);
  const arSoundTokens = item._soundTokens || (_qrBanglaToLatin(_qrNorm(item.ar || '')).split(/\s+/).map(_qrScriptAgnosticPhonemeKey).filter(Boolean));

  let score = 0;
  let matched = [];
  if(queryNorm && bn.includes(queryNorm)){ score += 420; matched.push('Bangla text'); }
  if(queryNorm && en.includes(queryNorm)){ score += 260; matched.push('English text'); }
  if(qAr && ar.includes(qAr) && qAr.length >= 4){ score += 520; matched.push('Arabic phrase'); }
  if(qPh){
    const arKey = item._soundKey || _qrScriptAgnosticPhonemeKey(item.ar || '');
    if(arKey.includes(qPh) && qPh.length >= 4){ score += 420; matched.push('Sound match'); }
    score += _qrSetJaccard(_qrMakeNgrams(qPh,2), _qrMakeNgrams(arKey,2)) * 220;
    score += _qrSetJaccard(_qrMakeNgrams(qPh,3), _qrMakeNgrams(arKey,3)) * 280;
  }
  const bnOverlap = _qrTokenOverlapScore(qTokens, bnTokens);
  const enOverlap = _qrTokenOverlapScore(qTokens, enTokens);
  const arOverlap = _qrTokenOverlapScore(qTokens, arTokens);
  const sndOverlap = _qrTokenOverlapScore(qSoundTokens, arSoundTokens);
  score += bnOverlap.recall * 220 + bnOverlap.precision * 80;
  score += enOverlap.recall * 120 + enOverlap.precision * 45;
  score += arOverlap.recall * 150 + arOverlap.precision * 50;
  score += sndOverlap.recall * 260 + sndOverlap.precision * 90;
  score += _qrLongestTokenRun(qTokens, bnTokens) * 40;
  score += _qrLongestTokenRun(qTokens, enTokens) * 24;
  score += _qrLongestTokenRun(qSoundTokens, arSoundTokens) * 70;
  matched = matched.concat(bnOverlap.matched.slice(0,2), enOverlap.matched.slice(0,1), sndOverlap.matched.slice(0,2));
  return { score, preview: item.ar, matchedWords: Array.from(new Set(matched)).filter(Boolean).slice(0,4) };
}

function _qrRenderTypedAyahResults(items, meta = {}){
  const {results, list, hint} = _qrTypedSearchEls();
  if(!results) return;
  if(!items || !items.length){
    results.style.display = '';
    results.innerHTML = `<div style="padding:10px 12px;border-radius:12px;border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.04);color:var(--t2);font-size:.66rem;line-height:1.6">No ayah match found. Try more words, Arabic text, Bangla translation words, or a direct reference like 2:255.</div>`;
    if(list) list.style.display = '';
    if(hint) hint.textContent = 'Ayah search supports direct reference (2:255), Arabic ayah text, or Bangla/English translation words.';
    return;
  }
  const top = items[0].score || 1;
  results.style.display = '';
  results.innerHTML = `
    <div style="padding:10px 12px;border-radius:14px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07)">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px">
        <div style="font-size:.64rem;color:var(--t3);letter-spacing:.08em;text-transform:uppercase">Ayah search results</div>
        <div style="font-size:.58rem;color:var(--t3)">${_qrEscHtml(meta.label || '')}</div>
      </div>
      <div style="display:grid;gap:8px">
        ${items.map(item => {
          const s = SURAHS.find(x => x.n === item.surah);
          const conf = _qrVoiceConfidence(item.score, top);
          const matched = (item.matchedWords || []).join(' · ') || 'Closest ayah match';
          return `
            <div style="padding:11px 12px;border-radius:14px;border:1px solid rgba(var(--accent-rgb),.18);background:rgba(var(--accent-rgb),.06)">
              <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px">
                <div style="min-width:0">
                  <div style="font-size:.76rem;font-weight:700;color:var(--gold)">${_qrEscHtml(s?.en || ('Surah ' + item.surah))} · Ayah ${item.ayah}</div>
                  <div style="font-size:.58rem;color:var(--teal);margin-top:4px">${_qrEscHtml(matched)}</div>
                </div>
                <div style="font-size:.62rem;color:var(--text);padding:5px 8px;border-radius:999px;background:rgba(var(--teal-rgb),.12);border:1px solid rgba(var(--teal-rgb),.18);white-space:nowrap">${conf}%</div>
              </div>
              ${item.ar ? `<div style="margin-top:8px;font-size:.82rem;line-height:1.95;color:var(--text);direction:rtl;text-align:right;font-family:'Noto Naskh Arabic','Scheherazade New','Amiri',serif">${_qrEscHtml(item.ar)}</div>` : ''}
              ${item.bn ? `<div style="font-size:.62rem;color:var(--t2);line-height:1.6;margin-top:7px">${_qrEscHtml(String(item.bn).slice(0,190))}</div>` : ''}
              <div style="display:flex;gap:8px;margin-top:9px">
                <button onclick="qrOpenVoiceMatch(${item.surah},${item.ayah})" style="flex:1;text-align:center;padding:10px 12px;border-radius:12px;border:1px solid rgba(var(--teal-rgb),.22);background:rgba(var(--teal-rgb),.09);color:var(--teal);cursor:pointer;-webkit-tap-highlight-color:transparent;font-weight:700">Open ayah</button>
              </div>
            </div>`;
        }).join('')}
      </div>
    </div>`;
  if(list) list.style.display = 'none';
  if(hint) hint.textContent = 'Ayah text search is active. You can paste Arabic ayah, Bangla translation words, or a direct reference like 36:58.';
}

async function _qrRunTypedAyahSearch(term){
  const ref = _qrParseAyahRef(term);
  if(ref){
    _qrRenderTypedAyahResults([{surah: ref.surah, ayah: ref.ayah, ar: '', bn: 'Direct surah:ayah reference', score: 9999, matchedWords:['Direct reference']}], {label:'Direct reference'});
    return;
  }
  _qrShowTextSearchStatus('Searching ayah text across the Quran… first time may take a little longer while the Quran cache loads.', 'loading');
  let corpus = [];
  try {
    corpus = await _qrEnsureFullReciteCorpus();
  } catch(e) {}
  if(!Array.isArray(corpus) || !corpus.length){
    _qrShowTextSearchStatus('Could not load the full Quran text right now. Please try again.', 'error');
    return;
  }
  const scored = corpus.map(item => {
    const meta = _qrScoreTypedAyahQuery(term, item);
    return meta ? ({...item, ...meta}) : null;
  }).filter(Boolean).filter(x => x.score > 120).sort((a,b) => b.score - a.score).slice(0,5);
  _qrRenderTypedAyahResults(scored, {label:'Best matches'});
}

function qpFilter(q) {
  const term = String(q || '').trim();
  const lowered = term.toLowerCase();
  const {list, results, hint} = _qrTypedSearchEls();
  if(!list) return;

  if(_qrTypedSearchTimer){ clearTimeout(_qrTypedSearchTimer); _qrTypedSearchTimer = null; }

  if(!term){
    if(results){ results.style.display = 'none'; results.innerHTML = ''; }
    if(list) list.style.display = '';
    if(hint) hint.textContent = 'Auto mode smartly detects: surah name, surah:ayah reference like 2:255, or pasted ayah text.';
    list.querySelectorAll('.qr-surah-row').forEach(row => row.style.display = '');
    return;
  }

  const mode = _qrSearchMode === 'auto' ? (_qrLooksLikeAyahQuery(term) ? 'ayah' : 'surah') : _qrSearchMode;
  if(mode === 'surah'){
    if(results){ results.style.display = 'none'; results.innerHTML = ''; }
    if(list) list.style.display = '';
    if(hint) hint.textContent = 'Surah search is active. Type a surah name, Arabic name, or surah number.';
    list.querySelectorAll('.qr-surah-row').forEach((row, i) => {
      const s = SURAHS[i];
      if(!s) return;
      const match = !lowered || s.en.toLowerCase().includes(lowered) || s.ar.includes(term) || String(s.n).includes(term);
      row.style.display = match ? '' : 'none';
    });
    return;
  }

  list.querySelectorAll('.qr-surah-row').forEach(row => row.style.display = '');
  if(list) list.style.display = 'none';
  _qrTypedSearchTimer = setTimeout(() => { _qrRunTypedAyahSearch(term); }, 260);
}


// ── Quran Voice Search / Recite-to-Find v4 ─────────────────
let _qrVoiceRecognition = null;
let _qrVoiceMode = 'surah';
let _qrReciteMatchCache = new Map();
let _qrReciteCandidatesCache = new Map();

function _qrVoiceEls(){
  return {
    status: document.getElementById('qr-voice-status'),
    results: document.getElementById('qr-voice-results'),
    surahBtn: document.getElementById('qr-voice-surah-btn'),
    reciteBtn: document.getElementById('qr-voice-recite-btn')
  };
}

function _qrVoiceSetBusy(busy){
  const {surahBtn, reciteBtn} = _qrVoiceEls();
  [surahBtn, reciteBtn].forEach(btn => {
    if(!btn) return;
    btn.disabled = !!busy;
    btn.style.opacity = busy ? '.72' : '1';
    btn.style.transform = busy ? 'scale(.985)' : '';
    btn.style.pointerEvents = busy ? 'none' : '';
  });
}

function _qrVoiceShowStatus(msg, kind){
  const {status} = _qrVoiceEls();
  if(!status) return;
  status.style.display = msg ? '' : 'none';
  status.textContent = msg || '';
  status.style.color = kind === 'error' ? 'var(--rose)' : kind === 'success' ? 'var(--teal)' : 'var(--t2)';
  status.style.borderColor = kind === 'error' ? 'rgba(var(--rose-rgb),.2)' : kind === 'success' ? 'rgba(var(--teal-rgb),.18)' : 'rgba(255,255,255,.06)';
  status.style.background = kind === 'error' ? 'rgba(var(--rose-rgb),.05)' : kind === 'success' ? 'rgba(var(--teal-rgb),.05)' : 'rgba(255,255,255,.03)';
}

function _qrEscHtml(s){
  return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function _qrVoiceConfidence(score, top){
  if(!score || !top) return 0;
  const ratio = Math.max(0, Math.min(1, score / Math.max(1, top)));
  return Math.max(18, Math.min(98, Math.round(35 + (ratio * 63))));
}

function _qrVoiceHighlightSnippet(text, transcript){
  const source = String(text || '').trim();
  if(!source) return '';
  const tokens = _qrTokenizeArabic(transcript).map(t => _qrArabicNorm(t));
  if(!tokens.length) return source.length > 160 ? source.slice(0,160) + '…' : source;
  const words = source.split(/\s+/);
  let bestStart = 0, bestLen = Math.min(words.length, 12), bestHits = 0;
  for(let i = 0; i < words.length; i++){
    for(let len = 4; len <= Math.min(14, words.length - i); len++){
      const slice = words.slice(i, i + len);
      const normSlice = _qrArabicNorm(slice.join(' '));
      let hits = 0;
      tokens.forEach(t => { if(t && normSlice.includes(t)) hits++; });
      if(hits > bestHits || (hits === bestHits && len < bestLen)){
        bestHits = hits; bestStart = i; bestLen = len;
      }
    }
  }
  const out = words.slice(bestStart, bestStart + bestLen).join(' ');
  return out || source.slice(0, 160);
}

function _qrVoiceMatchWordsText(hit){
  const kws = Array.from(new Set([...(hit.matchedArabicWords || []), ...(hit.matchedSoundWords || [])])).slice(0, 6);
  return kws.length ? kws.join(' · ') : 'Closest sound pattern match';
}

function _qrVoiceRenderResults(items, transcript){
  const {results} = _qrVoiceEls();
  if(!results) return;
  if(!items || !items.length){
    results.style.display = 'none';
    results.innerHTML = '';
    return;
  }
  results.style.display = '';
  results.innerHTML = `
    <div style="padding:10px 12px;border-radius:14px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07)">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:8px">
        <div style="font-size:.62rem;color:var(--t3);letter-spacing:.06em;text-transform:uppercase">Best match</div>
        <div style="font-size:.56rem;color:var(--t3);max-width:52%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${_qrEscHtml(transcript || '')}</div>
      </div>
      <div style="display:grid;gap:8px">
        ${items.map(item => `
          <div style="padding:11px 12px;border-radius:14px;border:1px solid rgba(var(--accent-rgb),.18);background:rgba(var(--accent-rgb),.06)">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px">
              <div style="min-width:0">
                <div style="font-size:.76rem;font-weight:700;color:var(--gold)">${_qrEscHtml(item.title)}</div>
                <div style="font-size:.58rem;color:var(--teal);margin-top:4px">Confidence ${item.confidence || 0}% · ${_qrEscHtml(item.matchWords || 'Closest match')}</div>
              </div>
              <div style="font-size:.62rem;color:var(--text);padding:5px 8px;border-radius:999px;background:rgba(var(--teal-rgb),.12);border:1px solid rgba(var(--teal-rgb),.18);white-space:nowrap">${item.confidence || 0}%</div>
            </div>
            ${item.preview ? `<div style="margin-top:8px;font-size:.8rem;line-height:1.95;color:var(--text);direction:rtl;text-align:right;font-family:'Noto Naskh Arabic','Scheherazade New','Amiri',serif">${_qrEscHtml(item.preview)}</div>` : ''}
            ${item.sub ? `<div style="font-size:.62rem;color:var(--t2);line-height:1.6;margin-top:6px">${_qrEscHtml(item.sub)}</div>` : ''}
            <div style="display:flex;gap:8px;margin-top:9px">
              <button onclick="${item.action}" style="flex:1;text-align:center;padding:10px 12px;border-radius:12px;border:1px solid rgba(var(--teal-rgb),.22);background:rgba(var(--teal-rgb),.09);color:var(--teal);cursor:pointer;-webkit-tap-highlight-color:transparent;font-weight:700">Open match</button>
            </div>
          </div>
        `).join('')}
      </div>
    </div>`;
}

function _qrNorm(s){
  return String(s || '')
    .toLowerCase()
    .normalize('NFD').replace(/[̀-ͯ]/g,'')
    .replace(/[ً-ٰٟۖ-ۭ]/g,'')
    .replace(/['‘’`´-]/g,' ')
    .replace(/\b(surah|surahh|sura|soorah|সূরা|সুরা|chapter|ayah|ayat|আয়াত|আয়াত|verse)\b/g,' ')
    .replace(/[^\p{L}\p{N}\s]/gu,' ')
    .replace(/\s+/g,' ')
    .trim();
}

function _qrArabicNorm(s){
  return String(s || '')
    .replace(/[ً-ٰٟۖ-ۭ]/g,'')
    .replace(/[\u0640]/g,'')
    .replace(/[إأآٱ]/g,'ا')
    .replace(/ى/g,'ي')
    .replace(/ة/g,'ه')
    .replace(/ؤ/g,'و')
    .replace(/ئ/g,'ي')
    .replace(/\s+/g,' ')
    .trim();
}

const _qrSurahAliasMap = (() => {
  const base = {
    'fatiha':1,'fatihah':1,'فاتحه':1,'al fatiha':1,'surah fatiha':1,
    'baqarah':2,'bakara':2,'bakarah':2,'baqara':2,
    'imran':3,'ale imran':3,'al imran':3,
    'nisa':4,'an nisa':4,
    'maidah':5,'maida':5,
    'anam':6,
    'araf':7,'a raf':7,
    'anfal':8,
    'tawbah':9,'taubah':9,'toba':9,
    'yunus':10,
    'yusuf':12,
    'rad':13,'ra d':13,
    'ibrahim':14,
    'kahf':18,'kahaf':18,'kafh':18,
    'maryam':19,
    'taha':20,'ta ha':20,
    'yasin':36,'ya sin':36,'yaseen':36,'ya seen':36,'يس':36,
    'rahman':55,'ar rahman':55,
    'waqiah':56,'waqia':56,'waqi ah':56,
    'hadid':57,
    'hashr':59,
    'jumua':62,'jumuah':62,'jummah':62,
    'mulk':67,'al mulk':67,'mulk surah':67,
    'qalam':68,
    'haqqah':69,'haqqa':69,
    'nuh':71,
    'jinn':72,'jin':72,
    'muzammil':73,'muzzammil':73,
    'mudathir':74,'muddassir':74,'muddaththir':74,
    'qiyamah':75,'qiyama':75,
    'insan':76,'dahr':76,
    'mursalat':77,
    'naba':78,'nabaa':78,
    'naziyat':79,'naziat':79,
    'abasa':80,
    'takwir':81,
    'infitar':82,
    'mutaffifin':83,
    'inshiqaq':84,
    'burooj':85,'buruj':85,
    'tariq':86,'tarik':86,
    'ala':87,'a la':87,
    'ghashiyah':88,'gashiya':88,
    'fajr':89,
    'balad':90,
    'shams':91,
    'layl':92,'lail':92,
    'duha':93,'doha':93,
    'sharh':94,'inshirah':94,
    'tin':95,'teen':95,
    'alaq':96,'iqra':96,
    'qadr':97,'qadar':97,
    'bayyinah':98,'baiyina':98,
    'zilzal':99,'zalzalah':99,
    'adiyat':100,'adiyaat':100,
    'qariah':101,'qaria':101,
    'takathur':102,'takasur':102,
    'asr':103,
    'humazah':104,'humaza':104,
    'fil':105,'feel':105,
    'quraysh':106,'kuraish':106,'quraish':106,
    'maun':107,'maoon':107,
    'kawthar':108,'kausar':108,'kawsar':108,
    'kafirun':109,'kafiroon':109,
    'nasr':110,'naser':110,
    'masad':111,'lahab':111,'abu lahab':111,
    'ikhlas':112,'ekhlas':112,
    'falaq':113,'falak':113,
    'nas':114,'naas':114
  };
  SURAHS.forEach(s => {
    const keys = new Set([
      _qrNorm(s.en),
      _qrNorm(s.en.replace(/^al\s+/i,'')),
      _qrNorm(s.en.replace(/^an\s+/i,'')),
      _qrNorm(s.en.replace(/^ar\s+/i,'')),
      _qrNorm(s.en.replace(/^as\s+/i,'')),
      _qrNorm(s.en.replace(/^at\s+/i,'')),
      _qrNorm(s.ar),
      _qrArabicNorm(s.ar)
    ]);
    keys.forEach(k => { if(k) base[k] = s.n; });
  });
  return base;
})();

function _qrFindAyahNumber(text){
  const raw = String(text || '');
  let m = raw.match(/\b(?:ayah|ayat|আয়াত|আয়াত|verse)\s*(\d{1,3})\b/i);
  if(m) return parseInt(m[1]);
  m = raw.match(/\b(\d{1,3})\b/);
  if(m) return parseInt(m[1]);
  return null;
}

function _qrDiceCoefficient(a,b){
  a = String(a || '');
  b = String(b || '');
  if(!a || !b) return 0;
  if(a === b) return 1;
  const grams = s => {
    if(s.length < 2) return [s];
    const out = [];
    for(let i = 0; i < s.length - 1; i++) out.push(s.slice(i, i + 2));
    return out;
  };
  const ag = grams(a), bg = grams(b);
  const map = new Map();
  ag.forEach(g => map.set(g, (map.get(g) || 0) + 1));
  let hits = 0;
  bg.forEach(g => {
    const n = map.get(g) || 0;
    if(n > 0){ hits++; map.set(g, n - 1); }
  });
  return (2 * hits) / Math.max(1, ag.length + bg.length);
}

function _qrCleanSurahCommand(text){
  return _qrNorm(text)
    .replace(/\b(open|go|goto|jump|play|listen|read|find|search|show|start|take|bring|please|plz|bolo|khulo|openo|jaa|jao|niye|neo|dao|den|din|khuje|ber|koro|korun|chalaw|chalu|suniye|poro|porun|tilawat|recite)\b/g,' ')
    .replace(/\b(of|the|to|me|my|and|then|now|for)\b/g,' ')
    .replace(/\s+/g,' ')
    .trim();
}

function _qrFindSurahByTranscript(text){
  const query = _qrCleanSurahCommand(text);
  const arabNorm = _qrArabicNorm(text);
  const qKey = _qrScriptAgnosticPhonemeKey(query || text);
  const qTokens = (query || '').split(/\s+/).filter(Boolean);
  let best = null;

  Object.entries(_qrSurahAliasMap).forEach(([alias, num]) => {
    if(!alias) return;
    const aliasNorm = _qrNorm(alias);
    const aliasArabic = _qrArabicNorm(alias);
    const aliasKey = _qrScriptAgnosticPhonemeKey(aliasNorm || aliasArabic || alias);
    let score = 0;

    if(query && (query === aliasNorm || query === aliasArabic)) score += 220;
    if(query && (query.includes(aliasNorm) || aliasNorm.includes(query))) score += 170;
    if(arabNorm && (arabNorm.includes(aliasArabic) || aliasArabic.includes(arabNorm))) score += 165;

    if(query && aliasNorm){
      const dice = _qrDiceCoefficient(query.replace(/\s+/g,''), aliasNorm.replace(/\s+/g,''));
      score += dice * 100;
    }
    if(qKey && aliasKey){
      const keyDice = _qrDiceCoefficient(qKey, aliasKey);
      score += keyDice * 140;
      if(qKey === aliasKey) score += 80;
      else if(qKey.includes(aliasKey) || aliasKey.includes(qKey)) score += 55;
    }

    if(qTokens.length){
      const aliasTokens = aliasNorm.split(/\s+/).filter(Boolean);
      const overlap = qTokens.filter(t => aliasTokens.includes(t)).length;
      score += overlap * 18;
    }

    const s = SURAHS.find(x => x.n === parseInt(num));
    if(s){
      const numWords = [String(s.n), `surah ${s.n}`, `sura ${s.n}`, `সূরা ${s.n}`, `সুরা ${s.n}`];
      if(numWords.some(nw => _qrNorm(text).includes(_qrNorm(nw)))) score += 150;
    }

    if(!best || score > best.score) best = { num: parseInt(num), score, alias };
  });

  return best && best.score >= 115 ? best : null;
}

function _qrFindBestSurahFromAlternatives(texts){
  const pool = [];
  (texts || []).forEach(t => {
    const hit = _qrFindSurahByTranscript(t);
    if(hit) pool.push({ ...hit, transcript: t });
  });
  if(!pool.length) return null;
  pool.sort((a,b) => b.score - a.score);
  const top = pool[0];
  const same = pool.filter(x => x.num === top.num);
  if(same.length > 1) top.score += Math.min(60, (same.length - 1) * 18);
  const confidence = Math.max(40, Math.min(99, Math.round(35 + Math.min(1, top.score / 260) * 64)));
  return { ...top, confidence };
}

const QR_RECITE_CORPUS_CACHE_KEY = 'qr_recite_full_corpus_v4';
const QR_VOICE_FAST_MODE = true;
const QR_FAST_PRIORITY_SURAHS = [1,2,18,36,55,67,68,78,87,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114];
function _qrRecentStartedSurahs(limit = 6){
  try{
    const prog = _qrGetProgress ? _qrGetProgress() : {};
    return Object.entries(prog || {})
      .filter(([,v]) => Number(v) > 0)
      .sort((a,b) => Number(b[1]) - Number(a[1]))
      .slice(0, limit)
      .map(([k]) => parseInt(k))
      .filter(Boolean);
  }catch(e){ return []; }
}
function _qrPriorityReciteCorpus(baseCorpus){
  try{
    const picks = new Set(QR_FAST_PRIORITY_SURAHS);
    if(_qrState && _qrState.surahNum) picks.add(Number(_qrState.surahNum));
    _qrRecentStartedSurahs(8).forEach(n => picks.add(Number(n)));
    const rows = (baseCorpus || []).filter(x => picks.has(Number(x.surah)));
    return rows.length ? rows : (baseCorpus || []);
  }catch(e){
    return baseCorpus || [];
  }
}

let _qrFullReciteCorpusPromise = null;
let _qrReciteWindowsCache = null;
let _qrReciteWindowsCacheSize = 0;

function _qrBuildReciteCorpus(){
  const corpus = [];
  const currentSurah = _qrState.surahNum;
  if(Array.isArray(_qrAyahsData) && _qrAyahsData.length && currentSurah){
    _qrAyahsData.forEach(a => corpus.push({ surah: currentSurah, ayah: a.n, ar: a.ar || '', bn: a.bn || '' }));
  }
  Object.entries(QP_OFFLINE || {}).forEach(([surah, data]) => {
    if(!data || !Array.isArray(data.ar)) return;
    data.ar.forEach((ar, idx) => {
      corpus.push({ surah: parseInt(surah), ayah: idx + 1, ar: ar || '', bn: data.bn?.[idx] || '' });
    });
  });
  const seen = new Set();
  return corpus.filter(item => {
    const k = `${item.surah}:${item.ayah}`;
    if(seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

function _qrGetCachedFullReciteCorpus(){
  try {
    const raw = localStorage.getItem(QR_RECITE_CORPUS_CACHE_KEY);
    if(!raw) return null;
    const parsed = JSON.parse(raw);
    if(Array.isArray(parsed?.ayahs) && parsed.ayahs.length > 6200) return parsed.ayahs;
  } catch(e){}
  return null;
}

function _qrStoreFullReciteCorpus(ayahs){
  try {
    localStorage.setItem(QR_RECITE_CORPUS_CACHE_KEY, JSON.stringify({ ts: Date.now(), ayahs }));
  } catch(e){}
}

async function _qrFetchSurahForReciteCorpus(num){
  try {
    const res = await fetch(`https://raw.githubusercontent.com/semarketir/quranjson/master/source/surah/surah_${num}.json`);
    if(res.ok){
      const data = await res.json();
      const verses = Array.isArray(data?.verse) ? data.verse : Array.isArray(data?.verses) ? data.verses : [];
      if(verses.length){
        return verses.map((v, idx) => ({
          surah: num,
          ayah: parseInt(v?.id) || parseInt(v?.verse_id) || parseInt(v?.number) || idx + 1,
          ar: v?.arabic || v?.text || v?.verse || '',
          bn: v?.translation || v?.meaning || ''
        })).filter(v => v.ar);
      }
    }
  } catch(e){}
  try {
    const res = await fetch(`https://api.alquran.cloud/v1/surah/${num}`);
    if(res.ok){
      const data = await res.json();
      const ayahs = Array.isArray(data?.data?.ayahs) ? data.data.ayahs : [];
      return ayahs.map((a, idx) => ({ surah: num, ayah: a?.numberInSurah || idx + 1, ar: a?.text || '', bn: '' })).filter(v => v.ar);
    }
  } catch(e){}
  return [];
}

async function _qrEnsureFullReciteCorpus(progressCb){
  const cached = _qrGetCachedFullReciteCorpus();
  if(cached?.length) return cached;
  if(_qrFullReciteCorpusPromise) return _qrFullReciteCorpusPromise;
  _qrFullReciteCorpusPromise = (async () => {
    const all = [];
    for(let i = 1; i <= 114; i++){
      const part = await _qrFetchSurahForReciteCorpus(i);
      if(Array.isArray(part) && part.length) all.push(...part);
      if(typeof progressCb === 'function') progressCb(i, 114);
    }
    if(all.length > 6200) _qrStoreFullReciteCorpus(all);
    return all;
  })();
  try {
    return await _qrFullReciteCorpusPromise;
  } finally {
    _qrFullReciteCorpusPromise = null;
  }
}

function _qrArabicCompact(s){
  return _qrArabicNorm(s).replace(/\s+/g,'');
}

function _qrTokenizeArabic(s){
  return _qrArabicNorm(s).split(' ').filter(w => w && w.length > 1);
}

function _qrArabicPhonetic(s){
  return _qrArabicNorm(s)
    .replace(/[اأإآٱ]/g,'ا')
    .replace(/[يىئ]/g,'ي')
    .replace(/[وؤ]/g,'و')
    .replace(/[هة]/g,'ه')
    .replace(/[صسث]/g,'س')
    .replace(/[ضظذز]/g,'ز')
    .replace(/[تط]/g,'ت')
    .replace(/[د]/g,'د')
    .replace(/[قك]/g,'ك')
    .replace(/[حخ]/g,'ح')
    .replace(/[جش]/g,'ج')
    .replace(/[غع]/g,'ع')
    .replace(/[ف]/g,'ف')
    .replace(/[ل]/g,'ل')
    .replace(/\s+/g,' ')
    .trim();
}

function _qrBanglaToLatin(s){
  return String(s || '')
    .replace(/[অও]/g,'o')
    .replace(/[আাঅ্যা]/g,'a')
    .replace(/[ইঈিী]/g,'i')
    .replace(/[উঊুূ]/g,'u')
    .replace(/[এে]/g,'e')
    .replace(/[ঐৈ]/g,'oi')
    .replace(/[ঔৌ]/g,'ou')
    .replace(/[কখ]/g,'kh')
    .replace(/[গঘ]/g,'gh')
    .replace(/[ঙ]/g,'ng')
    .replace(/[চছ]/g,'ch')
    .replace(/[জঝযয়য়]/g,'j')
    .replace(/[ঞ]/g,'n')
    .replace(/[টঠতথ]/g,'t')
    .replace(/[ডঢদধ]/g,'d')
    .replace(/[ণন]/g,'n')
    .replace(/[পফ]/g,'f')
    .replace(/[বভ]/g,'b')
    .replace(/[ম]/g,'m')
    .replace(/[রড়ঢ়]/g,'r')
    .replace(/[ল]/g,'l')
    .replace(/[শষস]/g,'s')
    .replace(/[হ]/g,'h')
    .replace(/[ৎ]/g,'t')
    .replace(/[ং]/g,'ng')
    .replace(/[ঃ]/g,'h')
    .replace(/[ঁ]/g,'n')
    .replace(/[^\p{L}\p{N}\s]/gu,' ')
    .replace(/\s+/g,' ')
    .trim();
}

function _qrScriptAgnosticPhonemeKey(s){
  let str = String(s || '').trim().toLowerCase();
  if(!str) return '';
  str = _qrBanglaToLatin(str);
  str = _qrArabicNorm(str)
    .replace(/الله/g,'allah')
    .replace(/[اأإآٱ]/g,'a')
    .replace(/[يىئ]/g,'y')
    .replace(/[وؤ]/g,'w')
    .replace(/[هة]/g,'h')
    .replace(/[ب]/g,'b')
    .replace(/[تط]/g,'t')
    .replace(/[ثصس]/g,'s')
    .replace(/[جش]/g,'sh')
    .replace(/[حخ]/g,'h')
    .replace(/[دذضظ]/g,'d')
    .replace(/[ر]/g,'r')
    .replace(/[ز]/g,'z')
    .replace(/[عغ]/g,'a')
    .replace(/[ف]/g,'f')
    .replace(/[قك]/g,'k')
    .replace(/[ل]/g,'l')
    .replace(/[م]/g,'m')
    .replace(/[ن]/g,'n');
  str = str
    .replace(/kh/g,'h')
    .replace(/gh/g,'g')
    .replace(/sh/g,'s')
    .replace(/ch/g,'s')
    .replace(/dh/g,'d')
    .replace(/th/g,'t')
    .replace(/ph/g,'f')
    .replace(/q/g,'k')
    .replace(/c/g,'k')
    .replace(/x/g,'ks')
    .replace(/ou|oo/g,'u')
    .replace(/ee/g,'i')
    .replace(/aa/g,'a')
    .replace(/[^a-z0-9\s]/g,' ')
    .replace(/[aeiou]/g,'')
    .replace(/(.)\1+/g,'$1')
    .replace(/\s+/g,' ')
    .trim();
  return str.replace(/\s+/g,'');
}

function _qrMakeNgrams(s, n){
  const clean = String(s || '');
  const grams = new Set();
  if(!clean) return grams;
  if(clean.length <= n){ grams.add(clean); return grams; }
  for(let i = 0; i <= clean.length - n; i++) grams.add(clean.slice(i, i+n));
  return grams;
}

function _qrSetJaccard(a, b){
  if(!a.size || !b.size) return 0;
  let inter = 0;
  a.forEach(v => { if(b.has(v)) inter++; });
  return inter / (a.size + b.size - inter || 1);
}

function _qrLongestTokenRun(queryTokens, targetTokens){
  if(!queryTokens.length || !targetTokens.length) return 0;
  let best = 0;
  for(let i = 0; i < queryTokens.length; i++){
    for(let j = 0; j < targetTokens.length; j++){
      let run = 0;
      while(queryTokens[i + run] && targetTokens[j + run] && queryTokens[i + run] === targetTokens[j + run]) run++;
      if(run > best) best = run;
    }
  }
  return best;
}

function _qrTokenOverlapScore(aTokens, bTokens){
  if(!aTokens.length || !bTokens.length) return { hits: 0, recall: 0, precision: 0, matched: [] };
  const bSet = new Set(bTokens);
  const aSet = Array.from(new Set(aTokens));
  const matched = aSet.filter(tok => bSet.has(tok));
  const hits = matched.length;
  const recall = hits / Math.max(1, aSet.length);
  const precision = hits / Math.max(1, new Set(bTokens).size);
  return { hits, recall, precision, matched };
}

function _qrScoreAyahMatch(transcript, item){
  const qAr = _qrArabicCompact(transcript);
  const tAr = item._arCompact || _qrArabicCompact(item.ar);
  if(!qAr && !transcript) return null;

  const qPh = _qrArabicCompact(_qrArabicPhonetic(transcript));
  const tPh = item._arPhCompact || _qrArabicCompact(_qrArabicPhonetic(item.ar));

  const qTokens = _qrTokenizeArabic(transcript);
  const tTokens = item._arTokens || _qrTokenizeArabic(item.ar);
  const qPhTokens = _qrArabicPhonetic(transcript).split(' ').filter(Boolean);
  const tPhTokens = item._arPhTokens || _qrArabicPhonetic(item.ar).split(' ').filter(Boolean);

  const qSoundKey = _qrScriptAgnosticPhonemeKey(transcript);
  const tSoundKey = item._soundKey || _qrScriptAgnosticPhonemeKey(item.ar);
  const qSoundTokens = (_qrBanglaToLatin(_qrNorm(transcript)).split(/\s+/).map(_qrScriptAgnosticPhonemeKey).filter(Boolean));
  const tSoundTokens = item._soundTokens || (_qrBanglaToLatin(_qrNorm(item.ar)).split(/\s+/).map(_qrScriptAgnosticPhonemeKey).filter(Boolean));

  const tok = _qrTokenOverlapScore(qTokens, tTokens);
  const phTok = _qrTokenOverlapScore(qPhTokens, tPhTokens);
  const sndTok = _qrTokenOverlapScore(qSoundTokens, tSoundTokens);

  const longestRun = _qrLongestTokenRun(qTokens, tTokens);
  const longestPhRun = _qrLongestTokenRun(qPhTokens, tPhTokens);
  const longestSndRun = _qrLongestTokenRun(qSoundTokens, tSoundTokens);

  const bg = _qrSetJaccard(_qrMakeNgrams(qAr, 2), _qrMakeNgrams(tAr, 2));
  const tg = _qrSetJaccard(_qrMakeNgrams(qAr, 3), _qrMakeNgrams(tAr, 3));
  const phBg = _qrSetJaccard(_qrMakeNgrams(qPh, 2), _qrMakeNgrams(tPh, 2));
  const phTg = _qrSetJaccard(_qrMakeNgrams(qPh, 3), _qrMakeNgrams(tPh, 3));
  const sndBg = _qrSetJaccard(_qrMakeNgrams(qSoundKey, 2), _qrMakeNgrams(tSoundKey, 2));
  const sndTg = _qrSetJaccard(_qrMakeNgrams(qSoundKey, 3), _qrMakeNgrams(tSoundKey, 3));

  let score = 0;
  score += tok.recall * 90 + tok.precision * 22;
  score += phTok.recall * 150 + phTok.precision * 45;
  score += sndTok.recall * 190 + sndTok.precision * 60;
  score += bg * 70 + tg * 88 + phBg * 150 + phTg * 185 + sndBg * 175 + sndTg * 230;
  score += longestRun * 28 + longestPhRun * 65 + longestSndRun * 82;

  if(tPh.includes(qPh) && qPh.length >= 8) score += 160;
  if(tAr.includes(qAr) && qAr.length >= 10) score += 140;
  if(tSoundKey.includes(qSoundKey) && qSoundKey.length >= 5) score += 220;
  if(qSoundKey.includes(tSoundKey) && tSoundKey.length >= 7) score += 65;
  if(longestSndRun >= Math.max(2, Math.min(5, qSoundTokens.length))) score += 140;
  if(sndTok.hits >= Math.max(2, Math.ceil(qSoundTokens.length * 0.5))) score += 120;
  if(phTok.hits >= Math.max(2, Math.ceil(qPhTokens.length * 0.6))) score += 80;

  if(qSoundTokens.length <= 2 && longestSndRun < qSoundTokens.length) score *= 0.82;
  if(qSoundKey.length < 5 && qPh.length < 8) score *= 0.7;
  if(item.windowSize > 1 && longestSndRun >= 2) score += 30 * item.windowSize;

  return {
    score,
    matchedArabicWords: tok.matched.slice(0, 4),
    matchedSoundWords: sndTok.matched.slice(0, 4),
    soundRatio: sndBg + sndTg + sndTok.recall,
    tokenRatio: phTok.recall + tok.recall
  };
}

function _qrBuildReciteWindows(corpus, maxWindowSize = 2){
  const cacheSizeKey = `${corpus.length}::${maxWindowSize}`;
  if(_qrReciteWindowsCache && _qrReciteWindowsCacheSize === cacheSizeKey) return _qrReciteWindowsCache;
  const bySurah = new Map();
  corpus.forEach(item => {
    if(!bySurah.has(item.surah)) bySurah.set(item.surah, []);
    bySurah.get(item.surah).push(item);
  });
  const out = [];
  bySurah.forEach((rows, surah) => {
    rows.sort((a,b) => a.ayah - b.ayah);
    for(let i = 0; i < rows.length; i++){
      const base = rows[i];
      if(!base || !base.ar) continue;
      const maxLen = Math.min(maxWindowSize, rows.length - i);
      for(let len = 1; len <= maxLen; len++){
        if(len > 1){
          let ok = true;
          for(let j = 1; j < len; j++){
            if(rows[i + j].ayah !== rows[i + j - 1].ayah + 1){ ok = false; break; }
          }
          if(!ok) continue;
        }
        const slice = rows.slice(i, i + len);
        const ar = slice.map(x => x.ar).join(' ');
        out.push({
          surah,
          ayah: slice[0].ayah,
          endAyah: slice[slice.length - 1].ayah,
          ar,
          bn: slice.map(x => x.bn || '').filter(Boolean).join(' '),
          windowSize: slice.length,
          _arCompact: _qrArabicCompact(ar),
          _arTokens: _qrTokenizeArabic(ar),
          _arPhTokens: _qrArabicPhonetic(ar).split(' ').filter(Boolean),
          _arPhCompact: _qrArabicCompact(_qrArabicPhonetic(ar)),
          _soundKey: _qrScriptAgnosticPhonemeKey(ar),
          _soundTokens: _qrBanglaToLatin(_qrNorm(ar)).split(/\s+/).map(_qrScriptAgnosticPhonemeKey).filter(Boolean)
        });
        if(maxWindowSize <= 2 && len === 2) break;
      }
    }
  });
  _qrReciteWindowsCache = out;
  _qrReciteWindowsCacheSize = cacheSizeKey;
  return out;
}

function _qrReciteLightKey(s){
  return (_qrScriptAgnosticPhonemeKey(s) || '').slice(0, 28);
}

function _qrWarmFullReciteCorpusInBackground(){
  try {
    if(_qrGetCachedFullReciteCorpus()?.length) return;
    if(_qrFullReciteCorpusPromise) return;
    setTimeout(() => {
      _qrEnsureFullReciteCorpus().catch(() => {});
    }, 1200);
  } catch(e){}
}

function _qrFastReciteCandidates(transcript, windows, limit = 320){
  const key = _qrReciteLightKey(transcript);
  const cacheKey = `${windows.length}::${limit}::${key}`;
  if(_qrReciteCandidatesCache.has(cacheKey)) return _qrReciteCandidatesCache.get(cacheKey);
  const qSound = _qrScriptAgnosticPhonemeKey(transcript);
  const qPh = _qrArabicCompact(_qrArabicPhonetic(transcript));
  const qSoundGr2 = _qrMakeNgrams(qSound, 2);
  const qPhGr2 = _qrMakeNgrams(qPh, 2);
  const qSoundTokens = (_qrBanglaToLatin(_qrNorm(transcript)).split(/\s+/).map(_qrScriptAgnosticPhonemeKey).filter(Boolean));
  const qLen = qSoundTokens.length || Math.max(1, Math.ceil((qSound || '').length / 4));
  const out = [];
  for(const item of windows){
    let light = 0;
    const sKey = item._soundKey || '';
    if(!sKey) continue;
    if(Math.abs((item._soundTokens?.length || 0) - qLen) > Math.max(6, qLen * 2)) continue;
    const prefixLen = Math.min(5, qSound.length);
    if(prefixLen >= 3 && qSound){
      if(sKey.includes(qSound.slice(0, prefixLen)) || qSound.includes(sKey.slice(0, prefixLen))) light += 10;
    }
    const sg2 = item._sg2 || (item._sg2 = _qrMakeNgrams(sKey, 2));
    const pg2 = item._pg2 || (item._pg2 = _qrMakeNgrams(item._arPhCompact || '', 2));
    light += _qrSetJaccard(qSoundGr2, sg2) * 95;
    light += _qrSetJaccard(qPhGr2, pg2) * 42;
    if(qSoundTokens.length && item._soundTokens){
      const overlap = _qrTokenOverlapScore(qSoundTokens, item._soundTokens);
      light += overlap.hits * 22 + overlap.recall * 18;
      if(overlap.hits === 0 && qSoundTokens.length >= 2 && light < 9) continue;
    }
    if(item.windowSize > 1) light -= 4;
    if(light > 6) out.push({ item, light });
  }
  out.sort((a,b) => b.light - a.light);
  const picked = out.slice(0, limit).map(x => x.item);
  _qrReciteCandidatesCache.set(cacheKey, picked);
  return picked;
}

async function _qrFindBestRecitationMatches(transcript, opts = {}){
  const cacheKey = `${opts.fullCorpus ? 'full' : 'part'}::${opts.maxWindowSize || 2}::${_qrReciteLightKey(transcript)}`;
  if(_qrReciteMatchCache.has(cacheKey)) return _qrReciteMatchCache.get(cacheKey);

  const transcriptNorm = _qrNorm(transcript);
  const transcriptWords = transcriptNorm.split(/\s+/).filter(Boolean);
  const wantFast = opts.fastMode !== false;
  const baseCorpus = _qrBuildReciteCorpus();
  let corpus = wantFast ? _qrPriorityReciteCorpus(baseCorpus) : baseCorpus;

  if(opts.fullCorpus && !wantFast){
    const cachedFull = _qrGetCachedFullReciteCorpus();
    if(Array.isArray(cachedFull) && cachedFull.length){
      corpus = cachedFull;
    } else if(opts.allowNetworkFetch){
      const full = await _qrEnsureFullReciteCorpus(opts.onProgress);
      if(Array.isArray(full) && full.length) corpus = full;
    }
  }

  const maxWindowSize = opts.maxWindowSize || (transcriptWords.length >= 9 ? 2 : 1);
  const windows = _qrBuildReciteWindows(corpus, maxWindowSize);
  let candidates = _qrFastReciteCandidates(transcript, windows, opts.candidateLimit || (wantFast ? 48 : 120));

  if((!candidates || candidates.length < 6) && wantFast && corpus !== baseCorpus){
    const widerWindows = _qrBuildReciteWindows(baseCorpus, Math.min(2, maxWindowSize));
    candidates = _qrFastReciteCandidates(transcript, widerWindows, Math.min(72, (opts.candidateLimit || 72)));
    corpus = baseCorpus;
  }

  const scored = [];
  const seen = new Set();
  const minScore = opts.minScore || (wantFast ? 168 : 155);

  for(let i = 0; i < candidates.length; i++){
    const item = candidates[i];
    const meta = _qrScoreAyahMatch(transcript, item);
    if(meta && meta.score > minScore){
      const row = { ...item, ...meta };
      const k = `${row.surah}:${row.ayah}:${row.endAyah}`;
      if(!seen.has(k)){
        seen.add(k);
        scored.push(row);
      }
    }
    if(i && i % 36 === 0){
      if(typeof opts.onMatchProgress === 'function') opts.onMatchProgress(i, candidates.length);
      await new Promise(r => setTimeout(r, 0));
    }
  }

  scored.sort((a,b) => b.score - a.score);
  const topRows = scored.slice(0, 6);
  if(!topRows.length){ _qrReciteMatchCache.set(cacheKey, []); return []; }

  const top = topRows[0].score;
  const result = topRows
    .filter((h, i) => i < 3 && h.score >= Math.max(minScore, top * 0.76))
    .map(h => ({
      surah: h.surah,
      ayah: h.ayah,
      endAyah: h.endAyah,
      ar: h.ar,
      bn: h.bn,
      score: h.score,
      confidence: _qrVoiceConfidence(h.score, top),
      matchedArabicWords: h.matchedArabicWords || [],
      matchedSoundWords: h.matchedSoundWords || [],
      matchWords: _qrVoiceMatchWordsText(h),
      preview: _qrVoiceHighlightSnippet(h.ar, transcript)
    }));

  _qrReciteMatchCache.set(cacheKey, result);
  return result;
}

async function qrOpenVoiceMatch(surah, ayah){
  await qrSelectSurah(surah, ayah || 1);
  if(ayah && _qrAyahsData && _qrAyahsData.length){
    const idx = _qrAyahsData.findIndex(a => a.n === ayah);
    if(idx >= 0){
      setTimeout(() => qrGoToIdx(idx), 280);
    }
  }
}

function _qrVoiceBuildResultCards(matches, transcript){
  return matches.map(hit => {
    const s = SURAHS.find(x => x.n === hit.surah);
    const ayahLabel = hit.endAyah && hit.endAyah !== hit.ayah ? `${hit.ayah}–${hit.endAyah}` : `${hit.ayah}`;
    return {
      title: `${s?.en || ('Surah ' + hit.surah)} · Ayah ${ayahLabel}`,
      sub: hit.bn ? hit.bn.slice(0, 180) : 'Tap to open this ayah match',
      preview: hit.preview || (hit.ar || '').slice(0, 160),
      confidence: hit.confidence || 0,
      matchWords: hit.matchWords || 'Closest match',
      action: `qrOpenVoiceMatch(${hit.surah},${hit.ayah})`
    };
  });
}

function qrVoiceSearch(mode){
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  _qrVoiceMode = mode || 'surah';
  _qrVoiceRenderResults([]);
  if(!SR){
    _qrVoiceShowStatus('This browser does not support live voice recognition. Try Chrome on Android, or use normal search.', 'error');
    return;
  }
  try { if(_qrVoiceRecognition) _qrVoiceRecognition.stop(); } catch(e) {}
  const rec = new SR();
  _qrVoiceRecognition = rec;
  rec.lang = mode === 'recite' ? 'ar-SA' : 'bn-BD';
  rec.continuous = false;
  rec.interimResults = true;
  rec.maxAlternatives = mode === 'recite' ? 1 : 2;

  _qrVoiceSetBusy(true);
  _qrVoiceShowStatus(mode === 'recite' ? 'Listening… recite one short ayah clearly.' : 'Listening… say a surah name.', '');

  let finalText = '';
  let heard = '';
  let heardAlternatives = [];

  rec.onresult = async (event) => {
    let interim = '';
    for(let i = event.resultIndex; i < event.results.length; i++){
      const result = event.results[i];
      const chunk = result[0]?.transcript || '';
      if(result.isFinal) finalText += ' ' + chunk;
      else interim += ' ' + chunk;
      for(let j = 0; j < result.length; j++){
        const alt = result[j]?.transcript?.trim();
        if(alt) heardAlternatives.push(alt);
      }
    }
    heard = (finalText || interim || '').trim();
    const preview = Array.from(new Set(heardAlternatives)).slice(-3).join(' • ');
    _qrVoiceShowStatus(heard ? 'Voice captured… matching now.' : 'Listening…', '');
  };

  rec.onerror = (event) => {
    _qrVoiceSetBusy(false);
    const code = event?.error || 'unknown';
    const msg = code === 'not-allowed'
      ? 'Microphone permission is blocked. Allow mic access, then try again.'
      : code === 'no-speech'
      ? 'No voice was detected. Please try again and speak a little louder.'
      : 'Voice recognition failed. Please try again.';
    _qrVoiceShowStatus(msg, 'error');
  };

  rec.onend = async () => {
    _qrVoiceSetBusy(false);
    const transcript = (finalText || heard || '').trim();
    const alternatives = Array.from(new Set([transcript, ...heardAlternatives].map(x => String(x || '').trim()).filter(Boolean))).slice(0, _qrVoiceMode === 'recite' ? 2 : 4);
    if(!transcript && !alternatives.length){
      _qrVoiceShowStatus('Could not hear clearly. Try again.', 'error');
      return;
    }

    const primaryText = alternatives[0] || transcript;
    const surahHit = _qrFindBestSurahFromAlternatives(alternatives);
    const ayahNum = _qrFindAyahNumber(primaryText);

    if(_qrVoiceMode === 'surah'){
      if(surahHit){
        const s = SURAHS.find(x => x.n === surahHit.num);
        const usedText = surahHit.transcript || primaryText;
        _qrVoiceShowStatus(`Opening ${s?.en || ('Surah ' + surahHit.num)}${ayahNum ? ' · Ayah ' + ayahNum : ''} · Voice confidence ${surahHit.confidence || 0}%`, 'success');
        _qrVoiceRenderResults([{ 
          title: `${s?.en || ('Surah ' + surahHit.num)}${s?.ar ? ' · ' + s.ar : ''}`,
          confidence: surahHit.confidence || 0,
          matchWords: `Heard: ${usedText}`,
          preview: s?.ar || '',
          sub: `Matched voice command to Surah ${s?.n || surahHit.num}. ${ayahNum ? 'Ayah ' + ayahNum + ' will open.' : 'Opening from the beginning.'}`,
          action: `qrOpenVoiceMatch(${surahHit.num}, ${ayahNum || 1})`
        }], usedText);
        await qrOpenVoiceMatch(surahHit.num, ayahNum || 1);
        return;
      }
      let reciteHits = [];
      const fallbackAlts = alternatives.slice(0, 2);
      for(const alt of fallbackAlts){
        const altHits = await _qrFindBestRecitationMatches(alt, {
          fullCorpus: false,
          allowNetworkFetch: false,
          candidateLimit: 42,
          maxWindowSize: 1,
          fastMode: true,
          minScore: 165
        });
        altHits.forEach(h => reciteHits.push({ ...h, heardText: alt }));
        if(reciteHits.length && reciteHits[0]?.confidence >= 84) break;
      }
      reciteHits.sort((a,b) => b.score - a.score);
      const dedup = [];
      const seen = new Set();
      reciteHits.forEach(h => {
        const k = `${h.surah}:${h.ayah}:${h.endAyah || h.ayah}`;
        if(!seen.has(k)){
          seen.add(k);
          dedup.push(h);
        }
      });
      if(dedup.length){
        const top = dedup[0];
        const next = dedup[1];
        const cards = _qrVoiceBuildResultCards(dedup.slice(0,3), primaryText);
        _qrVoiceRenderResults(cards, primaryText);
        if((top.confidence || 0) >= 70 || (!next || top.score > next.score * 1.12)){
          const s = SURAHS.find(x => x.n === top.surah);
          _qrVoiceShowStatus(`Opening ${s?.en || ('Surah ' + top.surah)} · Ayah ${top.ayah}`, 'success');
          await qrOpenVoiceMatch(top.surah, top.ayah);
          return;
        }
        _qrVoiceShowStatus('Closest Quran match found. Tap to open.', 'success');
        return;
      }
      _qrVoiceShowStatus('No clear surah found. Try again with a short name.', 'error');
      return;
    }


    let hits = [];
    const reciteAlts = alternatives.slice(0, 2);
    for(const alt of reciteAlts){
      const altHits = await _qrFindBestRecitationMatches(alt, {
        fullCorpus: true,
        allowNetworkFetch: false,
        candidateLimit: 150,
        maxWindowSize: 1,
        minScore: 165
      });
      altHits.forEach(h => hits.push({ ...h, heardText: alt }));
      if(altHits[0]?.confidence >= 90) break;
    }
    hits.sort((a,b) => b.score - a.score);
    const unique = [];
    const seen = new Set();
    hits.forEach(h => {
      const k = `${h.surah}:${h.ayah}:${h.endAyah || h.ayah}`;
      if(!seen.has(k)){
        seen.add(k);
        unique.push(h);
      }
    });

    if(unique.length){
      const top = unique[0];
      const cards = _qrVoiceBuildResultCards(unique.slice(0,5), top.heardText || primaryText);
      const s = SURAHS.find(x => x.n === top.surah);
      const topAyahLabel = top.endAyah && top.endAyah !== top.ayah ? `${top.ayah}–${top.endAyah}` : `${top.ayah}`;
      _qrVoiceShowStatus(`Best match: ${s?.en || ('Surah ' + top.surah)} · Ayah ${topAyahLabel} · ${top.confidence || 0}%`, 'success');
      _qrVoiceRenderResults(cards, top.heardText || primaryText);
      if((top.confidence || 0) >= 78){
        await qrOpenVoiceMatch(top.surah, top.ayah);
      }
      return;
    }

    _qrVoiceShowStatus('No strong ayah match yet. Recite one full ayah clearly.', 'error');
  };

  _qrWarmFullReciteCorpusInBackground();
  try { rec.start(); }
  catch(e){
    _qrVoiceSetBusy(false);
    _qrVoiceShowStatus('Could not start voice recognition right now. Please try again.', 'error');
  }
}


// ── Bookmarks list ──────────────────────────────────────────
function _qrRenderBookmarksList() {
  const el = document.getElementById('qr-bookmarks-list');
  if(!el) return;
  const bms = _qrGetBookmarks();
  if(!bms.length) {
    el.innerHTML = '<div style="text-align:center;padding:32px 16px;font-size:0.75rem;color:var(--t3);font-style:italic">No bookmarks yet.<br>Tap an ayah while reading to bookmark it.</div>';
    return;
  }
  el.innerHTML = bms.map((b,i) => {
    const s = SURAHS.find(x => x.n === b.surah);
    return `<div class="qr-bm-card" onclick="qrSelectSurah(${b.surah},${b.ayah})">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px">
        <div class="qr-bm-surah">${s?.en || 'Surah ' + b.surah} · Ayah ${b.ayah}</div>
        <button onclick="event.stopPropagation();_qrToggleBookmark(${b.surah},${b.ayah});_qrRenderBookmarksList()" style="background:none;border:none;font-size:0.875rem;cursor:pointer;color:var(--rose);padding:2px 4px">✕</button>
      </div>
      ${b.ar ? `<div class="qr-bm-ar">${b.ar.slice(0,80)}${b.ar.length>80?'…':''}</div>` : ''}
      ${b.bn ? `<div style="font-size:0.625rem;color:var(--t2);margin-top:4px;line-height:1.6">${b.bn.slice(0,100)}${b.bn.length>100?'…':''}</div>` : ''}
    </div>`;
  }).join('');
}

// ── Hifz list ───────────────────────────────────────────────
function _qrRenderHifzList() {
  const el = document.getElementById('qr-hifz-list');
  if(!el) return;
  const hifz = _qrGetHifzSurahs();
  if(!hifz.length) {
    el.innerHTML = '<div style="text-align:center;padding:32px 16px;font-size:0.75rem;color:var(--t3);font-style:italic">No surahs added to Hifz yet.<br>Open any surah and tap 🧠 to start memorising.</div>';
    return;
  }
  el.innerHTML = hifz.map(num => {
    const s = SURAHS.find(x => x.n === num);
    return `<div class="qr-bm-card" style="border-color:rgba(var(--purple-rgb),.2)" onclick="qrSelectSurah(${num})">
      <div style="display:flex;align-items:center;justify-content:space-between">
        <div>
          <div class="qr-bm-surah" style="color:#ce93d8">${s?.en || 'Surah '+num} <span style="font-family:'Playfair Display',serif;font-size:0.875rem;color:var(--gold)">${s?.ar||''}</span></div>
          <div class="qr-bm-detail">${s?.v||''} ayahs · Tap to practice</div>
        </div>
        <button onclick="event.stopPropagation();_qrToggleHifzSurah(${num});_qrRenderHifzList()" style="background:none;border:none;font-size:0.875rem;cursor:pointer;color:var(--rose);padding:2px 4px">✕</button>
      </div>
    </div>`;
  }).join('');
}

// ── Continue reading banner ─────────────────────────────────
function _qrRenderContinueBanner() {
  return; // Home page continue reading kept inside popup for a cleaner minimalist layout
}

// ── Open reader ─────────────────────────────────────────────
async function qrSelectSurah(num, scrollToAyah) {
  _qrState.surahNum = num;
  _qrHifzRevealed  = new Set();
  _qrSave();

  const s = SURAHS.find(x => x.n === num);

  // Update header
  const titleEl = document.getElementById('qr-surah-title');
  const subEl   = document.getElementById('qr-surah-sub');
  const arEl    = document.getElementById('qr-arabic-title');
  const infoEl  = document.getElementById('qr-bottom-info');
  if(titleEl) titleEl.textContent = s ? s.en : 'Surah ' + num;
  if(subEl)   subEl.textContent   = s ? s.v + ' Ayahs · Surah ' + num + ' of 114' : '';
  if(arEl)    arEl.textContent    = s ? s.ar : '';
  if(infoEl)  infoEl.textContent  = s ? 'Surah ' + num + ' of 114' : '';

  // Bismillah
  const bism = document.getElementById('qr-bismillah');
  if(bism) bism.style.display = (num === 9 || num === 1) ? 'none' : 'block';

  // Toolbar active states
  _qrUpdateToolbar();

  // Open the reader feat-page (it's a separate full-screen page)
  const readerPage = document.getElementById('page-quran-reader');
  if(readerPage) {
    // Track which page was open before reader, so we can go back to it
    const prevOpen = document.querySelector('.feat-page.open:not(#page-quran-reader)');
    readerPage._prevPageId = prevOpen ? prevOpen.id : null;

    document.querySelectorAll('.feat-page.open').forEach(p => {
      if(p.id !== 'page-quran-reader') p.classList.remove('open');
    });
    readerPage.classList.add('open');
    document.body.style.overflow = 'hidden';
    // Hide main nav
    const nav = document.getElementById('main-nav');
    if(nav) nav.style.display = 'none';
    try { history.pushState({feat:'page-quran-reader'}, '', ''); } catch(e) {}
  }

  // Check hifz
  const isHifz = _qrGetHifzSurahs().includes(num);
  _qrState.hifzMode = isHifz;
  const hifzBar = document.getElementById('qr-hifz-bar');
  if(hifzBar) hifzBar.style.display = isHifz ? 'block' : 'none';
  _qrUpdateToolbar();

  // Load ayahs
  await qrLoadSurah(num);

  // Scroll to position
  const body = document.getElementById('qr-reader-body');
  if(body) {
    body.scrollTop = 0;
    if(scrollToAyah > 1) {
      setTimeout(() => {
        const ayahEl = document.getElementById('qr-ayah-' + scrollToAyah);
        if(ayahEl) ayahEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 300);
    }
  }

  // Scroll reader page to top
  if(readerPage) readerPage.scrollTop = 0;

  // Update badge
  const badge = document.getElementById('qplayer-now-badge');
  if(badge) { badge.style.display='inline'; badge.textContent = s?.en || 'Surah '+num; }
}

// Keep old name for compat
async function qpSelectSurah(num) { return qrSelectSurah(num); }

function qrCloseReader() {
  const p = document.getElementById('page-quran-reader');
  if(p) p.classList.remove('open');
  document.body.style.overflow = '';
  // Show main nav again
  const nav = document.getElementById('main-nav');
  if(nav) {
    nav.style.display       = '';
    nav.style.opacity       = '1';
    nav.style.transform     = '';
    nav.style.pointerEvents = '';
  }
  // Stop audio
  if (_qrAudio) { _qrAudio.pause(); _qrAudio.src = ''; }
  _qrState.audioPlaying = false;
  // Refresh surah list to show updated progress
  const list = document.getElementById('qp-list');
  if(list) { list.dataset.built = ''; list.innerHTML = ''; qpRenderSurahList(); }
  _qrRenderContinueBanner();
  _qrRenderOverallStats();

  // Go back to the page that opened the reader (e.g. page-quran or page-surah-view)
  const prevId = p && p._prevPageId;
  if(prevId) {
    const prevPage = document.getElementById(prevId);
    if(prevPage) {
      prevPage.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
  }
}

// ── Load ayahs ──────────────────────────────────────────────
async function qrLoadSurah(num) {
  if(_qrState.loading) return;
  _qrState.loading = true;
  _qrState.loaded  = false;
  const loadEl = document.getElementById('qr-loading');
  const errEl  = document.getElementById('qr-error');
  const ayahEl = document.getElementById('qr-ayahs');
  if(loadEl) loadEl.style.display = 'block';
  if(errEl)  errEl.style.display  = 'none';
  if(ayahEl) ayahEl.innerHTML     = '';

  let ayahs = null;

  const offline = QP_OFFLINE[String(num)];
  if(offline && offline.ar && offline.ar.length) {
    ayahs = offline.ar.map((ar, i) => ({ n: i+1, ar, bn: offline.bn?.[i] || '' }));
  }
  if(!ayahs) {
    try {
      const res = await fetch(`https://raw.githubusercontent.com/semarketir/quranjson/master/source/surah/surah_${num}.json`);
      if(res.ok) {
        const d = await res.json();
        if(d?.verse) ayahs = Object.entries(d.verse).sort((a,b)=>parseInt(a[0].replace(/\D/g,''))-parseInt(b[0].replace(/\D/g,''))).map(([k,v])=>({n:parseInt(k.replace(/\D/g,'')), ar:v, bn:''}));
      }
    } catch(e) {}
  }
  if(!ayahs) {
    try {
      const [vRes, tRes] = await Promise.all([
        fetch(`https://api.quran.com/api/v4/verses/by_chapter/${num}?per_page=300&fields=text_uthmani`),
        fetch(`https://api.quran.com/api/v4/verses/by_chapter/${num}?per_page=300&translations=161`),
      ]);
      if(vRes.ok) {
        const vd = await vRes.json(); const td = tRes.ok ? await tRes.json() : null;
        if(vd?.verses?.length) ayahs = vd.verses.map((v,i)=>({n: v.verse_number || (i+1), ar:v.text_uthmani||'', bn:td?.verses?.[i]?.translations?.[0]?.text?.replace(/<[^>]+>/g,'')||''}));
      }
    } catch(e) {}
  }
  if(!ayahs) {
    try {
      const [arRes, bnRes] = await Promise.all([
        fetch(`https://api.alquran.cloud/v1/surah/${num}`),
        fetch(`https://api.alquran.cloud/v1/surah/${num}/bn.bengali`),
      ]);
      if(arRes.ok) {
        const ad = await arRes.json(); const bd = bnRes.ok ? await bnRes.json() : {code:0};
        if(ad.code===200) ayahs = ad.data.ayahs.map((a,i)=>({n:a.numberInSurah, ar:a.text, bn:bd.code===200?(bd.data.ayahs[i]?.text||''):''}));
      }
    } catch(e) {}
  }

  _qrState.loading = false;
  if(loadEl) loadEl.style.display = 'none';

  if(!ayahs) {
    if(errEl) {
      errEl.style.display = 'block';
      errEl.innerHTML = `<div style="text-align:center;padding:40px 16px"><div style="font-size:2rem;margin-bottom:10px">⚠️</div><div style="font-size:0.875rem;color:var(--t2);margin-bottom:6px">Could not load Surah</div><div style="font-size:0.625rem;color:var(--t3);margin-bottom:18px">Internet connection required</div><button onclick="qrLoadSurah(${num})" style="padding:10px 22px;border-radius:12px;border:1px solid rgba(var(--accent-rgb),.3);background:rgba(var(--accent-rgb),.1);color:var(--gold);font-family:'Manrope',sans-serif;font-size:0.75rem;cursor:pointer">↺ Retry</button></div>`;
    }
    return;
  }

  _qrState.loaded = true;
  _qrRenderAyahs(ayahs, num);
  _qrInitScroll(num, ayahs.length);
}

// Keep old name
async function qpLoadSurah(num) { return qrLoadSurah(num); }

// ── NEW PLAYER: stage + dots + pill bar ─────────────────────
let _qrAyahsData  = [];   // loaded ayahs array
let _qrCurIdx     = 0;    // 0-based index of current ayah in stage
let _qrDoneSet    = new Set();  // set of done ayah numbers (current surah)
let _qrTouchX0    = null;
let _qrTouchY0    = null;

// ── Ayah done persistence helpers ──────────────────────────
function _qrDoneKey(surahNum) { return 'mrd_qr_done_' + surahNum; }

function _qrLoadDone(surahNum) {
  try { return new Set(JSON.parse(localStorage.getItem(_qrDoneKey(surahNum)) || '[]')); }
  catch { return new Set(); }
}

function _qrSaveDone(surahNum) {
  try { localStorage.setItem(_qrDoneKey(surahNum), JSON.stringify([..._qrDoneSet])); } catch {}
}

function _qrUpdateDoneBar() {
  const total = _qrAyahsData.length;
  const done  = _qrDoneSet.size;
  const pct   = total ? (done / total * 100) : 0;

  const wrap  = document.getElementById('qr-done-bar-wrap');
  const fill  = document.getElementById('qr-done-fill');
  const label = document.getElementById('qr-done-label');
  if (!fill || !label) return;

  // Hide bar until ayahs are loaded
  if (wrap) wrap.style.display = total > 0 ? 'flex' : 'none';
  if (!total) return;

  fill.style.width = pct + '%';

  if (done === total) {
    fill.style.background = 'linear-gradient(90deg,var(--gold),var(--gold2))';
    label.textContent     = '✦ Complete!';
    label.style.color     = 'var(--gold)';
    label.style.fontWeight = '600';
  } else {
    fill.style.background  = 'linear-gradient(90deg,var(--teal),var(--green))';
    label.textContent      = done + ' / ' + total + ' ✓';
    label.style.color      = done > 0 ? 'var(--teal)' : 'var(--t3)';
    label.style.fontWeight = '';
  }
}

function _qrRenderAyahs(ayahs, surahNum) {
  const num = surahNum || _qrState.surahNum;
  _qrAyahsData = ayahs;
  // store in hidden el for compat
  const el = document.getElementById('qr-ayahs');
  if(el) { el.dataset.ayahs = JSON.stringify(ayahs); el.dataset.surah = num; }

  // Load persisted done set for this surah
  _qrDoneSet = _qrLoadDone(num);

  // Restore last position
  const savedProg = _qrGetProgress()[num] || 0;
  _qrCurIdx = savedProg > 0 ? Math.max(0, savedProg - 1) : 0;
  _qrState.activeAyah = ayahs[_qrCurIdx]?.n || 1;

  _qrRenderDots();
  _qrShowStageAyah(_qrCurIdx, null);
  _qrUpdateReadProgress();
  _qrUpdateDoneBar();
  _qrBuildFullSurahList(ayahs, num);
  _qrBuildMenuAyahList(ayahs);
  _qrUpdateHifzProgress();
  _qrShowReadingTime(ayahs.length);
}

function _qrRenderDots() {
  const dots = document.getElementById('qr-dots');
  if(!dots) return;
  const total = _qrAyahsData.length;
  if(total > 60) { dots.innerHTML = ''; return; }
  dots.innerHTML = _qrAyahsData.map((a,i) =>
    `<div class="qr-dot${i===_qrCurIdx?' active':''}${_qrDoneSet.has(a.n)?' done':''}" data-i="${i}" onclick="qrGoToIdx(${i})"></div>`
  ).join('');
}

function _qrUpdateDots() {
  const dots = document.getElementById('qr-dots');
  if(!dots) return;
  dots.querySelectorAll('.qr-dot').forEach((d,i) => {
    d.classList.toggle('active', i === _qrCurIdx);
    d.classList.toggle('done', _qrDoneSet.has(_qrAyahsData[i]?.n));
  });
}

function _qrShowStageAyah(idx, dir) {
  const a = _qrAyahsData[idx];
  if(!a) return;
  const inner   = document.getElementById('qr-stage-inner');
  const badge   = document.getElementById('qr-stage-badge');
  const arEl    = document.getElementById('qr-stage-ar');
  const transEl = document.getElementById('qr-stage-trans');
  if(!inner) return;

  const animate = dir !== null;
  if(animate) {
    inner.classList.add(dir === 'next' ? 'qr-slide-out-l' : 'qr-slide-out-r');
  }

  const doUpdate = () => {
    const surahNum = _qrState.surahNum;
    const isDone   = _qrDoneSet.has(a.n);
    if(badge) {
      badge.textContent = surahNum + ':' + a.n + (isDone ? '  ✓' : '');
      badge.className   = 'qr-stage-badge' + (isDone ? ' qr-stage-badge-done' : '');
    }
    if(arEl) {
      const fsz = _qrState.fontSize === 'xlarge' ? 'xlarge' : _qrState.fontSize === 'large' ? 'large' : '';
      arEl.className  = 'qr-stage-ar' + (fsz ? ' '+fsz : '');
      arEl.textContent = _qrState.showAr ? a.ar : '';
      arEl.style.display = _qrState.showAr ? '' : 'none';
    }
    if(transEl) {
      transEl.innerHTML = (_qrState.showBn && a.bn) ? a.bn : '';
      transEl.style.display = (_qrState.showBn && a.bn) ? '' : 'none';
    }
    // Done button state
    const doneBtn = document.getElementById('qr-pill-done');
    if(doneBtn) doneBtn.classList.toggle('marked', isDone);
    // Play button state
    const playBtn = document.getElementById('qr-pill-play');
    if(playBtn) playBtn.textContent = _qrState.audioPlaying ? '⏸' : '▶';
    if(animate) {
      inner.classList.remove('qr-slide-out-l','qr-slide-out-r');
      inner.classList.add(dir === 'next' ? 'qr-slide-in-l' : 'qr-slide-in-r');
      setTimeout(() => inner.classList.remove('qr-slide-in-l','qr-slide-in-r'), 240);
    }
  };

  if(animate) { setTimeout(doUpdate, 180); } else { doUpdate(); }

  _qrState.activeAyah = a.n;
  _qrSetProgress(_qrState.surahNum, a.n);
}

function qrGoToIdx(idx) {
  if(idx < 0 || idx >= _qrAyahsData.length) return;
  const dir = idx > _qrCurIdx ? 'next' : 'prev';
  _qrCurIdx = idx;
  _qrShowStageAyah(idx, dir);
  _qrUpdateDots();
  _qrUpdateReadProgress();
  // Scroll dots to active
  const dotEl = document.querySelector(`.qr-dot[data-i="${idx}"]`);
  if(dotEl) dotEl.scrollIntoView({ inline:'center', behavior:'smooth' });
}

// Pill bar actions
function qrPillNext() {
  if(_qrCurIdx < _qrAyahsData.length - 1) {
    qrGoToIdx(_qrCurIdx + 1);
  } else {
    qrNextSurah();
  }
}

function qrPillPrev() {
  if(_qrCurIdx > 0) {
    qrGoToIdx(_qrCurIdx - 1);
  } else {
    qrPrevSurah();
  }
}

function qrPillMarkDone() {
  const a = _qrAyahsData[_qrCurIdx];
  if(!a) return;
  if(_qrDoneSet.has(a.n)) {
    _qrDoneSet.delete(a.n);
  } else {
    _qrDoneSet.add(a.n);
    // Auto-advance
    setTimeout(() => qrPillNext(), 280);
  }
  // Persist + update bar
  _qrSaveDone(_qrState.surahNum);
  _qrShowStageAyah(_qrCurIdx, null);
  _qrUpdateDots();
  _qrUpdateDoneBar();

  // Celebrate surah completion
  if (_qrDoneSet.size === _qrAyahsData.length && _qrAyahsData.length > 0) {
    setTimeout(_qrCelebrateSurahComplete, 400);
  }
}

function qrPillPlay() {
  const a = _qrAyahsData[_qrCurIdx];
  if (!a) return;

  // If audio is actively playing → pause it
  if (_qrState.audioPlaying && _qrAudio && !_qrAudio.paused) {
    qrAudioPause();
    return;
  }

  // If audio is paused on the SAME ayah → resume it
  if (_qrAudio && _qrAudio.paused && _qrState.audioAyah === a.n && _qrState.audioOn) {
    _qrAudio.playbackRate = _qrAudioSpeed;
    _qrAudio.play().catch(() => {});
    _qrState.audioPlaying = true;
    _qrStartProgTimer();
    _qrUpdateAudioBar();
    const playBtn = document.getElementById('qr-pill-play');
    if (playBtn) playBtn.textContent = '⏸';
    return;
  }

  // Otherwise → start playing the current ayah fresh
  qrAudioPlayAyah(a.n);
}

// Touch/swipe for stage
function qrTouchStart(e) { _qrTouchX0 = e.touches[0].clientX; _qrTouchY0 = e.touches[0].clientY; }
function qrTouchMove(e)  { /* allow scroll */ }
function qrTouchEnd(e) {
  if(_qrTouchX0 === null) return;
  const dx = e.changedTouches[0].clientX - _qrTouchX0;
  const dy = e.changedTouches[0].clientY - _qrTouchY0;
  _qrTouchX0 = null; _qrTouchY0 = null;
  if(Math.abs(dx) < 40 || Math.abs(dy) > Math.abs(dx)) return;
  if(dx < 0) qrPillNext(); else qrPillPrev();
}

// Full-surah slide-over
function qrOpenFullSurah() {
  const el = document.getElementById('qr-fullsurah-body');
  if(el) el.classList.add('open');
  // Rebuild with latest done states
  _qrBuildFullSurahList(_qrAyahsData, _qrState.surahNum);
}
function qrCloseFullSurah() {
  const el = document.getElementById('qr-fullsurah-body');
  if(el) el.classList.remove('open');
}

function _qrBuildFullSurahList(ayahs, surahNum) {
  const list  = document.getElementById('qr-fullsurah-list');
  const title = document.getElementById('qr-fullsurah-title');
  const bism  = document.getElementById('qr-bismillah-full');
  if(!list) return;
  const s = SURAHS.find(x => x.n === surahNum);
  if(title) title.textContent = (s ? s.en : 'Surah ' + surahNum) + ' — Full View';
  if(bism)  bism.style.display = (surahNum === 9) ? 'none' : '';
  list.innerHTML = ayahs.map((a,i) => {
    const isDone = _qrDoneSet.has(a.n);
    return `<div style="padding:14px 0;border-bottom:1px solid rgba(255,255,255,.05);cursor:pointer;position:relative" onclick="qrCloseFullSurah();setTimeout(()=>qrGoToIdx(${i}),120)">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
        <div style="width:24px;height:24px;border-radius:50%;background:${isDone?'rgba(var(--green-rgb),.18)':'rgba(var(--accent-rgb),.1)'};border:1px solid ${isDone?'rgba(var(--green-rgb),.45)':'rgba(var(--accent-rgb),.2)'};display:flex;align-items:center;justify-content:center;font-size:0.4375rem;color:${isDone?'var(--green)':'var(--gold)'};font-weight:700;flex-shrink:0">${isDone?'✓':a.n}</div>
        <div style="font-family:'Playfair Display',serif;font-size:1.25rem;direction:rtl;text-align:right;flex:1;color:${isDone?'var(--t2)':'var(--text)'};line-height:1.9">${a.ar}</div>
      </div>
      ${a.bn ? `<div style="font-size:0.75rem;color:var(--t2);line-height:1.6;padding-left:32px">${a.bn}</div>` : ''}
    </div>`;
  }).join('');
}

// Menu sheet
function _qrBuildMenuAyahList(ayahs) {
  const el = document.getElementById('qr-menu-ayah-list');
  if(!el) return;
  el.innerHTML = ayahs.map((a,i) =>
    `<div class="qr-jump-item${i===_qrCurIdx?' current':''}" onclick="qrGoToIdx(${i});qrCloseMenu()" data-i="${i}">${a.n}${a.bn ? ' — ' + a.bn.slice(0,55) + (a.bn.length>55?'…':'') : ''}</div>`
  ).join('');
}

function qrOpenMenu() {
  qrUpdateMenuState();
  const el = document.getElementById('qr-menu-sheet');
  if(el) el.classList.add('open');
  // Sync reciter select with hidden compat select
  const ms = document.getElementById('qr-menu-reciter');
  const rs = document.getElementById('qr-reciter-select');
  if(ms && rs && rs.options.length > 0 && ms.options.length === 0) ms.innerHTML = rs.innerHTML;
  if(ms && rs) ms.value = rs.value;
  const msp = document.getElementById('qr-menu-speed');
  const rsp = document.getElementById('qr-speed-select');
  if(msp && rsp) msp.value = rsp.value;
}

function qrCloseMenu() {
  const el = document.getElementById('qr-menu-sheet');
  if(el) el.classList.remove('open');
}

function qrUpdateMenuState() {
  const s = _qrState;
  const set = (id,val,isOn) => {
    const e=document.getElementById(id);
    if(!e) return;
    e.textContent=val;
    e.className='qr-sheet-row-val'+(isOn?' on':'');
  };
  set('qr-menu-ar-val',    s.showAr ? 'On' : 'Off', s.showAr);
  set('qr-menu-bn-val',    s.showBn ? 'On' : 'Off', s.showBn);
  set('qr-menu-font-val',  s.fontSize === 'normal' ? 'Normal' : s.fontSize === 'large' ? 'Large' : 'X-Large', s.fontSize !== 'normal');
  set('qr-menu-audio-val', s.audioOn ? 'On' : 'Off', s.audioOn);
  set('qr-menu-repeat-val',s.repeatAyah ? 'On' : 'Off', s.repeatAyah);
  set('qr-menu-night-val', s.nightMode ? 'On' : 'Off', s.nightMode);
  const hasBm = _qrGetBookmarks().some(b => b.surah === s.surahNum);
  set('qr-menu-bm-val', hasBm ? 'Saved ✓' : '', hasBm);
  // Update ayah list current marker
  document.querySelectorAll('.qr-jump-item').forEach((el,i) => {
    el.classList.toggle('current', i === _qrCurIdx);
  });
}

function qrQuickToggleBn(btn) {
  qrToggleBn();
  const el = btn || document.getElementById('qr-quick-bn-toggle');
  if (el) {
    el.textContent = _qrState.showBn ? 'বাংলা On' : 'বাংলা Off';
    el.style.color = _qrState.showBn ? 'var(--green)' : 'var(--t3)';
    el.style.borderColor = _qrState.showBn ? 'rgba(var(--green-rgb),.25)' : 'rgba(255,255,255,.12)';
    el.style.background = _qrState.showBn ? 'rgba(var(--green-rgb),.08)' : 'rgba(255,255,255,.05)';
  }
  qrUpdateMenuState();
  _qrShowStageAyah(_qrCurIdx,null);
  showToast(_qrState.showBn ? 'বাংলা translation on' : 'বাংলা translation off');
}

function qrMenuToggleAr()    { qrToggleAr();     qrUpdateMenuState(); _qrShowStageAyah(_qrCurIdx,null); }
function qrMenuToggleBn()    { qrToggleBn();     qrUpdateMenuState(); _qrShowStageAyah(_qrCurIdx,null); }
function qrMenuCycleFont()   { qrToggleFont();   qrUpdateMenuState(); _qrShowStageAyah(_qrCurIdx,null); }
function qrMenuToggleAudio() { qrToggleAudio();  qrUpdateMenuState(); }
function qrMenuToggleRepeat(){ qrAudioToggleRepeat(); qrUpdateMenuState(); }
function qrMenuToggleNight() { qrToggleNightMode(); qrUpdateMenuState(); }
function qrMenuToggleHifz()  { qrToggleHifzMode(); qrUpdateMenuState(); }
function qrMenuPrevSurah()   { qrCloseMenu(); qrPrevSurah(); }
function qrMenuNextSurah()   { qrCloseMenu(); qrNextSurah(); }

// ── Render ayahs (compat) ───────────────────────────────────
function qrActivateAyah(n) {
  const idx = _qrAyahsData.findIndex(a => a.n === n);
  if(idx >= 0) qrGoToIdx(idx);
}

function _qrUpdateReadProgress() {
  const total = _qrAyahsData.length;
  const prog  = total > 0 ? ((_qrCurIdx + 1) / total * 100) : 0;
  const bar   = document.getElementById('qr-read-prog');
  if(bar) bar.style.width = prog + '%';
}

function _qrInitScroll(num, totalAyahs) {
  const prog = _qrGetProgress()[num] || 0;
  const startIdx = prog > 0 ? Math.max(0, prog - 1) : 0;
  if(startIdx !== _qrCurIdx) {
    _qrCurIdx = startIdx;
    _qrUpdateDots();
    _qrShowStageAyah(startIdx, null);
    _qrUpdateReadProgress();
  }
  _qrUpdateHifzProgress();
}

// ── Toolbar ─────────────────────────────────────────────────
function _qrUpdateToolbar() {
  const arBtn    = document.getElementById('qr-btn-ar');
  const bnBtn    = document.getElementById('qr-btn-bn');
  const fontBtn  = document.getElementById('qr-btn-font');
  const hifzBtn  = document.getElementById('qr-btn-hifz');
  const bmBtn    = document.getElementById('qr-btn-bm');
  const audioBtn = document.getElementById('qr-btn-audio');
  if(arBtn)    { arBtn.classList.toggle('active', _qrState.showAr); }
  if(bnBtn)    { bnBtn.classList.toggle('active', _qrState.showBn); }
  const quickBnBtn = document.getElementById('qr-quick-bn-toggle');
  if(quickBnBtn) {
    quickBnBtn.textContent = _qrState.showBn ? 'বাংলা On' : 'বাংলা Off';
    quickBnBtn.style.color = _qrState.showBn ? 'var(--green)' : 'var(--t3)';
    quickBnBtn.style.borderColor = _qrState.showBn ? 'rgba(var(--green-rgb),.25)' : 'rgba(255,255,255,.12)';
    quickBnBtn.style.background = _qrState.showBn ? 'rgba(var(--green-rgb),.08)' : 'rgba(255,255,255,.05)';
  }
  if(fontBtn)  { fontBtn.textContent = _qrState.fontSize === 'normal' ? 'Aa' : _qrState.fontSize === 'large' ? 'Aa+' : 'Aa++'; }
  if(hifzBtn)  { hifzBtn.classList.toggle('active', _qrState.hifzMode); }
  if(audioBtn) { audioBtn.classList.toggle('active', _qrState.audioOn); }
  if(bmBtn)    {
    const hasBm = _qrGetBookmarks().some(b => b.surah === _qrState.surahNum);
    bmBtn.classList.toggle('active', hasBm);
    bmBtn.textContent = hasBm ? '🔖' : '🔖';
  }
  const nightBtn = document.getElementById('qr-btn-night');
  if(nightBtn) { nightBtn.classList.toggle('active', _qrNightMode); nightBtn.textContent = _qrNightMode ? '☀️' : '🌙'; }
  // Sync reciter select
  const sel = document.getElementById('qr-reciter-select');
  if (sel) sel.value = _qrState.reciter;
  _qrUpdateAudioBar();
}

function qrToggleAr() {
  _qrState.showAr = !_qrState.showAr;
  _qrSave(); _qrUpdateToolbar();
  const raw = document.getElementById('qr-ayahs')?.dataset?.ayahs;
  if(raw) _qrRenderAyahs(JSON.parse(raw));
}
function qrToggleBn() {
  _qrState.showBn = !_qrState.showBn;
  _qrSave(); _qrUpdateToolbar();
  const raw = document.getElementById('qr-ayahs')?.dataset?.ayahs;
  if(raw) _qrRenderAyahs(JSON.parse(raw));
}
function qrToggleFont() {
  const sizes = ['normal','large','xlarge'];
  const idx   = sizes.indexOf(_qrState.fontSize);
  _qrState.fontSize = sizes[(idx + 1) % sizes.length];
  _qrSave(); _qrUpdateToolbar();
  const raw = document.getElementById('qr-ayahs')?.dataset?.ayahs;
  if(raw) _qrRenderAyahs(JSON.parse(raw));
}
function qrToggleBookmark() {
  // Toggle bookmark for surah (jump to first ayah bookmark)
  const bms = _qrGetBookmarks().filter(b => b.surah === _qrState.surahNum);
  if(bms.length) {
    // Remove all bookmarks for this surah
    let all = _qrGetBookmarks().filter(b => b.surah !== _qrState.surahNum);
    _qrSaveBookmarks(all);
  } else {
    // Bookmark current active ayah or ayah 1
    const n = _qrState.activeAyah > 0 ? _qrState.activeAyah : 1;
    const raw = document.getElementById('qr-ayahs')?.dataset?.ayahs;
    const ayahs = raw ? JSON.parse(raw) : [];
    const a = ayahs.find(x => x.n === n) || ayahs[0];
    if(a) _qrToggleBookmark(_qrState.surahNum, a.n, a.ar, a.bn);
  }
  _qrUpdateToolbar();
}

// ── Ayah-level bookmark ─────────────────────────────────────
function qrAyahBookmark(n, ar, bn) {
  _qrToggleBookmark(_qrState.surahNum, n, ar, bn);
  const btn = document.getElementById('qr-bm-btn-' + n);
  const isBm = _qrIsBookmarked(_qrState.surahNum, n);
  if(btn) { btn.textContent = isBm ? '🔖 Bookmarked' : '🔖 Bookmark'; btn.classList.toggle('bookmarked', isBm); }
  _qrUpdateToolbar();
  showToast(isBm ? '🔖 Ayah bookmarked' : 'Bookmark removed');
}

// ── Copy ayah ───────────────────────────────────────────────
function qrCopyAyah(ar, bn) {
  const text = ar + (bn ? '\n\n' + bn : '');
  if(navigator.clipboard) navigator.clipboard.writeText(text).then(()=>showToast('✓ Copied')).catch(()=>showToast('Copy failed'));
  else showToast('Copy not supported');
}

// ── Share ayah ──────────────────────────────────────────────
function qrShareAyah(surahNum, ayahN, ar, bn) {
  const s = SURAHS.find(x => x.n === surahNum);
  const ref = s ? `(${s.en} ${surahNum}:${ayahN})` : `(${surahNum}:${ayahN})`;
  const text = ar + '\n\n' + (bn || '') + '\n' + ref;
  if(navigator.share) {
    navigator.share({ text }).catch(()=>{});
  } else {
    qrCopyAyah(ar, bn);
    showToast('✓ Copied to clipboard');
  }
}

// ── Night / Focus mode ───────────────────────────────────────
let _qrNightMode = false;
function qrToggleNightMode() {
  _qrNightMode = !_qrNightMode;
  const page = document.getElementById('page-quran-reader');
  if(page) page.classList.toggle('night-mode', _qrNightMode);
  const btn = document.getElementById('qr-btn-night');
  if(btn) { btn.classList.toggle('active', _qrNightMode); btn.textContent = _qrNightMode ? '☀️' : '🌙'; }
  showToast(_qrNightMode ? '🌙 Night mode on' : '☀️ Day mode');
}

// ── Reading time estimate ─────────────────────────────────────
function _qrShowReadingTime(ayahCount) {
  const el = document.getElementById('qr-read-time');
  if(!el) return;
  // ~3 sec/ayah for Arabic recitation, ~5 sec for reading
  const mins = Math.max(1, Math.round(ayahCount * 4 / 60));
  el.textContent = `~${mins} min`;
  el.style.display = '';
}
function qrToggleHifzMode() {
  _qrState.hifzMode = !_qrState.hifzMode;
  _qrToggleHifzSurah(_qrState.surahNum);
  const hifzBar = document.getElementById('qr-hifz-bar');
  if(hifzBar) hifzBar.style.display = _qrState.hifzMode ? 'block' : 'none';
  _qrUpdateToolbar();
  const raw = document.getElementById('qr-ayahs')?.dataset?.ayahs;
  if(raw) _qrRenderAyahs(JSON.parse(raw));
  showToast(_qrState.hifzMode ? '🧠 Hifz mode on — ayahs hidden' : 'Hifz mode off');
}
function qrHifzRevealOne(n) {
  if(_qrHifzRevealed.has(n)) _qrHifzRevealed.delete(n);
  else _qrHifzRevealed.add(n);
  const el = document.getElementById('qr-ayah-' + n);
  if(el) {
    el.classList.toggle('hifz-hidden', !_qrHifzRevealed.has(n));
    const btn = el.querySelector('[onclick*="qrHifzRevealOne"]');
    if(btn) btn.textContent = _qrHifzRevealed.has(n) ? '🙈 Hide' : '👁 Reveal';
  }
  _qrUpdateHifzProgress();
}
function qrHifzRevealNext() {
  const raw = document.getElementById('qr-ayahs')?.dataset?.ayahs;
  if(!raw) return;
  const ayahs = JSON.parse(raw);
  const nextHidden = ayahs.find(a => !_qrHifzRevealed.has(a.n));
  if(nextHidden) qrHifzRevealOne(nextHidden.n);
  else showToast('All ayahs revealed! 🎉');
}
function qrHifzRevealAll() {
  const raw = document.getElementById('qr-ayahs')?.dataset?.ayahs;
  if(!raw) return;
  JSON.parse(raw).forEach(a => _qrHifzRevealed.add(a.n));
  document.querySelectorAll('.qr-ayah').forEach(el => el.classList.remove('hifz-hidden'));
  _qrUpdateHifzProgress();
}
function qrHifzHideAll() {
  _qrHifzRevealed.clear();
  document.querySelectorAll('.qr-ayah').forEach(el => el.classList.add('hifz-hidden'));
  _qrUpdateHifzProgress();
}
function _qrUpdateHifzProgress() {
  const el  = document.getElementById('qr-hifz-progress');
  if(!el) return;
  const raw = document.getElementById('qr-ayahs')?.dataset?.ayahs;
  if(!raw) return;
  const total = JSON.parse(raw).length;
  el.textContent = _qrHifzRevealed.size + ' / ' + total + ' revealed';
}

// ── Navigation ───────────────────────────────────────────────
function qrPrevSurah() { if(_qrState.surahNum > 1)   qrSelectSurah(_qrState.surahNum - 1); }
function qrNextSurah() { if(_qrState.surahNum < 114)  qrSelectSurah(_qrState.surahNum + 1); }
function qpPrevSurah() { qrPrevSurah(); }
function qpNextSurah() { qrNextSurah(); }
function qpBackToList() { qrCloseReader(); }

// ── Juz quick-jump ───────────────────────────────────────────
// First surah of each Juz (approximate)
const JUZ_START = {1:1,2:2,3:3,4:4,5:5,6:6,7:7,8:8,9:9,10:10,11:11,12:12,13:13,14:15,15:17,16:18,17:21,18:23,19:25,20:27,21:29,22:33,23:36,24:39,25:41,26:46,27:51,28:58,29:67,30:78};
function qrJumpJuz(juzNum) {
  const surahNum = JUZ_START[juzNum];
  if(!surahNum) return;
  // Scroll the surah list to that surah
  const list = document.getElementById('qp-list');
  if(!list) return;
  const rows = list.querySelectorAll('.qr-surah-row');
  const targetRow = rows[surahNum - 1];
  if(targetRow) targetRow.scrollIntoView({ behavior:'smooth', block:'start' });
  showToast('Juz ' + juzNum + ' — ' + (SURAHS.find(x=>x.n===surahNum)?.en||''));
}

function qrResetAllProgress() {
  if(!confirm('Reset all Quran reading progress? This cannot be undone.')) return;
  try { localStorage.removeItem('mrd_qr_prog'); } catch{}
  const list = document.getElementById('qp-list');
  if(list) { list.dataset.built=''; list.innerHTML=''; qpRenderSurahList(); }
  _qrRenderContinueBanner();
  showToast('✓ Progress reset');
}

// ── Mark surah fully complete ────────────────────────────────
function qrMarkSurahComplete() {
  const s = SURAHS.find(x => x.n === _qrState.surahNum);
  if(!s) return;
  _qrSetProgress(s.n, s.v);
  _qrState.activeAyah = s.v;
  _qrUpdateReadProgress();
  showToast('✓ ' + s.en + ' marked complete!');
  // scroll progress bar to 100%
  const bar = document.getElementById('qr-read-prog');
  if(bar) bar.style.width = '100%';
}

// Old toggle compat aliases (in case called anywhere)
function qpToggleAr()       { qrToggleAr(); }
function qpToggleBn()       { qrToggleBn(); }
function qpToggleFontSize() { qrToggleFont(); }

// ── Overall reading stats ────────────────────────────────────
function _qrRenderOverallStats() {
  const el = document.getElementById('qr-overall-stats');
  if(!el) return;
  const prog = _qrGetProgress();
  const entries = Object.entries(prog);
  const started = entries.filter(([,v]) => v > 0).length;
  const completed = entries.filter(([k,v]) => {
    const s = SURAHS.find(x => x.n === parseInt(k));
    return s && v >= s.v;
  }).length;
  const totalAyahs = SURAHS.reduce((a,s) => a + s.v, 0);
  const readAyahs  = entries.reduce((a,[k,v]) => a + Math.min(v, SURAHS.find(x=>x.n===parseInt(k))?.v||0), 0);
  const pct = Math.round(readAyahs / totalAyahs * 100);
  if(started === 0) { el.style.display='none'; return; }
  el.style.display = 'flex';
  const stat = (val, lbl, color) => `<div style="flex:1;text-align:center;padding:10px 6px;border-radius:12px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07)">
    <div style="font-family:'Playfair Display',serif;font-size:1.375rem;font-weight:300;color:${color};line-height:1">${val}</div>
    <div style="font-size:0.4375rem;letter-spacing:.1em;text-transform:uppercase;color:var(--t3);margin-top:3px">${lbl}</div>
  </div>`;
  el.innerHTML =
    stat(started,   'started',   'var(--gold)') +
    stat(completed, 'complete',  'var(--green)') +
    stat(pct+'%',   'of Quran',  'var(--teal)');
}
function _qrUpdateStreakBadge() {
  const el = document.getElementById('qr-streak-badge');
  if(!el) return;
  const prog  = _qrGetProgress();
  const count = Object.values(prog).filter(v => v > 0).length;
  if(count > 0) {
    el.style.display = '';
    el.textContent   = count + ' surah' + (count > 1 ? 's' : '') + ' started';
  } else { el.style.display = 'none'; }
}

// Old _qpState kept as proxy for compat
var _qpState = {
  get surahNum()  { return _qrState.surahNum; },
  set surahNum(v) { _qrState.surahNum = v; },
  get showAr()    { return _qrState.showAr; },
  get showBn()    { return _qrState.showBn; },
  get fontSize()  { return _qrState.fontSize; },
  get loaded()    { return _qrState.loaded; },
  get loading()   { return _qrState.loading; },
};

function loadQPBookmark() { _qrLoad(); }
function saveQPBookmark() { _qrSave(); }
loadQPBookmark();

// ══════════════════════════════════════════════
// FEATURE PAGES — open/close
// ══════════════════════════════════════════════
// _featPageOpening declared at top of script
function openFeatPage(id) {
  if(_featPageOpening) return;
  _featPageOpening = true;
  setTimeout(() => { _featPageOpening = false; }, 500);

  const page = document.getElementById(id);
  if(!page) { _featPageOpening = false; return; }

  // Push current open page onto stack (if any) instead of closing it
  const currentOpen = document.querySelector('.feat-page.open');
  if(currentOpen && currentOpen.id !== id) {
    currentOpen.classList.remove('open');
    _featPageStack.push(currentOpen.id);
  }

  try { history.pushState({feat:id},'',''); } catch(e) {}
  page.classList.add('open');
  document.body.style.overflow = 'hidden';

  // Hide bottom nav + quick-nav pill
  const _nav  = document.getElementById('main-nav');
  const _qnav = document.getElementById('quick-nav');
  if(_nav)  { _nav.style.display = ''; _nav.style.transition  = 'opacity .22s, transform .22s'; _nav.style.opacity  = '0'; _nav.style.transform  = 'translateY(20px)'; _nav.style.pointerEvents  = 'none'; }
  if(_qnav) { _qnav.style.transition = 'opacity .22s, transform .22s'; _qnav.style.opacity = '0'; _qnav.style.transform = 'translateY(12px)'; _qnav.style.pointerEvents = 'none'; }

  // Init content
  const inits = {
    'page-ayah':        () => refreshHomeExtras(),
    'page-sunnah':      () => { renderSunnah(); renderSunnahHijriTip(); },
    'page-activities':  () => { renderDateStrip(); renderViewingBanner(); renderList(); },
    'page-mood':        () => renderMoodCheckin(),
    'page-nafs-coach':  () => renderNafsCoachPage(),
    'page-notes':       () => { if(typeof renderNotes==='function') renderNotes(); },
    'page-dua':         () => { if(typeof renderDuaLibrary==='function') renderDuaLibrary(); },
    'page-qibla':       () => initQibla(),
    'page-asma':        () => renderAsmaGrid(),
    'page-challenge':   () => renderDailyChallenge(),
    'page-achievements':() => { renderAchievements(); updateAchieveBadge(); },
    'page-quran':       () => { qpRenderSurahList(); _qrRenderContinueBanner(); _qrUpdateStreakBadge(); _qrRenderOverallStats(); },
    'page-tasbih':      () => tasbihInit(),
    'page-calendar':    () => renderIslamicCalendar(),
    'page-hadith':      () => renderHadithPage(),
    'page-quiz':        () => renderQuizPage(),
    'page-finance':     () => renderFinancePage(),
    'page-names':       () => renderNamesPage(),
    'page-tafsir':      () => renderTafsirPage(),
    'page-history':     () => renderHistoryPage(),
    'page-news':        () => renderNewsPage(),
  };
  const fn = inits[id];
  if(fn) setTimeout(() => { fn(); try{ window.applySvgEmojiReplacement?.(page); }catch(e){} }, 80);
  else   setTimeout(() => { try{ window.applySvgEmojiReplacement?.(page); }catch(e){} }, 60);
  setTimeout(() => { updateFeatBadges(); try{ window.applySvgEmojiReplacement?.(page); }catch(e){} }, 500);
}

function closeFeatPage(id) {
  const page = document.getElementById(id);
  if(!page) return;
  page.classList.remove('open');

  // If there's a previous page on the stack, go back to it
  const prevId = _featPageStack.pop();
  if(prevId) {
    const prevPage = document.getElementById(prevId);
    if(prevPage) {
      prevPage.classList.add('open');
      document.body.style.overflow = 'hidden';
      return; // nav stays hidden, still inside a page
    }
  }

  // No previous page — fully back to home
  document.body.style.overflow = '';
  const _nav  = document.getElementById('main-nav');
  const _qnav = document.getElementById('quick-nav');
  if(_nav) {
    _nav.style.display       = '';
    _nav.style.transition    = 'opacity .25s, transform .25s cubic-bezier(.22,1,.36,1)';
    _nav.style.opacity       = '1';
    _nav.style.transform     = 'translateY(0)';
    _nav.style.pointerEvents = '';
    setTimeout(() => { if(_nav){ _nav.style.transition=''; _nav.style.opacity=''; _nav.style.transform=''; } }, 300);
  }
  if(_qnav) {
    _qnav.style.transition    = 'opacity .25s, transform .25s cubic-bezier(.22,1,.36,1)';
    _qnav.style.transform     = 'translateY(0)';
    _qnav.style.pointerEvents = '';
    setTimeout(() => { if(_qnav){ _qnav.style.transition=''; _qnav.style.transform=''; } }, 300);
  }
}

// Close on Android back button / browser back
window.addEventListener('popstate', (e) => {
  const open = document.querySelector('.feat-page.open');
  if(open) closeFeatPage(open.id);
});

// Update feat grid badges
function updateFeatBadges() {
  const chBadge = document.getElementById('feat-challenge-badge');
  if(chBadge) { const done = loadChallengeState().done; chBadge.style.display=done?'inline':'none'; chBadge.textContent='✓ Done'; }
  const achBadge = document.getElementById('feat-achieve-badge');
  if(achBadge) { const n=Object.keys(loadAchievements()).length; achBadge.textContent=n+'/15'; }
  const qpBadge = document.getElementById('feat-quran-badge');
  if(qpBadge && _qpState.surahNum) { const s=SURAHS.find(x=>x.n===_qpState.surahNum); if(s){qpBadge.textContent=s.en;qpBadge.style.display='inline';} }
}

// ══════════════════════════════════════════════
// 📿 TASBIH COUNTER
// ══════════════════════════════════════════════
const TASBIH_LIST = [
  { ar:'سُبْحَانَ اللّٰهِ',       en:'Subhanallah',   meaning:'Glory be to Allah',       target:33 },
  { ar:'اَلْحَمْدُ لِلّٰهِ',     en:'Alhamdulillah', meaning:'All praise is due to Allah', target:33 },
  { ar:'اَللّٰهُ اَكْبَرُ',      en:'Allahu Akbar',  meaning:'Allah is the Greatest',    target:34 },
  { ar:'لَآ اِلٰهَ اِلَّا اللّٰهُ', en:'La ilaha illallah', meaning:'There is no god but Allah', target:100 },
  { ar:'اَسْتَغْفِرُ اللّٰهَ',   en:'Astaghfirullah', meaning:'I seek forgiveness from Allah', target:100 },
  { ar:'صَلَّى اللّٰهُ عَلَيْهِ وَسَلَّمَ', en:'Salawat', meaning:'Blessings upon the Prophet ﷺ', target:100 },
];

let _tasbihIdx   = 0;
let _tasbihCount = 0;

function tasbihInit() {
  // Render preset tabs
  const el = document.getElementById('tasbih-presets');
  if(!el) return;
  el.innerHTML = TASBIH_LIST.map((t,i) => `
    <button onclick="tasbihSwitch(${i})" style="padding:6px 14px;border-radius:99px;border:1px solid ${i===_tasbihIdx?'rgba(var(--accent-rgb),.4)':'rgba(255,255,255,.1)'};background:${i===_tasbihIdx?'rgba(var(--accent-rgb),.12)':'rgba(255,255,255,.05)'};color:${i===_tasbihIdx?'var(--gold)':'var(--t2)'};font-family:'Manrope',sans-serif;font-size:0.5rem;letter-spacing:.08em;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:all .2s">
      ${t.en}
    </button>`).join('');
  tasbihRender();
}

function tasbihSwitch(idx) {
  _tasbihIdx   = idx;
  _tasbihCount = 0;
  tasbihInit();
}

function tasbihTap() {
  const t = TASBIH_LIST[_tasbihIdx];
  _tasbihCount++;
  if(_tasbihCount > t.target) _tasbihCount = 0;
  const btn = document.getElementById('tasbih-tap-btn');
  if(btn) { btn.style.transform='scale(.92)'; setTimeout(()=>btn.style.transform='',150); }
  if(_tasbihCount === t.target) {
    showCelebration('Tasbih Complete! 📿', `${t.en} × ${t.target} complete`, '📿');
  }
  tasbihRender();
  // Update feat badge
  const badge = document.getElementById('feat-tasbih-badge');
  if(badge) { badge.textContent = _tasbihCount + '/' + t.target; badge.style.display = 'inline'; }
}

function tasbihReset() { _tasbihCount = 0; tasbihRender(); }
function tasbihNext()  { tasbihSwitch((_tasbihIdx + 1) % TASBIH_LIST.length); }

function tasbihRender() {
  const t = TASBIH_LIST[_tasbihIdx];
  const pct = _tasbihCount / t.target;
  const arc = document.getElementById('tasbih-arc');
  if(arc) arc.style.strokeDashoffset = 534 * (1 - pct);
  const countEl = document.getElementById('tasbih-count');
  if(countEl) countEl.textContent = _tasbihCount;
  const targetEl = document.getElementById('tasbih-target-lbl');
  if(targetEl) targetEl.textContent = '/ ' + t.target;
  const arEl = document.getElementById('tasbih-arabic');
  if(arEl) arEl.textContent = t.ar;
  const meanEl = document.getElementById('tasbih-meaning');
  if(meanEl) meanEl.textContent = t.meaning;
}

// ══════════════════════════════════════════════
// 📅 ISLAMIC CALENDAR
// ══════════════════════════════════════════════
function renderIslamicCalendar() {
  const el = document.getElementById('islamic-calendar-content');
  if(!el) return;

  const today = new Date();
  const hijri = toHijriObj(today);
  const HIJRI_MONTHS = ['Muharram','Safar','Rabi al-Awwal','Rabi al-Thani','Jumada al-Awwal','Jumada al-Thani','Rajab','Sha\'ban','Ramadan','Shawwal','Dhu al-Qi\'dah','Dhu al-Hijjah'];
  const HIJRI_MONTHS_AR = ['محرم','صفر','ربيع الأول','ربيع الثاني','جمادى الأولى','جمادى الثانية','رجب','شعبان','رمضان','شوال','ذو القعدة','ذو الحجة'];

  // Important Islamic dates
  const ISLAMIC_EVENTS = [
    { m:1,  d:1,  name:'Islamic New Year',      ar:'رأس السنة الهجرية' },
    { m:1,  d:10, name:'Ashura',                ar:'يوم عاشوراء' },
    { m:3,  d:12, name:'Mawlid al-Nabi ﷺ',     ar:'المولد النبوي الشريف' },
    { m:7,  d:27, name:'Isra & Mi\'raj',        ar:'الإسراء والمعراج' },
    { m:8,  d:15, name:'Laylat al-Bara\'at',    ar:'ليلة البراءة' },
    { m:9,  d:1,  name:'Ramadan Begins',         ar:'بداية رمضان' },
    { m:9,  d:27, name:'Laylat al-Qadr',        ar:'ليلة القدر' },
    { m:10, d:1,  name:'Eid al-Fitr',           ar:'عيد الفطر' },
    { m:12, d:10, name:'Eid al-Adha',           ar:'عيد الأضحى' },
  ];

  // Find next upcoming event
  const upcoming = ISLAMIC_EVENTS.map(e => {
    let evH = { month: e.m, day: e.d, year: hijri.year };
    if(e.m < hijri.month || (e.m === hijri.month && e.d < hijri.day)) evH.year++;
    const daysLeft = (e.m - hijri.month) * 30 + (e.d - hijri.day);
    return { ...e, daysLeft: daysLeft <= 0 ? daysLeft + 360 : daysLeft };
  }).sort((a,b) => a.daysLeft - b.daysLeft);

  el.innerHTML = `
    <!-- Current Hijri date -->
    <div class="glass" style="border-radius:24px;padding:24px;text-align:center;margin-bottom:16px;position:relative;overflow:hidden">
      <div style="position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,rgba(var(--accent-rgb),.4),transparent)"></div>
      <div style="font-family:'Playfair Display',serif;font-size:3.5rem;font-weight:300;color:var(--gold);line-height:1;margin-bottom:4px">${hijri.day}</div>
      <div style="font-family:'Playfair Display',serif;font-size:1.5rem;color:var(--text);margin-bottom:2px">${HIJRI_MONTHS[hijri.month-1]}</div>
      <div style="font-size:0.875rem;color:var(--t2);margin-bottom:12px">${hijri.year} AH</div>
      <div style="font-family:'Playfair Display',serif;font-size:1.125rem;color:var(--gold);direction:rtl;opacity:.8">${HIJRI_MONTHS_AR[hijri.month-1]} ${hijri.year}</div>
      <div style="margin-top:12px;font-size:0.625rem;color:var(--t3);letter-spacing:.08em">${today.toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'})}</div>
    </div>

    <!-- Upcoming events -->
    <div style="font-size:0.4375rem;letter-spacing:.2em;text-transform:uppercase;color:var(--t3);font-weight:700;margin-bottom:10px;padding:0 4px">Upcoming Islamic Events</div>
    <div style="display:flex;flex-direction:column;gap:8px">
      ${upcoming.slice(0,8).map((e,i) => `
        <div style="border-radius:18px;padding:14px 16px;background:${i===0?'rgba(var(--accent-rgb),.08)':'rgba(255,255,255,.04)'};border:1px solid ${i===0?'rgba(var(--accent-rgb),.25)':'rgba(255,255,255,.07)'};display:flex;align-items:center;gap:12px">
          <div style="width:44px;height:44px;border-radius:12px;background:${i===0?'rgba(var(--accent-rgb),.15)':'rgba(255,255,255,.06)'};border:1px solid ${i===0?'rgba(var(--accent-rgb),.3)':'rgba(255,255,255,.08)'};display:flex;align-items:center;justify-content:center;flex-direction:column;flex-shrink:0">
            <div style="font-family:'Playfair Display',serif;font-size:1rem;color:${i===0?'var(--gold)':'var(--t2)'};font-weight:600">${e.d}</div>
            <div style="font-size:0.35rem;color:var(--t3);letter-spacing:.06em;text-transform:uppercase">${HIJRI_MONTHS[e.m-1].slice(0,3)}</div>
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-size:0.875rem;font-weight:500;color:${i===0?'var(--text)':'var(--t2)'};margin-bottom:2px">${e.name}</div>
            <div style="font-family:'Playfair Display',serif;font-size:0.875rem;color:var(--gold);opacity:.7;direction:rtl;text-align:left">${e.ar}</div>
          </div>
          <div style="flex-shrink:0;text-align:right">
            <div style="font-size:0.625rem;color:${i===0?'var(--gold)':'var(--t3)'};font-weight:${i===0?'600':'400'}">${e.daysLeft === 0 ? 'Today!' : e.daysLeft + 'd'}</div>
          </div>
        </div>`).join('')}
    </div>`;
}

// ══════════════════════════════════════════════
// 💡 HADITH OF THE DAY
// ══════════════════════════════════════════════
const HADITHS = [
  { text: 'The best of you are those who learn the Quran and teach it.', bn: 'তোমাদের মধ্যে সর্বোত্তম সে ব্যক্তি যে কুরআন শিক্ষা করে এবং অপরকে শেখায়।', source: 'Bukhari', arabic: 'خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَعَلَّمَهُ' },
  { text: 'None of you truly believes until he loves for his brother what he loves for himself.', bn: 'তোমাদের মধ্যে কেউ প্রকৃত মুমিন হবে না যতক্ষণ না সে তার ভাইয়ের জন্য তাই পছন্দ করে যা নিজের জন্য পছন্দ করে।', source: 'Bukhari & Muslim', arabic: 'لَا يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لِأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ' },
  { text: 'The strong person is not the one who can overpower others. Rather, the strong person is the one who controls himself when he is angry.', bn: 'শক্তিশালী ব্যক্তি সে নয় যে কুস্তিতে অন্যকে পরাজিত করে। প্রকৃত শক্তিশালী সে যে রাগের সময় নিজেকে সংযত রাখতে পারে।', source: 'Bukhari & Muslim', arabic: 'لَيْسَ الشَّدِيدُ بِالصُّرَعَةِ، إِنَّمَا الشَّدِيدُ الَّذِي يَمْلِكُ نَفْسَهُ عِنْدَ الْغَضَبِ' },
  { text: 'Make things easy and do not make them difficult. Cheer people up and do not drive them away.', bn: 'সহজ করো, কঠিন করো না। সুসংবাদ দাও, বিরক্ত করো না।', source: 'Bukhari', arabic: 'يَسِّرُوا وَلَا تُعَسِّرُوا، وَبَشِّرُوا وَلَا تُنَفِّرُوا' },
  { text: 'Smiling at your brother is an act of charity.', bn: 'তোমার ভাইয়ের প্রতি তোমার হাসি একটি সদকা।', source: 'Tirmidhi', arabic: 'تَبَسُّمُكَ فِي وَجْهِ أَخِيكَ لَكَ صَدَقَةٌ' },
  { text: 'The most beloved deeds to Allah are those done regularly, even if they are small.', bn: 'আল্লাহর কাছে সবচেয়ে প্রিয় আমল হলো যা নিয়মিত করা হয়, যদিও তা অল্প।', source: 'Bukhari & Muslim', arabic: 'أَحَبُّ الأَعْمَالِ إِلَى اللَّهِ أَدْوَمُهَا وَإِنْ قَلَّ' },
  { text: 'Whoever believes in Allah and the Last Day, let him speak good or remain silent.', bn: 'যে ব্যক্তি আল্লাহ ও আখিরাতে বিশ্বাস করে, সে যেন ভালো কথা বলে অথবা চুপ থাকে।', source: 'Bukhari & Muslim', arabic: 'مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الآخِرِ فَلْيَقُلْ خَيْرًا أَوْ لِيَصْمُتْ' },
  { text: 'Take benefit of five before five: your youth before your old age, your health before your sickness, your wealth before your poverty, your free time before you are preoccupied, and your life before your death.', bn: 'পাঁচটি জিনিসকে পাঁচটির আগে গনীমত মনে করো: বার্ধক্যের আগে যৌবন, অসুস্থতার আগে সুস্বাস্থ্য, দারিদ্র্যের আগে সম্পদ, ব্যস্ততার আগে অবসর এবং মৃত্যুর আগে জীবন।', source: 'Hakim', arabic: '' },
  { text: 'The world is a prison for the believer and a paradise for the disbeliever.', bn: 'পৃথিবী মুমিনের জন্য কারাগার এবং কাফেরের জন্য জান্নাত।', source: 'Muslim', arabic: 'الدُّنْيَا سِجْنُ الْمُؤْمِنِ وَجَنَّةُ الْكَافِرِ' },
  { text: 'Be in this world as if you were a stranger or a traveler.', bn: 'দুনিয়ায় এমনভাবে থাকো যেন তুমি একজন অপরিচিত বা পথচারী।', source: 'Bukhari', arabic: 'كُنْ فِي الدُّنْيَا كَأَنَّكَ غَرِيبٌ أَوْ عَابِرُ سَبِيلٍ' },
  { text: 'He who does not thank people, does not thank Allah.', bn: 'যে মানুষের প্রতি কৃতজ্ঞ নয়, সে আল্লাহর প্রতিও কৃতজ্ঞ নয়।', source: 'Abu Dawud', arabic: 'مَنْ لَا يَشْكُرُ النَّاسَ لَا يَشْكُرُ اللَّهَ' },
  { text: 'Verily, with hardship comes ease.', bn: 'নিশ্চয়ই কষ্টের সাথে স্বস্তি আছে।', source: 'Quran 94:6', arabic: 'إِنَّ مَعَ الْعُسْرِ يُسْرًا' },
  { text: 'The seeking of knowledge is obligatory for every Muslim.', bn: 'জ্ঞান অর্জন করা প্রত্যেক মুসলমানের উপর ফরজ।', source: 'Ibn Majah', arabic: 'طَلَبُ الْعِلْمِ فَرِيضَةٌ عَلَى كُلِّ مُسْلِمٍ' },
  { text: 'Allah does not look at your appearance or your possessions; but He looks at your heart and your deeds.', bn: 'আল্লাহ তোমাদের চেহারা ও সম্পদের দিকে তাকান না, বরং তিনি তোমাদের অন্তর ও আমলের দিকে তাকান।', source: 'Muslim', arabic: 'إِنَّ اللَّهَ لَا يَنْظُرُ إِلَى صُوَرِكُمْ وَأَمْوَالِكُمْ وَلَكِنْ يَنْظُرُ إِلَى قُلُوبِكُمْ وَأَعْمَالِكُمْ' },
  { text: 'Feed the hungry, visit the sick, and free the captive.', bn: 'ক্ষুধার্তকে খাওয়াও, অসুস্থকে দেখতে যাও এবং বন্দিকে মুক্ত করো।', source: 'Bukhari', arabic: 'أَطْعِمُوا الْجَائِعَ، وَعُودُوا الْمَرِيضَ، وَفُكُّوا الْعَانِيَ' },
];


// ══════════════════════════════════════════════
// 📚 HADITH LIBRARY ENGINE
// Uses cdn.jsdelivr.net/gh/fawazahmed0/hadith-api
// Sections hardcoded (real chapter names + ranges).
// Each hadith fetched individually by number.
// ══════════════════════════════════════════════

const HD_CDN = 'https://cdn.jsdelivr.net/gh/fawazahmed0/hadith-api@1/editions';

// Edition slugs for English, Arabic and Bengali
const HD_ED = {
  bukhari:  { en:'eng-bukhari',  ar:'ara-bukhari',  bn:'ben-bukhari'  },
  muslim:   { en:'eng-muslim',   ar:'ara-muslim',   bn:'ben-muslim'   },
  abudawud: { en:'eng-abudawud', ar:'ara-abudawud', bn:'ben-abudawud' },
  tirmidhi: { en:'eng-tirmidhi', ar:'ara-tirmidhi', bn:'ben-tirmidhi' },
  nasai:    { en:'eng-nasai',    ar:'ara-nasai',    bn:'ben-nasai'    },
  ibnmajah: { en:'eng-ibnmajah', ar:'ara-ibnmajah', bn:'ben-ibnmajah' },
};

// Hardcoded section metadata: real chapter names + hadith number ranges
// Format: [id, name, start, end]
const HD_SECTIONS_META = {
  bukhari: [
    ['1','Revelation',1,7],['2','Belief',8,58],['3','Knowledge',59,134],
    ['4','Ablutions (Wudu)',135,247],['5','Bathing (Ghusl)',248,293],
    ['6','Menstrual Periods',294,333],['7','Rubbing Hands & Feet with Dust (Tayammum)',334,348],
    ['8','Prayers (Salat)',349,521],['9','Times of the Prayers',522,601],
    ['10','Call to Prayers (Adhaan)',602,675],['11','Friday Prayer',876,941],
    ['12','Fear Prayer',942,948],['13','The Two Festivals (Eids)',949,1001],
    ['14','Witr Prayer',1002,1013],['15','Invoking Allah for Rain (Istisqaa)',1014,1036],
    ['16','Eclipses',1037,1068],['17','Prostration During Recital of Quran',1069,1083],
    ['18','Shortening the Prayers',1083,1118],['19','Prayer at Night (Tahajjud)',1119,1179],
    ['20','Virtues of Prayer at Masjid Makkah & Madinah',1180,1198],
    ['21','Actions while Praying',1199,1239],['22','Forgetfulness in Prayer',1240,1249],
    ['23','Funerals (Al-Janaaiz)',1237,1393],['24','Obligatory Charity Tax (Zakat)',1395,1520],
    ['25','Hajj (Pilgrimage)',1513,1773],['26','Fasting',1892,2000],
    ['27','Praying at Night in Ramadhan (Taraweeh)',2010,2015],
    ['28','Retiring to Mosque for Remembrance of Allah (Itikaf)',2016,2045],
    ['29','Sales and Trade',2062,2239],['30','Loans, Payment of Loans, Freezing of Property',2285,2315],
    ['31','Representation, Authorization, Business by Proxy',2319,2338],
    ['32','Agriculture',2339,2363],['33','Distributing Water',2369,2378],
    ['34','Hiring',2425,2442],['35','Gifts',2565,2622],
    ['36','Witnesses',2640,2680],['37','Peacemaking (Reconciliation)',2693,2709],
    ['38','Conditions',2720,2736],['39','Wills and Testaments (Wasaayaa)',2738,2752],
    ['40','Fighting for the Cause of Allah (Jihaad)',2782,2972],
    ['41','Penalty of Hunting while on Pilgrimage (Muhsar)',1817,1836],
    ['42','Virtues of Madinah',1872,1891],['43','Fasting',1894,2005],
    ['44','Praying Tarawih',2010,2015],['45','Virtues of the Night of Power',2015,2024],
    ['46','Itikaf',2025,2045],['47','Sales',2063,2239],
    ['48','Obligatory Khumus',3114,3136],['49','Beginning of Creation',3215,3315],
    ['50','Prophets',3316,3456],['51','Virtues and Merits of the Prophet (pbuh)',3545,3627],
    ['52','Companions of the Prophet',3628,3800],['53','Merits of Al-Ansaar',3799,3900],
    ['54','Military Expeditions (Al-Maghaazi)',4000,4471],
    ['55','Quran Exegesis',4477,4949],['56','Virtues of the Quran',4959,5048],
    ['57','Wedlock, Marriage (Nikaah)',5063,5229],['58','Divorce',5249,5350],
    ['59','Supporting the Family',5353,5371],['60','Food, Meals',5382,5452],
    ['61','Sacrifice on Occasion of Birth (Aqiqa)',5466,5474],
    ['62','Hunting, Slaughtering',5476,5529],['63','Al-Adha Festival Sacrifice',5545,5566],
    ['64','Drinks',5578,5638],['65','Patients',5640,5678],
    ['66','Medicine',5678,5762],['67','Dress',5785,5855],
    ['68','Good Manners and Form (Al-Adab)',5996,6236],
    ['69','Asking Permission',6228,6290],['70','Invocations',6298,6384],
    ['71','Softening of the Heart (Ar-Riqaq)',6414,6570],
    ['72','Divine Will (Al-Qadar)',6594,6614],['73','Oaths and Vows',6617,6686],
    ['74','Expiation for Unfulfilled Oaths',6700,6718],
    ['75','Laws of Inheritance (Al-Faraaid)',6724,6745],
    ['76','Limits and Punishments set by Allah (Hudood)',6770,6861],
    ['77','Punishment of Disbelievers at War with Allah and His Apostle',6922,6927],
    ['78','Blood Money (Ad-Diyaat)',6900,6921],
    ['79','Dealing with Apostates',6921,6923],
    ['80','Coercion (Al-Ikraah)',6939,6950],
    ['81','Tricks (Al-Hiyal)',6950,6981],
    ['82','Interpretation of Dreams',6983,7047],
    ['83','Afflictions and the End of the World',7059,7135],
    ['84','Judgments (Ahkaam)',7148,7197],
    ['85','Wishes',7227,7238],['86','Accepting Information Given by One Person',7254,7256],
    ['87','Holding Firm to the Quran and Sunnah',7273,7563],
  ],
  muslim: [
    ['1','Faith',1,485],['2','Purification',486,653],['3','Menstruation',654,737],
    ['4','Prayer',738,1230],['5','Prayer - Travellers',1231,1532],
    ['6','Friday Prayer',1895,1945],['7','Prayer in Congregation',1946,2054],
    ['8','Fear Prayer',2055,2064],['9','The Two Eids',2064,2107],
    ['10','Rain Prayer',2069,2080],['11','Eclipses',2107,2136],
    ['12','Funerals',2137,2276],['13','Zakat',2277,2441],
    ['14','Fasting',2394,2578],['15','Itikaf',2635,2641],
    ['16','Pilgrimage',2641,3009],['17','Marriage',3233,3466],
    ['18','Suckling',3701,3766],['19','Divorce',3665,3701],
    ['20','Business Transactions',3762,3859],['21','Inheritance',3917,3923],
    ['22','Bequests',3991,4007],['23','Vows',4225,4260],
    ['24','Oaths',4260,4311],['25','Qasamah, Muharibeen',4370,4412],
    ['26','Punishments',4413,4481],['27','Judicial Decisions',4481,4508],
    ['28','Lost and Found Property',4508,4519],
    ['29','Jihad',4562,4712],['30','Governance',4713,4783],
    ['31','Hunting and Slaughter',4818,4863],
    ['32','Sacrifices',4862,4882],['33','Drinks',4995,5079],
    ['34','Clothes and Adornment',5080,5178],['35','General Behavior',5179,5240],
    ['36','Greetings',5370,5432],['37','Words of Politeness',5432,5468],
    ['38','Poetry',5598,5614],['39','Dreams',5614,5656],
    ['40','Virtues',5783,5974],['41','Companions',5975,6234],
    ['42','Virtue, Enjoining Good Manners',6234,6371],
    ['43','Destiny',6405,6434],['44','Knowledge',6468,6511],
    ['45','Remembrance of Allah',6482,6572],['46','Repentance',6618,6645],
    ['47','Heart-Melting Traditions',6635,6640],
    ['48','Paradise, Its Description',6796,6835],
    ['49','The Characteristics of the Hypocrites',6995,7014],
    ['50','Tribulations and Portents of the Last Hour',6957,7563],
  ],
  abudawud: [
    ['1','Purification (Kitab Al-Taharah)',1,392],
    ['2','Prayer (Kitab Al-Salat)',393,1062],
    ['3','Zakat (Kitab Al-Zakat)',1558,1689],
    ['4','Lost and Found Articles',1700,1722],
    ['5','Fasting (Kitab Al-Siyam)',2302,2411],
    ['6','Pilgrimage (Kitab Al-Manasik Wal-Hajj)',1729,1922],
    ['7','Marriage (Nikah)',2046,2178],
    ['8','Divorce',2173,2301],
    ['9','Buying and Selling (Kitab Al-Buyu)',3462,3518],
    ['10','Wages (Kitab Al-Ijarah)',3519,3542],
    ['11','Tribute, Spoils, and Rulership',2954,3066],
    ['12','Jihad (Kitab Al-Jihad)',2483,2781],
    ['13','Sacrifices (Kitab Al-Dahaya)',2788,2810],
    ['14','Game (Kitab Al-Said)',2845,2874],
    ['15','Wills (Kitab Al-Wasaya)',2862,2871],
    ['16','Inheritance (Kitab Al-Faraid)',2879,2929],
    ['17','Oaths and Vows (Kitab Al-Ayman Wa Al-Nudhur)',3243,3321],
    ['18','Commercial Transactions',3462,3540],
    ['19','Dialects and Readings of the Quran',3991,4003],
    ['20','Hot Baths (Hammam)',4013,4020],
    ['21','Clothing (Kitab Al-Libas)',4015,4109],
    ['22','Combing the Hair (Kitab Al-Tarajjul)',4154,4200],
    ['23','Signet-Rings (Kitab Al-Khatam)',4205,4234],
    ['24','Divination and Omens',4228,4237],
    ['25','Medicine (Kitab Al-Tibb)',3855,3919],
    ['26','Dialects and Readings of the Quran',3988,4003],
    ['27','General Behavior (Kitab Al-Adab)',4800,4989],
    ['28','Sunnah (Kitab Al-Sunnah)',4590,4681],
    ['29','The Office of the Judge (Kitab Al-Aqdiyah)',3576,3598],
    ['30','Knowledge (Kitab Al-Ilm)',3641,3668],
    ['31','Dialects and Readings',3987,4005],
  ],
  tirmidhi: [
    ['1','Purification',1,148],['2','Prayer',149,419],
    ['3','Witr',454,475],['4','Friday Prayer',487,527],
    ['5','The Two Eids',536,556],['6','Traveling',539,569],
    ['7','Zakat',617,662],['8','Fasting',682,776],
    ['9','Hajj',814,975],['10','Funerals',976,1059],
    ['11','Marriage',1072,1179],['12','Suckling',1150,1171],
    ['13','Divorce',1172,1214],['14','Business',1200,1335],
    ['15','Judgements',1321,1390],['16','Blood Money (Diyat)',1381,1426],
    ['17','Prescribed Punishments (Hudood)',1434,1466],
    ['18','Hunting',1468,1508],['19','Sacrifices',1494,1530],
    ['20','Vows and Oaths',1537,1567],['21','Military Expeditions',1545,1592],
    ['22','Virtues of Jihad',1617,1702],['23','Clothing',1718,1803],
    ['24','Food',1841,1877],['25','Drinks',1860,1910],
    ['26','Righteousness and Maintaining Good Relations',1917,2066],
    ['27','Medicine',2038,2086],['28','Inheritance',2092,2117],
    ['29','Wasiyyah (Wills & Testaments)',2118,2127],
    ['30','Wala and Gifts',2128,2137],['31','Qadar (Divine Decree)',2140,2161],
    ['32','Knowledge',2152,2183],['33','Seeking Permission',2690,2712],
    ['34','Manners',2485,2627],['35','Parables',2844,2875],
    ['36','Virtues of the Quran',2898,2926],
    ['37','Recitation',2927,2955],['38','Supplications (Dua)',3370,3521],
    ['39','Virtues of Jihad',3666,3700],['40','Descriptions of Paradise',3728,3769],
    ['41','Descriptions of Jahannam',3814,3856],
    ['42','Faith (Iman)',2613,2660],['43','Knowledge',2649,2685],
    ['44','Zuhd (Asceticism)',2308,2418],
    ['45','Virtues of the Prophet',3594,3650],
    ['46','Virtues of the Quran',3469,3501],
    ['47','Tafsir of the Quran',3062,3251],
    ['48','Permissible and Prohibited',1714,1718],
  ],
  nasai: [
    ['1','The Book of Purification',1,161],
    ['2','The Book of Water',162,202],
    ['3','Menstruation and Istihadah',203,382],
    ['4','Ghusl and Tayammum',383,434],
    ['5','Salah',435,461],['6','Times of Prayer',478,633],
    ['7','Adhan',634,679],['8','Masajid',689,737],
    ['9','Qiblah',738,765],['10','Leadership in Prayer',771,842],
    ['11','Commencement of Prayer',861,913],
    ['12','Adhan and Iqamah',626,681],
    ['13','Prayer (Witr)',1666,1765],
    ['14','Friday Prayer',1373,1443],
    ['15','Prayer in Cases of Fear',1531,1547],
    ['16','The Two Eids',1554,1600],
    ['17','Qiyam Al-Layl (The Night Prayer)',1596,1666],
    ['18','Sujood al-Quran',959,1001],
    ['19','Shortening the Prayer',1439,1534],
    ['20','Prayer When Traveling',1434,1465],
    ['21','The Eclipse Prayer',1463,1501],
    ['22','Seeking Rain (Istisqa)',1503,1530],
    ['23','Funerals',1823,2032],
    ['24','Fasting',2082,2231],['25','Zakat',2374,2519],
    ['26','Hajj',2619,3091],['27','Jihad',3085,3181],
    ['28','Slaughtering',4339,4472],
    ['29','Marriage',3221,3414],['30','Divorce',3388,3549],
    ['31','Horses',3559,3593],['32','Endowments (Waqf)',3591,3604],
    ['33','Wills',3603,3618],
    ['34','Financial Transactions',4432,4550],
    ['35','Oaths',3786,3820],
    ['36','Arbitration',5381,5432],
    ['37','Seeking Refuge with Allah',5441,5530],
    ['38','Drinks',5658,5712],
    ['39','Dress',5045,5148],
    ['40','Adornment',5228,5267],
    ['41','Women',3215,3241],
    ['42','General Behavior',5758,5758],
  ],
  ibnmajah: [
    ['1','Sunnah',1,226],['2','Purification and its Sunnah',268,654],
    ['3','Prayer',655,1083],['4','Adhan and Iqamah',702,793],
    ['5','Masajid and Congregations',734,813],
    ['6','Establishing the Prayer',812,1085],
    ['7','Friday Prayer',1082,1132],
    ['8','Shortening the Prayer',1331,1339],
    ['9','Prayer at Night',1327,1353],
    ['10','Funerals',1484,1636],['11','Fasting',1634,1789],
    ['12','Zakat',1780,1862],['13','Marriage',1846,2044],
    ['14','Divorce',2016,2110],['15','Expiation of Oaths',2107,2124],
    ['16','Business Transactions',2145,2332],
    ['17','Hajj',2873,3086],
    ['18','Jihad',2751,2856],
    ['19','Sacrifices',3121,3172],
    ['20','Slaughtering',3163,3221],
    ['21','Hunting',3204,3234],
    ['22','Food',3277,3370],['23','Drinks',3379,3434],
    ['24','Medicine',3436,3546],
    ['25','Dress',3553,3631],
    ['26','Good Manners',3640,3753],
    ['27','Supplication',3819,3934],
    ['28','Interpretation of Dreams',3906,3924],
    ['29','Tribulations',3953,4084],
    ['30','Asceticism',4099,4341],
  ],
};

// Section-level cache: 'bukhari:1' -> [{n,ar,en,ref,grade}, ...]
const HD_SEC_CACHE = {};

// Per-book section list cache
const HD_BOOK_SECTIONS = {};

function hdBnChapterName(name) {
  if(!name) return '';
  const exact = {
    'Revelation':'ওহী',
    'Belief':'ঈমান',
    'Knowledge':'ইলম',
    'Ablution':'অজু',
    'Bathing':'গোসল',
    'Menstrual Periods':'হায়েজ',
    'Tayammum':'তায়াম্মুম',
    'Prayer':'সালাত',
    'Prayer Times':'সালাতের সময়',
    'Call to Prayer':'আযান',
    'Friday Prayer':'জুমআর সালাত',
    'Fear Prayer':'ভয়কালীন সালাত',
    'Eid Prayers':'ঈদের সালাত',
    'Witr Prayer':'বিতর সালাত',
    'Istisqa Prayer':'ইস্তিসকা সালাত',
    'Eclipses':'গ্রহণ',
    'Prostration During Quran Recital':'তিলাওয়াতের সিজদা',
    'Shortening the Prayer':'সালাত সংক্ষিপ্তকরণ',
    'Night Prayer':'রাতের সালাত',
    'Funerals':'জানাযা',
    'Zakat':'যাকাত',
    'Hajj':'হজ্জ',
    'Umrah':'উমরাহ',
    'Fasting':'সিয়াম',
    'Tarawih':'তারাবীহ',
    'Retiring to a Mosque for Remembrance of Allah (I\'tikaf)':'ইতিকাফ',
    'Sales and Trade':'বেচাকেনা ও ব্যবসা',
    'Business Transactions':'ব্যবসায়িক লেনদেন',
    'Partnership':'অংশীদারিত্ব',
    'Loans, Payment of Loans, Freezing of Property, Bankruptcy':'ঋণ, পরিশোধ, সম্পদ জব্দ ও দেউলিয়াত্ব',
    'Oppressions':'যুলুম',
    'Lost Things Picked up by Someone (Luqata)':'কুড়ানো হারানো বস্তু',
    'Peacemaking':'মীমাংসা',
    'Conditions':'শর্তাবলি',
    'Wills and Testaments':'ওসিয়ত',
    'Jihad':'জিহাদ',
    'Beginning of Creation':'সৃষ্টির সূচনা',
    'Prophets':'নবীগণ',
    'Virtues and Merits of the Prophet (pbuh) and his Companions':'নবী ﷺ ও সাহাবীদের মর্যাদা',
    'Merits of the Ansar':'আনসারদের ফযীলত',
    'Companions of the Prophet':'সাহাবীগণ',
    'Good Manners and Form':'উত্তম আখলাক ও আচরণ',
    'Invocations':'দোআ',
    'To make the Heart Tender (Ar-Riqaq)':'অন্তর কোমল করার বিষয়',
    'Divine Will (Al-Qadar)':'তাকদীর',
    'Oaths and Vows':'কসম ও মানত',
    'Expiation for Unfulfilled Oaths':'ভঙ্গ কসমের কাফফারা',
    'Laws of Inheritance (Al-Faraa\'id)':'উত্তরাধিকার আইন',
    'Limits and Punishments set by Allah (Hudood)':'হুদুদ ও শাস্তি',
    'Blood Money (Ad-Diyat)':'রক্তপণ',
    'Apostates':'মুরতাদ',
    'Under Duress':'জবরদস্তি',
    'Tricks':'কৌশল',
    'Interpretation of Dreams':'স্বপ্নের ব্যাখ্যা',
    'Afflictions and the End of the World':'ফিতনা ও কিয়ামতের আলামত',
    'Judgments':'বিচার-ফয়সালা',
    'Wishes':'কামনা-বাসনা',
    'Accepting Information Given by a Truthful Person':'সত্যবাদীর সংবাদ গ্রহণ',
    'Holding Fast to the Quran and Sunnah':'কুরআন ও সুন্নাহ আঁকড়ে ধরা',
    'Oneness, Uniqueness of Allah (Tawheed)':'তাওহীদ'
  };
  if(exact[name]) return exact[name];
  let s = ' ' + name + ' ';
  const reps = [
    [' of the Prophet ',' নবী ﷺ এর '],[' of Prophet ',' নবী ﷺ এর '],[' Messenger of Allah ',' রাসূলুল্লাহ ﷺ '],[' Allah ',' আল্লাহ '],
    [' Revelation ',' ওহী '],[' Belief ',' ঈমান '],[' Knowledge ',' ইলম '],[' Ablution ',' অজু '],[' Prayer Times ',' সালাতের সময় '],[' Prayer ',' সালাত '],[' Call to Prayer ',' আযান '],
    [' Friday ',' জুমআ '],[' Funeral ',' জানাযা '],[' Funerals ',' জানাযা '],[' Zakat ',' যাকাত '],[' Fasting ',' সিয়াম '],[' Hajj ',' হজ্জ '],[' Umrah ',' উমরাহ '],
    [' Marriage ',' বিবাহ '],[' Divorce ',' তালাক '],[' Breastfeeding ',' দুধপান '],[' Sales ',' বেচাকেনা '],[' Trade ',' ব্যবসা '],[' Loans ',' ঋণ '],[' Oppressions ',' যুলুম '],
    [' Peacemaking ',' মীমাংসা '],[' Conditions ',' শর্তাবলি '],[' Wills ',' ওসিয়ত '],[' Testaments ',' ওসিয়ত '],[' Jihad ',' জিহাদ '],[' Creation ',' সৃষ্টি '],[' Prophets ',' নবীগণ '],
    [' Virtues ',' ফযীলত '],[' Merits ',' মর্যাদা '],[' Companions ',' সাহাবীগণ '],[' Manners ',' আখলাক '],[' Invocations ',' দোআ '],[' Supplications ',' দোআ '],[' Heart ',' অন্তর '],
    [' Tender ',' কোমল '],[' Divine Will ',' তাকদীর '],[' Oaths ',' কসম '],[' Vows ',' মানত '],[' Expiation ',' কাফফারা '],[' Inheritance ',' উত্তরাধিকার '],[' Limits ',' সীমা '],
    [' Punishments ',' শাস্তি '],[' Blood Money ',' রক্তপণ '],[' Apostates ',' মুরতাদ '],[' Tricks ',' কৌশল '],[' Dreams ',' স্বপ্ন '],[' Afflictions ',' ফিতনা '],[' Judgments ',' বিচার-ফয়সালা '],
    [' Wishes ',' কামনা '],[' Tawheed ',' তাওহীদ '],[' Chapter ',' অধ্যায় '],[' Book ',' কিতাব '],[' The ',' '],[' the ',' '],[' and ',' ও ']
  ];
  reps.forEach(([a,b]) => { s = s.replaceAll(a,b); });
  return s.replace(/\s+/g,' ').trim();
}

// Build section list for a book from hardcoded metadata
function hdGetBookSections(bookId) {
  if (HD_BOOK_SECTIONS[bookId]) return HD_BOOK_SECTIONS[bookId];
  const meta = HD_SECTIONS_META[bookId] || [];
  const sections = meta.map(([id, name, start, end]) => ({
    id, name, nameBn: hdBnChapterName(name), count: end - start + 1, start, end
  }));
  HD_BOOK_SECTIONS[bookId] = sections;
  return sections;
}

// Fetch all hadiths in a section range using jsDelivr individual-hadith endpoints
async function hdFetchSection(bookId, sectionId) {
  const cacheKey = bookId + ':' + sectionId;
  if (HD_SEC_CACHE[cacheKey]) return HD_SEC_CACHE[cacheKey];

  const { en: enEd, ar: arEd, bn: bnEd } = HD_ED[bookId];
  const bookName = HD_BOOKS.find(b => b.id === bookId)?.name || bookId;

  const enUrl = `${HD_CDN}/${enEd}/sections/${sectionId}.min.json`;
  const arUrl = `${HD_CDN}/${arEd}/sections/${sectionId}.min.json`;
  const bnUrl = bnEd ? `${HD_CDN}/${bnEd}/sections/${sectionId}.min.json` : null;

  let enHadiths = [], arMap = {}, bnMap = {};
  try {
    const fetches = [fetch(enUrl), fetch(arUrl)];
    if(bnUrl) fetches.push(fetch(bnUrl));
    const [enRes, arRes, bnRes] = await Promise.all(fetches);
    if(enRes.ok) { const d = await enRes.json(); enHadiths = d.hadiths || []; }
    if(arRes.ok) { const d = await arRes.json(); (d.hadiths||[]).forEach(h=>{ arMap[h.hadithnumber]=h.text||''; }); }
    if(bnRes&&bnRes.ok) { const d = await bnRes.json(); (d.hadiths||[]).forEach(h=>{ bnMap[h.hadithnumber]=h.text||''; }); }
  } catch(e) {
    console.warn('hdFetchSection error', bookId, sectionId, e);
  }

  const result = enHadiths.map(h => ({
    n:     h.hadithnumber,
    ar:    arMap[h.hadithnumber] || '',
    en:    h.text || '',
    bn:    bnMap[h.hadithnumber] || '',
    ref:   bookName + ' ' + h.hadithnumber,
    grade: (h.grades && h.grades[0]) ? h.grades[0].grade : 'Sahih',
  })).filter(h => h.en);

  HD_SEC_CACHE[cacheKey] = result;
  return result;
}

// Book UI metadata
const HD_BOOKS = [
  { id:'bukhari',  name:'Sahih al-Bukhari',  nameBn:'সহীহ আল-বুখারী',  icon:'📙', color:'rgba(var(--accent-rgb),.18)',  border:'rgba(var(--accent-rgb),.3)',  hadithCount:7563, chapters:[] },
  { id:'muslim',   name:'Sahih Muslim',       nameBn:'সহীহ মুসলিম',     icon:'📗', color:'rgba(var(--green-rgb),.14)',  border:'rgba(var(--green-rgb),.28)', hadithCount:7563, chapters:[] },
  { id:'abudawud', name:'Abu Dawud',           nameBn:'আবু দাউদ',         icon:'📘', color:'rgba(var(--teal-rgb),.13)',  border:'rgba(var(--teal-rgb),.26)', hadithCount:5274, chapters:[] },
  { id:'tirmidhi', name:'Jami al-Tirmidhi',   nameBn:'জামে তিরমিযী',    icon:'📕', color:'rgba(var(--rose-rgb),.13)', border:'rgba(var(--rose-rgb),.26)',hadithCount:3956, chapters:[] },
  { id:'nasai',    name:"Sunan an-Nasa'i",     nameBn:'নাসাঈ',            icon:'📓', color:'rgba(var(--purple-rgb),.13)', border:'rgba(var(--purple-rgb),.26)',hadithCount:5758, chapters:[] },
  { id:'ibnmajah', name:'Sunan Ibn Majah',     nameBn:'ইবনে মাজাহ',      icon:'📒', color:'rgba(var(--amber-rgb),.13)',  border:'rgba(var(--amber-rgb),.26)', hadithCount:4341, chapters:[] },
];

// ── State ──
let _hd = {
  lang: 'en',      // 'en' | 'bn'
  fontSize: 1,     // 0=sm, 1=md, 2=lg
  layout: 'v',     // 'v'=vertical scroll | 'h'=horizontal swipe cards
  theme: 'plain',  // 'plain' | 'parchment' | 'night' | 'rose'
  showArabic: true,
  showReflection: true,
  showGrade: true,
  view: 'home',
  activeBook: null,
  activeChapter: null,
  rdrHadiths: [],
  rdrIdx: 0,
  rdrBookId: '',
  rdrChapterId: '',
  filterBook: 'all',
  saved: {},
  readCount: 0,
};
const HD_SIZES = [0.8125, 0.9375, 1.0625];

function hdLoad() {
  try { const s = localStorage.getItem('mrd_hd'); if(s) Object.assign(_hd, JSON.parse(s)); } catch{}
}
function hdSave() {
  try { localStorage.setItem('mrd_hd', JSON.stringify({lang:_hd.lang,fontSize:_hd.fontSize,layout:_hd.layout,theme:_hd.theme,showArabic:_hd.showArabic,showReflection:_hd.showReflection,showGrade:_hd.showGrade,saved:_hd.saved,readCount:_hd.readCount,lastBook:_hd.rdrBookId,lastChap:_hd.rdrChapterId,lastIdx:_hd.rdrIdx})); } catch{}
}

// ── Entry points ──
function renderHadithPage() { hdLoad(); hdInitPage(); }

function hdClose() { closeFeatPage('page-hadith'); }

function hdInitPage() {
  // Daily hadith
  const idx = parseInt(dateKey(now).replace(/-/g,'')) % HADITHS.length;
  const h = HADITHS[idx];
  const dn = document.getElementById('hd-daily-date');
  const dar = document.getElementById('hd-daily-ar');
  const dtext = document.getElementById('hd-daily-text');
  const dsrc = document.getElementById('hd-daily-source');
  if(dn) dn.textContent = new Date().toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'});
  if(dar) dar.textContent = h.arabic || '';
  if(dtext) dtext.textContent = '"' + (_hd.lang==='bn' ? (h.bn||h.text) : h.text) + '"';
  if(dsrc) dsrc.textContent = '— ' + h.source;

  // Quick books grid
  hdRenderQuickBooks();

  // Continue reading
  hdRenderContinue();

  // Stats
  const ss = document.getElementById('hd-stat-saved');
  const sr = document.getElementById('hd-stat-read');
  const sst = document.getElementById('hd-stat-streak');
  if(ss) ss.textContent = Object.keys(_hd.saved||{}).length;
  if(sr) sr.textContent = _hd.readCount||0;
  if(sst) sst.textContent = 1; // could calc streak

  // Apply lang toggle state
  hdApplyLang();

  hdShowView(_hd.view || 'home');
}

function hdRenderQuickBooks() {
  const el = document.getElementById('hd-quick-books');
  if(!el) return;
  el.innerHTML = HD_BOOKS.map(b => `
    <div class="hd-quick-book" onclick="hdSelectBook('${b.id}')" style="border-color:${b.border};background:${b.color};padding:16px 12px">
      <div style="width:48px;height:48px;margin:0 auto 10px;border-radius:15px;display:grid;place-items:center;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04);color:var(--text)">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M7 4.75h7.2c1.78 0 2.67 0 3.28.35.53.3.97.74 1.27 1.27.35.61.35 1.5.35 3.28v8.4c0 .9 0 1.35-.19 1.67a1.5 1.5 0 0 1-.59.59c-.32.19-.77.19-1.67.19H7.75c-1.6 0-2.4 0-3.01-.31a2.75 2.75 0 0 1-1.2-1.2c-.31-.61-.31-1.41-.31-3.01V8.25c0-1.6 0-2.4.31-3.01.27-.53.67-.93 1.2-1.2.61-.29 1.41-.29 3.01-.29Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/>
          <path d="M8.5 9h6.5M8.5 12.25h6.5M8.5 15.5h4.25" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>
        </svg>
      </div>
      <div style="font-size:0.5625rem;color:var(--text);font-weight:600;letter-spacing:.02em;line-height:1.35">${_hd.lang==='bn'?b.nameBn:b.name}</div>
      <div style="font-size:0.4375rem;color:var(--t3);margin-top:4px">${b.hadithCount.toLocaleString()} hadiths</div>
    </div>`).join('');
}

function hdRenderContinue() {
  const wrap = document.getElementById('hd-continue-wrap');
  const ttl = document.getElementById('hd-continue-title');
  const sub = document.getElementById('hd-continue-sub');
  if(!wrap||!ttl||!sub) return;
  const b = HD_BOOKS.find(x=>x.id===_hd.lastBook);
  if(!b||!_hd.lastChap) { wrap.style.display='none'; return; }
  const sections = hdGetBookSections(_hd.lastBook) || [];
  const sec = sections.find(s=>s.id===_hd.lastChap);
  wrap.style.display = 'block';
  ttl.textContent = (_hd.lang==='bn'?b.nameBn:b.name) + ' — ' + (sec?(_hd.lang==='bn' ? (sec.nameBn||sec.name) : sec.name):(_hd.lang==='bn' ? ('অধ্যায় '+_hd.lastChap) : ('Section '+_hd.lastChap)));
  sub.textContent = 'Hadith '+((_hd.lastIdx||0)+1);
}

function hdApplyLang() {
  const knob = document.getElementById('hd-lang-knob');
  const lbl = document.getElementById('hd-lang-label');
  if(knob) knob.style.transform = _hd.lang==='bn' ? 'translateX(18px)' : 'translateX(0)';
  if(lbl) lbl.textContent = _hd.lang==='bn' ? 'বাং' : 'EN';
}

function hdToggleLang() {
  _hd.lang = _hd.lang==='en' ? 'bn' : 'en';
  hdSave();
  Object.keys(HD_SEC_CACHE).forEach(k => delete HD_SEC_CACHE[k]);
  hdInitPage();
  const rdr = document.getElementById('hd-reader');
  if(rdr?.dataset.open) hdRdrRender();
}

function hdCycleFont() {
  _hd.fontSize = (_hd.fontSize+1) % 3;
  hdSave();
  if(document.getElementById('hd-reader')?.dataset.open) hdRdrRender();
}

// ── Settings panel ──
function hdOpenSettings() {
  const p = document.getElementById('hd-settings-panel');
  if(!p) return;
  // Sync button states
  [0,1,2].forEach(i => document.getElementById('hd-fs-'+i)?.classList.toggle('active', i===(_hd.fontSize||1)));
  ['v','h'].forEach(l => document.getElementById('hd-lay-'+l)?.classList.toggle('active', l===(_hd.layout||'v')));
  ['plain','parchment','night','rose'].forEach(t => document.getElementById('hd-th-'+t)?.classList.toggle('active', t===(_hd.theme||'plain')));
  document.getElementById('hd-show-arabic')?.classList.toggle('active', _hd.showArabic!==false);
  document.getElementById('hd-show-reflection')?.classList.toggle('active', _hd.showReflection!==false);
  document.getElementById('hd-show-grade')?.classList.toggle('active', _hd.showGrade!==false);
  p.classList.add('open');
}
function hdCloseSettings(e) {
  if(e && e.target !== document.getElementById('hd-settings-panel')) return;
  document.getElementById('hd-settings-panel')?.classList.remove('open');
}
function hdSetFont(n) {
  _hd.fontSize = n; hdSave();
  [0,1,2].forEach(i => document.getElementById('hd-fs-'+i)?.classList.toggle('active', i===n));
  hdRdrRender();
}
function hdSetLayout(l) {
  _hd.layout = l; hdSave();
  ['v','h'].forEach(x => document.getElementById('hd-lay-'+x)?.classList.toggle('active', x===l));
  hdRdrRender();
}
function hdSetTheme(t) {
  _hd.theme = t; hdSave();
  ['plain','parchment','night','rose'].forEach(x => document.getElementById('hd-th-'+x)?.classList.toggle('active', x===t));
  hdRdrRender();
}
function hdToggleShow(key) {
  const map = {arabic:'showArabic', reflection:'showReflection', grade:'showGrade'};
  const field = map[key];
  if(!field) return;
  _hd[field] = !(_hd[field]!==false);
  hdSave();
  document.getElementById('hd-show-'+key)?.classList.toggle('active', _hd[field]);
  hdRdrRender();
}

// ── Open reader ──
function hdOpenReader() {
  const rdr = document.getElementById('hd-reader');
  if(rdr) { rdr.style.transform='translateX(0)'; rdr.dataset.open='1'; }
  setTimeout(()=>{
    const body = document.getElementById('hd-rdr-body');
    if(body && window._hdSwipeStart) {
      body.removeEventListener('touchstart', window._hdSwipeStart);
      body.removeEventListener('touchend',   window._hdSwipeEnd);
      body.addEventListener('touchstart', window._hdSwipeStart, {passive:true});
      body.addEventListener('touchend',   window._hdSwipeEnd,   {passive:true});
    }
  }, 50);
}

// ── Close reader ──
function hdCloseReader() {
  const rdr = document.getElementById('hd-reader');
  if(rdr) { rdr.style.transform='translateX(100%)'; delete rdr.dataset.open; }
  document.getElementById('hd-settings-panel')?.classList.remove('open');
  hdSave();
}

// ── Render hadith card HTML ──
function hdCardHTML(h, isSaved) {
  const fs = HD_SIZES[_hd.fontSize!=null?_hd.fontSize:1];
  const theme = _hd.theme || 'plain';
  const showAr = _hd.showArabic !== false;
  const showRef = _hd.showGrade !== false;
  const showRefl = _hd.showReflection !== false;
  const isbn = _hd.lang === 'bn';
  return `
    <div class="hd-hadith-card theme-${theme}${isSaved?' saved':''}" style="margin:14px">
      ${showAr ? `<div class="hd-ar" style="font-size:${fs*1.5}rem;margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid rgba(var(--accent-rgb),.12)">${h.ar||''}</div>` : ''}
      ${isbn ? `
        <div style="font-size:0.4375rem;letter-spacing:.18em;text-transform:uppercase;color:var(--teal);margin-bottom:8px;font-weight:700">বাংলা অনুবাদ</div>
        <div class="hd-bn" style="font-size:${fs}rem;margin-bottom:16px">${h.bn||h.en}</div>
        <div style="font-size:0.4375rem;letter-spacing:.18em;text-transform:uppercase;color:var(--t3);margin-bottom:8px;font-weight:700">English</div>
        <div class="hd-tr" style="font-size:${fs*.9}rem;font-style:italic;color:var(--t2);margin-bottom:16px">${h.en}</div>
      ` : `
        <div style="font-size:0.4375rem;letter-spacing:.18em;text-transform:uppercase;color:var(--teal);margin-bottom:8px;font-weight:700">Translation</div>
        <div class="hd-tr" style="font-size:${fs}rem;font-style:italic;margin-bottom:16px">${h.en}</div>
      `}
      ${showRef ? `
      <div style="display:flex;align-items:center;justify-content:space-between;padding-top:12px;border-top:1px solid rgba(255,255,255,.06)">
        <div>
          <div style="font-size:0.5rem;letter-spacing:.12em;text-transform:uppercase;color:var(--gold);margin-bottom:2px">${h.ref||''}</div>
          <div style="font-size:0.5rem;letter-spacing:.08em;text-transform:uppercase;color:${h.grade==='Sahih'?'var(--green)':'var(--amber)'}">✦ ${h.grade||'Sahih'}</div>
        </div>
        <div style="font-family:'Playfair Display',serif;font-size:1.5rem;color:var(--t4)">${h.n||''}</div>
      </div>` : ''}
    </div>
    ${showRefl ? `
    <div style="margin:0 14px 14px;padding:16px;border-radius:16px;background:rgba(var(--purple-rgb),.05);border:1px solid rgba(var(--purple-rgb),.12)">
      <div style="font-size:0.4375rem;letter-spacing:.16em;text-transform:uppercase;color:var(--purple);margin-bottom:8px">💭 ${isbn?'আজকের চিন্তা':'Reflection'}</div>
      <div style="font-size:${fs*.85}rem;color:var(--t2);line-height:1.7">${isbn?'এই হাদিসটি আপনার জীবনে কীভাবে প্রয়োগ করতে পারেন?':'How can you apply this hadith in your life today? Take a moment to reflect and set an intention.'}</div>
    </div>` : ''}`;
}

// ── Main render ──
function hdRdrRender() {
  const hadiths = _hd.rdrHadiths;
  const idx = _hd.rdrIdx;
  if(!hadiths||!hadiths.length) return;
  const h = hadiths[idx];
  if(!h) return;

  // Progress
  const prog = document.getElementById('hd-rdr-prog');
  if(prog) prog.style.width = (((idx+1)/hadiths.length)*100)+'%';

  // Counter
  const ctr = document.getElementById('hd-rdr-counter');
  if(ctr) ctr.textContent = (idx+1)+' / '+hadiths.length;

  // Nav button opacity
  const prev = document.getElementById('hd-rdr-prev');
  const next = document.getElementById('hd-rdr-next');
  if(prev) prev.style.opacity = idx===0?'0.3':'1';
  if(next) next.style.opacity = idx===hadiths.length-1?'0.3':'1';

  // Save button
  const saveBtn = document.getElementById('hd-rdr-save-btn');
  const saveKey = _hd.rdrBookId+':'+_hd.rdrChapterId+':'+idx;
  const isSaved = !!(_hd.saved||{})[saveKey];
  if(saveBtn) saveBtn.textContent = isSaved ? '🤎' : '🤍';

  const body = document.getElementById('hd-rdr-body');
  if(!body) return;

  // Track read count
  if(!(_hd._readSet||{})[saveKey]) {
    _hd._readSet = _hd._readSet||{};
    _hd._readSet[saveKey] = 1;
    _hd.readCount = (_hd.readCount||0)+1;
  }

  const layout = _hd.layout || 'v';

  if(layout === 'h') {
    // Horizontal swipe-card mode — render prev/current/next for scroll-snap
    body.className = 'layout-h';
    body.style.cssText = 'flex:1;display:flex;flex-direction:row;overflow-x:auto;overflow-y:hidden;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;touch-action:pan-x;';
    const slides = [];
    hadiths.forEach((hh, i) => {
      const sk = _hd.rdrBookId+':'+_hd.rdrChapterId+':'+i;
      const sv = !!(_hd.saved||{})[sk];
      slides.push(`<div class="hd-rdr-slide" style="flex:0 0 100%;scroll-snap-align:start;overflow-y:auto;height:100%;padding:0 0 8px;" data-idx="${i}">${hdCardHTML(hh, sv)}</div>`);
    });
    body.innerHTML = slides.join('');
    // Scroll to current without animation
    requestAnimationFrame(()=>{
      body.scrollLeft = idx * body.offsetWidth;
      // Listen for scroll to update idx
      body.onscroll = hdHorizontalScroll;
    });
  } else {
    // Vertical mode
    body.style.cssText = 'flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:0 0 8px;touch-action:pan-y;';
    body.onscroll = null;
    body.innerHTML = hdCardHTML(h, isSaved);
    body.scrollTop = 0;
  }
}

// Horizontal scroll handler — updates idx as user swipes
function hdHorizontalScroll() {
  const body = document.getElementById('hd-rdr-body');
  if(!body) return;
  const newIdx = Math.round(body.scrollLeft / body.offsetWidth);
  if(newIdx !== _hd.rdrIdx && newIdx >= 0 && newIdx < (_hd.rdrHadiths||[]).length) {
    _hd.rdrIdx = newIdx;
    _hd.lastIdx = newIdx;
    // Update progress + counter + nav
    const hadiths = _hd.rdrHadiths;
    const prog = document.getElementById('hd-rdr-prog');
    if(prog) prog.style.width = (((newIdx+1)/hadiths.length)*100)+'%';
    const ctr = document.getElementById('hd-rdr-counter');
    if(ctr) ctr.textContent = (newIdx+1)+' / '+hadiths.length;
    const prev = document.getElementById('hd-rdr-prev');
    const next = document.getElementById('hd-rdr-next');
    if(prev) prev.style.opacity = newIdx===0?'0.3':'1';
    if(next) next.style.opacity = newIdx===hadiths.length-1?'0.3':'1';
    const saveBtn = document.getElementById('hd-rdr-save-btn');
    const saveKey = _hd.rdrBookId+':'+_hd.rdrChapterId+':'+newIdx;
    if(saveBtn) saveBtn.textContent = !!(_hd.saved||{})[saveKey]?'🤎':'🤍';
  }
}

// ── Navigation ──
function hdRdrPrev() {
  if(!_hd.rdrHadiths||!_hd.rdrHadiths.length) return;
  if(_hd.layout==='h') {
    // In horizontal mode just scroll
    const body = document.getElementById('hd-rdr-body');
    if(body && _hd.rdrIdx>0) { _hd.rdrIdx--; body.scrollLeft = _hd.rdrIdx * body.offsetWidth; }
    return;
  }
  if(_hd.rdrIdx>0){ _hd.rdrIdx--; _hd.lastIdx=_hd.rdrIdx; hdRdrAnimate('right'); }
}
function hdRdrNext() {
  if(!_hd.rdrHadiths||!_hd.rdrHadiths.length) return;
  if(_hd.layout==='h') {
    const body = document.getElementById('hd-rdr-body');
    if(body && _hd.rdrIdx<_hd.rdrHadiths.length-1) { _hd.rdrIdx++; body.scrollLeft = _hd.rdrIdx * body.offsetWidth; }
    return;
  }
  if(_hd.rdrIdx<_hd.rdrHadiths.length-1){ _hd.rdrIdx++; _hd.lastIdx=_hd.rdrIdx; hdRdrAnimate('left'); }
}

// Slide animation (vertical mode only)
function hdRdrAnimate(dir) {
  const body = document.getElementById('hd-rdr-body');
  if(!body) return;
  body.style.transition = 'transform .2s cubic-bezier(.4,0,.6,1),opacity .16s';
  body.style.transform = dir==='left'?'translateX(-60px)':'translateX(60px)';
  body.style.opacity = '0';
  setTimeout(()=>{
    hdRdrRender();
    body.style.transition = 'none';
    body.style.transform = dir==='left'?'translateX(60px)':'translateX(-60px)';
    body.style.opacity = '0';
    body.scrollTop = 0;
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      body.style.transition = 'transform .28s cubic-bezier(.22,1,.36,1),opacity .22s';
      body.style.transform = 'translateX(0)';
      body.style.opacity = '1';
    }));
  }, 180);
}

// Swipe gesture (vertical mode)
(function(){
  let sx=0,sy=0,st=0;
  function onStart(e){const t=e.touches?.[0]||e;sx=t.clientX;sy=t.clientY;st=Date.now();}
  function onEnd(e){
    if(_hd.layout==='h') return; // horizontal mode handles its own scroll
    const t=e.changedTouches?.[0]||e;
    const dx=t.clientX-sx,dy=t.clientY-sy,dt=Date.now()-st;
    if(dt>400||Math.abs(dx)<40||Math.abs(dy)>Math.abs(dx)*.8) return;
    if(dx<-40) hdRdrNext(); else hdRdrPrev();
  }
  window._hdSwipeStart=onStart; window._hdSwipeEnd=onEnd;
})();

// ── View management ──
function hdShowView(v) {
  _hd.view = v;
  ['home','books','saved','search'].forEach(id => {
    const el = document.getElementById('hd-view-'+id);
    const tab = document.getElementById('hd-tab-'+id);
    if(el) el.style.display = id===v ? '' : 'none';
    if(tab) tab.classList.toggle('active', id===v);
  });
  if(v==='books') hdRenderBooksList();
  if(v==='saved') hdRenderSaved();
  if(v==='search') hdRenderSearch('');
}

// ── Books view ──
function hdRenderBooksList() {
  const el = document.getElementById('hd-books-list');
  if(!el) return;
  el.innerHTML = HD_BOOKS.map(b => `
    <div class="hd-book-card" onclick="hdSelectBook('${b.id}')" style="border-color:${b.border}">
      <div style="width:44px;height:44px;border-radius:12px;background:${b.color};border:1px solid ${b.border};display:flex;align-items:center;justify-content:center;font-size:1.375rem;flex-shrink:0">${b.icon}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:0.875rem;color:var(--text);font-weight:500">${_hd.lang==='bn'?b.nameBn:b.name}</div>
        <div style="font-size:0.5625rem;color:var(--t3);margin-top:2px">${b.hadithCount.toLocaleString()} hadiths</div>
      </div>
      <div style="color:var(--t3);font-size:0.875rem">›</div>
    </div>`).join('');
}

function hdSelectBook(bookId) {
  hdShowView('books');
  const b = HD_BOOKS.find(x=>x.id===bookId);
  if(!b) return;
  _hd.activeBook = bookId;
  document.getElementById('hd-books-list-wrap').style.display='none';
  document.getElementById('hd-chapters-wrap').style.display='';
  const nameEl = document.getElementById('hd-book-name');
  const metaEl = document.getElementById('hd-book-meta');
  if(nameEl) nameEl.textContent = _hd.lang==='bn'?b.nameBn:b.name;
  const cl = document.getElementById('hd-chapters-list');
  if(!cl) return;

  const sections = hdGetBookSections(bookId);
  if(metaEl) metaEl.textContent = _hd.lang==='bn' ? (b.hadithCount.toLocaleString()+' হাদীস · '+sections.length+' অধ্যায়') : (b.hadithCount.toLocaleString()+' hadiths · '+sections.length+' chapters');

  cl.innerHTML = sections.map((sec,i) => `
    <div class="hd-chapter-row" onclick="hdOpenChapter('${bookId}','${sec.id}')">
      <div style="width:28px;height:28px;border-radius:8px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);display:flex;align-items:center;justify-content:center;font-size:0.625rem;color:var(--t3);flex-shrink:0">${i+1}</div>
      <div style="flex:1">
        <div style="font-size:0.8125rem;color:var(--text)">${_hd.lang==='bn'?(sec.nameBn||sec.name):sec.name}</div>
        <div style="font-size:0.5625rem;color:var(--t3);margin-top:1px">${sec.count} hadiths</div>
      </div>
      <div style="color:var(--t3);font-size:0.875rem">›</div>
    </div>`).join('');
}

function hdBackToBooks() {
  document.getElementById('hd-books-list-wrap').style.display='';
  document.getElementById('hd-chapters-wrap').style.display='none';
}

async function hdOpenChapter(bookId, sectionId) {
  const b = HD_BOOKS.find(x=>x.id===bookId);
  if(!b) return;

  _hd.rdrIdx = 0;
  _hd.rdrBookId = bookId;
  _hd.rdrChapterId = sectionId;
  _hd.lastBook = bookId; _hd.lastChap = sectionId; _hd.lastIdx = 0;

  // Get section name for header
  const sections = hdGetBookSections(bookId) || [];
  const sec = sections.find(s=>s.id===sectionId);
  const rdrBook = document.getElementById('hd-rdr-book');
  const rdrChap = document.getElementById('hd-rdr-chapter');
  if(rdrBook) rdrBook.textContent = _hd.lang==='bn'?b.nameBn:b.name;
  if(rdrChap) rdrChap.textContent = sec ? (_hd.lang==='bn' ? (sec.nameBn||sec.name) : sec.name) : (_hd.lang==='bn' ? ('অধ্যায় '+sectionId) : ('Section '+sectionId));

  // Open reader with loading state
  hdOpenReader();
  const body = document.getElementById('hd-rdr-body');
  if(body) body.innerHTML = `<div style="text-align:center;padding:72px 20px;color:var(--t3)">
    <div style="font-size:2.5rem;margin-bottom:14px">📖</div>
    <div style="font-size:0.875rem;margin-bottom:6px">Loading hadiths…</div>
    <div style="font-size:0.6875rem;opacity:.55">Fetching Arabic + English from API</div></div>`;

  const hadiths = await hdFetchSection(bookId, sectionId);
  _hd.rdrHadiths = hadiths;

  if(!hadiths.length) {
    if(body) body.innerHTML = `<div style="text-align:center;padding:72px 20px;color:var(--rose)">
      <div style="font-size:2rem;margin-bottom:12px">⚠️</div>
      <div style="font-size:0.875rem">Failed to load hadiths.<br><span style="opacity:.6;font-size:0.75rem">Check connection and try again.</span></div></div>`;
    return;
  }

  hdRdrRender();
  hdSave();
}

// ── Reader ──
// (hdOpenReader moved above)

// (hdCloseReader moved above)

// (hdRdrRender moved above)

// (hdRdrPrev / hdRdrNext moved above)

function hdRdrToggleSave() {
  const key = _hd.rdrBookId+':'+_hd.rdrChapterId+':'+_hd.rdrIdx;
  const h = _hd.rdrHadiths[_hd.rdrIdx];
  if(!h) return;
  _hd.saved = _hd.saved||{};
  if(_hd.saved[key]) { delete _hd.saved[key]; }
  else { _hd.saved[key] = { ar:h.ar, en:h.en, bn:h.bn, ref:h.ref, grade:h.grade, bookId:_hd.rdrBookId, chapId:_hd.rdrChapterId, idx:_hd.rdrIdx }; }
  hdSave();
  hdRdrRender();
}

function hdRdrCopy() {
  const h = _hd.rdrHadiths[_hd.rdrIdx];
  if(!h) return;
  const txt = h.ar+'\n\n'+(_hd.lang==='bn'?h.bn:h.en)+'\n\n— '+h.ref;
  navigator.clipboard.writeText(txt).catch(()=>{});
  // Toast
  const btn = document.querySelector('#hd-reader button[onclick="hdRdrCopy()"]');
  if(btn){const orig=btn.textContent;btn.textContent='✓';setTimeout(()=>btn.textContent=orig,1200);}
}

function hdRdrShare() {
  const h = _hd.rdrHadiths[_hd.rdrIdx];
  if(!h) return;
  const txt = h.ar+'\n\n'+(_hd.lang==='bn'?h.bn:h.en)+'\n\n— '+h.ref+'\n\nShared from Toukir\'s Flow 📿';
  if(navigator.share) navigator.share({text:txt}).catch(()=>{});
  else { navigator.clipboard.writeText(txt).catch(()=>{}); }
}

// ── Saved view ──
function hdRenderSaved() {
  const el = document.getElementById('hd-saved-list');
  if(!el) return;
  const saved = _hd.saved||{};
  const keys = Object.keys(saved);
  if(!keys.length) {
    el.innerHTML = `<div style="text-align:center;padding:40px 0;color:var(--t3);font-size:0.875rem">No saved hadiths yet.<br><span style="font-size:0.75rem;opacity:.6">Tap 🤍 while reading to save.</span></div>`;
    return;
  }
  el.innerHTML = keys.map(k => {
    const h = saved[k];
    const b = HD_BOOKS.find(x=>x.id===h.bookId);
    return `<div class="hd-hadith-card saved" onclick="hdOpenSaved('${k}')">
      <div style="font-size:0.4375rem;letter-spacing:.16em;text-transform:uppercase;color:var(--gold);margin-bottom:8px">${b?(_hd.lang==='bn'?b.nameBn:b.name):''} · ${h.ref||''}</div>
      <div class="hd-ar" style="font-size:1.125rem;margin-bottom:10px">${h.ar}</div>
      <div style="font-size:0.8125rem;color:var(--t2);line-height:1.6;font-style:italic">${_hd.lang==='bn'?(h.bn||h.en):h.en}</div>
    </div>`;
  }).join('');
}

async function hdOpenSaved(key) {
  const h = (_hd.saved||{})[key];
  if(!h) return;
  const b = HD_BOOKS.find(x=>x.id===h.bookId);
  if(!b) return;
  _hd.rdrBookId = h.bookId;
  _hd.rdrChapterId = h.chapId;
  _hd.rdrIdx = h.idx||0;
  const rdrBook = document.getElementById('hd-rdr-book');
  const rdrChap = document.getElementById('hd-rdr-chapter');
  if(rdrBook) rdrBook.textContent = _hd.lang==='bn'?b.nameBn:b.name;
  // Try to get section name
  const sections = hdGetBookSections(h.bookId) || [];
  const sec = sections.find(s=>s.id===h.chapId);
  if(rdrChap) rdrChap.textContent = sec ? (_hd.lang==='bn' ? (sec.nameBn||sec.name) : sec.name) : (_hd.lang==='bn' ? ('অধ্যায় '+h.chapId) : ('Section '+h.chapId));
  hdOpenReader();
  const body = document.getElementById('hd-rdr-body');
  if(body) body.innerHTML = `<div style="text-align:center;padding:72px 20px;color:var(--t3)"><div style="font-size:2rem;margin-bottom:10px">📖</div><div>Loading…</div></div>`;
  const hadiths = await hdFetchSection(h.bookId, h.chapId);
  _hd.rdrHadiths = hadiths;
  hdRdrRender();
}

// ── Search view ──
// Search works across all cached sections (fetched on demand as user reads)
// For a live search across a specific book, user picks the book filter first

function hdGetCachedHadiths() {
  const results = [];
  for (const [cacheKey, hadiths] of Object.entries(HD_SEC_CACHE)) {
    const [bookId, secId] = cacheKey.split(':');
    const b = HD_BOOKS.find(x=>x.id===bookId);
    if(!b) continue;
    const sections = hdGetBookSections(bookId) || [];
    const sec = sections.find(s=>s.id===secId);
    hadiths.forEach((h,i) => {
      results.push({...h, bookId, bookName:b.name, bookNameBn:b.nameBn, chapId:secId,
        chapName:sec?sec.name:('Section '+secId), chapNameBn:sec?(sec.nameBn||sec.name):('অধ্যায় '+secId), chapIdx:i, bookIcon:b.icon, bookColor:b.color, bookBorder:b.border});
    });
  }
  return results;
}

function hdSetFilter(f, btn) {
  _hd.filterBook = f;
  document.querySelectorAll('.hd-filter-chip').forEach(el=>el.classList.remove('active'));
  if(btn) btn.classList.add('active');
  const inp = document.getElementById('hd-search-input');
  hdSearch(inp?inp.value:'');
}

async function hdSearch(q) {
  const el = document.getElementById('hd-search-results');
  if(!el) return;
  const ql = q.toLowerCase().trim();

  // If no query, show instructions
  if(!ql && (!_hd.filterBook || _hd.filterBook==='all')) {
    el.innerHTML = `<div style="text-align:center;padding:30px 0;color:var(--t3);font-size:0.8125rem">Type to search across loaded sections…<br><span style="font-size:0.6875rem;opacity:.6;margin-top:6px;display:block">Or pick a book below to load & search it</span></div>`;
    return;
  }

  // If a specific book is selected and has a query, fetch all its sections live
  if(ql && _hd.filterBook && _hd.filterBook!=='all') {
    el.innerHTML = `<div style="text-align:center;padding:30px 0;color:var(--t3);font-size:0.8125rem">
      <div style="font-size:1.5rem;margin-bottom:8px">🔍</div>Searching ${HD_BOOKS.find(b=>b.id===_hd.filterBook)?.name||''}…</div>`;

    const sections = await hdGetBookSections(_hd.filterBook);
    // Fetch all sections for this book (they cache, so repeat searches are instant)
    await Promise.all(sections.map(s => hdFetchSection(_hd.filterBook, s.id)));
  }

  const all = hdGetCachedHadiths();
  const filtered = all.filter(h => {
    if(_hd.filterBook && _hd.filterBook!=='all' && h.bookId!==_hd.filterBook) return false;
    if(!ql) return true;
    return h.en.toLowerCase().includes(ql) || h.ar.includes(q) ||
           String(h.n).includes(ql) || (h.ref&&h.ref.toLowerCase().includes(ql));
  });

  if(!filtered.length) {
    el.innerHTML = `<div style="text-align:center;padding:30px 0;color:var(--t3);font-size:0.8125rem">No hadiths found.<br><span style="font-size:0.6875rem;opacity:.6">Try selecting a specific book to search all its hadiths.</span></div>`;
    return;
  }

  el.innerHTML = filtered.slice(0,100).map(h => `
    <div class="hd-hadith-card" onclick="hdOpenSearchResult('${h.bookId}','${h.chapId}',${h.chapIdx})" style="border-color:${h.bookBorder||'rgba(255,255,255,.07)'}">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px">
        <span style="font-size:0.9375rem">${h.bookIcon}</span>
        <span style="font-size:0.4375rem;letter-spacing:.14em;text-transform:uppercase;color:var(--t3)">${_hd.lang==='bn'?h.bookNameBn:h.bookName} · ${_hd.lang==='bn'?(h.chapNameBn||h.chapName):h.chapName}</span>
        ${h.ref?`<span style="font-size:0.4375rem;color:var(--gold);margin-left:auto">${h.ref}</span>`:''}
      </div>
      <div class="hd-ar" style="font-size:1rem;margin-bottom:8px">${h.ar||''}</div>
      <div style="font-size:0.8125rem;color:var(--t2);line-height:1.6;font-style:italic">${h.en}</div>
    </div>`).join('')
  + (filtered.length>100 ? `<div style="text-align:center;padding:14px;color:var(--t3);font-size:0.75rem">${filtered.length-100} more results — refine your search to narrow down.</div>` : '');
}

async function hdOpenSearchResult(bookId, chapId, chapIdx) {
  const b = HD_BOOKS.find(x=>x.id===bookId);
  if(!b) return;
  _hd.rdrIdx = chapIdx;
  _hd.rdrBookId = bookId; _hd.rdrChapterId = chapId;
  const sections = hdGetBookSections(bookId) || [];
  const sec = sections.find(s=>s.id===chapId);
  const rdrBook = document.getElementById('hd-rdr-book');
  const rdrChap = document.getElementById('hd-rdr-chapter');
  if(rdrBook) rdrBook.textContent = _hd.lang==='bn'?b.nameBn:b.name;
  if(rdrChap) rdrChap.textContent = sec ? (_hd.lang==='bn' ? (sec.nameBn||sec.name) : sec.name) : (_hd.lang==='bn' ? ('অধ্যায় '+chapId) : ('Section '+chapId));
  hdOpenReader();
  const body = document.getElementById('hd-rdr-body');
  if(body) body.innerHTML = `<div style="text-align:center;padding:72px 20px;color:var(--t3)"><div style="font-size:2rem;margin-bottom:10px">📖</div><div>Loading…</div></div>`;
  const hadiths = await hdFetchSection(bookId, chapId);
  _hd.rdrHadiths = hadiths;
  hdRdrRender();
}

// ── Daily hadith full view ──
function hdOpenDailyHadith() {
  const idx = parseInt(dateKey(now).replace(/-/g,'')) % HADITHS.length;
  const h = HADITHS[idx];
  _hd.rdrHadiths = [{ n:1, ar:h.arabic||'', en:h.text, bn:h.bn||h.text, ref:h.source, grade:'Sahih' }];
  _hd.rdrIdx = 0; _hd.rdrBookId='daily'; _hd.rdrChapterId='daily';
  const rdrBook = document.getElementById('hd-rdr-book');
  const rdrChap = document.getElementById('hd-rdr-chapter');
  if(rdrBook) rdrBook.textContent = 'Daily Hadith';
  if(rdrChap) rdrChap.textContent = new Date().toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'});
  hdOpenReader(); hdRdrRender();
}

// ── Continue reading ──
async function hdContinueReading() {
  if(!_hd.lastBook || !_hd.lastChap) return;
  await hdOpenChapter(_hd.lastBook, _hd.lastChap);
  _hd.rdrIdx = _hd.lastIdx||0;
  hdRdrRender();
}

function hdRenderSearch(q) { hdSearch(q); }

// Hook into openFeatPage for new features — merged into main openFeatPage above

// Helper: Calculate Quran reading streak (consecutive days with qr progress)
function calcQuranReadingStreak() {
  const prog = (() => { try { return JSON.parse(localStorage.getItem('mrd_qr_prog') || '{}'); } catch { return {}; }})();
  // qr progress keyed by surah number — check daily data for quranPages > 0 instead
  let streak = 0;
  for (let i = 0; i < 365; i++) {
    const d = new Date(now); d.setDate(d.getDate() - i);
    const k = dateKey(d);
    const dayData = daily[k];
    const hasQuran = dayData && (dayData.quranPages > 0 || dayData.quranDone);
    if (hasQuran) streak++;
    else if (i > 0) break; // only break streak after first day
  }
  return streak;
}

function renderStreakRow() {
  const el = document.getElementById('streak-row');
  if (!el) return;
  const pStreak = calcAllFivePrayerStreak();
  const score   = calcDayScore(TODAY_KEY);
  const water   = loadWater(TODAY_KEY);
  const qStreak = calcQuranReadingStreak();

  el.innerHTML = [
    pStreak > 0 ? `<span class="streak-pill" style="background:rgba(var(--accent-rgb),.1);border-color:rgba(var(--accent-rgb),.3);color:var(--gold)">🔥 ${pStreak}d prayer</span>` : '',
    score  > 0  ? `<span class="streak-pill" style="background:rgba(var(--accent-rgb),.1);border-color:rgba(var(--accent-rgb),.3);color:var(--teal)">⭐ ${score}%</span>` : '',
    water  > 0  ? `<span class="streak-pill" style="background:rgba(107,191,181,.08);border-color:rgba(var(--accent-rgb),.25);color:var(--teal)">💧 ${water}/8</span>` : '',
    qStreak > 1 ? `<span class="streak-pill" style="background:rgba(var(--accent-rgb),.08);border-color:rgba(var(--accent-rgb),.25);color:var(--gold)">📖 ${qStreak}d Quran</span>` : '',
  ].filter(Boolean).join('');
}

/* ══════════════════════════════════════════════
   SURAH VIEW — Full 114 Surah Browse & Audio Play
   ══════════════════════════════════════════════ */
const SV_SURAHS = [
  {n:1,ar:'الفاتحة',en:'Al-Fatihah',ayat:7,juz:1,type:'Meccan',meaning:'The Opening'},
  {n:2,ar:'البقرة',en:'Al-Baqarah',ayat:286,juz:1,type:'Medinan',meaning:'The Cow'},
  {n:3,ar:'آل عمران',en:"Ali 'Imran",ayat:200,juz:3,type:'Medinan',meaning:'Family of Imran'},
  {n:4,ar:'النساء',en:"An-Nisa'",ayat:176,juz:4,type:'Medinan',meaning:'The Women'},
  {n:5,ar:'المائدة',en:'Al-Ma\'idah',ayat:120,juz:6,type:'Medinan',meaning:'The Table Spread'},
  {n:6,ar:'الأنعام',en:"Al-An'am",ayat:165,juz:7,type:'Meccan',meaning:'The Cattle'},
  {n:7,ar:'الأعراف',en:"Al-A'raf",ayat:206,juz:8,type:'Meccan',meaning:'The Heights'},
  {n:8,ar:'الأنفال',en:'Al-Anfal',ayat:75,juz:9,type:'Medinan',meaning:'The Spoils of War'},
  {n:9,ar:'التوبة',en:'At-Tawbah',ayat:129,juz:10,type:'Medinan',meaning:'The Repentance'},
  {n:10,ar:'يونس',en:'Yunus',ayat:109,juz:11,type:'Meccan',meaning:'Jonah'},
  {n:11,ar:'هود',en:'Hud',ayat:123,juz:11,type:'Meccan',meaning:'Hud'},
  {n:12,ar:'يوسف',en:'Yusuf',ayat:111,juz:12,type:'Meccan',meaning:'Joseph'},
  {n:13,ar:'الرعد',en:"Ar-Ra'd",ayat:43,juz:13,type:'Medinan',meaning:'The Thunder'},
  {n:14,ar:'إبراهيم',en:'Ibrahim',ayat:52,juz:13,type:'Meccan',meaning:'Abraham'},
  {n:15,ar:'الحجر',en:'Al-Hijr',ayat:99,juz:14,type:'Meccan',meaning:'The Rocky Tract'},
  {n:16,ar:'النحل',en:'An-Nahl',ayat:128,juz:14,type:'Meccan',meaning:'The Bee'},
  {n:17,ar:'الإسراء',en:"Al-Isra'",ayat:111,juz:15,type:'Meccan',meaning:'The Night Journey'},
  {n:18,ar:'الكهف',en:'Al-Kahf',ayat:110,juz:15,type:'Meccan',meaning:'The Cave'},
  {n:19,ar:'مريم',en:'Maryam',ayat:98,juz:16,type:'Meccan',meaning:'Mary'},
  {n:20,ar:'طه',en:'Ta-Ha',ayat:135,juz:16,type:'Meccan',meaning:'Ta-Ha'},
  {n:21,ar:'الأنبياء',en:"Al-Anbiya'",ayat:112,juz:17,type:'Meccan',meaning:'The Prophets'},
  {n:22,ar:'الحج',en:'Al-Hajj',ayat:78,juz:17,type:'Medinan',meaning:'The Pilgrimage'},
  {n:23,ar:'المؤمنون',en:"Al-Mu'minun",ayat:118,juz:18,type:'Meccan',meaning:'The Believers'},
  {n:24,ar:'النور',en:'An-Nur',ayat:64,juz:18,type:'Medinan',meaning:'The Light'},
  {n:25,ar:'الفرقان',en:'Al-Furqan',ayat:77,juz:18,type:'Meccan',meaning:'The Criterion'},
  {n:26,ar:'الشعراء',en:"Ash-Shu'ara'",ayat:227,juz:19,type:'Meccan',meaning:'The Poets'},
  {n:27,ar:'النمل',en:'An-Naml',ayat:93,juz:19,type:'Meccan',meaning:'The Ant'},
  {n:28,ar:'القصص',en:'Al-Qasas',ayat:88,juz:20,type:'Meccan',meaning:'The Stories'},
  {n:29,ar:'العنكبوت',en:"Al-'Ankabut",ayat:69,juz:20,type:'Meccan',meaning:'The Spider'},
  {n:30,ar:'الروم',en:'Ar-Rum',ayat:60,juz:21,type:'Meccan',meaning:'The Romans'},
  {n:31,ar:'لقمان',en:'Luqman',ayat:34,juz:21,type:'Meccan',meaning:'Luqman'},
  {n:32,ar:'السجدة',en:'As-Sajdah',ayat:30,juz:21,type:'Meccan',meaning:'The Prostration'},
  {n:33,ar:'الأحزاب',en:'Al-Ahzab',ayat:73,juz:21,type:'Medinan',meaning:'The Combined Forces'},
  {n:34,ar:'سبأ',en:"Saba'",ayat:54,juz:22,type:'Meccan',meaning:'Sheba'},
  {n:35,ar:'فاطر',en:'Fatir',ayat:45,juz:22,type:'Meccan',meaning:'Originator'},
  {n:36,ar:'يس',en:'Ya-Sin',ayat:83,juz:22,type:'Meccan',meaning:'Ya-Sin'},
  {n:37,ar:'الصافات',en:'As-Saffat',ayat:182,juz:23,type:'Meccan',meaning:'Those who set the Ranks'},
  {n:38,ar:'ص',en:'Sad',ayat:88,juz:23,type:'Meccan',meaning:'The Letter Sad'},
  {n:39,ar:'الزمر',en:'Az-Zumar',ayat:75,juz:23,type:'Meccan',meaning:'The Troops'},
  {n:40,ar:'غافر',en:'Ghafir',ayat:85,juz:24,type:'Meccan',meaning:'The Forgiver'},
  {n:41,ar:'فصلت',en:'Fussilat',ayat:54,juz:24,type:'Meccan',meaning:'Explained in Detail'},
  {n:42,ar:'الشورى',en:'Ash-Shuraa',ayat:53,juz:25,type:'Meccan',meaning:'The Consultation'},
  {n:43,ar:'الزخرف',en:'Az-Zukhruf',ayat:89,juz:25,type:'Meccan',meaning:'The Ornaments of Gold'},
  {n:44,ar:'الدخان',en:'Ad-Dukhan',ayat:59,juz:25,type:'Meccan',meaning:'The Smoke'},
  {n:45,ar:'الجاثية',en:'Al-Jathiyah',ayat:37,juz:25,type:'Meccan',meaning:'The Crouching'},
  {n:46,ar:'الأحقاف',en:"Al-Ahqaf",ayat:35,juz:26,type:'Meccan',meaning:'The Wind-Curved Sandhills'},
  {n:47,ar:'محمد',en:'Muhammad',ayat:38,juz:26,type:'Medinan',meaning:'Muhammad'},
  {n:48,ar:'الفتح',en:'Al-Fath',ayat:29,juz:26,type:'Medinan',meaning:'The Victory'},
  {n:49,ar:'الحجرات',en:'Al-Hujurat',ayat:18,juz:26,type:'Medinan',meaning:'The Rooms'},
  {n:50,ar:'ق',en:'Qaf',ayat:45,juz:26,type:'Meccan',meaning:'The Letter Qaf'},
  {n:51,ar:'الذاريات',en:'Adh-Dhariyat',ayat:60,juz:26,type:'Meccan',meaning:'The Winnowing Winds'},
  {n:52,ar:'الطور',en:'At-Tur',ayat:49,juz:27,type:'Meccan',meaning:'The Mount'},
  {n:53,ar:'النجم',en:'An-Najm',ayat:62,juz:27,type:'Meccan',meaning:'The Star'},
  {n:54,ar:'القمر',en:'Al-Qamar',ayat:55,juz:27,type:'Meccan',meaning:'The Moon'},
  {n:55,ar:'الرحمن',en:'Ar-Rahman',ayat:78,juz:27,type:'Medinan',meaning:'The Beneficent'},
  {n:56,ar:'الواقعة',en:"Al-Waqi'ah",ayat:96,juz:27,type:'Meccan',meaning:'The Inevitable'},
  {n:57,ar:'الحديد',en:'Al-Hadid',ayat:29,juz:27,type:'Medinan',meaning:'The Iron'},
  {n:58,ar:'المجادلة',en:'Al-Mujadila',ayat:22,juz:28,type:'Medinan',meaning:'The Pleading Woman'},
  {n:59,ar:'الحشر',en:'Al-Hashr',ayat:24,juz:28,type:'Medinan',meaning:'The Exile'},
  {n:60,ar:'الممتحنة',en:'Al-Mumtahanah',ayat:13,juz:28,type:'Medinan',meaning:'She that is to be examined'},
  {n:61,ar:'الصف',en:'As-Saf',ayat:14,juz:28,type:'Medinan',meaning:'The Ranks'},
  {n:62,ar:'الجمعة',en:"Al-Jumu'ah",ayat:11,juz:28,type:'Medinan',meaning:'The Congregation'},
  {n:63,ar:'المنافقون',en:'Al-Munafiqun',ayat:11,juz:28,type:'Medinan',meaning:'The Hypocrites'},
  {n:64,ar:'التغابن',en:'At-Taghabun',ayat:18,juz:28,type:'Medinan',meaning:'The Mutual Disillusion'},
  {n:65,ar:'الطلاق',en:'At-Talaq',ayat:12,juz:28,type:'Medinan',meaning:'The Divorce'},
  {n:66,ar:'التحريم',en:'At-Tahrim',ayat:12,juz:28,type:'Medinan',meaning:'The Prohibition'},
  {n:67,ar:'الملك',en:'Al-Mulk',ayat:30,juz:29,type:'Meccan',meaning:'The Sovereignty'},
  {n:68,ar:'القلم',en:'Al-Qalam',ayat:52,juz:29,type:'Meccan',meaning:'The Pen'},
  {n:69,ar:'الحاقة',en:"Al-Haqqah",ayat:52,juz:29,type:'Meccan',meaning:'The Reality'},
  {n:70,ar:'المعارج',en:"Al-Ma'arij",ayat:44,juz:29,type:'Meccan',meaning:'The Ascending Stairways'},
  {n:71,ar:'نوح',en:'Nuh',ayat:28,juz:29,type:'Meccan',meaning:'Noah'},
  {n:72,ar:'الجن',en:'Al-Jinn',ayat:28,juz:29,type:'Meccan',meaning:'The Jinn'},
  {n:73,ar:'المزمل',en:'Al-Muzzammil',ayat:20,juz:29,type:'Meccan',meaning:'The Enshrouded One'},
  {n:74,ar:'المدثر',en:'Al-Muddaththir',ayat:56,juz:29,type:'Meccan',meaning:'The Cloaked One'},
  {n:75,ar:'القيامة',en:'Al-Qiyamah',ayat:40,juz:29,type:'Meccan',meaning:'The Resurrection'},
  {n:76,ar:'الإنسان',en:'Al-Insan',ayat:31,juz:29,type:'Medinan',meaning:'The Human'},
  {n:77,ar:'المرسلات',en:'Al-Mursalat',ayat:50,juz:29,type:'Meccan',meaning:'The Emissaries'},
  {n:78,ar:'النبأ',en:"An-Naba'",ayat:40,juz:30,type:'Meccan',meaning:'The Tidings'},
  {n:79,ar:'النازعات',en:"An-Nazi'at",ayat:46,juz:30,type:'Meccan',meaning:'Those who drag forth'},
  {n:80,ar:'عبس',en:"'Abasa",ayat:42,juz:30,type:'Meccan',meaning:'He Frowned'},
  {n:81,ar:'التكوير',en:'At-Takwir',ayat:29,juz:30,type:'Meccan',meaning:'The Overthrowing'},
  {n:82,ar:'الإنفطار',en:'Al-Infitar',ayat:19,juz:30,type:'Meccan',meaning:'The Cleaving'},
  {n:83,ar:'المطففين',en:'Al-Mutaffifin',ayat:36,juz:30,type:'Meccan',meaning:'The Defrauding'},
  {n:84,ar:'الإنشقاق',en:'Al-Inshiqaq',ayat:25,juz:30,type:'Meccan',meaning:'The Sundering'},
  {n:85,ar:'البروج',en:'Al-Buruj',ayat:22,juz:30,type:'Meccan',meaning:'The Mansions of the Stars'},
  {n:86,ar:'الطارق',en:'At-Tariq',ayat:17,juz:30,type:'Meccan',meaning:'The Morning Star'},
  {n:87,ar:'الأعلى',en:"Al-A'la",ayat:19,juz:30,type:'Meccan',meaning:'The Most High'},
  {n:88,ar:'الغاشية',en:'Al-Ghashiyah',ayat:26,juz:30,type:'Meccan',meaning:'The Overwhelming'},
  {n:89,ar:'الفجر',en:'Al-Fajr',ayat:30,juz:30,type:'Meccan',meaning:'The Dawn'},
  {n:90,ar:'البلد',en:'Al-Balad',ayat:20,juz:30,type:'Meccan',meaning:'The City'},
  {n:91,ar:'الشمس',en:'Ash-Shams',ayat:15,juz:30,type:'Meccan',meaning:'The Sun'},
  {n:92,ar:'الليل',en:'Al-Layl',ayat:21,juz:30,type:'Meccan',meaning:'The Night'},
  {n:93,ar:'الضحى',en:'Ad-Duha',ayat:11,juz:30,type:'Meccan',meaning:'The Morning Hours'},
  {n:94,ar:'الشرح',en:'Ash-Sharh',ayat:8,juz:30,type:'Meccan',meaning:'The Relief'},
  {n:95,ar:'التين',en:'At-Tin',ayat:8,juz:30,type:'Meccan',meaning:'The Fig'},
  {n:96,ar:'العلق',en:"Al-'Alaq",ayat:19,juz:30,type:'Meccan',meaning:'The Clot'},
  {n:97,ar:'القدر',en:'Al-Qadr',ayat:5,juz:30,type:'Meccan',meaning:'The Power'},
  {n:98,ar:'البينة',en:'Al-Bayyinah',ayat:8,juz:30,type:'Medinan',meaning:'The Clear Proof'},
  {n:99,ar:'الزلزلة',en:'Az-Zalzalah',ayat:8,juz:30,type:'Medinan',meaning:'The Earthquake'},
  {n:100,ar:'العاديات',en:"Al-'Adiyat",ayat:11,juz:30,type:'Meccan',meaning:'The Courser'},
  {n:101,ar:'القارعة',en:"Al-Qari'ah",ayat:11,juz:30,type:'Meccan',meaning:'The Calamity'},
  {n:102,ar:'التكاثر',en:'At-Takathur',ayat:8,juz:30,type:'Meccan',meaning:'The Rivalry in World Increase'},
  {n:103,ar:'العصر',en:"Al-'Asr",ayat:3,juz:30,type:'Meccan',meaning:'The Declining Day'},
  {n:104,ar:'الهمزة',en:'Al-Humazah',ayat:9,juz:30,type:'Meccan',meaning:'The Traducer'},
  {n:105,ar:'الفيل',en:'Al-Fil',ayat:5,juz:30,type:'Meccan',meaning:'The Elephant'},
  {n:106,ar:'قريش',en:'Quraysh',ayat:4,juz:30,type:'Meccan',meaning:'Quraysh'},
  {n:107,ar:'الماعون',en:"Al-Ma'un",ayat:7,juz:30,type:'Meccan',meaning:'The Small Kindnesses'},
  {n:108,ar:'الكوثر',en:'Al-Kawthar',ayat:3,juz:30,type:'Meccan',meaning:'The Abundance'},
  {n:109,ar:'الكافرون',en:'Al-Kafirun',ayat:6,juz:30,type:'Meccan',meaning:'The Disbelievers'},
  {n:110,ar:'النصر',en:'An-Nasr',ayat:3,juz:30,type:'Medinan',meaning:'The Divine Support'},
  {n:111,ar:'المسد',en:'Al-Masad',ayat:5,juz:30,type:'Meccan',meaning:'The Palm Fibre'},
  {n:112,ar:'الإخلاص',en:'Al-Ikhlas',ayat:4,juz:30,type:'Meccan',meaning:'The Sincerity'},
  {n:113,ar:'الفلق',en:'Al-Falaq',ayat:5,juz:30,type:'Meccan',meaning:'The Daybreak'},
  {n:114,ar:'الناس',en:'An-Nas',ayat:6,juz:30,type:'Meccan',meaning:'Mankind'},
];

let svReciter = 'ar.alafasy';
let svAudio = null;
let svPlayingNum = null;
let svIsPlaying = false;
let svFilterText = '';
let svFilterJuz = 0;

function svToggleLang(btn) {
  svLang = svLang === 'bn' ? 'en' : 'bn';
  if (btn) btn.textContent = svLang === 'bn' ? 'বাংলা' : 'English';
  if (svrSurahNum) svOpenReader(svrSurahNum);
  showToast(svLang === 'bn' ? 'বাংলা translation on' : 'English translation on');
}

function svSetReciter(val) {
  svReciter = val;
  if (svAudio && svPlayingNum) {
    const wasPaused = svAudio.paused;
    const pos = svAudio.currentTime;
    svAudio.src = svBuildUrl(svPlayingNum);
    if (!wasPaused) { svAudio.currentTime = pos; svAudio.play(); }
  }
}

function svBuildUrl(surahNum) {
  const reciterMap = {
    'ar.alafasy': 'https://everyayah.com/data/Alafasy_128kbps/',
    'ar.abdurrahmaansudais': 'https://everyayah.com/data/Abdurrahmaan_As-Sudais_192kbps/',
    'ar.minshawi': 'https://everyayah.com/data/Minshawy_Murattal_128kbps/',
    'ar.husary': 'https://everyayah.com/data/Husary_128kbps/',
    'ar.shaatree': 'https://everyayah.com/data/Abu_Bakr_Ash-Shaatree_128kbps/',
  };
  const base = reciterMap[svReciter] || reciterMap['ar.alafasy'];
  const s = String(surahNum).padStart(3,'0');
  // Full surah = ayah 000
  return `${base}${s}000.mp3`;
}

function svRenderList() {
  const container = document.getElementById('sv-list');
  if (!container) return;
  const q = svFilterText.trim().toLowerCase();
  let surahs = SV_SURAHS;
  if (svFilterJuz > 0) surahs = surahs.filter(s => s.juz === svFilterJuz);
  if (q) surahs = surahs.filter(s =>
    s.en.toLowerCase().includes(q) ||
    s.ar.includes(q) ||
    String(s.n).includes(q) ||
    s.meaning.toLowerCase().includes(q)
  );

  if (!surahs.length) {
    container.innerHTML = `<div style="text-align:center;color:var(--t3);font-size:0.75rem;padding:48px 0;font-style:italic">No surahs found</div>`;
    return;
  }

  container.innerHTML = surahs.map(s => {
    const typeClass = s.type === 'Meccan' ? 'meccan' : 'medinan';
    return `
    <div class="sv-row" id="sv-row-${s.n}">
      <div class="sv-num-badge">${s.n}</div>
      <div class="sv-row-info" onclick="svOpenReader(${s.n})">
        <div class="sv-row-top">
          <span class="sv-row-en">${s.en}</span>
          <span class="sv-row-ar">${s.ar}</span>
        </div>
        <div class="sv-row-meta">
          <span class="sv-row-meta-txt">${s.ayat} ayahs</span>
          <span class="sv-row-meta-txt" style="opacity:.4">·</span>
          <span class="sv-row-meta-txt">Juz ${s.juz}</span>
          <span class="sv-row-type ${typeClass}">${s.type}</span>
        </div>
      </div>
      <button class="sv-read-btn" onclick="svOpenReader(${s.n})">Read</button>
    </div>`;
  }).join('');
}

function svJumpJuz(juz, btn) {
  svFilterJuz = juz;
  document.querySelectorAll('.sv-juz-pill').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  svRenderList();
}

/* ══ Surah Full Reader (in-page panel) ══ */
let svrSurahNum = null;
let svrAyahs = [];      // [{ar, tr}]
let svLang = 'bn';
let svrAudio = null;
let svrPlayingAyah = null; // 1-based
let svrIsPlaying = false;
let svrTotalAyahs = 0;

// Per-ayah audio URLs (everyayah.com)
function svrAyahUrl(surahNum, ayahNum) {
  const bases = {
    'ar.alafasy': 'https://everyayah.com/data/Alafasy_128kbps/',
    'ar.abdurrahmaansudais': 'https://everyayah.com/data/Abdurrahmaan_As-Sudais_192kbps/',
    'ar.minshawi': 'https://everyayah.com/data/Minshawy_Murattal_128kbps/',
    'ar.husary': 'https://everyayah.com/data/Husary_128kbps/',
    'ar.shaatree': 'https://everyayah.com/data/Abu_Bakr_Ash-Shaatree_128kbps/',
  };
  const base = bases[svReciter] || bases['ar.alafasy'];
  return `${base}${String(surahNum).padStart(3,'0')}${String(ayahNum).padStart(3,'0')}.mp3`;
}

async function svOpenReader(num) {
  svrSurahNum = num;
  const surah = SV_SURAHS.find(s => s.n === num);
  if (!surah) return;

  // Open panel
  const panel = document.getElementById('sv-reader-panel');
  panel.classList.add('open');

  // Set header
  document.getElementById('sv-rdr-title').textContent = `${surah.n}. ${surah.en}`;
  document.getElementById('sv-rdr-sub').textContent = `${surah.ayat} ayahs · ${surah.type} · Juz ${surah.juz}`;
  document.getElementById('sv-rdr-arabic').textContent = surah.ar;

  // Show loading
  const loading = document.getElementById('sv-rdr-loading');
  const ayahsDiv = document.getElementById('sv-rdr-ayahs');
  loading.style.display = 'flex';
  ayahsDiv.innerHTML = '';
  document.getElementById('sv-rdr-prog-fill').style.width = '0%';

  // Fetch ayahs from alquran.cloud API
  try {
    const translationEdition = svLang === 'bn' ? 'bn.bengali' : 'en.asad';
    const res = await fetch(`https://api.alquran.cloud/v1/surah/${num}/editions/quran-uthmani,${translationEdition}`);
    const json = await res.json();
    if (json.code !== 200) throw new Error('API error');
    const arAyahs = json.data[0].ayahs;
    const trAyahs = json.data[1].ayahs;
    svrAyahs = arAyahs.map((a, i) => ({ ar: a.text, tr: trAyahs[i]?.text || '' }));
    svrTotalAyahs = svrAyahs.length;
    const svLangBtn = document.getElementById('sv-lang-toggle');
    if (svLangBtn) svLangBtn.textContent = svLang === 'bn' ? 'বাংলা' : 'English';
    loading.style.display = 'none';
    svrRenderAyahs(surah, num);
  } catch(e) {
    loading.style.display = 'none';
    ayahsDiv.innerHTML = `<div style="text-align:center;padding:40px 20px;color:var(--t3);font-size:0.8125rem;font-style:italic">
      Could not load surah. Please check your connection.<br>
      <button onclick="svOpenReader(${num})" style="margin-top:12px;padding:8px 18px;border-radius:10px;border:1px solid rgba(var(--accent-rgb),.3);background:rgba(var(--accent-rgb),.1);color:var(--gold);font-family:'Manrope',sans-serif;font-size:0.75rem;cursor:pointer">↺ Retry</button>
    </div>`;
  }
}

function svrRenderAyahs(surah, num) {
  const ayahsDiv = document.getElementById('sv-rdr-ayahs');
  const showBismillah = num !== 1 && num !== 9;
  let html = '';
  if (showBismillah) {
    html += `<div class="sv-bismillah">بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ</div>`;
  }
  svrAyahs.forEach((a, i) => {
    const ayahNum = i + 1;
    const isPlay = svrPlayingAyah === ayahNum && svrSurahNum === num;
    html += `
    <div class="sv-ayah-row ${isPlay ? 'playing' : ''}" id="sv-ayah-${ayahNum}" onclick="svrPlayAyah(${ayahNum})">
      <div class="sv-ayah-num-wrap">
        <div class="sv-ayah-num">${ayahNum}</div>
      </div>
      <div class="sv-ayah-ar">${a.ar}</div>
      <div class="sv-ayah-tr">${a.tr}</div>
    </div>`;
  });
  ayahsDiv.innerHTML = html;
}

function svrPlayAyah(ayahNum) {
  if (!svrAyahs.length) return;
  if (svrPlayingAyah === ayahNum) {
    // toggle
    if (svrAudio) {
      if (svrIsPlaying) { svrAudio.pause(); svrIsPlaying = false; }
      else { svrAudio.play(); svrIsPlaying = true; }
    }
    svrUpdateAudioBar();
    svrRefreshPlayingRow();
    return;
  }
  if (svrAudio) { svrAudio.pause(); svrAudio = null; }
  svrPlayingAyah = ayahNum;
  svrIsPlaying = true;
  svrAudio = new Audio(svrAyahUrl(svrSurahNum, ayahNum));
  svrAudio.addEventListener('timeupdate', svrAudioTick);
  svrAudio.addEventListener('ended', () => {
    // auto-advance to next ayah
    if (svrPlayingAyah < svrTotalAyahs) {
      svrPlayAyah(svrPlayingAyah + 1);
    } else {
      svrIsPlaying = false;
      svrUpdateAudioBar();
      svrRefreshPlayingRow();
    }
  });
  svrAudio.play().catch(()=>{});
  svrUpdateAudioBar();
  svrRefreshPlayingRow();
  // Scroll ayah into view
  setTimeout(() => {
    const el = document.getElementById(`sv-ayah-${ayahNum}`);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, 80);
}

function svrAudioTick() {
  if (!svrAudio) return;
  const dur = svrAudio.duration || 0;
  const cur = svrAudio.currentTime || 0;
  const pct = dur ? (cur / dur * 100) : 0;
  const fill = document.getElementById('sv-rdr-seek-fill');
  const thumb = document.getElementById('sv-rdr-seek-thumb');
  const curEl = document.getElementById('sv-rdr-cur');
  const durEl = document.getElementById('sv-rdr-dur');
  if (fill) fill.style.width = pct + '%';
  if (thumb) thumb.style.left = pct + '%';
  if (curEl) curEl.textContent = svFmtTime(cur);
  if (durEl) durEl.textContent = svFmtTime(dur);
}

function svrUpdateAudioBar() {
  const bar = document.getElementById('sv-rdr-audio');
  if (!bar) return;
  if (svrPlayingAyah) {
    bar.style.display = 'block';
    const surah = SV_SURAHS.find(s => s.n === svrSurahNum);
    const nowEl = document.getElementById('sv-rdr-now-lbl');
    const lblEl = document.getElementById('sv-rdr-ayah-lbl');
    const playBtn = document.getElementById('sv-rdr-play-btn');
    if (nowEl && surah) nowEl.textContent = `${surah.en} — ${surah.ar}`;
    if (lblEl) lblEl.textContent = `Ayah ${svrPlayingAyah} of ${svrTotalAyahs}`;
    if (playBtn) playBtn.textContent = svrIsPlaying ? '⏸' : '▶';
  } else {
    bar.style.display = 'none';
  }
}

function svrRefreshPlayingRow() {
  document.querySelectorAll('.sv-ayah-row.playing').forEach(el => el.classList.remove('playing'));
  if (svrPlayingAyah) {
    const el = document.getElementById(`sv-ayah-${svrPlayingAyah}`);
    if (el) el.classList.add('playing');
  }
}

function svRdrTogglePlay() {
  if (!svrAudio && svrPlayingAyah) {
    svrPlayAyah(svrPlayingAyah); return;
  }
  if (!svrAudio && svrTotalAyahs > 0) {
    svrPlayAyah(1); return;
  }
  if (svrAudio) {
    if (svrIsPlaying) { svrAudio.pause(); svrIsPlaying = false; }
    else { svrAudio.play(); svrIsPlaying = true; }
    svrUpdateAudioBar();
    svrRefreshPlayingRow();
  }
}

function svRdrPrevAyah() {
  if (!svrPlayingAyah) { svrPlayAyah(1); return; }
  if (svrPlayingAyah > 1) svrPlayAyah(svrPlayingAyah - 1);
}

function svRdrNextAyah() {
  if (!svrPlayingAyah) { svrPlayAyah(1); return; }
  if (svrPlayingAyah < svrTotalAyahs) svrPlayAyah(svrPlayingAyah + 1);
}

function svRdrStopAudio() {
  if (svrAudio) { svrAudio.pause(); svrAudio = null; }
  svrPlayingAyah = null; svrIsPlaying = false;
  svrUpdateAudioBar();
  document.querySelectorAll('.sv-ayah-row.playing').forEach(el => el.classList.remove('playing'));
}

function svRdrSeek(e, el) {
  if (!svrAudio || !isFinite(svrAudio.duration)) return;
  const rect = el.getBoundingClientRect();
  const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
  svrAudio.currentTime = pct * svrAudio.duration;
}

function svRdrOnScroll() {
  const body = document.getElementById('sv-rdr-body');
  if (!body || !svrTotalAyahs) return;
  const scrollPct = body.scrollTop / (body.scrollHeight - body.clientHeight) * 100;
  const fill = document.getElementById('sv-rdr-prog-fill');
  if (fill) fill.style.width = Math.min(100, scrollPct || 0) + '%';
}

function svCloseReader() {
  const panel = document.getElementById('sv-reader-panel');
  panel.classList.remove('open');
  // Stop audio when closing reader
  svRdrStopAudio();
}

function svPlaySurah(num) {
  // Open the full reader for this surah
  svOpenReader(num);
}

function svAudioTick() {
  if (!svAudio) return;
  const dur = svAudio.duration || 0;
  const cur = svAudio.currentTime || 0;
  const pct = dur ? (cur / dur * 100) : 0;
  const fill = document.getElementById('sv-mini-fill');
  const thumb = document.getElementById('sv-mini-thumb');
  const curEl = document.getElementById('sv-mini-cur');
  const durEl = document.getElementById('sv-mini-dur');
  if (fill) fill.style.width = pct + '%';
  if (thumb) thumb.style.left = pct + '%';
  if (curEl) curEl.textContent = svFmtTime(cur);
  if (durEl) durEl.textContent = svFmtTime(dur);
}

function svFmtTime(s) {
  if (!isFinite(s)) return '0:00';
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2,'0')}`;
}

function svUpdateMiniPlayer() {
  const s = SV_SURAHS.find(x => x.n === svPlayingNum);
  const nameEl = document.getElementById('sv-mini-surah-name');
  const statusEl = document.getElementById('sv-mini-status');
  const playBtn = document.getElementById('sv-mini-play-btn');
  if (nameEl && s) nameEl.textContent = `${s.n}. ${s.en} — ${s.ar}`;
  if (statusEl) statusEl.textContent = svIsPlaying ? 'Now Playing' : 'Paused';
  if (playBtn) playBtn.textContent = svIsPlaying ? '⏸' : '▶';
}

function svMiniTogglePlay() {
  if (!svAudio) return;
  if (svIsPlaying) { svAudio.pause(); svIsPlaying = false; }
  else { svAudio.play(); svIsPlaying = true; }
  svUpdateMiniPlayer();
  svRenderList();
}

function svMiniStop() {
  if (svAudio) { svAudio.pause(); svAudio = null; }
  svPlayingNum = null;
  svIsPlaying = false;
  const mp = document.getElementById('sv-mini-player');
  if (mp) mp.style.display = 'none';
  const badge = document.getElementById('sv-now-playing-badge');
  if (badge) badge.style.display = 'none';
  svRenderList();
}

function svMiniSeek(e, el) {
  if (!svAudio || !isFinite(svAudio.duration)) return;
  const rect = el.getBoundingClientRect();
  const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
  svAudio.currentTime = pct * svAudio.duration;
}

function svFilter(q) {
  svFilterText = q;
  svRenderList();
}

function svJumpJuz(juz) {
  svFilterJuz = juz;
  const btns = document.querySelectorAll('#sv-juz-strip button');
  btns.forEach((b, i) => {
    const isActive = (juz === 0 && i === 0) || (juz > 0 && b.textContent.includes('Juz ' + juz));
    b.style.borderColor = isActive ? 'rgba(var(--accent-rgb),.3)' : 'rgba(255,255,255,.09)';
    b.style.background = isActive ? 'rgba(var(--accent-rgb),.1)' : 'rgba(255,255,255,.04)';
    b.style.color = isActive ? 'var(--gold)' : 'var(--t3)';
  });
  svRenderList();
}

// Init on page open
document.addEventListener('DOMContentLoaded', () => {
  const origFn = window.openFeatPage;
  if (origFn) {
    window.openFeatPage = function(id, ...args) {
      origFn(id, ...args);
      if (id === 'page-surah-view') {
        svRenderList();
      }
    };
  }
});

// ══════════════════════════════════════════════
// ISLAMIC QUIZ — AI-Powered Unlimited Bangla Quiz
// ══════════════════════════════════════════════
const _QUIZ = {
  state: 'home', // home | loading | active | result
  currentQ: null,
  options: [],
  answered: false,
  score: 0,
  total: 0,
  streak: 0,
  maxStreak: 0,
  wrongCount: 0,
  timeLeft: 30,
  timerInterval: null,
  selectedCats: [],
  difficulty: 'মিক্স',
  history: [],
  currentTab: 'quiz',
  sessionScore: 0,
  sessionTotal: 0,
  usedQuestions: new Set(),
  mode: 'unlimited',
  apiEnabled: false,
  apiProvider: 'gemini',
  apiKey: '',
  apiModel: 'gemini-2.0-flash',
  apiLastError: '',
};

const QUIZ_CATS = [
  { id: 'quran',     name: 'কুরআন',        icon: '📖', desc: 'আয়াত, সূরা, তাফসীর' },
  { id: 'hadith',    name: 'হাদিস',         icon: '📜', desc: 'সহিহ হাদিস' },
  { id: 'fiqh',      name: 'ফিকহ',          icon: '⚖️', desc: 'ইসলামী বিধান' },
  { id: 'aqeedah',   name: 'আকিদা',         icon: '🌙', desc: 'বিশ্বাস ও ঈমান' },
  { id: 'seerah',    name: 'সীরাত',         icon: '🕌', desc: 'নবীজির জীবন' },
  { id: 'history',   name: 'ইতিহাস',        icon: '🏛️', desc: 'ইসলামী ইতিহাস' },
  { id: 'dua',       name: 'দুআ ও যিকর',   icon: '🤲', desc: 'দৈনন্দিন দুআ' },
  { id: 'ethics',    name: 'নৈতিকতা',       icon: '💎', desc: 'ইসলামী চরিত্র' },
];

const QUIZ_DIFFS = ['সহজ', 'মাঝারি', 'কঠিন', 'মিক্স'];

function _quizSave() {
  try {
    localStorage.setItem('quizData', JSON.stringify({
      totalScore: _QUIZ.score,
      totalPlayed: _QUIZ.total,
      maxStreak: _QUIZ.maxStreak,
      history: _QUIZ.history.slice(0, 30),
      streak: _QUIZ.streak,
      mode: _QUIZ.mode || 'unlimited',
      apiEnabled: !!_QUIZ.apiEnabled,
      apiProvider: _QUIZ.apiProvider || 'gemini',
      apiKey: _QUIZ.apiKey || '',
      apiModel: _QUIZ.apiModel || 'gemini-2.0-flash',
    }));
  } catch(e) {}
}

function _quizLoad() {
  try {
    const d = JSON.parse(localStorage.getItem('quizData') || '{}');
    _QUIZ.score = d.totalScore || 0;
    _QUIZ.total = d.totalPlayed || 0;
    _QUIZ.maxStreak = d.maxStreak || 0;
    _QUIZ.history = d.history || [];
    _QUIZ.streak = d.streak || 0;
    _QUIZ.mode = d.mode || 'unlimited';
    _QUIZ.apiEnabled = !!d.apiEnabled;
    _QUIZ.apiProvider = d.apiProvider || 'gemini';
    _QUIZ.apiKey = d.apiKey || '';
    _QUIZ.apiModel = d.apiModel || 'gemini-2.0-flash';
  } catch(e) {}
}

function renderQuizPage() {
  _quizLoad();
  _QUIZ.state = 'home';
  _QUIZ.selectedCats = [];
  _QUIZ.difficulty = 'মিক্স';
  _QUIZ.currentTab = 'quiz';
  _quizRenderHome();
  _quizUpdateBadge();
}

function _quizUpdateBadge() {
  const b = document.getElementById('feat-quiz-badge');
  if (!b) return;
  if (_QUIZ.streak >= 3) { b.textContent = '🔥'; b.style.display = 'flex'; }
  else b.style.display = 'none';
}

function _quizRenderHome() {
  const body = document.getElementById('quiz-body');
  if (!body) return;
  const sub = document.getElementById('quiz-hdr-sub');
  if (sub) sub.textContent = 'AI-চালিত অসীম প্রশ্ন';
  const streakEl = document.getElementById('quiz-streak-display');
  if (streakEl) {
    streakEl.style.display = _QUIZ.streak > 0 ? 'flex' : 'none';
    const sv = document.getElementById('quiz-streak-val');
    if (sv) sv.textContent = _QUIZ.streak + ' 🔥';
  }
  const pct = _QUIZ.total > 0 ? Math.round((_QUIZ.score / _QUIZ.total) * 100) : 0;
  const grade = _quizGrade(pct);

  // Tab rendering
  const tabContent = _QUIZ.currentTab === 'history' ? _quizHistoryHTML() : _QUIZ.currentTab === 'stats' ? _quizStatsHTML() : _quizSetupHTML(pct, grade);

  body.innerHTML = `
    <div class="quiz-home">
      <div class="quiz-tabs">
        <button class="quiz-tab ${_QUIZ.currentTab === 'quiz' ? 'active' : ''}" onclick="_quizSetTab('quiz')">কুইজ</button>
        <button class="quiz-tab ${_QUIZ.currentTab === 'history' ? 'active' : ''}" onclick="_quizSetTab('history')">ইতিহাস</button>
        <button class="quiz-tab ${_QUIZ.currentTab === 'stats' ? 'active' : ''}" onclick="_quizSetTab('stats')">পরিসংখ্যান</button>
      </div>
      ${tabContent}
    </div>
  `;
}

function _quizSetTab(tab) {
  _QUIZ.currentTab = tab;
  _quizRenderHome();
}


function _quizApiReady() {
  return _QUIZ.mode === 'api' && !!(_QUIZ.apiEnabled && (_QUIZ.apiKey || '').trim());
}

function _quizSaveApiSettings() {
  const keyEl = document.getElementById('quiz-api-key');
  const modelEl = document.getElementById('quiz-api-model');
  _QUIZ.apiKey = (keyEl?.value || '').trim();
  _QUIZ.apiModel = (modelEl?.value || 'gemini-2.0-flash').trim() || 'gemini-2.0-flash';
  _QUIZ.apiEnabled = !!_QUIZ.apiKey;
  _QUIZ.apiLastError = '';
  _quizSave();
  _quizRenderHome();
  try { if(typeof toast === 'function') toast(_QUIZ.apiEnabled ? 'Quiz API saved' : 'API key removed'); } catch(e) {}
}

function _quizClearApiSettings() {
  _QUIZ.apiKey = '';
  _QUIZ.apiEnabled = false;
  _QUIZ.apiLastError = '';
  _quizSave();
  _quizRenderHome();
}

function _quizExtractJSON(raw) {
  try {
    const t = String(raw || '').trim();
    const fenced = t.match(/```(?:json)?\s*([\s\S]*?)```/i);
    const source = fenced ? fenced[1].trim() : t;
    const first = source.indexOf('{');
    const last = source.lastIndexOf('}');
    if (first === -1 || last === -1 || last <= first) return null;
    return JSON.parse(source.slice(first, last + 1));
  } catch (e) {
    return null;
  }
}

function _quizNormalizeApiQuestion(data) {
  if (!data || typeof data !== 'object') return null;
  const opts = Array.isArray(data.options) ? data.options.map(x => String(x || '').trim()).filter(Boolean) : [];
  let correct = Number(data.correct);
  if (!Number.isInteger(correct) && typeof data.correctAnswer === 'string') {
    correct = opts.findIndex(x => x === data.correctAnswer.trim());
  }
  if (opts.length !== 4 || correct < 0 || correct > 3) return null;
  const picked = _QUIZ.selectedCats[0] || 'general';
  const pickedCat = QUIZ_CATS.find(c => c.id === picked);
  return {
    catId: data.catId || pickedCat?.id || picked,
    category: data.category || pickedCat?.name || 'ইসলাম',
    diff: data.diff || _QUIZ.difficulty || 'মিক্স',
    question: String(data.question || '').trim(),
    options: opts,
    correct,
    explanation: String(data.explanation || '').trim(),
    reference: String(data.reference || '').trim(),
  };
}

async function _quizFetchApiQuestion() {
  if (!_quizApiReady()) {
    _QUIZ.apiLastError = 'API key সেট করা নেই';
    return null;
  }
  const selectedNames = _QUIZ.selectedCats.length
    ? _QUIZ.selectedCats.map(id => QUIZ_CATS.find(c => c.id === id)?.name).filter(Boolean)
    : ['কুরআন','হাদিস','ফিকহ','আকিদা','সীরাত','দুআ ও যিকর','ইসলামী ইতিহাস'];
  const diff = _QUIZ.difficulty === 'মিক্স' ? 'সহজ/মাঝারি/কঠিনের যেকোনো একটি' : _QUIZ.difficulty;
  const prompt = `Generate exactly 1 fresh Islamic multiple-choice quiz question in Bangla.
Return ONLY valid JSON with this exact shape:
{"question":"...","options":["...","...","...","..."],"correct":0,"explanation":"...","reference":"...","category":"...","diff":"..."}

Rules:
- Bangla language only.
- Exactly 4 options.
- Only one correct answer.
- Topic should match one of: ${selectedNames.join(', ')}.
- Difficulty: ${diff}.
- Avoid repeating very common beginner questions if possible.
- Question must be respectful, concise, and educational.
- If citing, keep reference short like "সূরা বাকারা: 255" or "বুখারি: 8".
- correct must be 0,1,2,3 only.
- No markdown, no code fence, no extra text.`;

  try {
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(_QUIZ.apiModel || 'gemini-2.0-flash')}:generateContent?key=${encodeURIComponent(_QUIZ.apiKey)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 1.1,
          responseMimeType: 'application/json'
        }
      })
    });
    if (!res.ok) {
      _QUIZ.apiLastError = `API error ${res.status}`;
      return null;
    }
    const json = await res.json();
    const raw = json?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('\n') || '';
    const parsed = _quizExtractJSON(raw);
    const normalized = _quizNormalizeApiQuestion(parsed);
    if (!normalized || !normalized.question) {
      _QUIZ.apiLastError = 'API response parse করা যায়নি';
      return null;
    }
    _QUIZ.apiLastError = '';
    return normalized;
  } catch (e) {
    _QUIZ.apiLastError = e?.message || 'API request failed';
    return null;
  }
}

function _quizPickLocalQuestion() {
  const catFilter = _QUIZ.selectedCats.length > 0
    ? q => _QUIZ.selectedCats.includes(q.catId)
    : () => true;
  const diffFilter = _QUIZ.difficulty === 'মিক্স'
    ? () => true
    : q => q.diff === _QUIZ.difficulty;

  let pool = _QUIZ_BANK.filter(q => catFilter(q) && diffFilter(q) && !_QUIZ.usedQuestions.has(q.question.slice(0,40)));
  if (pool.length === 0) {
    _QUIZ.usedQuestions.clear();
    pool = _QUIZ_BANK.filter(q => catFilter(q) && diffFilter(q));
  }
  if (pool.length === 0) return null;
  const q = pool[Math.floor(Math.random() * pool.length)];
  _QUIZ.usedQuestions.add(q.question.slice(0, 40));
  return q;
}

function _quizSetupHTML(pct, grade) {
  const catCards = QUIZ_CATS.map(c => `
    <div class="quiz-cat-card ${_QUIZ.selectedCats.includes(c.id) ? 'selected' : ''}" onclick="_quizToggleCat('${c.id}')">
      <div class="quiz-cat-check">✓</div>
      <div class="quiz-cat-icon">${c.icon}</div>
      <div class="quiz-cat-name">${c.name}</div>
      <div class="quiz-cat-count">${c.desc}</div>
    </div>
  `).join('');

  const diffBtns = QUIZ_DIFFS.map(d => `
    <button class="quiz-diff-btn ${_QUIZ.difficulty === d ? 'active' : ''}" onclick="_quizSetDiff('${d}')">${d}</button>
  `).join('');

  const apiPanel = `
    <div style="margin-top:10px;padding:14px;border-radius:18px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.03)">
      <div style="font-size:.72rem;color:var(--t2);line-height:1.6;margin-bottom:10px">
        Gemini API key দিলে প্রতি বার নতুন quiz generate হবে। Key না থাকলে local প্রশ্ন ব্যবহার হবে।
      </div>
      <input id="quiz-api-key" type="password" value="${_QUIZ.apiKey ? _QUIZ.apiKey.replace(/"/g,'&quot;') : ''}" placeholder="Gemini API key paste করুন" style="width:100%;padding:12px 14px;border-radius:14px;border:1px solid rgba(255,255,255,.09);background:rgba(0,0,0,.18);color:var(--text);font-family:'Manrope',sans-serif;font-size:.8rem;outline:none;margin-bottom:8px">
      <input id="quiz-api-model" type="text" value="${(_QUIZ.apiModel || 'gemini-2.0-flash').replace(/"/g,'&quot;')}" placeholder="Model e.g. gemini-2.0-flash" style="width:100%;padding:12px 14px;border-radius:14px;border:1px solid rgba(255,255,255,.09);background:rgba(0,0,0,.18);color:var(--text);font-family:'Manrope',sans-serif;font-size:.8rem;outline:none;margin-bottom:8px">
      ${_QUIZ.apiLastError ? `<div style="font-size:.68rem;color:#ff9f9f;margin-bottom:8px">${_QUIZ.apiLastError}</div>` : ''}
      <div style="display:flex;gap:8px">
        <button type="button" onclick="_quizSaveApiSettings()" style="flex:1;padding:11px 14px;border-radius:14px;border:1px solid rgba(var(--green-rgb),.25);background:rgba(var(--green-rgb),.10);color:var(--green);font-family:'Manrope',sans-serif;font-size:.76rem">API Save</button>
        <button type="button" onclick="_quizClearApiSettings()" style="padding:11px 14px;border-radius:14px;border:1px solid rgba(255,255,255,.1);background:transparent;color:var(--t2);font-family:'Manrope',sans-serif;font-size:.76rem">Clear</button>
      </div>
    </div>`;

  const modeCards = `
    <div style="display:grid;grid-template-columns:1fr;gap:10px;margin-bottom:18px">
      <button type="button" onclick="_quizSetMode('unlimited')" style="text-align:left;padding:14px 16px;border-radius:18px;border:1px solid ${_QUIZ.mode === 'unlimited' ? 'rgba(var(--green-rgb),.32)' : 'rgba(255,255,255,.08)'};background:${_QUIZ.mode === 'unlimited' ? 'rgba(var(--green-rgb),.10)' : 'rgba(255,255,255,.03)'};color:var(--text);font-family:'Manrope',sans-serif">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
          <div>
            <div style="font-size:.82rem;font-weight:700;color:var(--text)">♾️ Unlimited Quiz</div>
            <div style="font-size:.72rem;color:var(--t2);margin-top:4px">যত ইচ্ছা তত প্রশ্ন খেলতে পারবেন। local question bank থেকে চলবে।</div>
          </div>
          <div style="font-size:.7rem;color:${_QUIZ.mode === 'unlimited' ? 'var(--green)' : 'var(--t3)'}">${_QUIZ.mode === 'unlimited' ? 'চালু' : 'নির্বাচন করুন'}</div>
        </div>
      </button>

      <button type="button" onclick="_quizSetMode('api')" style="text-align:left;padding:14px 16px;border-radius:18px;border:1px solid ${_QUIZ.mode === 'api' ? 'rgba(var(--accent-rgb),.32)' : 'rgba(255,255,255,.08)'};background:${_QUIZ.mode === 'api' ? 'rgba(var(--accent-rgb),.10)' : 'rgba(255,255,255,.03)'};color:var(--text);font-family:'Manrope',sans-serif">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
          <div>
            <div style="font-size:.82rem;font-weight:700;color:var(--text)">🌐 API New Quiz</div>
            <div style="font-size:.72rem;color:var(--t2);margin-top:4px">প্রতি বার API দিয়ে fresh Bangla quiz generate হবে।</div>
          </div>
          <div style="font-size:.7rem;color:${_QUIZ.mode === 'api' ? 'var(--gold)' : 'var(--t3)'}">${_QUIZ.mode === 'api' ? (_QUIZ.apiEnabled ? 'API ready' : 'key দরকার') : 'নির্বাচন করুন'}</div>
        </div>
      </button>
      ${_QUIZ.mode === 'api' ? apiPanel : ''}
    </div>`;

  return `
    ${_QUIZ.total > 0 ? `
    <div class="quiz-score-banner">
      <div class="quiz-score-circle">
        <div class="quiz-score-num">${pct}%</div>
        <div class="quiz-score-label">সঠিক</div>
      </div>
      <div class="quiz-score-info">
        <div class="quiz-score-title">${grade.title}</div>
        <div class="quiz-score-sub">মোট ${_QUIZ.total}টি প্রশ্ন • সঠিক ${_QUIZ.score}টি<br>সর্বোচ্চ ধারা: ${_QUIZ.maxStreak} 🔥</div>
      </div>
    </div>` : `
    <div style="padding:16px;border-radius:18px;border:1px solid rgba(var(--green-rgb),.15);background:rgba(var(--green-rgb),.05);margin-bottom:20px;text-align:center">
      <div style="font-size:1.75rem;margin-bottom:6px">🧠</div>
      <div style="font-size:0.875rem;color:var(--text);font-weight:500;margin-bottom:4px">ইসলামিক জ্ঞান যাচাই করুন</div>
      <div style="font-size:0.75rem;color:var(--t2)">AI দিয়ে তৈরি অসীম প্রশ্ন — বাংলায়</div>
    </div>`}

    <div class="quiz-section-title">বিষয় বেছে নিন</div>
    <div class="quiz-cat-grid">${catCards}</div>

    <div class="quiz-section-title">কঠিনতা</div>
    <div class="quiz-difficulty-row">${diffBtns}</div>

    <div class="quiz-section-title">খেলার ধরন</div>
    ${modeCards}

    <button class="quiz-start-btn" onclick="_quizStart()">
      ${_QUIZ.mode === 'unlimited'
        ? (_QUIZ.selectedCats.length === 0 ? '♾️ Unlimited Quiz শুরু করুন' : `♾️ ${_QUIZ.selectedCats.length}টি বিষয়ে unlimited quiz শুরু করুন`)
        : (_QUIZ.selectedCats.length === 0 ? '🎲 যেকোনো বিষয়ে শুরু করুন' : `✅ ${_QUIZ.selectedCats.length}টি বিষয়ে শুরু করুন`)}
    </button>
  `;
}

function _quizHistoryHTML() {
  if (_QUIZ.history.length === 0) {
    return `<div style="text-align:center;padding:40px 20px;color:var(--t3)">
      <div style="font-size:2rem;margin-bottom:10px">📋</div>
      <div>এখনো কোনো কুইজ সম্পন্ন হয়নি</div>
    </div>`;
  }
  return _QUIZ.history.map(h => {
    const pct = Math.round((h.score / h.total) * 100);
    const g = _quizGrade(pct);
    return `<div class="quiz-history-item">
      <div class="quiz-hi-grade">${g.emoji}</div>
      <div class="quiz-hi-info">
        <div class="quiz-hi-cat">${h.cats || 'মিক্স'} • ${h.diff || 'মিক্স'}</div>
        <div class="quiz-hi-meta">${h.date} • ${h.total}টি প্রশ্ন</div>
      </div>
      <div class="quiz-hi-score">${pct}%</div>
    </div>`;
  }).join('');
}

function _quizStatsHTML() {
  const pct = _QUIZ.total > 0 ? Math.round((_QUIZ.score / _QUIZ.total) * 100) : 0;
  return `
    <div class="quiz-result-stats" style="margin-bottom:0">
      <div class="quiz-rs-card"><div class="quiz-rs-val">${_QUIZ.total}</div><div class="quiz-rs-label">মোট প্রশ্ন</div></div>
      <div class="quiz-rs-card"><div class="quiz-rs-val">${pct}%</div><div class="quiz-rs-label">সঠিক হার</div></div>
      <div class="quiz-rs-card"><div class="quiz-rs-val">${_QUIZ.maxStreak}🔥</div><div class="quiz-rs-label">সর্বোচ্চ ধারা</div></div>
    </div>
    <div style="margin-top:16px;padding:16px;border-radius:16px;border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.03)">
      <div class="quiz-section-title" style="margin:0 0 12px">বিষয় ভিত্তিক</div>
      ${QUIZ_CATS.map(c => {
        const hd = _QUIZ.history.filter(h => h.cats && h.cats.includes(c.name));
        const catScore = hd.reduce((s,h)=>s+h.score,0);
        const catTotal = hd.reduce((s,h)=>s+h.total,0);
        const catPct = catTotal > 0 ? Math.round((catScore/catTotal)*100) : 0;
        return `<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
          <div style="font-size:1rem;width:24px">${c.icon}</div>
          <div style="flex:1">
            <div style="font-size:0.75rem;color:var(--text);margin-bottom:4px">${c.name}</div>
            <div style="height:4px;border-radius:99px;background:rgba(255,255,255,.07);overflow:hidden">
              <div style="height:100%;width:${catPct}%;background:linear-gradient(90deg,var(--green),var(--teal));border-radius:99px;transition:width .5s"></div>
            </div>
          </div>
          <div style="font-size:0.75rem;color:var(--t3);min-width:32px;text-align:right">${catTotal > 0 ? catPct+'%' : '—'}</div>
        </div>`;
      }).join('')}
    </div>
  `;
}

function _quizGrade(pct) {
  if (pct >= 90) return { title: 'অসাধারণ! মাশাআল্লাহ 🌟', emoji: '🌟' };
  if (pct >= 75) return { title: 'চমৎকার! আলহামদুলিল্লাহ', emoji: '✨' };
  if (pct >= 60) return { title: 'ভালো! আরো শিখতে থাকুন', emoji: '👍' };
  if (pct >= 40) return { title: 'মাঝারি। আরো চেষ্টা করুন', emoji: '📚' };
  return { title: 'আরো পড়াশোনা করুন', emoji: '🤔' };
}

function _quizToggleCat(id) {
  const idx = _QUIZ.selectedCats.indexOf(id);
  if (idx === -1) _QUIZ.selectedCats.push(id);
  else _QUIZ.selectedCats.splice(idx, 1);
  _quizRenderHome();
}

function _quizSetDiff(d) {
  _QUIZ.difficulty = d;
  _quizRenderHome();
}

function _quizSetMode(mode) {
  _QUIZ.mode = mode || 'unlimited';
  _quizSave();
  _quizRenderHome();
}

function _quizStart() {
  _QUIZ.sessionScore = 0;
  _QUIZ.sessionTotal = 0;
  _QUIZ.wrongCount = 0;
  _QUIZ.usedQuestions.clear();
  _quizNextQuestion();
}

async function _quizNextQuestion() {
  _QUIZ.answered = false;
  _quizShowLoading();
  clearInterval(_QUIZ.timerInterval);

  let q = null;
  if (_QUIZ.mode === 'api') {
    q = await _quizFetchApiQuestion();
  }
  if (!q) {
    q = _quizPickLocalQuestion();
  }
  if (!q) { _quizShowError(); return; }

  _QUIZ.currentQ = q;
  _quizShowQuestion();
}


function _quizShowLoading() {
  const body = document.getElementById('quiz-body');
  if (!body) return;
  const sub = document.getElementById('quiz-hdr-sub');
  if (sub) sub.textContent = `${_QUIZ.mode === 'api' ? 'API থেকে' : ''} প্রশ্ন ${_QUIZ.sessionTotal + 1} তৈরি হচ্ছে...`;
  body.innerHTML = `
    <div class="quiz-loading">
      <div class="quiz-spinner"></div>
      <div class="quiz-loading-text">${_QUIZ.mode === 'api' ? 'নতুন API quiz তৈরি হচ্ছে…' : 'প্রশ্ন লোড হচ্ছে…'}<br><span style="font-size:0.6875rem;color:var(--t3)">বিষয়: ${_QUIZ.selectedCats.length > 0 ? _QUIZ.selectedCats.map(id => QUIZ_CATS.find(c=>c.id===id)?.name).join(', ') : 'মিক্স'}${_QUIZ.mode === 'api' ? ' • fresh generated' : ''}</span></div>
    </div>
  `;
}

function _quizShowError() {
  const body = document.getElementById('quiz-body');
  if (!body) return;
  body.innerHTML = `
    <div class="quiz-loading">
      <div style="font-size:2rem">⚠️</div>
      <div class="quiz-loading-text">প্রশ্ন লোড করতে সমস্যা হয়েছে</div>
      <button onclick="_quizNextQuestion()" style="margin-top:10px;padding:11px 24px;border-radius:14px;border:1px solid rgba(var(--green-rgb),.3);background:rgba(var(--green-rgb),.1);color:var(--green);font-family:'Manrope',sans-serif;cursor:pointer;font-size:0.75rem;">আবার চেষ্টা করুন</button>
      ${_QUIZ.apiLastError ? `<div style="margin-top:10px;font-size:.68rem;color:#ff9f9f">${_QUIZ.apiLastError}</div>` : ''}
      <button onclick="renderQuizPage()" style="margin-top:6px;padding:9px 20px;border-radius:14px;border:1px solid rgba(255,255,255,.1);background:transparent;color:var(--t2);font-family:'Manrope',sans-serif;cursor:pointer;font-size:0.75rem;">হোমে যান</button>
    </div>
  `;
}

function _quizShowQuestion() {
  const body = document.getElementById('quiz-body');
  if (!body) return;
  const q = _QUIZ.currentQ;
  const sub = document.getElementById('quiz-hdr-sub');
  if (sub) sub.textContent = `${_QUIZ.mode === 'api' ? 'API New Quiz' : (_QUIZ.mode === 'unlimited' ? 'Unlimited' : 'Quiz')} • প্রশ্ন ${_QUIZ.sessionTotal + 1} • ${q.category || ''}`;

  const letters = ['ক', 'খ', 'গ', 'ঘ'];

  body.innerHTML = `
    <div class="quiz-active">
      <div class="quiz-progress-bar-wrap">
        <div class="quiz-progress-bar-fill" id="quiz-timer-bar" style="width:100%"></div>
      </div>
      <div class="quiz-q-meta">
        <span class="quiz-q-num">প্রশ্ন ${_QUIZ.sessionTotal + 1}</span>
        <span class="quiz-q-cat">${q.category || 'ইসলাম'}</span>
        <span class="quiz-q-timer" id="quiz-timer">30</span>
      </div>
      <div class="quiz-question">${q.question}</div>
      <div class="quiz-options" id="quiz-opts">
        ${q.options.map((opt, i) => `
          <div class="quiz-option" id="qopt-${i}" onclick="_quizAnswer(${i})">
            <div class="quiz-opt-letter">${letters[i]}</div>
            <div>${opt}</div>
          </div>
        `).join('')}
      </div>
      <div id="quiz-expl"></div>
      <div id="quiz-next-wrap"></div>
    </div>
  `;

  _quizStartTimer();
}

function _quizStartTimer() {
  _QUIZ.timeLeft = 30;
  clearInterval(_QUIZ.timerInterval);

  _QUIZ.timerInterval = setInterval(() => {
    _QUIZ.timeLeft--;
    const el = document.getElementById('quiz-timer');
    const bar = document.getElementById('quiz-timer-bar');
    if (el) {
      el.textContent = _QUIZ.timeLeft;
      if (_QUIZ.timeLeft <= 10) el.classList.add('urgent');
    }
    if (bar) bar.style.width = (_QUIZ.timeLeft / 30 * 100) + '%';

    if (_QUIZ.timeLeft <= 0) {
      clearInterval(_QUIZ.timerInterval);
      if (!_QUIZ.answered) _quizAnswer(-1); // time out
    }
  }, 1000);
}

function _quizAnswer(idx) {
  if (_QUIZ.answered) return;
  _QUIZ.answered = true;
  clearInterval(_QUIZ.timerInterval);

  const q = _QUIZ.currentQ;
  const correct = q.correct;
  const isCorrect = idx === correct;

  _QUIZ.sessionTotal++;
  _QUIZ.total++;

  if (isCorrect) {
    _QUIZ.sessionScore++;
    _QUIZ.score++;
    _QUIZ.streak++;
    if (_QUIZ.streak > _QUIZ.maxStreak) _QUIZ.maxStreak = _QUIZ.streak;
  } else {
    _QUIZ.wrongCount++;
    _QUIZ.streak = 0;
  }

  // Update streak display
  const streakEl = document.getElementById('quiz-streak-display');
  if (streakEl) {
    streakEl.style.display = _QUIZ.streak > 0 ? 'flex' : 'none';
    const sv = document.getElementById('quiz-streak-val');
    if (sv) sv.textContent = _QUIZ.streak + ' 🔥';
  }

  // Highlight options
  const opts = document.querySelectorAll('.quiz-option');
  opts.forEach((el, i) => {
    el.classList.add('disabled');
    if (i === correct) el.classList.add('correct');
    else if (i === idx && !isCorrect) el.classList.add('wrong');
  });

  // Show explanation
  const explEl = document.getElementById('quiz-expl');
  if (explEl) {
    const icon = idx === -1 ? '⏰' : isCorrect ? '✅' : '❌';
    const msg = idx === -1 ? 'সময় শেষ! সঠিক উত্তর:' : isCorrect ? 'চমৎকার! সঠিক উত্তর।' : 'ভুল। সঠিক উত্তর:';
    explEl.innerHTML = `
      <div class="quiz-explanation">
        <strong>${icon} ${msg}</strong> ${q.options[correct]}<br>
        ${q.explanation || ''}
        ${q.reference ? `<br><span style="color:var(--gold);font-size:0.6875rem">📎 ${q.reference}</span>` : ''}
      </div>
    `;
  }

  // Show next button
  const nextWrap = document.getElementById('quiz-next-wrap');
  if (nextWrap) {
    nextWrap.innerHTML = `
      <div style="display:flex;gap:8px">
        <button class="quiz-next-btn" style="flex:1" onclick="_quizNextQuestion()">${_QUIZ.mode === 'api' ? 'নতুন API quiz আনুন →' : (_QUIZ.mode === 'unlimited' ? 'আরো প্রশ্ন খেলুন →' : 'পরের প্রশ্ন →')}</button>
        <button class="quiz-next-btn" style="flex:0 0 auto;padding:15px 14px" onclick="_quizShowResult()" title="ফলাফল দেখুন">🏁</button>
      </div>
    `;
  }

  _quizSave();
}

function _quizShowResult() {
  clearInterval(_QUIZ.timerInterval);
  const body = document.getElementById('quiz-body');
  if (!body) return;

  const pct = _QUIZ.sessionTotal > 0 ? Math.round((_QUIZ.sessionScore / _QUIZ.sessionTotal) * 100) : 0;
  const grade = _quizGrade(pct);

  // Save to history
  const catNames = _QUIZ.selectedCats.length > 0
    ? _QUIZ.selectedCats.map(id => QUIZ_CATS.find(c=>c.id===id)?.name).join(', ')
    : 'মিক্স';
  _QUIZ.history.unshift({
    score: _QUIZ.sessionScore,
    total: _QUIZ.sessionTotal,
    cats: catNames,
    diff: _QUIZ.difficulty,
    date: new Date().toLocaleDateString('bn-BD', { day:'numeric', month:'short' }),
  });
  _quizSave();
  _quizUpdateBadge();

  const sub = document.getElementById('quiz-hdr-sub');
  if (sub) sub.textContent = 'ফলাফল';

  body.innerHTML = `
    <div class="quiz-result">
      <div class="quiz-result-circle">
        <div class="quiz-result-score">${pct}%</div>
        <div class="quiz-result-total">${_QUIZ.sessionScore}/${_QUIZ.sessionTotal}</div>
      </div>
      <div class="quiz-result-title">${grade.title}</div>
      <div class="quiz-result-sub">
        ${catNames} • ${_QUIZ.difficulty} • ${_QUIZ.mode === 'api' ? 'API Fresh Mode' : (_QUIZ.mode === 'unlimited' ? 'Unlimited Mode' : 'Standard Mode')}<br>
        ধারাবাহিক সঠিক: ${_QUIZ.maxStreak} 🔥
      </div>
      <div class="quiz-result-stats">
        <div class="quiz-rs-card">
          <div class="quiz-rs-val" style="color:var(--green)">${_QUIZ.sessionScore}</div>
          <div class="quiz-rs-label">সঠিক</div>
        </div>
        <div class="quiz-rs-card">
          <div class="quiz-rs-val" style="color:var(--rose)">${_QUIZ.sessionTotal - _QUIZ.sessionScore}</div>
          <div class="quiz-rs-label">ভুল</div>
        </div>
        <div class="quiz-rs-card">
          <div class="quiz-rs-val">${_QUIZ.sessionTotal}</div>
          <div class="quiz-rs-label">মোট</div>
        </div>
      </div>
      <div class="quiz-result-btns">
        <button class="quiz-rb" onclick="renderQuizPage()">🏠 হোম</button>
        <button class="quiz-rb" onclick="_quizNextQuestion()">♾️ আরো খেলুন</button>
        <button class="quiz-rb primary" onclick="_quizStart()">🔄 আবার খেলুন</button>
      </div>
    </div>
  `;
}
// ══ ISLAMIC QUIZ QUESTION BANK (200+) ══
const _QUIZ_BANK = [
  // ── কুরআন ──
  {catId:'quran',category:'কুরআন',diff:'সহজ',question:'কুরআনে মোট কতটি সূরা আছে?',options:['১১৪টি','১১২টি','১১৬টি','১২০টি'],correct:0,explanation:'পবিত্র কুরআনে মোট ১১৪টি সূরা রয়েছে।',reference:''},
  {catId:'quran',category:'কুরআন',diff:'সহজ',question:'কুরআনের প্রথম সূরার নাম কী?',options:['আল-বাকারা','আল-ফাতিহা','আল-ইখলাস','আল-নাস'],correct:1,explanation:'কুরআনের প্রথম সূরা হলো আল-ফাতিহা, যা "উম্মুল কিতাব" নামেও পরিচিত।',reference:''},
  {catId:'quran',category:'কুরআন',diff:'সহজ',question:'কুরআনের সবচেয়ে বড় সূরা কোনটি?',options:['আল-ইমরান','আন-নিসা','আল-বাকারা','আল-মায়িদা'],correct:2,explanation:'আল-বাকারা কুরআনের সবচেয়ে বড় সূরা, এতে ২৮৬টি আয়াত রয়েছে।',reference:''},
  {catId:'quran',category:'কুরআন',diff:'সহজ',question:'কুরআনের সবচেয়ে ছোট সূরা কোনটি?',options:['আল-ইখলাস','আল-কাউসার','আল-আসর','আল-ফালাক'],correct:1,explanation:'আল-কাউসার কুরআনের সবচেয়ে ছোট সূরা, এতে মাত্র ৩টি আয়াত আছে।',reference:''},
  {catId:'quran',category:'কুরআন',diff:'সহজ',question:'কুরআন কত বছর ধরে নাজিল হয়েছে?',options:['২০ বছর','২৩ বছর','২৫ বছর','৩০ বছর'],correct:1,explanation:'কুরআন প্রায় ২৩ বছর ধরে ধীরে ধীরে নাজিল হয়েছে।',reference:''},
  {catId:'quran',category:'কুরআন',diff:'সহজ',question:'কুরআনের কোন সূরায় "আয়াতুল কুরসি" আছে?',options:['আল-ইমরান','আল-বাকারা','আন-নিসা','আল-মায়িদা'],correct:1,explanation:'আয়াতুল কুরসি সূরা আল-বাকারার ২৫৫ নং আয়াত।',reference:'সূরা বাকারা: ২৫৫'},
  {catId:'quran',category:'কুরআন',diff:'মাঝারি',question:'কুরআনে মোট কতটি পারা (জুয) আছে?',options:['২৫টি','২৮টি','৩০টি','৩২টি'],correct:2,explanation:'কুরআনকে মোট ৩০টি পারায় ভাগ করা হয়েছে।',reference:''},
  {catId:'quran',category:'কুরআন',diff:'মাঝারি',question:'কুরআনের কোন সূরাকে "কুরআনের হৃদয়" বলা হয়?',options:['আল-ফাতিহা','ইয়াসীন','আল-বাকারা','আল-কাহফ'],correct:1,explanation:'সূরা ইয়াসীনকে কুরআনের হৃদয় বলা হয়।',reference:'তিরমিযি'},
  {catId:'quran',category:'কুরআন',diff:'মাঝারি',question:'কোন সূরায় বিসমিল্লাহ দুইবার আছে?',options:['আল-বাকারা','আন-নামল','আল-ফাতিহা','আত-তাওবা'],correct:1,explanation:'সূরা আন-নামলে বিসমিল্লাহ দুইবার আছে — শুরুতে ও আয়াত ৩০-এ।',reference:'সূরা আন-নামল: ৩০'},
  {catId:'quran',category:'কুরআন',diff:'মাঝারি',question:'কোন সূরার শুরুতে বিসমিল্লাহ নেই?',options:['আল-ফীল','আত-তাওবা','আল-কাফিরুন','আল-মাউন'],correct:1,explanation:'সূরা আত-তাওবা একমাত্র সূরা যার শুরুতে বিসমিল্লাহ নেই।',reference:''},
  {catId:'quran',category:'কুরআন',diff:'মাঝারি',question:'জুমার দিন কোন সূরা পাঠ করা বিশেষ ফযিলতপূর্ণ?',options:['সূরা ইয়াসীন','সূরা কাহফ','সূরা মুলক','সূরা ওয়াকিআ'],correct:1,explanation:'জুমার দিন সূরা কাহফ পাঠ করা সুন্নত।',reference:'হাকিম'},
  {catId:'quran',category:'কুরআন',diff:'কঠিন',question:'কুরআনে মোট কতটি আয়াত আছে?',options:['৬,২৩৬টি','৬,৩৪৮টি','৬,৬৬৬টি','৬,০০০টি'],correct:0,explanation:'কুরআনে মোট ৬,২৩৬টি আয়াত রয়েছে।',reference:''},
  {catId:'quran',category:'কুরআন',diff:'কঠিন',question:'কুরআনে কতটি মাক্কী সূরা আছে?',options:['৭০টি','৮৬টি','৯২টি','৮০টি'],correct:1,explanation:'কুরআনে ৮৬টি মাক্কী ও ২৮টি মাদানী সূরা রয়েছে।',reference:''},
  {catId:'quran',category:'কুরআন',diff:'কঠিন',question:'কুরআনের দীর্ঘতম আয়াত কোনটি?',options:['আয়াতুল কুরসি','সূরা বাকারা ২৮২','সূরা বাকারা ২৫৫','সূরা বাকারা ১৮৩'],correct:1,explanation:'সূরা বাকারার ২৮২ নং আয়াত (ঋণ-দলিল সংক্রান্ত) কুরআনের দীর্ঘতম আয়াত।',reference:'সূরা বাকারা: ২৮২'},
  {catId:'quran',category:'কুরআন',diff:'কঠিন',question:'কুরআনের কোন সূরায় সবচেয়ে বেশি আল্লাহর নাম উল্লেখ আছে?',options:['আল-বাকারা','আল-ইমরান','আল-মুজাদালা','আল-হাশর'],correct:2,explanation:'সূরা আল-মুজাদালার প্রতিটি আয়াতে আল্লাহর নাম উল্লেখ আছে।',reference:''},

  // ── নামাজ ──
  {catId:'salah',category:'নামাজ',diff:'সহজ',question:'প্রতিদিন কতটি ফরজ নামাজ আদায় করতে হয়?',options:['৩টি','৪টি','৫টি','৬টি'],correct:2,explanation:'প্রতিদিন ৫ ওয়াক্ত ফরজ নামাজ আদায় করা ফরজ।',reference:''},
  {catId:'salah',category:'নামাজ',diff:'সহজ',question:'ফজর নামাজে কতটি রাকাত ফরজ?',options:['২টি','৩টি','৪টি','১টি'],correct:0,explanation:'ফজর নামাজে ২ রাকাত ফরজ।',reference:''},
  {catId:'salah',category:'নামাজ',diff:'সহজ',question:'জুমার নামাজ কোন দিন পড়া হয়?',options:['শনিবার','রবিবার','বৃহস্পতিবার','শুক্রবার'],correct:3,explanation:'জুমার নামাজ প্রতি শুক্রবার যোহরের সময়ে আদায় করা হয়।',reference:'সূরা জুমুআ: ৯'},
  {catId:'salah',category:'নামাজ',diff:'সহজ',question:'নামাজে কতটি ফরজ আছে?',options:['৬টি','৭টি','৮টি','৯টি'],correct:0,explanation:'নামাজের ফরজ ৬টি: তাকবিরে তাহরিমা, কিয়াম, কিরাআত, রুকু, সিজদা, শেষ বৈঠক।',reference:''},
  {catId:'salah',category:'নামাজ',diff:'মাঝারি',question:'তারাবির নামাজ কোন মাসে পড়া হয়?',options:['শাবান','রমজান','মুহাররম','রজব'],correct:1,explanation:'তারাবির নামাজ রমজান মাসে এশার পরে পড়া হয়।',reference:''},
  {catId:'salah',category:'নামাজ',diff:'মাঝারি',question:'রুকুতে কী পড়তে হয়?',options:['সুবহানাল্লাহিল আযিম','সুবহানা রাব্বিয়াল আলা','আল্লাহু আকবার','আমিন'],correct:0,explanation:'রুকুতে "সুবহানা রাব্বিয়াল আযিম" পড়তে হয়।',reference:''},
  {catId:'salah',category:'নামাজ',diff:'মাঝারি',question:'সিজদায় কী পড়তে হয়?',options:['সুবহানাল্লাহিল আযিম','সুবহানা রাব্বিয়াল আলা','আল্লাহু আকবার','রাব্বিগফিরলি'],correct:1,explanation:'সিজদায় "সুবহানা রাব্বিয়াল আলা" পড়তে হয়।',reference:''},
  {catId:'salah',category:'নামাজ',diff:'মাঝারি',question:'যোহর নামাজে মোট কত রাকাত (সুন্নতসহ)?',options:['৮ রাকাত','১০ রাকাত','১২ রাকাত','৬ রাকাত'],correct:1,explanation:'যোহরে ৪ সুন্নত + ৪ ফরজ + ২ সুন্নত = ১০ রাকাত।',reference:''},
  {catId:'salah',category:'নামাজ',diff:'কঠিন',question:'বিতর নামাজ কত রাকাত পড়া যায়?',options:['শুধু ১ রাকাত','শুধু ৩ রাকাত','১ বা ৩ রাকাত','যেকোনো বেজোড় সংখ্যা'],correct:3,explanation:'বিতর যেকোনো বেজোড় সংখ্যায় পড়া যায়, তবে ৩ রাকাত সবচেয়ে প্রচলিত।',reference:'বুখারি, মুসলিম'},
  {catId:'salah',category:'নামাজ',diff:'কঠিন',question:'তাহাজ্জুদ নামাজের সর্বোত্তম সময় কোনটি?',options:['মধ্যরাত','শেষ রাতের এক তৃতীয়াংশ','ফজরের আগে ১ ঘণ্টা','এশার পরপর'],correct:1,explanation:'রাতের শেষ তৃতীয়াংশে তাহাজ্জুদ পড়া সর্বোত্তম।',reference:'বুখারি: ১১৪৫'},

  // ── রোজা ──
  {catId:'sawm',category:'রোজা',diff:'সহজ',question:'রমজান মাস ইসলামী বর্ষের কততম মাস?',options:['৮ম','৯ম','১০ম','১১তম'],correct:1,explanation:'রমজান ইসলামী বর্ষের ৯ম মাস।',reference:''},
  {catId:'sawm',category:'রোজা',diff:'সহজ',question:'রোজার নিয়ত কখন করতে হয়?',options:['ফজরের পরে','সাহরির আগে বা সাহরির সময়ে','সূর্যোদয়ের আগে','যেকোনো সময়'],correct:1,explanation:'রাতে বা সাহরির সময়ে রোজার নিয়ত করতে হয়।',reference:'নাসাই: ২৩৩৩'},
  {catId:'sawm',category:'রোজা',diff:'মাঝারি',question:'কোন রাতকে "লাইলাতুল কদর" বলা হয়?',options:['রমজানের ১৫তম রাত','রমজানের শেষ ১০ রাতের বেজোড় রাত','শুধু ২৭তম রাত','শবে বরাত'],correct:1,explanation:'লাইলাতুল কদর রমজানের শেষ ১০ রাতের যেকোনো বেজোড় রাতে।',reference:'বুখারি: ২০১৭'},
  {catId:'sawm',category:'রোজা',diff:'মাঝারি',question:'ভুলে খেলে রোজার কী হয়?',options:['রোজা ভেঙে যায়','রোজা ভাঙে না','কাযা করতে হবে','কাফফারা দিতে হবে'],correct:1,explanation:'ভুলে খেলে রোজা ভাঙে না, আল্লাহ তা মাফ করেছেন।',reference:'বুখারি: ১৯৩৩'},
  {catId:'sawm',category:'রোজা',diff:'মাঝারি',question:'ঈদুল ফিতর কোন মাসে পালিত হয়?',options:['রমজান','শাওয়াল','যুলহিজ্জা','শাবান'],correct:1,explanation:'রমজানের পরে শাওয়াল মাসের ১ তারিখে ঈদুল ফিতর পালিত হয়।',reference:''},
  {catId:'sawm',category:'রোজা',diff:'কঠিন',question:'রমজানে ইচ্ছাকৃতভাবে রোজা ভাঙলে কাফফারা কী?',options:['শুধু কাযা','৬০ জন মিসকিন খাওয়ানো বা ৬০ দিন রোজা বা দাস মুক্তি','শুধু তওবা','১০ দিন রোজা'],correct:1,explanation:'ইচ্ছাকৃত রোজা ভাঙলে কাফফারা: দাস মুক্তি, না পারলে ৬০ দিন রোজা, না পারলে ৬০ জন মিসকিন খাওয়ানো।',reference:'বুখারি: ১৯৩৬'},

  // ── হজ্জ ──
  {catId:'hajj',category:'হজ্জ',diff:'সহজ',question:'হজ্জ ইসলামের কততম স্তম্ভ?',options:['৩য়','৪র্থ','৫ম','২য়'],correct:2,explanation:'হজ্জ ইসলামের ৫ম স্তম্ভ।',reference:'বুখারি: ৮'},
  {catId:'hajj',category:'হজ্জ',diff:'সহজ',question:'হজ্জ কোন মাসে পালিত হয়?',options:['রমজান','শাওয়াল','যুলহিজ্জা','মুহাররম'],correct:2,explanation:'হজ্জ যুলহিজ্জা মাসে পালিত হয়।',reference:''},
  {catId:'hajj',category:'হজ্জ',diff:'মাঝারি',question:'কাবা শরিফ কোথায় অবস্থিত?',options:['মদিনা','তায়েফ','মক্কা','জেদ্দা'],correct:2,explanation:'কাবা শরিফ সৌদি আরবের মক্কায় অবস্থিত।',reference:''},
  {catId:'hajj',category:'হজ্জ',diff:'মাঝারি',question:'হজ্জে পুরুষরা কী পোশাক পরেন?',options:['সাদা কুর্তা','ইহরাম','জুব্বা','থোব'],correct:1,explanation:'হজ্জে পুরুষরা দুই টুকরো সেলাইবিহীন সাদা কাপড় (ইহরাম) পরেন।',reference:''},
  {catId:'hajj',category:'হজ্জ',diff:'মাঝারি',question:'তাওয়াফ কতবার করতে হয়?',options:['৫ বার','৭ বার','৯ বার','৩ বার'],correct:1,explanation:'কাবা শরিফকে ৭ বার প্রদক্ষিণ করাকে তাওয়াফ বলে।',reference:''},
  {catId:'hajj',category:'হজ্জ',diff:'কঠিন',question:'আরাফাতের ময়দানে অবস্থান হজ্জের কততম দিনে?',options:['৭ যুলহিজ্জা','৯ যুলহিজ্জা','১০ যুলহিজ্জা','৮ যুলহিজ্জা'],correct:1,explanation:'৯ যুলহিজ্জা আরাফাতের দিন — এটি হজ্জের মূল রুকন।',reference:'মুসলিম: ১২১৮'},
  {catId:'hajj',category:'হজ্জ',diff:'কঠিন',question:'হজ্জের ফরজ কতটি?',options:['২টি','৩টি','৪টি','৫টি'],correct:1,explanation:'হজ্জের ফরজ ৩টি: ইহরাম, আরাফায় অবস্থান, তাওয়াফে যিয়ারত।',reference:''},

  // ── যাকাত ──
  {catId:'zakat',category:'যাকাত',diff:'সহজ',question:'যাকাত ইসলামের কততম স্তম্ভ?',options:['২য়','৩য়','৪র্থ','৫ম'],correct:1,explanation:'যাকাত ইসলামের ৩য় স্তম্ভ।',reference:''},
  {catId:'zakat',category:'যাকাত',diff:'মাঝারি',question:'সোনার যাকাতের নিসাব কত গ্রাম?',options:['৫০ গ্রাম','৭০ গ্রাম','৮৫ গ্রাম','১০০ গ্রাম'],correct:2,explanation:'সোনার নিসাব হলো ৮৫ গ্রাম (৭.৫ তোলা)।',reference:''},
  {catId:'zakat',category:'যাকাত',diff:'মাঝারি',question:'যাকাতের হার কত?',options:['২%','২.৫%','৫%','১০%'],correct:1,explanation:'সম্পদের ২.৫% যাকাত দিতে হয়।',reference:''},
  {catId:'zakat',category:'যাকাত',diff:'মাঝারি',question:'যাকাত ফরজ হওয়ার জন্য সম্পদ কতদিন থাকতে হবে?',options:['৬ মাস','১ বছর (এক হাওল)','২ বছর','৩ মাস'],correct:1,explanation:'নিসাব পরিমাণ সম্পদ এক চন্দ্রবর্ষ (হাওল) পূর্ণ হলে যাকাত ফরজ।',reference:''},
  {catId:'zakat',category:'যাকাত',diff:'কঠিন',question:'যাকাত কাদের দেওয়া যায়? (কুরআনে উল্লিখিত শ্রেণি)',options:['৪ শ্রেণি','৬ শ্রেণি','৮ শ্রেণি','১০ শ্রেণি'],correct:2,explanation:'সূরা তাওবার ৬০ নং আয়াতে ৮ শ্রেণির মানুষের কথা উল্লেখ আছে।',reference:'সূরা তাওবা: ৬০'},

  // ── সীরাত ──
  {catId:'seerah',category:'সীরাত',diff:'সহজ',question:'নবী মুহাম্মদ (সা.) কোথায় জন্মগ্রহণ করেন?',options:['মদিনা','তায়েফ','মক্কা','জেদ্দা'],correct:2,explanation:'নবী মুহাম্মদ (সা.) মক্কায় জন্মগ্রহণ করেন।',reference:''},
  {catId:'seerah',category:'সীরাত',diff:'সহজ',question:'নবীজি (সা.) এর পিতার নাম কী?',options:['আবু তালিব','আবদুল্লাহ','আবদুল মুত্তালিব','আমর'],correct:1,explanation:'নবীজির পিতার নাম আবদুল্লাহ, যিনি নবীজির জন্মের আগেই মারা যান।',reference:''},
  {catId:'seerah',category:'সীরাত',diff:'সহজ',question:'নবীজির (সা.) মাতার নাম কী?',options:['খাদিজা','ফাতিমা','আমিনা','হালিমা'],correct:2,explanation:'নবীজির মাতার নাম আমিনা বিনতে ওয়াহাব।',reference:''},
  {catId:'seerah',category:'সীরাত',diff:'সহজ',question:'নবীজির (সা.) প্রথম স্ত্রীর নাম কী?',options:['আয়েশা (রা.)','হাফসা (রা.)','খাদিজা (রা.)','যয়নব (রা.)'],correct:2,explanation:'নবীজির প্রথম স্ত্রী ছিলেন খাদিজা বিনতে খুওয়াইলিদ (রা.)।',reference:''},
  {catId:'seerah',category:'সীরাত',diff:'মাঝারি',question:'হিজরত কোন সালে হয়েছিল?',options:['৬১০ খ্রিস্টাব্দ','৬১৫ খ্রিস্টাব্দ','৬২২ খ্রিস্টাব্দ','৬৩০ খ্রিস্টাব্দ'],correct:2,explanation:'৬২২ খ্রিস্টাব্দে নবীজি মক্কা থেকে মদিনায় হিজরত করেন।',reference:''},
  {catId:'seerah',category:'সীরাত',diff:'মাঝারি',question:'বদরের যুদ্ধ কত হিজরিতে হয়েছিল?',options:['১ হিজরি','২ হিজরি','৩ হিজরি','৫ হিজরি'],correct:1,explanation:'বদরের যুদ্ধ ২ হিজরিতে (৬২৪ খ্রিস্টাব্দে) হয়েছিল।',reference:''},
  {catId:'seerah',category:'সীরাত',diff:'মাঝারি',question:'নবীজি (সা.) কত বছর বয়সে নবুওয়াত লাভ করেন?',options:['৩৫ বছর','৪০ বছর','৪৫ বছর','৩০ বছর'],correct:1,explanation:'নবীজি ৪০ বছর বয়সে হেরা গুহায় প্রথম ওহি লাভ করেন।',reference:'বুখারি: ৩'},
  {catId:'seerah',category:'সীরাত',diff:'কঠিন',question:'মক্কা বিজয় কত হিজরিতে হয়?',options:['৬ হিজরি','৭ হিজরি','৮ হিজরি','৯ হিজরি'],correct:2,explanation:'মক্কা বিজয় হয় ৮ম হিজরিতে (৬৩০ খ্রিস্টাব্দে)।',reference:''},
  {catId:'seerah',category:'সীরাত',diff:'কঠিন',question:'নবীজি (সা.) কত বছর বয়সে ইন্তেকাল করেন?',options:['৬০ বছর','৬৩ বছর','৬৫ বছর','৭০ বছর'],correct:1,explanation:'নবীজি (সা.) ৬৩ বছর বয়সে ১১ হিজরিতে ইন্তেকাল করেন।',reference:'বুখারি: ৩৫৩৬'},

  // ── আকীদা ──
  {catId:'aqeedah',category:'আকীদা',diff:'সহজ',question:'ইসলামের ৫টি স্তম্ভের প্রথমটি কোনটি?',options:['নামাজ','রোজা','কালিমা শাহাদাত','যাকাত'],correct:2,explanation:'শাহাদাত (কালিমা) ইসলামের প্রথম স্তম্ভ।',reference:'বুখারি: ৮'},
  {catId:'aqeedah',category:'আকীদা',diff:'সহজ',question:'ইমানের স্তম্ভ কতটি?',options:['৪টি','৫টি','৬টি','৭টি'],correct:2,explanation:'ইমানের ৬টি স্তম্ভ: আল্লাহ, ফেরেশতা, কিতাব, নবী, আখিরাত, তাকদির।',reference:'মুসলিম: ৮'},
  {catId:'aqeedah',category:'আকীদা',diff:'মাঝারি',question:'"আর-রহমান" এর অর্থ কী?',options:['সর্বশক্তিমান','পরম দয়ালু','সর্বজ্ঞ','সর্বশ্রোতা'],correct:1,explanation:'আর-রহমান অর্থ পরম দয়ালু।',reference:''},
  {catId:'aqeedah',category:'আকীদা',diff:'মাঝারি',question:'জান্নাতের দরজা কতটি?',options:['৪টি','৬টি','৭টি','৮টি'],correct:3,explanation:'জান্নাতের ৮টি দরজা রয়েছে।',reference:'বুখারি: ১৮৯৭'},
  {catId:'aqeedah',category:'আকীদা',diff:'মাঝারি',question:'জাহান্নামের দরজা কতটি?',options:['৫টি','৬টি','৭টি','৮টি'],correct:2,explanation:'জাহান্নামের ৭টি দরজা রয়েছে।',reference:'সূরা হিজর: ৪৪'},
  {catId:'aqeedah',category:'আকীদা',diff:'কঠিন',question:'কিয়ামতের বড় আলামত কতটি?',options:['৫টি','৭টি','১০টি','১২টি'],correct:2,explanation:'কিয়ামতের ১০টি বড় আলামত সহিহ মুসলিমে উল্লেখ আছে।',reference:'মুসলিম: ২৯০১'},

  // ── নবী-রাসূল ──
  {catId:'prophets',category:'নবী-রাসূল',diff:'সহজ',question:'কুরআনে কতজন নবীর নাম আছে?',options:['১৮ জন','২৫ জন','৩০ জন','৩৬ জন'],correct:1,explanation:'কুরআনে ২৫ জন নবী-রাসূলের নাম সরাসরি উল্লেখ আছে।',reference:''},
  {catId:'prophets',category:'নবী-রাসূল',diff:'সহজ',question:'প্রথম নবী কে?',options:['ইব্রাহিম (আ.)','নূহ (আ.)','আদম (আ.)','মুসা (আ.)'],correct:2,explanation:'হযরত আদম (আ.) প্রথম মানুষ এবং প্রথম নবী।',reference:''},
  {catId:'prophets',category:'নবী-রাসূল',diff:'মাঝারি',question:'কোন নবীকে "খলিলুল্লাহ" বলা হয়?',options:['মুসা (আ.)','ঈসা (আ.)','ইব্রাহিম (আ.)','দাউদ (আ.)'],correct:2,explanation:'ইব্রাহিম (আ.) কে "খলিলুল্লাহ" (আল্লাহর বন্ধু) বলা হয়।',reference:'সূরা নিসা: ১২৫'},
  {catId:'prophets',category:'নবী-রাসূল',diff:'মাঝারি',question:'কোন নবী সবচেয়ে দীর্ঘ জীবন পেয়েছিলেন?',options:['আদম (আ.)','ইব্রাহিম (আ.)','নূহ (আ.)','ইদ্রিস (আ.)'],correct:2,explanation:'নূহ (আ.) প্রায় ৯৫০ বছর জীবন পেয়েছিলেন।',reference:'সূরা আনকাবুত: ১৪'},
  {catId:'prophets',category:'নবী-রাসূল',diff:'কঠিন',question:'কোন নবীকে "কালিমুল্লাহ" বলা হয়?',options:['ইব্রাহিম (আ.)','মুসা (আ.)','ঈসা (আ.)','দাউদ (আ.)'],correct:1,explanation:'মুসা (আ.) কে "কালিমুল্লাহ" বলা হয়, কারণ আল্লাহ সরাসরি তাঁর সাথে কথা বলেছেন।',reference:'সূরা নিসা: ১৬৪'},
  {catId:'prophets',category:'নবী-রাসূল',diff:'কঠিন',question:'কোন নবীকে "রুহুল্লাহ" বলা হয়?',options:['মুসা (আ.)','ইব্রাহিম (আ.)','ঈসা (আ.)','ইদ্রিস (আ.)'],correct:2,explanation:'ঈসা (আ.) কে "রুহুল্লাহ" বলা হয়।',reference:'সূরা নিসা: ১৭১'},

  // ── দোয়া ও যিকির ──
  {catId:'dua',category:'দোয়া ও যিকির',diff:'সহজ',question:'"সুবহানাল্লাহ" এর অর্থ কী?',options:['আল্লাহ মহান','আল্লাহর প্রশংসা','আল্লাহ পবিত্র','আল্লাহ ছাড়া ইলাহ নেই'],correct:2,explanation:'"সুবহানাল্লাহ" অর্থ আল্লাহ পবিত্র।',reference:''},
  {catId:'dua',category:'দোয়া ও যিকির',diff:'সহজ',question:'"আলহামদুলিল্লাহ" এর অর্থ কী?',options:['আল্লাহ মহান','সকল প্রশংসা আল্লাহর','আল্লাহ পবিত্র','আল্লাহু আকবার'],correct:1,explanation:'"আলহামদুলিল্লাহ" অর্থ সকল প্রশংসা আল্লাহর জন্য।',reference:''},
  {catId:'dua',category:'দোয়া ও যিকির',diff:'সহজ',question:'খাওয়ার আগে কী বলতে হয়?',options:['আলহামদুলিল্লাহ','বিসমিল্লাহ','সুবহানাল্লাহ','আল্লাহু আকবার'],correct:1,explanation:'খাওয়ার শুরুতে "বিসমিল্লাহ" বলা সুন্নত।',reference:'বুখারি'},
  {catId:'dua',category:'দোয়া ও যিকির',diff:'মাঝারি',question:'ঘুমানোর আগে কোন আয়াত পড়া উত্তম?',options:['সূরা ফাতিহা','আয়াতুল কুরসি','সূরা ইখলাস','সূরা ফালাক'],correct:1,explanation:'ঘুমানোর আগে আয়াতুল কুরসি পড়লে সারারাত হেফাজতে থাকা যায়।',reference:'বুখারি: ৫০১০'},
  {catId:'dua',category:'দোয়া ও যিকির',diff:'মাঝারি',question:'ইস্তিগফারের সেরা দোয়া কোনটি?',options:['সুবহানাল্লাহ','সাইয়্যিদুল ইস্তিগফার','লা ইলাহা ইল্লাল্লাহ','আস্তাগফিরুল্লাহ'],correct:1,explanation:'সাইয়্যিদুল ইস্তিগফার হলো ইস্তিগফারের সেরা দোয়া।',reference:'বুখারি: ৬৩০৬'},
  {catId:'dua',category:'দোয়া ও যিকির',diff:'কঠিন',question:'কোন যিকিরটি সবচেয়ে উত্তম?',options:['সুবহানাল্লাহ','লা ইলাহা ইল্লাল্লাহ','আলহামদুলিল্লাহ','আল্লাহু আকবার'],correct:1,explanation:'"লা ইলাহা ইল্লাল্লাহ" সর্বোত্তম যিকির।',reference:'তিরমিযি: ৩৩৮৩'},

  // ── ফিকহ ──
  {catId:'fiqh',category:'ফিকহ',diff:'সহজ',question:'অযু ভাঙার কারণ নয় কোনটি?',options:['ঘুম','বমি','কান্না','বায়ু নিঃসরণ'],correct:2,explanation:'কান্নায় অযু ভাঙে না।',reference:''},
  {catId:'fiqh',category:'ফিকহ',diff:'সহজ',question:'অযুতে কতটি ফরজ আছে?',options:['৩টি','৪টি','৫টি','৬টি'],correct:1,explanation:'অযুর ফরজ ৪টি: মুখ, দুই হাত, মাথার মাসেহ, দুই পা ধোওয়া।',reference:'সূরা মায়িদা: ৬'},
  {catId:'fiqh',category:'ফিকহ',diff:'মাঝারি',question:'তায়াম্মুম কখন করা যায়?',options:['শুধু মরুভূমিতে','পানি না পেলে বা ব্যবহারে অক্ষম হলে','রোজার সময়','শুধু রোগীরা'],correct:1,explanation:'পানি না পেলে বা পানি ব্যবহারে অক্ষম হলে তায়াম্মুম করা যায়।',reference:'সূরা নিসা: ৪৩'},
  {catId:'fiqh',category:'ফিকহ',diff:'মাঝারি',question:'হালাল মাংস জবাইয়ের মূল শর্ত কোনটি?',options:['শুধু ধারালো ছুরি','বিসমিল্লাহ বলা ও রক্ত প্রবাহিত করা','কিবলামুখী হওয়া','মুসলিম কর্তৃক জবাই'],correct:1,explanation:'বিসমিল্লাহ বলা এবং রক্ত সম্পূর্ণ প্রবাহিত হওয়া হালাল জবাইয়ের মূল শর্ত।',reference:'সূরা আনআম: ১২১'},
  {catId:'fiqh',category:'ফিকহ',diff:'কঠিন',question:'ইসলামে সুদ (রিবা) কত প্রকার?',options:['২ প্রকার','৩ প্রকার','৪ প্রকার','৫ প্রকার'],correct:0,explanation:'ইসলামে সুদ মূলত দুই প্রকার: রিবা আল-ফাদল ও রিবা আল-নাসিয়া।',reference:'বুখারি: ২১৭৭'},

  // ── ইসলামী ইতিহাস ──
  {catId:'history',category:'ইতিহাস',diff:'সহজ',question:'ইসলামী হিজরি বর্ষের প্রথম মাস কোনটি?',options:['রমজান','যুলহিজ্জা','মুহাররম','রজব'],correct:2,explanation:'মুহাররম ইসলামী হিজরি বর্ষের প্রথম মাস।',reference:''},
  {catId:'history',category:'ইতিহাস',diff:'সহজ',question:'ইসলামের প্রথম খলিফা কে?',options:['উমর (রা.)','আবু বকর (রা.)','আলী (রা.)','উসমান (রা.)'],correct:1,explanation:'আবু বকর সিদ্দিক (রা.) ইসলামের প্রথম খলিফা।',reference:''},
  {catId:'history',category:'ইতিহাস',diff:'মাঝারি',question:'কোন খলিফার শাসনামলে কুরআন গ্রন্থাকারে সংকলিত হয়?',options:['আবু বকর (রা.)','উমর (রা.)','উসমান (রা.)','আলী (রা.)'],correct:2,explanation:'উসমান (রা.) এর শাসনামলে কুরআন একটি নির্দিষ্ট রূপে সংকলিত হয়।',reference:'বুখারি: ৪৯৮৭'},
  {catId:'history',category:'ইতিহাস',diff:'মাঝারি',question:'উহুদের যুদ্ধ কত হিজরিতে হয়েছিল?',options:['২ হিজরি','৩ হিজরি','৪ হিজরি','৫ হিজরি'],correct:1,explanation:'উহুদের যুদ্ধ ৩ হিজরিতে হয়েছিল।',reference:''},
  {catId:'history',category:'ইতিহাস',diff:'কঠিন',question:'কারবালার যুদ্ধ কোন হিজরিতে হয়েছিল?',options:['৪০ হিজরি','৫৭ হিজরি','৬১ হিজরি','৭০ হিজরি'],correct:2,explanation:'কারবালার যুদ্ধ ৬১ হিজরির ১০ মুহাররম (আশুরা) তারিখে হয়েছিল।',reference:''},
  {catId:'history',category:'ইতিহাস',diff:'কঠিন',question:'ইসলামের চার খলিফার মধ্যে সবচেয়ে দীর্ঘ শাসনকাল কার?',options:['আবু বকর (রা.)','উমর (রা.)','উসমান (রা.)','আলী (রা.)'],correct:2,explanation:'উসমান (রা.) ১২ বছর খলিফা ছিলেন, যা চার খলিফার মধ্যে সর্বোচ্চ।',reference:''},
];

// End of Quiz Module

// ══════════════════════════════════════════
// ISLAMIC FINANCE CALCULATOR
// ══════════════════════════════════════════
function renderFinancePage() {
  const body = document.getElementById('finance-body');
  if (!body) return;
  body.innerHTML = `
    <div style="padding:4px 0 24px">

      <!-- Tabs -->
      <div style="display:flex;gap:6px;margin-bottom:20px">
        <button class="fin-tab active" id="fin-tab-zakat" onclick="finTab('zakat')">যাকাত</button>
        <button class="fin-tab" id="fin-tab-fitra" onclick="finTab('fitra')">ফিতরা</button>
        <button class="fin-tab" id="fin-tab-loan" onclick="finTab('loan')">ঋণ ক্যালকুলেটর</button>
      </div>

      <!-- Zakat Panel -->
      <div id="fin-panel-zakat">
        <div style="font-size:0.6875rem;color:var(--t2);line-height:1.6;margin-bottom:16px;padding:12px;background:rgba(var(--accent-rgb),.07);border:1px solid rgba(var(--accent-rgb),.15);border-radius:14px">
          💡 নিসাব: ৮৫ গ্রাম সোনা বা ৫৯৫ গ্রাম রুপার সমতুল্য সম্পদ এক বছর থাকলে ২.৫% যাকাত ফরজ।
        </div>

        <div class="fin-field">
          <label class="fin-label">সোনা (গ্রাম)</label>
          <input class="fin-input" id="zk-gold" type="number" min="0" placeholder="0" oninput="calcZakat()">
        </div>
        <div class="fin-field">
          <label class="fin-label">সোনার বর্তমান দাম (প্রতি গ্রাম, টাকা)</label>
          <input class="fin-input" id="zk-gold-price" type="number" min="0" placeholder="যেমন: ৯০০০" oninput="calcZakat()">
        </div>
        <div class="fin-field">
          <label class="fin-label">রুপা (গ্রাম)</label>
          <input class="fin-input" id="zk-silver" type="number" min="0" placeholder="0" oninput="calcZakat()">
        </div>
        <div class="fin-field">
          <label class="fin-label">রুপার বর্তমান দাম (প্রতি গ্রাম, টাকা)</label>
          <input class="fin-input" id="zk-silver-price" type="number" min="0" placeholder="যেমন: ১১০" oninput="calcZakat()">
        </div>
        <div class="fin-field">
          <label class="fin-label">নগদ টাকা ও ব্যাংক ব্যালেন্স (টাকা)</label>
          <input class="fin-input" id="zk-cash" type="number" min="0" placeholder="0" oninput="calcZakat()">
        </div>
        <div class="fin-field">
          <label class="fin-label">ব্যবসায়িক পণ্যের মূল্য (টাকা)</label>
          <input class="fin-input" id="zk-business" type="number" min="0" placeholder="0" oninput="calcZakat()">
        </div>
        <div class="fin-field">
          <label class="fin-label">বিনিয়োগ / শেয়ার (টাকা)</label>
          <input class="fin-input" id="zk-invest" type="number" min="0" placeholder="0" oninput="calcZakat()">
        </div>
        <div class="fin-field">
          <label class="fin-label">পাওনা টাকা (যা ফেরত পাওয়ার সম্ভাবনা আছে)</label>
          <input class="fin-input" id="zk-receivable" type="number" min="0" placeholder="0" oninput="calcZakat()">
        </div>
        <div class="fin-field">
          <label class="fin-label">বাদ দিন: দেনা / ঋণ (টাকা)</label>
          <input class="fin-input" id="zk-debt" type="number" min="0" placeholder="0" oninput="calcZakat()">
        </div>

        <div id="zakat-result" style="display:none;margin-top:16px;padding:18px;border-radius:18px;background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.2)">
          <div id="zakat-nisab-status" style="font-size:0.75rem;margin-bottom:12px;padding:8px 12px;border-radius:10px"></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
            <div style="text-align:center;padding:12px;background:rgba(0,0,0,.2);border-radius:12px">
              <div style="font-family:'Playfair Display',serif;font-size:1.5rem;color:var(--gold)" id="zakat-total-wealth">০</div>
              <div style="font-size:0.5rem;letter-spacing:.1em;text-transform:uppercase;color:var(--t3);margin-top:2px">মোট যাকাতযোগ্য সম্পদ</div>
            </div>
            <div style="text-align:center;padding:12px;background:rgba(0,0,0,.2);border-radius:12px">
              <div style="font-family:'Playfair Display',serif;font-size:1.5rem;color:var(--green)" id="zakat-amount">০</div>
              <div style="font-size:0.5rem;letter-spacing:.1em;text-transform:uppercase;color:var(--t3);margin-top:2px">প্রদেয় যাকাত (২.৫%)</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Fitra Panel -->
      <div id="fin-panel-fitra" style="display:none">
        <div style="font-size:0.6875rem;color:var(--t2);line-height:1.6;margin-bottom:16px;padding:12px;background:rgba(var(--teal-rgb),.07);border:1px solid rgba(var(--teal-rgb),.15);border-radius:14px">
          💡 ফিতরা ঈদুল ফিতরের নামাজের আগে দিতে হয়। প্রতিজন সদস্যের জন্য ১.৬৫ কেজি গম বা ৩.৩ কেজি যব বা ৩.৩ কেজি খেজুরের সমতুল্য মূল্য।
        </div>
        <div class="fin-field">
          <label class="fin-label">পরিবারের মোট সদস্য সংখ্যা</label>
          <input class="fin-input" id="ft-members" type="number" min="1" placeholder="1" oninput="calcFitra()">
        </div>
        <div class="fin-field">
          <label class="fin-label">হিসাবের ভিত্তি</label>
          <select class="fin-input" id="ft-type" onchange="calcFitra()" style="-webkit-appearance:none;background:rgba(255,255,255,.05)">
            <option value="wheat">গম (১.৬৫ কেজি/জন)</option>
            <option value="barley">যব (৩.৩ কেজি/জন)</option>
            <option value="dates">খেজুর (৩.৩ কেজি/জন)</option>
          </select>
        </div>
        <div class="fin-field">
          <label class="fin-label">প্রতি কেজির বর্তমান দাম (টাকা)</label>
          <input class="fin-input" id="ft-price" type="number" min="0" placeholder="যেমন: ৬০" oninput="calcFitra()">
        </div>
        <div id="fitra-result" style="display:none;margin-top:16px;padding:18px;border-radius:18px;background:rgba(var(--teal-rgb),.08);border:1px solid rgba(var(--teal-rgb),.2)">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
            <div style="text-align:center;padding:12px;background:rgba(0,0,0,.2);border-radius:12px">
              <div style="font-family:'Playfair Display',serif;font-size:1.5rem;color:var(--teal)" id="fitra-per-person">০</div>
              <div style="font-size:0.5rem;letter-spacing:.1em;text-transform:uppercase;color:var(--t3);margin-top:2px">প্রতিজনের ফিতরা</div>
            </div>
            <div style="text-align:center;padding:12px;background:rgba(0,0,0,.2);border-radius:12px">
              <div style="font-family:'Playfair Display',serif;font-size:1.5rem;color:var(--green)" id="fitra-total">০</div>
              <div style="font-size:0.5rem;letter-spacing:.1em;text-transform:uppercase;color:var(--t3);margin-top:2px">মোট ফিতরা</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Loan Panel -->
      <div id="fin-panel-loan" style="display:none">
        <div style="font-size:0.6875rem;color:var(--t2);line-height:1.6;margin-bottom:16px;padding:12px;background:rgba(var(--purple-rgb),.07);border:1px solid rgba(var(--purple-rgb),.15);border-radius:14px">
          💡 ইসলামে সুদমুক্ত ঋণ (কর্জে হাসানা) উৎসাহিত। এই ক্যালকুলেটর সুদমুক্ত সমান কিস্তি হিসাব করে।
        </div>
        <div class="fin-field">
          <label class="fin-label">মোট ঋণের পরিমাণ (টাকা)</label>
          <input class="fin-input" id="ln-amount" type="number" min="0" placeholder="যেমন: ১০০০০০" oninput="calcLoan()">
        </div>
        <div class="fin-field">
          <label class="fin-label">মোট কিস্তির সংখ্যা (মাস)</label>
          <input class="fin-input" id="ln-months" type="number" min="1" placeholder="যেমন: ১২" oninput="calcLoan()">
        </div>
        <div id="loan-result" style="display:none;margin-top:16px;padding:18px;border-radius:18px;background:rgba(var(--purple-rgb),.08);border:1px solid rgba(var(--purple-rgb),.2)">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px">
            <div style="text-align:center;padding:12px;background:rgba(0,0,0,.2);border-radius:12px">
              <div style="font-family:'Playfair Display',serif;font-size:1.5rem;color:var(--purple)" id="loan-monthly">০</div>
              <div style="font-size:0.5rem;letter-spacing:.1em;text-transform:uppercase;color:var(--t3);margin-top:2px">মাসিক কিস্তি</div>
            </div>
            <div style="text-align:center;padding:12px;background:rgba(0,0,0,.2);border-radius:12px">
              <div style="font-family:'Playfair Display',serif;font-size:1.5rem;color:var(--teal)" id="loan-total">০</div>
              <div style="font-size:0.5rem;letter-spacing:.1em;text-transform:uppercase;color:var(--t3);margin-top:2px">মোট পরিশোধ</div>
            </div>
          </div>
          <div id="loan-schedule" style="margin-top:10px;max-height:200px;overflow-y:auto;border-radius:12px;background:rgba(0,0,0,.15)"></div>
        </div>
      </div>

    </div>
  `;

  // Add styles
  if (!document.getElementById('fin-styles')) {
    const s = document.createElement('style');
    s.id = 'fin-styles';
    s.textContent = `
      .fin-tab{flex:1;padding:9px 4px;border-radius:12px;border:1px solid rgba(255,255,255,.09);background:rgba(255,255,255,.04);color:var(--t2);font-family:'Manrope',sans-serif;font-size:0.6875rem;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:all .18s}
      .fin-tab.active{background:rgba(var(--accent-rgb),.12);border-color:rgba(var(--accent-rgb),.35);color:var(--gold)}
      .fin-field{margin-bottom:12px}
      .fin-label{display:block;font-size:0.5625rem;letter-spacing:.1em;text-transform:uppercase;color:var(--t3);margin-bottom:5px}
      .fin-input{width:100%;background:rgba(255,255,255,.05);border:1px solid var(--bd);border-radius:12px;padding:11px 14px;color:var(--text);font-family:'Manrope',sans-serif;font-size:0.9375rem;outline:none;-webkit-appearance:none}
      .fin-input:focus{border-color:rgba(var(--accent-rgb),.4)}
    `;
    document.head.appendChild(s);
  }
}

function finTab(tab) {
  ['zakat','fitra','loan'].forEach(t => {
    document.getElementById(`fin-tab-${t}`)?.classList.toggle('active', t === tab);
    const p = document.getElementById(`fin-panel-${t}`);
    if (p) p.style.display = t === tab ? 'block' : 'none';
  });
}

function fmtTk(n) {
  return '৳' + Math.round(n).toLocaleString('bn-BD');
}

function calcZakat() {
  const goldG   = parseFloat(document.getElementById('zk-gold')?.value) || 0;
  const goldP   = parseFloat(document.getElementById('zk-gold-price')?.value) || 0;
  const silverG = parseFloat(document.getElementById('zk-silver')?.value) || 0;
  const silverP = parseFloat(document.getElementById('zk-silver-price')?.value) || 0;
  const cash    = parseFloat(document.getElementById('zk-cash')?.value) || 0;
  const biz     = parseFloat(document.getElementById('zk-business')?.value) || 0;
  const invest  = parseFloat(document.getElementById('zk-invest')?.value) || 0;
  const recv    = parseFloat(document.getElementById('zk-receivable')?.value) || 0;
  const debt    = parseFloat(document.getElementById('zk-debt')?.value) || 0;

  const goldVal   = goldG * goldP;
  const silverVal = silverG * silverP;
  const total = goldVal + silverVal + cash + biz + invest + recv - debt;
  const zakatable = Math.max(0, total);

  // Nisab = 85g gold or 595g silver — use whichever user has entered prices for
  const nisabGold   = goldP > 0 ? 85 * goldP : Infinity;
  const nisabSilver = silverP > 0 ? 595 * silverP : Infinity;
  const nisab = Math.min(nisabGold, nisabSilver);

  const result = document.getElementById('zakat-result');
  const status = document.getElementById('zakat-nisab-status');
  if (!result) return;
  result.style.display = 'block';

  if (nisab === Infinity) {
    status.style.background = 'rgba(var(--amber-rgb),.1)';
    status.style.color = 'var(--amber)';
    status.textContent = '⚠️ সোনা বা রুপার দাম দিন নিসাব নির্ধারণের জন্য।';
    document.getElementById('zakat-total-wealth').textContent = fmtTk(zakatable);
    document.getElementById('zakat-amount').textContent = fmtTk(zakatable * 0.025);
    return;
  }

  if (zakatable >= nisab) {
    status.style.background = 'rgba(var(--green-rgb),.1)';
    status.style.color = 'var(--green)';
    status.textContent = '✅ নিসাব পূর্ণ হয়েছে — যাকাত ফরজ।';
  } else {
    status.style.background = 'rgba(var(--rose-rgb),.1)';
    status.style.color = 'var(--rose)';
    status.textContent = `❌ নিসাব পূর্ণ হয়নি (নিসাব: ${fmtTk(nisab)}) — যাকাত ফরজ নয়।`;
  }

  document.getElementById('zakat-total-wealth').textContent = fmtTk(zakatable);
  document.getElementById('zakat-amount').textContent = zakatable >= nisab ? fmtTk(zakatable * 0.025) : '০';
}

function calcFitra() {
  const members = parseFloat(document.getElementById('ft-members')?.value) || 0;
  const type    = document.getElementById('ft-type')?.value || 'wheat';
  const price   = parseFloat(document.getElementById('ft-price')?.value) || 0;

  const kg = type === 'wheat' ? 1.65 : 3.3;
  const perPerson = kg * price;
  const total = perPerson * members;

  const result = document.getElementById('fitra-result');
  if (!result) return;
  result.style.display = members > 0 && price > 0 ? 'block' : 'none';
  document.getElementById('fitra-per-person').textContent = fmtTk(perPerson);
  document.getElementById('fitra-total').textContent = fmtTk(total);
}

function calcLoan() {
  const amount = parseFloat(document.getElementById('ln-amount')?.value) || 0;
  const months = parseInt(document.getElementById('ln-months')?.value) || 0;

  const result = document.getElementById('loan-result');
  if (!result) return;
  if (amount <= 0 || months <= 0) { result.style.display = 'none'; return; }
  result.style.display = 'block';

  const monthly = amount / months;
  document.getElementById('loan-monthly').textContent = fmtTk(monthly);
  document.getElementById('loan-total').textContent = fmtTk(amount);

  // Schedule
  let schedule = `<table style="width:100%;border-collapse:collapse;font-size:0.6875rem">
    <tr style="color:var(--t3)"><td style="padding:6px 10px">কিস্তি</td><td style="padding:6px 10px;text-align:right">পরিমাণ</td><td style="padding:6px 10px;text-align:right">বাকি</td></tr>`;
  for (let i = 1; i <= Math.min(months, 24); i++) {
    const remaining = Math.max(0, amount - monthly * i);
    schedule += `<tr style="border-top:1px solid rgba(255,255,255,.05)">
      <td style="padding:6px 10px;color:var(--t2)">${i} মাস</td>
      <td style="padding:6px 10px;text-align:right;color:var(--purple)">${fmtTk(monthly)}</td>
      <td style="padding:6px 10px;text-align:right;color:var(--t3)">${fmtTk(remaining)}</td>
    </tr>`;
  }
  if (months > 24) schedule += `<tr><td colspan="3" style="padding:8px 10px;text-align:center;color:var(--t3);font-size:0.625rem">... মোট ${months} কিস্তি</td></tr>`;
  schedule += '</table>';
  document.getElementById('loan-schedule').innerHTML = schedule;
}

// ══════════════════════════════════════════════
//  NAME MEANING SEARCH
// ══════════════════════════════════════════════
const NAMES_DB = [
  // Boys
  {name:'Muhammad',arabic:'مُحَمَّد',gender:'ছেলে',meaning:'প্রশংসিত, যাকে বারবার প্রশংসা করা হয়',origin:'আরবি',tags:['নবী','জনপ্রিয়']},
  {name:'Ahmed',arabic:'أَحْمَد',gender:'ছেলে',meaning:'অত্যন্ত প্রশংসনীয়, সবচেয়ে বেশি প্রশংসিত',origin:'আরবি',tags:['নবী']},
  {name:'Abdullah',arabic:'عَبْدُ اللّٰه',gender:'ছেলে',meaning:'আল্লাহর বান্দা',origin:'আরবি',tags:['সাহাবী']},
  {name:'Ibrahim',arabic:'إِبْرَاهِيم',gender:'ছেলে',meaning:'বহু জাতির পিতা, আল্লাহর বন্ধু',origin:'হিব্রু/আরবি',tags:['নবী']},
  {name:'Ismail',arabic:'إِسْمَاعِيل',gender:'ছেলে',meaning:'আল্লাহ শুনেছেন',origin:'আরবি',tags:['নবী']},
  {name:'Yusuf',arabic:'يُوسُف',gender:'ছেলে',meaning:'আল্লাহ বৃদ্ধি করুন, সৌন্দর্যময়',origin:'আরবি',tags:['নবী']},
  {name:'Musa',arabic:'مُوسَى',gender:'ছেলে',meaning:'পানি থেকে রক্ষাপ্রাপ্ত',origin:'মিশরীয়/আরবি',tags:['নবী']},
  {name:'Isa',arabic:'عِيسَى',gender:'ছেলে',meaning:'আল্লাহর রহমত',origin:'আরবি',tags:['নবী']},
  {name:'Ali',arabic:'عَلِيّ',gender:'ছেলে',meaning:'উচ্চ মর্যাদাসম্পন্ন, মহৎ',origin:'আরবি',tags:['সাহাবী']},
  {name:'Hassan',arabic:'حَسَن',gender:'ছেলে',meaning:'সুন্দর, উত্তম',origin:'আরবি',tags:['সাহাবী']},
  {name:'Hussain',arabic:'حُسَيْن',gender:'ছেলে',meaning:'অতি সুন্দর, ছোট্ট সুন্দর',origin:'আরবি',tags:['সাহাবী']},
  {name:'Omar',arabic:'عُمَر',gender:'ছেলে',meaning:'দীর্ঘজীবী, বসবাসকারী',origin:'আরবি',tags:['সাহাবী','খলিফা']},
  {name:'Uthman',arabic:'عُثْمَان',gender:'ছেলে',meaning:'বাচ্চা বাস্টার্ড, সাপের বাচ্চা (শক্তিশালী)',origin:'আরবি',tags:['সাহাবী','খলিফা']},
  {name:'Abu Bakr',arabic:'أَبُو بَكْر',gender:'ছেলে',meaning:'উটের বাচ্চার পিতা, তরুণের পিতা',origin:'আরবি',tags:['সাহাবী','খলিফা']},
  {name:'Khalid',arabic:'خَالِد',gender:'ছেলে',meaning:'চিরন্তন, অমর',origin:'আরবি',tags:['সাহাবী']},
  {name:'Bilal',arabic:'بِلَال',gender:'ছেলে',meaning:'আর্দ্রতা, সতেজতা',origin:'আরবি',tags:['সাহাবী']},
  {name:'Salman',arabic:'سَلْمَان',gender:'ছেলে',meaning:'নিরাপদ, শান্তিপূর্ণ',origin:'আরবি',tags:['সাহাবী']},
  {name:'Hamza',arabic:'حَمْزَة',gender:'ছেলে',meaning:'সিংহ, শক্তিশালী',origin:'আরবি',tags:['সাহাবী']},
  {name:'Zaid',arabic:'زَيْد',gender:'ছেলে',meaning:'বৃদ্ধি, প্রাচুর্য',origin:'আরবি',tags:['সাহাবী']},
  {name:'Talha',arabic:'طَلْحَة',gender:'ছেলে',meaning:'তালগাছ, উদার',origin:'আরবি',tags:['সাহাবী']},
  {name:'Sufyan',arabic:'سُفْيَان',gender:'ছেলে',meaning:'দ্রুতগামী, বায়ু',origin:'আরবি',tags:[]},
  {name:'Rayyan',arabic:'رَيَّان',gender:'ছেলে',meaning:'জান্নাতের একটি দরজা, তৃপ্ত',origin:'আরবি',tags:['জান্নাত']},
  {name:'Mikail',arabic:'مِيكَائِيل',gender:'ছেলে',meaning:'আল্লাহর মতো কে',origin:'আরবি',tags:['ফেরেশতা']},
  {name:'Jibrail',arabic:'جِبْرَائِيل',gender:'ছেলে',meaning:'আল্লাহর শক্তি',origin:'আরবি',tags:['ফেরেশতা']},
  {name:'Nuh',arabic:'نُوح',gender:'ছেলে',meaning:'বিশ্রাম, সান্ত্বনা',origin:'আরবি',tags:['নবী']},
  {name:'Dawud',arabic:'دَاوُد',gender:'ছেলে',meaning:'প্রিয়, প্রিয়জন',origin:'আরবি',tags:['নবী']},
  {name:'Sulaiman',arabic:'سُلَيْمَان',gender:'ছেলে',meaning:'শান্তিপূর্ণ, শান্তির মানুষ',origin:'আরবি',tags:['নবী']},
  {name:'Yahya',arabic:'يَحْيَى',gender:'ছেলে',meaning:'সে জীবিত থাকবে',origin:'আরবি',tags:['নবী']},
  {name:'Idris',arabic:'إِدْرِيس',gender:'ছেলে',meaning:'পাঠক, অধ্যয়নকারী',origin:'আরবি',tags:['নবী']},
  {name:'Haroon',arabic:'هَارُون',gender:'ছেলে',meaning:'পর্বত, উচ্চ',origin:'আরবি',tags:['নবী']},
  {name:'Ayyub',arabic:'أَيُّوب',gender:'ছেলে',meaning:'ধৈর্যশীল, আল্লাহর দিকে প্রত্যাবর্তনকারী',origin:'আরবি',tags:['নবী']},
  {name:'Yunus',arabic:'يُونُس',gender:'ছেলে',meaning:'কপট, পায়রা',origin:'আরবি',tags:['নবী']},
  {name:'Luqman',arabic:'لُقْمَان',gender:'ছেলে',meaning:'জ্ঞানী, বিচক্ষণ',origin:'আরবি',tags:[]},
  {name:'Anas',arabic:'أَنَس',gender:'ছেলে',meaning:'বন্ধুত্বপূর্ণ, ঘনিষ্ঠ',origin:'আরবি',tags:['সাহাবী']},
  {name:'Jabir',arabic:'جَابِر',gender:'ছেলে',meaning:'সান্ত্বনাদাতা, মেরামতকারী',origin:'আরবি',tags:['সাহাবী']},
  {name:'Umar',arabic:'عُمَر',gender:'ছেলে',meaning:'দীর্ঘজীবী',origin:'আরবি',tags:[]},
  {name:'Faisal',arabic:'فَيْصَل',gender:'ছেলে',meaning:'বিচারক, নির্ধারণকারী',origin:'আরবি',tags:[]},
  {name:'Saad',arabic:'سَعْد',gender:'ছেলে',meaning:'সুখী, সৌভাগ্যবান',origin:'আরবি',tags:['সাহাবী']},
  {name:'Tariq',arabic:'طَارِق',gender:'ছেলে',meaning:'রাতে আসা, তারা',origin:'আরবি',tags:[]},
  {name:'Imran',arabic:'عِمْرَان',gender:'ছেলে',meaning:'সমৃদ্ধ, সভ্য',origin:'আরবি',tags:['কুরআন']},
  {name:'Adnan',arabic:'عَدْنَان',gender:'ছেলে',meaning:'স্থায়ী বাসিন্দা',origin:'আরবি',tags:[]},
  {name:'Asad',arabic:'أَسَد',gender:'ছেলে',meaning:'সিংহ',origin:'আরবি',tags:[]},
  {name:'Fahad',arabic:'فَهَد',gender:'ছেলে',meaning:'চিতাবাঘ',origin:'আরবি',tags:[]},
  {name:'Kamrul',arabic:'كَامِل',gender:'ছেলে',meaning:'পূর্ণাঙ্গ, সম্পূর্ণ',origin:'আরবি',tags:[]},
  {name:'Nabil',arabic:'نَبِيل',gender:'ছেলে',meaning:'মহৎ, উদার',origin:'আরবি',tags:[]},
  {name:'Rafi',arabic:'رَافِع',gender:'ছেলে',meaning:'উচ্চকারী, উন্নতকারী',origin:'আরবি',tags:[]},
  {name:'Sabbir',arabic:'صَابِر',gender:'ছেলে',meaning:'ধৈর্যশীল',origin:'আরবি',tags:[]},
  {name:'Toukir',arabic:'تَوْقِير',gender:'ছেলে',meaning:'সম্মান, মর্যাদা, শ্রদ্ধা',origin:'আরবি',tags:['বিশেষ']},
  {name:'Washim',arabic:'وَسِيم',gender:'ছেলে',meaning:'সুদর্শন, সুন্দর চেহারার',origin:'আরবি',tags:[]},
  // Girls
  {name:'Fatima',arabic:'فَاطِمَة',gender:'মেয়ে',meaning:'দুধ ছাড়ানো, বিরত রাখা',origin:'আরবি',tags:['সাহাবী','নবীর মেয়ে']},
  {name:'Aisha',arabic:'عَائِشَة',gender:'মেয়ে',meaning:'জীবন্ত, প্রাণবন্ত',origin:'আরবি',tags:['সাহাবী','নবীর স্ত্রী']},
  {name:'Khadija',arabic:'خَدِيجَة',gender:'মেয়ে',meaning:'সময়ের আগে জন্মানো',origin:'আরবি',tags:['সাহাবী','নবীর স্ত্রী']},
  {name:'Maryam',arabic:'مَرْيَم',gender:'মেয়ে',meaning:'সমুদ্রের বিন্দু, প্রিয়',origin:'আরবি',tags:['কুরআন','নবীর মা']},
  {name:'Zainab',arabic:'زَيْنَب',gender:'মেয়ে',meaning:'সুগন্ধি ফুলের গাছ',origin:'আরবি',tags:['সাহাবী']},
  {name:'Hafsa',arabic:'حَفْصَة',gender:'মেয়ে',meaning:'সিংহীর বাচ্চা',origin:'আরবি',tags:['নবীর স্ত্রী']},
  {name:'Asma',arabic:'أَسْمَاء',gender:'মেয়ে',meaning:'উচ্চ মর্যাদার, নামসমূহ',origin:'আরবি',tags:['সাহাবী']},
  {name:'Sumaya',arabic:'سُمَيَّة',gender:'মেয়ে',meaning:'উচ্চে, উঁচু',origin:'আরবি',tags:['সাহাবী']},
  {name:'Ruqayyah',arabic:'رُقَيَّة',gender:'মেয়ে',meaning:'উপরে উঠা, অগ্রগতি',origin:'আরবি',tags:['নবীর মেয়ে']},
  {name:'Safiya',arabic:'صَفِيَّة',gender:'মেয়ে',meaning:'বিশুদ্ধ, নির্মল',origin:'আরবি',tags:['নবীর স্ত্রী']},
  {name:'Nusaiba',arabic:'نُسَيْبَة',gender:'মেয়ে',meaning:'মর্যাদাশীলা',origin:'আরবি',tags:['সাহাবী']},
  {name:'Sakina',arabic:'سَكِينَة',gender:'মেয়ে',meaning:'শান্তি, স্থিরতা',origin:'আরবি',tags:[]},
  {name:'Tasnim',arabic:'تَسْنِيم',gender:'মেয়ে',meaning:'জান্নাতের একটি ঝরনা',origin:'আরবি',tags:['জান্নাত','কুরআন']},
  {name:'Raihana',arabic:'رَيْحَانَة',gender:'মেয়ে',meaning:'সুগন্ধি ফুল, তুলসী',origin:'আরবি',tags:[]},
  {name:'Noor',arabic:'نُور',gender:'মেয়ে',meaning:'আলো, জ্যোতি',origin:'আরবি',tags:[]},
  {name:'Lamia',arabic:'لَامِيَة',gender:'মেয়ে',meaning:'উজ্জ্বল, দীপ্তিময়',origin:'আরবি',tags:[]},
  {name:'Sadia',arabic:'سَعْدِيَّة',gender:'মেয়ে',meaning:'সুখী, সৌভাগ্যবতী',origin:'আরবি',tags:[]},
  {name:'Tanha',arabic:'تَنْها',gender:'মেয়ে',meaning:'একা, একাকী (রহস্যময়)',origin:'ফার্সি',tags:[]},
  {name:'Runa',arabic:'رُونَا',gender:'মেয়ে',meaning:'প্রবাহিত, গতিশীল',origin:'আরবি/স্ক্যান্ডিনেভিয়ান',tags:[]},
  {name:'Mahira',arabic:'مَاهِرَة',gender:'মেয়ে',meaning:'দক্ষ, বিশেষজ্ঞ',origin:'আরবি',tags:[]},
  {name:'Fariha',arabic:'فَارِحَة',gender:'মেয়ে',meaning:'আনন্দিত, খুশি',origin:'আরবি',tags:[]},
  {name:'Munira',arabic:'مُنِيرَة',gender:'মেয়ে',meaning:'আলোকময়, উজ্জ্বল',origin:'আরবি',tags:[]},
  {name:'Naima',arabic:'نَعِيمَة',gender:'মেয়ে',meaning:'আরামদায়ক জীবনযাপনকারী',origin:'আরবি',tags:[]},
  {name:'Tahmina',arabic:'تَهْمِينَة',gender:'মেয়ে',meaning:'প্রশংসিত, মূল্যবান',origin:'ফার্সি',tags:[]},
  {name:'Shaima',arabic:'شَيْمَاء',gender:'মেয়ে',meaning:'সুন্দর নৈতিক চরিত্রের',origin:'আরবি',tags:['সাহাবী']},
  {name:'Umm Kulthum',arabic:'أُمّ كُلْثُوم',gender:'মেয়ে',meaning:'গালভরা সন্তানের মা',origin:'আরবি',tags:['নবীর মেয়ে']},
  {name:'Jannatul',arabic:'جَنَّة',gender:'মেয়ে',meaning:'জান্নাত, বেহেশত',origin:'আরবি',tags:['জান্নাত']},
  {name:'Minhaj',arabic:'مِنْهَاج',gender:'ছেলে',meaning:'পথ, পদ্ধতি, মিনার',origin:'আরবি',tags:[]},
  {name:'Arif',arabic:'عَارِف',gender:'ছেলে',meaning:'জ্ঞানী, পরিচিত',origin:'আরবি',tags:[]},
  {name:'Barakah',arabic:'بَرَكَة',gender:'মেয়ে',meaning:'বরকত, আশীর্বাদ',origin:'আরবি',tags:['সাহাবী']},
];

let _nmQuery = '';
let _nmAiCache = {}; // name -> result cache
let _nmSearchTimer = null;

function _nmGetApiKey() {
  return localStorage.getItem('mrd_claude_api_key') || '';
}
function _nmSaveApiKey(k) {
  localStorage.setItem('mrd_claude_api_key', k.trim());
}

function renderNamesPage() {
  const body = document.getElementById('names-body');
  if (!body) return;
  body.innerHTML = `
    <div style="padding:4px 0 32px">

      <!-- API Key Banner (shown if no key) -->
      <div id="nm-key-banner" style="display:${_nmGetApiKey()?'none':'block'};margin-bottom:14px;padding:12px 14px;border-radius:14px;border:1px solid rgba(var(--accent-rgb),.25);background:rgba(var(--accent-rgb),.07)">
        <div style="font-size:0.6875rem;color:var(--gold);font-weight:600;margin-bottom:6px">🔑 Claude API Key দরকার</div>
        <div style="font-size:0.625rem;color:var(--t2);margin-bottom:10px;line-height:1.6">যেকোনো নামের অর্থ AI দিয়ে বের করতে Anthropic API key লাগবে। Console.anthropic.com থেকে নিন।</div>
        <div style="display:flex;gap:6px">
          <input id="nm-key-input" type="password" placeholder="sk-ant-..."
            style="flex:1;padding:8px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.12);background:rgba(0,0,0,.25);color:var(--t1);font-family:'Manrope',sans-serif;font-size:0.6875rem;outline:none;-webkit-appearance:none">
          <button onclick="_nmSaveKey()" style="padding:8px 14px;border-radius:10px;border:none;background:var(--gold);color:#1a1108;font-family:'Manrope',sans-serif;font-size:0.6875rem;font-weight:700;cursor:pointer">Save</button>
        </div>
      </div>

      <!-- Search Box -->
      <div style="position:relative;margin-bottom:10px">
        <input id="nm-search" type="text" placeholder="যেকোনো নাম লিখুন... (Ahmed, রাইয়ান, Zara...)"
          value="${_nmQuery}"
          oninput="_nmOnInput(this.value)"
          style="width:100%;box-sizing:border-box;padding:12px 16px 12px 42px;border-radius:14px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.05);color:var(--t1);font-family:'Manrope',sans-serif;font-size:0.8125rem;outline:none;-webkit-appearance:none;transition:border-color .18s"
          onfocus="this.style.borderColor='rgba(var(--purple-rgb),.4)'"
          onblur="this.style.borderColor='rgba(255,255,255,.12)'">
        <svg style="position:absolute;left:14px;top:50%;transform:translateY(-50%);opacity:.4;pointer-events:none" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
      </div>
      <div style="font-size:0.5625rem;color:var(--t3);margin-bottom:16px;padding-left:2px">AI যেকোনো আরবি/ইসলামিক নামের বিস্তারিত অর্থ বলবে ✨</div>

      <!-- Results Area -->
      <div id="nm-results">
        ${_nmQuery ? '' : _nmRenderPopular()}
      </div>
    </div>
  `;
  setTimeout(()=>{ const el=document.getElementById('nm-search'); if(el) el.focus(); }, 120);
  // If there was a previous query, re-trigger search
  if (_nmQuery && _nmAiCache[_nmQuery.trim().toLowerCase()]) {
    _nmShowResult(_nmQuery.trim(), _nmAiCache[_nmQuery.trim().toLowerCase()]);
  }
}

function _nmSaveKey() {
  const inp = document.getElementById('nm-key-input');
  if (!inp || !inp.value.trim()) return;
  _nmSaveApiKey(inp.value.trim());
  const banner = document.getElementById('nm-key-banner');
  if (banner) { banner.style.opacity='0'; banner.style.transition='opacity .3s'; setTimeout(()=>banner.style.display='none',300); }
}

function _nmOnInput(v) {
  _nmQuery = v;
  clearTimeout(_nmSearchTimer);
  const container = document.getElementById('nm-results');
  if (!v.trim()) {
    if (container) container.innerHTML = _nmRenderPopular();
    return;
  }
  // Check local DB first
  const localHit = NAMES_DB.find(n => n.name.toLowerCase() === v.trim().toLowerCase());
  if (localHit) { _nmShowResult(v.trim(), localHit); return; }
  // Check cache
  const cacheKey = v.trim().toLowerCase();
  if (_nmAiCache[cacheKey]) { _nmShowResult(v.trim(), _nmAiCache[cacheKey]); return; }
  // Debounce AI call
  if (container) container.innerHTML = `<div style="text-align:center;padding:32px 0;color:var(--t3);font-size:0.6875rem">টাইপ করুন...</div>`;
  _nmSearchTimer = setTimeout(() => _nmAiSearch(v.trim()), 700);
}

async function _nmAiSearch(name) {
  if (!name) return;
  const container = document.getElementById('nm-results');
  if (!container) return;
  const key = _nmGetApiKey();
  if (!key) {
    container.innerHTML = `<div style="text-align:center;padding:32px 0;color:var(--t3);font-size:0.6875rem">🔑 API key দিন উপরে</div>`;
    return;
  }
  // Loading state
  container.innerHTML = `
    <div style="padding:20px 16px;border-radius:16px;border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.03)">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
        <div style="width:36px;height:36px;border-radius:50%;background:rgba(var(--purple-rgb),.15);display:flex;align-items:center;justify-content:center;font-size:1rem">🔤</div>
        <div>
          <div style="font-size:0.9375rem;font-weight:600;color:var(--t1)">${name}</div>
          <div style="font-size:0.5625rem;color:var(--t3);margin-top:2px">অর্থ খোঁজা হচ্ছে...</div>
        </div>
      </div>
      <div style="display:flex;gap:5px;padding-top:4px">
        ${[0,1,2].map(i=>`<div style="height:6px;flex:1;border-radius:99px;background:rgba(var(--purple-rgb),.15);overflow:hidden"><div style="height:100%;width:40%;background:rgba(var(--purple-rgb),.5);border-radius:99px;animation:_nmShimmer 1.2s ${i*0.2}s infinite"></div></div>`).join('')}
      </div>
    </div>
    <style>@keyframes _nmShimmer{0%{transform:translateX(-100%)}100%{transform:translateX(300%)}}</style>
  `;
  try {
    const resp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 512,
        messages: [{
          role: 'user',
          content: `You are an Islamic name expert. For the name "${name}", respond ONLY with a valid JSON object (no markdown, no backticks) in this exact format:
{
  "name": "name in English",
  "arabic": "Arabic script",
  "gender": "ছেলে or মেয়ে or উভয়",
  "meaning": "বাংলায় অর্থ (2-3 sentences)",
  "origin": "language origin in Bangla",
  "virtue": "ইসলামিক গুরুত্ব বা ফজিলত (1-2 sentences in Bangla)",
  "tags": ["tag1","tag2"],
  "found": true
}
If not an Islamic/Arabic name, return {"found": false, "name": "${name}"}.`
        }]
      })
    });
    const data = await resp.json();
    if (data.error) throw new Error(data.error.message);
    const text = data.content?.[0]?.text || '';
    const cleaned = text.replace(/```json|```/g,'').trim();
    const result = JSON.parse(cleaned);
    const cacheKey = name.toLowerCase();
    _nmAiCache[cacheKey] = result;
    _nmShowResult(name, result);
  } catch(e) {
    if (container) container.innerHTML = `
      <div style="text-align:center;padding:32px 16px;border-radius:16px;border:1px solid rgba(var(--rose-rgb),.15);background:rgba(var(--rose-rgb),.05)">
        <div style="font-size:1.5rem;margin-bottom:8px">⚠️</div>
        <div style="font-size:0.6875rem;color:var(--rose)">অর্থ আনতে সমস্যা হয়েছে</div>
        <div style="font-size:0.5625rem;color:var(--t3);margin-top:4px">${e.message||'নেটওয়ার্ক বা API key চেক করুন'}</div>
        <button onclick="_nmAiSearch('${name}')" style="margin-top:12px;padding:7px 16px;border-radius:99px;border:1px solid rgba(255,255,255,.1);background:transparent;color:var(--t2);font-family:'Manrope',sans-serif;font-size:0.625rem;cursor:pointer">আবার চেষ্টা করুন</button>
      </div>`;
  }
}

function _nmShowResult(name, r) {
  const container = document.getElementById('nm-results');
  if (!container) return;
  if (!r || r.found === false) {
    container.innerHTML = `
      <div style="text-align:center;padding:36px 16px;border-radius:16px;border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.02)">
        <div style="font-size:2rem;margin-bottom:10px">🤔</div>
        <div style="font-size:0.75rem;color:var(--t2);font-weight:600">"${name}" — ইসলামিক নাম নয়</div>
        <div style="font-size:0.625rem;color:var(--t3);margin-top:6px">আরবি বা ইসলামিক নাম লিখুন</div>
      </div>`;
    return;
  }
  const isGirl = r.gender === 'মেয়ে';
  const accentColor = isGirl ? 'rgba(var(--rose-rgb),' : 'rgba(var(--teal-rgb),';
  container.innerHTML = `
    <div style="border-radius:18px;border:1px solid ${accentColor}.2);background:linear-gradient(135deg,${accentColor}.06) 0%,rgba(255,255,255,.02) 100%);overflow:hidden">
      <!-- Top bar -->
      <div style="height:3px;background:linear-gradient(90deg,${accentColor}.8),${accentColor}.3))"></div>
      <div style="padding:18px 16px 16px">

        <!-- Name + Arabic -->
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px">
          <div>
            <div style="font-size:1.5rem;font-weight:700;color:var(--t1);letter-spacing:.01em">${r.name||name}</div>
            <span style="font-size:0.5625rem;padding:3px 9px;border-radius:99px;background:${accentColor}.15);color:${isGirl?'var(--rose)':'rgba(var(--teal-rgb),1)'};margin-top:4px;display:inline-block">${r.gender||''}</span>
          </div>
          <div style="text-align:right">
            <div style="font-family:'Scheherazade New','Amiri',serif;font-size:1.75rem;color:var(--gold);direction:rtl;line-height:1.2">${r.arabic||''}</div>
            <div style="font-size:0.5rem;color:var(--t3);margin-top:2px;letter-spacing:.06em">${r.origin||''}</div>
          </div>
        </div>

        <!-- Meaning -->
        <div style="padding:12px;border-radius:12px;background:rgba(0,0,0,.2);margin-bottom:12px">
          <div style="font-size:0.5625rem;color:var(--gold);letter-spacing:.1em;text-transform:uppercase;margin-bottom:6px">📖 অর্থ</div>
          <div style="font-size:0.8125rem;color:var(--t1);line-height:1.7">${r.meaning||''}</div>
        </div>

        <!-- Virtue -->
        ${r.virtue ? `
        <div style="padding:12px;border-radius:12px;background:rgba(var(--accent-rgb),.06);border:1px solid rgba(var(--accent-rgb),.12);margin-bottom:12px">
          <div style="font-size:0.5625rem;color:var(--gold);letter-spacing:.1em;text-transform:uppercase;margin-bottom:6px">✨ ইসলামিক গুরুত্ব</div>
          <div style="font-size:0.75rem;color:var(--t2);line-height:1.7">${r.virtue}</div>
        </div>` : ''}

        <!-- Tags -->
        ${r.tags?.length ? `
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          ${r.tags.map(t=>`<span style="font-size:0.5rem;padding:3px 8px;border-radius:99px;background:rgba(var(--accent-rgb),.1);color:var(--gold);letter-spacing:.05em">${t}</span>`).join('')}
        </div>` : ''}

      </div>
    </div>

    <!-- Search another -->
    <div style="text-align:center;margin-top:16px;font-size:0.5625rem;color:var(--t3)">আরেকটি নাম খুঁজতে উপরে টাইপ করুন 🔍</div>
  `;
}

function _nmRenderPopular() {
  const popular = ['Muhammad','Ahmed','Fatima','Maryam','Rayyan','Tasnim','Yusuf','Aisha','Khalid','Noor'];
  return `
    <div>
      <div style="font-size:0.5625rem;color:var(--t3);letter-spacing:.1em;text-transform:uppercase;margin-bottom:10px">জনপ্রিয় নাম</div>
      <div style="display:flex;flex-wrap:wrap;gap:7px">
        ${popular.map(n=>`
          <button onclick="document.getElementById('nm-search').value='${n}';_nmOnInput('${n}')"
            style="padding:7px 13px;border-radius:99px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04);color:var(--t2);font-family:'Manrope',sans-serif;font-size:0.6875rem;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:all .18s"
            onmouseenter="this.style.borderColor='rgba(var(--purple-rgb),.4)';this.style.color='#c4b5fd'"
            onmouseleave="this.style.borderColor='rgba(255,255,255,.1)';this.style.color='var(--t2)'">${n}</button>
        `).join('')}
      </div>
    </div>
  `;
}

