
// ── Quran search improvements v7: typed highlight, nearby ayahs, better Bangla number parsing ──
(function(){
  function _qrEscRe(s){ return String(s || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  function _qrBdDigitsToAscii(s){
    return String(s || '').replace(/[০-৯]/g, d => '০১২৩৪৫৬৭৮৯'.indexOf(d));
  }

  const _qrSmallNumMap = {
    'zero':0,'শূন্য':0,
    'one':1,'ek':1,'এক':1,
    'two':2,'dui':2,'দুই':2,
    'three':3,'tin':3,'তিন':3,
    'four':4,'char':4,'চার':4,
    'five':5,'pach':5,'পাঁচ':5,
    'six':6,'choy':6,'ছয়':6,'ছয়':6,
    'seven':7,'sat':7,'সাত':7,
    'eight':8,'at':8,'আট':8,
    'nine':9,'noy':9,'নয়':9,'নয়':9,
    'ten':10,'dosh':10,'দশ':10,
    'eleven':11,'এগারো':11,'egarো':11,'egaro':11,
    'twelve':12,'বারো':12,'baro':12,
    'thirteen':13,'তেরো':13,'tero':13,
    'fourteen':14,'চৌদ্দ':14,'chouddo':14,'choddo':14,
    'fifteen':15,'পনেরো':15,'ponero':15,
    'sixteen':16,'ষোলো':16,'solo':16,'sholo':16,
    'seventeen':17,'সতেরো':17,'shotero':17,'sotero':17,
    'eighteen':18,'আঠারো':18,'atharo':18,
    'nineteen':19,'উনিশ':19,'unish':19,
    'twenty':20,'বিশ':20,'bish':20,
    'thirty':30,'ত্রিশ':30,'trish':30,
    'forty':40,'চল্লিশ':40,'chollish':40,
    'fifty':50,'পঞ্চাশ':50,'ponchash':50,
    'sixty':60,'ষাট':60,'shat':60,'saatty?':60,
    'seventy':70,'সত্তর':70,'sottor':70,
    'eighty':80,'আশি':80,'ashi':80,
    'ninety':90,'নব্বই':90,'nobboi':90,
    'hundred':100,'শত':100,'একশ':100,'একশো':100,'একশত':100,'sho':100,'shoto':100
  };
  const _qrCompoundBangla = {
    'একুশ':21,'বাইশ':22,'তেইশ':23,'চব্বিশ':24,'পঁচিশ':25,'পঁচিশ':25,'ছাব্বিশ':26,'সাতাশ':27,'আটাশ':28,'ঊনত্রিশ':29,'ঊনত্রিশ':29,
    'ত্রিশ':30,'একত্রিশ':31,'বত্রিশ':32,'তেত্রিশ':33,'চৌত্রিশ':34,'পঁয়ত্রিশ':35,'পয়ত্রিশ':35,'ছত্রিশ':36,'সাঁইত্রিশ':37,'সাইত্রিশ':37,'আটত্রিশ':38,'ঊনচল্লিশ':39,
    'চল্লিশ':40,'একচল্লিশ':41,'বিয়াল্লিশ':42,'বিয়াল্লিশ':42,'তেতাল্লিশ':43,'চুয়াল্লিশ':44,'পঁয়তাল্লিশ':45,'ছেচল্লিশ':46,'সাতচল্লিশ':47,'আটচল্লিশ':48,'ঊনপঞ্চাশ':49,
    'পঞ্চাশ':50,'একান্ন':51,'বাহান্ন':52,'তিপ্পান্ন':53,'চুয়ান্ন':54,'পঞ্চান্ন':55,'ছাপ্পান্ন':56,'সাতান্ন':57,'আটান্ন':58,'ঊনষাট':59,
    'ষাট':60,'একষট্টি':61,'বাষট্টি':62,'তেষট্টি':63,'চৌষট্টি':64,'পঁয়ষট্টি':65,'ছেষট্টি':66,'সাতষট্টি':67,'আটষট্টি':68,'ঊনসত্তর':69,
    'সত্তর':70,'একাত্তর':71,'বাহাত্তর':72,'তিয়াত্তর':73,'চুয়াত্তর':74,'পঁচাত্তর':75,'ছিয়াত্তর':76,'সাতাত্তর':77,'আটাত্তর':78,'ঊনআশি':79,
    'আশি':80,'একাশি':81,'বিরাশি':82,'তিরাশি':83,'চুরাশি':84,'পঁচাশি':85,'ছিয়াশি':86,'সাতাশি':87,'আটাশি':88,'ঊননব্বই':89,
    'নব্বই':90,'একানব্বই':91,'বিরানব্বই':92,'তিরানব্বই':93,'চুরানব্বই':94,'পঁচানব্বই':95,'ছিয়ানব্বই':96,'সাতানব্বই':97,'আটানব্বই':98,'নিরানব্বই':99,
    'একশ':100,'একশো':100
  };

  function _qrNormNumberText(text){
    return _qrBdDigitsToAscii(String(text || '').toLowerCase())
      .replace(/[,:;()\[\]{}]/g,' ')
      .replace(/\s+/g,' ')
      .trim();
  }

  function _qrParseBanglaEnglishNumberPhrase(phrase){
    const raw = _qrNormNumberText(phrase);
    if(!raw) return null;
    if(/^\d{1,3}$/.test(raw)) return parseInt(raw,10);
    if(_qrCompoundBangla[raw] != null) return _qrCompoundBangla[raw];
    const tokens = raw.split(/\s+/).filter(Boolean);
    if(tokens.length === 1 && _qrSmallNumMap[tokens[0]] != null) return _qrSmallNumMap[tokens[0]];

    let total = 0, current = 0, hit = false;
    for(const t of tokens){
      if(/^\d+$/.test(t)) { current += parseInt(t,10); hit = true; continue; }
      if(_qrCompoundBangla[t] != null){ current += _qrCompoundBangla[t]; hit = true; continue; }
      const v = _qrSmallNumMap[t];
      if(v == null) continue;
      hit = true;
      if(v === 100){ current = Math.max(1, current) * 100; }
      else current += v;
    }
    total += current;
    return hit ? total : null;
  }

  function _qrExtractAyahPhrase(text){
    const raw = _qrNormNumberText(text);
    if(!raw) return '';
    const m = raw.match(/(?:ayah|ayat|verse|আয়াত|আয়াত)\s+([^\n]+)/i);
    if(m) return m[1].trim();
    return raw;
  }

  window._qrFindAyahNumber = function(text){
    const raw = _qrNormNumberText(text);
    let m = raw.match(/\b(?:ayah|ayat|verse|আয়াত|আয়াত)\s*(\d{1,3})\b/i);
    if(m) return parseInt(m[1],10);
    m = raw.match(/\b(\d{1,3})\b/);
    if(m) return parseInt(m[1],10);

    const phrase = _qrExtractAyahPhrase(raw);
    const candidates = [];
    if(phrase) {
      const parts = phrase.split(/\s+/);
      for(let len = Math.min(4, parts.length); len >= 1; len--){
        const chunk = parts.slice(0, len).join(' ');
        const n = _qrParseBanglaEnglishNumberPhrase(chunk);
        if(Number.isInteger(n)) candidates.push(n);
      }
    }
    const full = _qrParseBanglaEnglishNumberPhrase(raw);
    if(Number.isInteger(full)) candidates.push(full);
    const valid = candidates.find(n => n >= 1 && n <= 286);
    return Number.isInteger(valid) ? valid : null;
  };

  window._qrParseAyahRef = function(term){
    const clean = _qrNormNumberText(term);
    let m = clean.match(/^(\d{1,3})\s*[:.]\s*(\d{1,3})$/);
    if(m) return {surah:+m[1], ayah:+m[2]};
    m = clean.match(/^(?:surah\s*)?(\d{1,3})\s+(?:ayah\s*|ayat\s*|verse\s*|আয়াত\s*|আয়াত\s*)(.+)$/i);
    if(m){
      const ay = _qrFindAyahNumber(m[2]);
      if(ay) return {surah:+m[1], ayah:ay};
    }
    m = clean.match(/^(.*?)[,\s]+(?:ayah\s*|ayat\s*|verse\s*|আয়াত\s*|আয়াত\s*)(.+)$/i);
    if(m){
      const surahTerm = (m[1] || '').trim();
      const ayah = _qrFindAyahNumber(m[2]);
      const s = SURAHS.find(x => x.en.toLowerCase().includes(surahTerm.toLowerCase()) || x.ar.includes(surahTerm));
      if(s && ayah) return {surah:s.n, ayah};
    }
    return null;
  };

  function _qrUniqueTokens(tokens){ return Array.from(new Set((tokens || []).map(x => String(x || '').trim()).filter(Boolean))); }

  function _qrHighlightAyahText(text, query, item){
    const src = String(text || '');
    if(!src) return '';
    const q = String(query || '').trim();
    let marks = [];
    const rawTokens = _qrUniqueTokens([
      ..._qrAyahSearchTokens(q).filter(t => t.length > 1),
      ..._qrTokenizeArabic(q).filter(t => t.length > 1)
    ]).slice(0, 8);
    rawTokens.forEach(tok => {
      const re = new RegExp('(' + _qrEscRe(tok) + ')', 'giu');
      marks.push({re, cls:'qr-match-hl'});
    });
    const soundTokens = _qrUniqueTokens((item?.matchedTokens || []).filter(t => t.length > 1)).slice(0,6);
    soundTokens.forEach(tok => {
      const re = new RegExp('(' + _qrEscRe(tok) + ')', 'giu');
      marks.push({re, cls:'qr-match-hl-2'});
    });
    let out = _qrEscHtml(src);
    marks.forEach(({re, cls}) => {
      out = out.replace(re, `<mark class="${cls}">$1</mark>`);
    });
    return out;
  }

  function _qrNearbyAyahs(corpus, surah, ayah, span){
    const n = span || 2;
    return (corpus || []).filter(x => x.surah === surah && x.ayah >= ayah - n && x.ayah <= ayah + n && x.ayah !== ayah)
      .sort((a,b) => a.ayah - b.ayah)
      .map(x => ({ surah:x.surah, ayah:x.ayah, ar:x.ar || '', bn:x.bn || '' }));
  }

  const _origScoreTyped = window._qrScoreTypedAyahQuery;
  window._qrScoreTypedAyahQuery = function(term, item){
    const meta = _origScoreTyped ? _origScoreTyped(term, item) : null;
    if(!meta || meta.score < 0) return meta;
    const qTokens = _qrAyahSearchTokens(term || '');
    const bnTokens = _qrAyahSearchTokens(item?.bn || '');
    const enTokens = _qrAyahSearchTokens(item?.en || '');
    const arTokens = _qrTokenizeArabic(item?.ar || '');
    const matchedTokens = _qrUniqueTokens([
      ...qTokens.filter(t => bnTokens.includes(t) || enTokens.includes(t) || arTokens.includes(t)),
      ...((meta.matchedWords || []).filter(w => !/text|phrase|match|reference/i.test(w)))
    ]).slice(0, 6);
    return {...meta, matchedTokens};
  };

  window._qrRunTypedAyahSearch = async function(term){
    const ref = _qrParseAyahRef(term);
    if(ref){
      _qrRenderTypedAyahResults([{surah: ref.surah, ayah: ref.ayah, ar: '', bn: 'Direct surah:ayah reference', score: 9999, matchedWords:['Direct reference'], matchedTokens:[]}], {label:'Direct reference', query: term});
      return;
    }
    _qrShowTextSearchStatus('Searching ayah text across the Quran… first time may take a little longer while the Quran cache loads.', 'loading');
    let corpus = [];
    try { corpus = await _qrEnsureFullReciteCorpus(); } catch(e) {}
    if(!Array.isArray(corpus) || !corpus.length){
      _qrShowTextSearchStatus('Could not load the full Quran text right now. Please try again.', 'error');
      return;
    }
    const scored = corpus.map(item => {
      const meta = _qrScoreTypedAyahQuery(term, item);
      return meta ? ({...item, ...meta}) : null;
    }).filter(Boolean).filter(x => x.score > 120).sort((a,b) => b.score - a.score).slice(0,5)
      .map(item => ({...item, nearby: _qrNearbyAyahs(corpus, item.surah, item.ayah, 2)}));
    _qrRenderTypedAyahResults(scored, {label:'Best matches', query: term});
  };

  window._qrRenderTypedAyahResults = function(items, meta = {}){
    const {results, list, hint} = _qrTypedSearchEls();
    if(!results) return;
    if(!items || !items.length){
      results.style.display = '';
      results.innerHTML = `<div style="padding:10px 12px;border-radius:12px;border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.04);color:var(--t2);font-size:.66rem;line-height:1.6">No ayah match found. Try more words, Arabic text, Bangla translation words, or a direct reference like 2:255.</div>`;
      if(list) list.style.display = '';
      if(hint) hint.textContent = 'Ayah search supports direct reference (2:255), Arabic ayah text, or Bangla/English translation words.';
      return;
    }
    const top = items[0].score || 1;
    results.style.display = '';
    results.innerHTML = `
      <style>
        .qr-match-hl,.qr-match-hl-2{padding:.02em .22em;border-radius:.36em;color:#f7fff9;background:rgba(var(--teal-rgb),.24);box-shadow:inset 0 0 0 1px rgba(var(--teal-rgb),.22)}
        .qr-match-hl-2{background:rgba(var(--accent-rgb),.22);box-shadow:inset 0 0 0 1px rgba(var(--accent-rgb),.22)}
        .qr-nearby-chip{padding:6px 9px;border-radius:999px;border:1px solid rgba(255,255,255,.09);background:rgba(255,255,255,.04);color:var(--t2);font-size:.58rem;cursor:pointer;-webkit-tap-highlight-color:transparent;white-space:nowrap}
        .qr-nearby-chip:hover{border-color:rgba(var(--teal-rgb),.24);color:var(--teal)}
      
/* Dhikr section refinement */
.dhikr-shell{padding:16px 16px 14px;border-radius:26px;display:flex;flex-direction:column;gap:12px}
.dhikr-shell .sec-lbl{padding:0 !important;margin:0 !important}
#dhikr-card{display:flex;flex-direction:column;gap:10px}
.dhikr-tabs{display:flex !important;flex-wrap:nowrap !important;overflow-x:auto !important;overflow-y:hidden !important;gap:10px !important;padding:0 0 2px !important;margin:0 !important;-webkit-overflow-scrolling:touch;scrollbar-width:none}
.dhikr-tabs::-webkit-scrollbar{display:none}
.dhikr-tab{flex:0 0 auto;white-space:nowrap}
.dhikr-main-card{margin-top:2px}
</style>
      <div style="padding:10px 12px;border-radius:14px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07)">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:8px">
          <div style="font-size:.64rem;color:var(--t3);letter-spacing:.08em;text-transform:uppercase">Ayah search results</div>
          <div style="font-size:.58rem;color:var(--t3)">${_qrEscHtml(meta.label || '')}</div>
        </div>
        <div style="display:grid;gap:10px">
          ${items.map(item => {
            const s = SURAHS.find(x => x.n === item.surah);
            const conf = _qrVoiceConfidence(item.score, top);
            const matched = (item.matchedWords || []).join(' · ') || 'Closest ayah match';
            const arPreview = item.ar ? _qrHighlightAyahText(item.ar, meta.query || '', item) : '';
            const bnPreview = item.bn ? _qrHighlightAyahText(item.bn, meta.query || '', item) : '';
            const nearby = (item.nearby || []).slice(0,4);
            return `
              <div style="padding:11px 12px;border-radius:14px;border:1px solid rgba(var(--accent-rgb),.18);background:rgba(var(--accent-rgb),.06)">
                <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px">
                  <div style="min-width:0">
                    <div style="font-size:.74rem;font-weight:700;color:var(--gold)">${_qrEscHtml(s?.en || ('Surah ' + item.surah))} · Ayah ${item.ayah}</div>
                    <div style="font-size:.58rem;color:var(--teal);margin-top:4px">Confidence ${conf}% · ${_qrEscHtml(matched)}</div>
                  </div>
                  <div style="font-size:.62rem;color:var(--text);padding:5px 8px;border-radius:999px;background:rgba(var(--teal-rgb),.12);border:1px solid rgba(var(--teal-rgb),.18);white-space:nowrap">${conf}%</div>
                </div>
                ${arPreview ? `<div style="margin-top:8px;font-size:.86rem;line-height:2;color:var(--text);direction:rtl;text-align:right;font-family:'Noto Naskh Arabic','Scheherazade New','Amiri',serif">${arPreview}</div>` : ''}
                ${bnPreview ? `<div style="margin-top:6px;font-size:.64rem;color:var(--t2);line-height:1.75">${bnPreview}</div>` : ''}
                ${item.matchedTokens?.length ? `<div style="margin-top:7px;font-size:.56rem;color:var(--t3)">Matched words: ${_qrEscHtml(item.matchedTokens.join(' · '))}</div>` : ''}
                ${nearby.length ? `<div style="margin-top:9px">
                  <div style="font-size:.56rem;color:var(--t3);margin-bottom:6px">Nearby ayahs from the same surah</div>
                  <div style="display:flex;gap:6px;overflow:auto hidden;padding-bottom:2px">${nearby.map(n => `<button class="qr-nearby-chip" onclick="qrOpenVoiceMatch(${n.surah},${n.ayah})">Ayah ${n.ayah}</button>`).join('')}</div>
                </div>` : ''}
                <div style="display:flex;gap:8px;margin-top:10px">
                  <button onclick="qrOpenVoiceMatch(${item.surah},${item.ayah})" style="flex:1;text-align:center;padding:10px 12px;border-radius:12px;border:1px solid rgba(var(--teal-rgb),.22);background:rgba(var(--teal-rgb),.09);color:var(--teal);cursor:pointer;-webkit-tap-highlight-color:transparent;font-weight:700">Open ayah</button>
                </div>
              </div>`;
          }).join('')}
        </div>
      </div>`;
    if(list) list.style.display = 'none';
    if(hint) hint.textContent = 'Ayah text search is active. Matched words are highlighted, and nearby ayahs from the same surah are suggested below each result.';
  };
})();
