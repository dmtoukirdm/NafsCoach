
/* Magic Indicator — init nb-near on first load */
(function initMagicNav(){
  var btns = Array.from(document.querySelectorAll('.nb'));
  var active = btns.findIndex(b => b.classList.contains('active'));
  btns.forEach(b => b.classList.remove('nb-near'));
  if(active > 0) btns[active-1].classList.add('nb-near');
  if(active < btns.length-1) btns[active+1].classList.add('nb-near');
})();
